// Dashboard JavaScript functionality

let statusChart = null;

function initializeDashboard(stats) {
    // Update statistics display
    updateStats(stats);
    
    // Initialize charts
    initializeCharts(stats);
    
    // Auto-refresh every 30 seconds
    setInterval(refreshStats, 30000);
}

function updateStats(stats) {
    document.getElementById('total-memories').textContent = stats.total_memories || 0;
    document.getElementById('active-memories').textContent = stats.active_memories || 0;
    document.getElementById('total-feedbacks').textContent = stats.total_feedbacks || 0;
    document.getElementById('agents').textContent = stats.agents || 0;
    document.getElementById('archived-memories').textContent = stats.archived_memories || 0;
    document.getElementById('error-memories').textContent = stats.error_memories || 0;
    document.getElementById('total-searches').textContent = stats.total_searches || 0;
    document.getElementById('agent-types').textContent = stats.agent_types || 0;
    document.getElementById('unique-agents').textContent = stats.agents || 0;
    document.getElementById('total-vectors').textContent = stats.total_vectors || 0;
    document.getElementById('vector-dimension').textContent = stats.dimension || 'N/A';
    
    // Update vector status
    const statusElement = document.getElementById('vector-status');
    const status = stats.status || 'unknown';
    statusElement.textContent = status;
    statusElement.className = `badge bg-${status === 'available' ? 'success' : 'danger'}`;
}

function initializeCharts(stats) {
    // Status Distribution Chart
    const statusCtx = document.getElementById('statusChart').getContext('2d');
    
    const statusData = {
        labels: ['Active', 'Archived', 'Error'],
        datasets: [{
            data: [
                stats.active_memories || 0,
                stats.archived_memories || 0,
                stats.error_memories || 0
            ],
            backgroundColor: [
                'rgba(25, 135, 84, 0.8)',   // Success green
                'rgba(255, 193, 7, 0.8)',   // Warning yellow
                'rgba(220, 53, 69, 0.8)'    // Danger red
            ],
            borderColor: [
                'rgba(25, 135, 84, 1)',
                'rgba(255, 193, 7, 1)',
                'rgba(220, 53, 69, 1)'
            ],
            borderWidth: 1
        }]
    };
    
    if (statusChart) {
        statusChart.destroy();
    }
    
    statusChart = new Chart(statusCtx, {
        type: 'doughnut',
        data: statusData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

function refreshStats() {
    fetch('/internal/stats')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateStats(data.stats);
                initializeCharts(data.stats);
                console.log('Stats refreshed successfully');
            } else {
                console.error('Failed to refresh stats:', data.error);
            }
        })
        .catch(error => {
            console.error('Error refreshing stats:', error);
        });
}

// Utility functions
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Add click handlers for refresh buttons
    const refreshButtons = document.querySelectorAll('[onclick="refreshStats()"]');
    refreshButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Add loading state
            const icon = this.querySelector('i');
            icon.classList.add('rotating');
            
            setTimeout(() => {
                icon.classList.remove('rotating');
            }, 1000);
        });
    });
});

// Add CSS animation for rotating icon
const style = document.createElement('style');
style.textContent = `
    .rotating {
        animation: rotate 1s linear infinite;
    }
    
    @keyframes rotate {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
`;
document.head.appendChild(style);
