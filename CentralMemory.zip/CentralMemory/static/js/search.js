// Search page JavaScript functionality

document.addEventListener('DOMContentLoaded', function() {
    // Initialize search form
    document.getElementById('search-form').addEventListener('submit', performSearch);
    
    // Auto-search on query change (with debounce)
    let searchTimeout;
    document.getElementById('search-query').addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(performSearch, 500);
    });
});

function performSearch(event) {
    if (event) {
        event.preventDefault();
    }
    
    const query = document.getElementById('search-query').value.trim();
    if (!query) {
        hideSearchResults();
        return;
    }
    
    // Collect search parameters
    const searchParams = {
        query: query,
        search_type: document.getElementById('search-type').value,
        limit: parseInt(document.getElementById('limit-filter').value),
        filters: {}
    };
    
    // Add filters
    const agentId = document.getElementById('agent-filter').value.trim();
    if (agentId) {
        searchParams.filters.agent_id = agentId;
    }
    
    const agentType = document.getElementById('agent-type-filter').value.trim();
    if (agentType) {
        searchParams.filters.agent_type = agentType;
    }
    
    const status = document.getElementById('status-filter').value;
    if (status) {
        searchParams.filters.status = status;
    }
    
    const tags = document.getElementById('tags-filter').value.trim();
    if (tags) {
        searchParams.filters.tags = tags.split(',').map(tag => tag.trim()).filter(tag => tag);
    }
    
    // Show loading state
    showLoading();
    hideError();
    
    // Perform search
    fetch('/internal/search', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(searchParams)
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        
        if (data.success) {
            displaySearchResults(data.results, data.total, searchParams);
        } else {
            showError(data.error || 'Search failed');
        }
    })
    .catch(error => {
        hideLoading();
        showError('Network error occurred');
        console.error('Search error:', error);
    });
}

function displaySearchResults(results, total, searchParams) {
    if (results.length === 0) {
        showNoResults();
        return;
    }
    
    const resultsContainer = document.getElementById('results-container');
    resultsContainer.innerHTML = '';
    
    // Update results info
    document.getElementById('results-info').innerHTML = `
        Found ${total} result(s) for "${searchParams.query}" 
        <span class="badge bg-secondary">${searchParams.search_type}</span>
    `;
    
    // Display results
    results.forEach(result => {
        const resultElement = createResultElement(result);
        resultsContainer.appendChild(resultElement);
    });
    
    // Show results container
    document.getElementById('search-results').style.display = 'block';
    document.getElementById('no-results').style.display = 'none';
    
    // Replace feather icons
    feather.replace();
}

function createResultElement(result) {
    const memory = result.memory;
    const score = result.relevance_score;
    
    const resultDiv = document.createElement('div');
    resultDiv.className = 'mb-3 p-3 border rounded search-result';
    
    resultDiv.innerHTML = `
        <div class="d-flex justify-content-between align-items-start">
            <div class="flex-grow-1">
                <h6 class="mb-2">
                    <span class="badge bg-primary me-2">${memory.agent_type}</span>
                    ${memory.agent_id}
                    <span class="relevance-score text-muted ms-2">
                        Score: ${score.toFixed(3)}
                    </span>
                </h6>
                <div class="mb-2">
                    <strong>Prompt:</strong>
                    <p class="mb-1">${truncateText(memory.prompt, 200)}</p>
                </div>
                <div class="mb-2">
                    <strong>Response:</strong>
                    <p class="mb-1">${truncateText(memory.response, 200)}</p>
                </div>
            </div>
            <div class="text-end">
                <span class="badge bg-${getStatusColor(memory.status)}">${memory.status}</span>
            </div>
        </div>
        
        <div class="row mt-3">
            <div class="col-md-6">
                <small class="text-muted">
                    <i data-feather="clock"></i>
                    ${formatDate(memory.created_at)}
                </small>
            </div>
            <div class="col-md-6 text-end">
                <small class="text-muted">
                    Quality: ${memory.quality_score.toFixed(2)}
                    | Feedbacks: ${memory.feedback_count}
                </small>
            </div>
        </div>
        
        ${memory.tags && memory.tags.length > 0 ? `
        <div class="mt-2">
            ${memory.tags.map(tag => `<span class="badge bg-secondary me-1">${tag}</span>`).join('')}
        </div>
        ` : ''}
        
        <div class="mt-3">
            <button type="button" class="btn btn-sm btn-outline-primary" 
                    onclick="viewMemory(${memory.id})">
                <i data-feather="eye"></i>
                View Details
            </button>
        </div>
    `;
    
    return resultDiv;
}

function clearSearch() {
    document.getElementById('search-form').reset();
    hideSearchResults();
    hideError();
}

function showLoading() {
    document.getElementById('search-loading').classList.remove('d-none');
    document.getElementById('search-loading').classList.add('d-flex');
}

function hideLoading() {
    document.getElementById('search-loading').classList.add('d-none');
    document.getElementById('search-loading').classList.remove('d-flex');
}

function showError(message) {
    document.getElementById('error-message').textContent = message;
    document.getElementById('search-error').style.display = 'block';
    feather.replace();
}

function hideError() {
    document.getElementById('search-error').style.display = 'none';
}

function showNoResults() {
    document.getElementById('no-results').style.display = 'block';
    document.getElementById('search-results').style.display = 'none';
    feather.replace();
}

function hideSearchResults() {
    document.getElementById('search-results').style.display = 'none';
    document.getElementById('no-results').style.display = 'none';
}

function viewMemory(memoryId) {
    window.location.href = `/memories/${memoryId}`;
}

// Utility functions
function truncateText(text, maxLength) {
    if (text.length <= maxLength) {
        return text;
    }
    return text.substring(0, maxLength) + '...';
}

function getStatusColor(status) {
    switch (status) {
        case 'active': return 'success';
        case 'archived': return 'warning';
        case 'error': return 'danger';
        default: return 'secondary';
    }
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
}

// Add keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl/Cmd + K to focus search
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        document.getElementById('search-query').focus();
    }
    
    // Escape to clear search
    if (e.key === 'Escape') {
        clearSearch();
    }
});
