// Memories page JavaScript functionality

let currentFilter = 'all';
let agentList = [];

document.addEventListener('DOMContentLoaded', function() {
    // Load agent list for filter
    loadAgentList();
    
    // Initialize search
    document.getElementById('memory-search').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            searchMemories();
        }
    });
});

function loadAgentList() {
    // Extract unique agents from current memories
    const memoryItems = document.querySelectorAll('.memory-item');
    const agents = new Set();
    
    memoryItems.forEach(item => {
        const agentId = item.dataset.agent;
        if (agentId) {
            agents.add(agentId);
        }
    });
    
    // Populate agent filter
    const agentFilter = document.getElementById('agent-filter');
    agentFilter.innerHTML = '<option value="">All Agents</option>';
    
    agents.forEach(agent => {
        const option = document.createElement('option');
        option.value = agent;
        option.textContent = agent;
        agentFilter.appendChild(option);
    });
}

function filterMemories(status) {
    currentFilter = status;
    const memoryItems = document.querySelectorAll('.memory-item');
    
    memoryItems.forEach(item => {
        const itemStatus = item.dataset.status;
        if (status === 'all' || itemStatus === status) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
    
    // Update active button
    document.querySelectorAll('.btn-group button').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
}

function filterByAgent() {
    const selectedAgent = document.getElementById('agent-filter').value;
    const memoryItems = document.querySelectorAll('.memory-item');
    
    memoryItems.forEach(item => {
        const itemAgent = item.dataset.agent;
        const itemStatus = item.dataset.status;
        
        const statusMatch = currentFilter === 'all' || itemStatus === currentFilter;
        const agentMatch = !selectedAgent || itemAgent === selectedAgent;
        
        if (statusMatch && agentMatch) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

function searchMemories() {
    const query = document.getElementById('memory-search').value.trim();
    if (!query) {
        // Reset to current filter
        filterMemories(currentFilter);
        return;
    }
    
    const memoryItems = document.querySelectorAll('.memory-item');
    
    memoryItems.forEach(item => {
        const prompt = item.querySelector('.card-text').textContent.toLowerCase();
        const agent = item.dataset.agent.toLowerCase();
        const searchQuery = query.toLowerCase();
        
        const matches = prompt.includes(searchQuery) || agent.includes(searchQuery);
        const statusMatch = currentFilter === 'all' || item.dataset.status === currentFilter;
        
        if (matches && statusMatch) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

function viewMemory(memoryId) {
    window.location.href = `/memories/${memoryId}`;
}

function archiveMemory(memoryId) {
    if (!confirm('Are you sure you want to archive this memory?')) {
        return;
    }
    
    showLoading();
    
    fetch(`/memories/${memoryId}/archive`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        
        if (data.success) {
            showAlert('Memory archived successfully', 'success');
            // Update the memory item
            const memoryItem = document.querySelector(`[data-memory-id="${memoryId}"]`);
            if (memoryItem) {
                memoryItem.dataset.status = 'archived';
                // Update badge and button
                const badge = memoryItem.querySelector('.badge');
                badge.textContent = 'archived';
                badge.className = 'badge bg-warning';
                
                const archiveBtn = memoryItem.querySelector('[onclick*="archiveMemory"]');
                if (archiveBtn) {
                    archiveBtn.outerHTML = `
                        <button type="button" class="btn btn-sm btn-outline-success" 
                                onclick="restoreMemory(${memoryId})">
                            <i data-feather="refresh-cw"></i>
                            Restore
                        </button>
                    `;
                    feather.replace();
                }
            }
        } else {
            showAlert(data.error || 'Failed to archive memory', 'danger');
        }
    })
    .catch(error => {
        hideLoading();
        showAlert('Error archiving memory', 'danger');
        console.error('Error:', error);
    });
}

function restoreMemory(memoryId) {
    if (!confirm('Are you sure you want to restore this memory?')) {
        return;
    }
    
    showLoading();
    
    fetch(`/memories/${memoryId}/restore`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        
        if (data.success) {
            showAlert('Memory restored successfully', 'success');
            // Update the memory item
            const memoryItem = document.querySelector(`[data-memory-id="${memoryId}"]`);
            if (memoryItem) {
                memoryItem.dataset.status = 'active';
                // Update badge and button
                const badge = memoryItem.querySelector('.badge');
                badge.textContent = 'active';
                badge.className = 'badge bg-success';
                
                const restoreBtn = memoryItem.querySelector('[onclick*="restoreMemory"]');
                if (restoreBtn) {
                    restoreBtn.outerHTML = `
                        <button type="button" class="btn btn-sm btn-outline-warning" 
                                onclick="archiveMemory(${memoryId})">
                            <i data-feather="archive"></i>
                            Archive
                        </button>
                    `;
                    feather.replace();
                }
            }
        } else {
            showAlert(data.error || 'Failed to restore memory', 'danger');
        }
    })
    .catch(error => {
        hideLoading();
        showAlert('Error restoring memory', 'danger');
        console.error('Error:', error);
    });
}

function showLoading() {
    document.getElementById('loading-spinner').classList.remove('d-none');
    document.getElementById('loading-spinner').classList.add('d-flex');
}

function hideLoading() {
    document.getElementById('loading-spinner').classList.add('d-none');
    document.getElementById('loading-spinner').classList.remove('d-flex');
}

function showAlert(message, type) {
    // Create alert element
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.setAttribute('role', 'alert');
    alert.innerHTML = `
        <i data-feather="${type === 'success' ? 'check-circle' : 'alert-circle'}"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Insert at the top of the container
    const container = document.querySelector('.container-fluid');
    container.insertBefore(alert, container.firstChild);
    
    // Replace feather icons
    feather.replace();
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (alert.parentNode) {
            alert.remove();
        }
    }, 5000);
}

// Add data attribute for memory IDs
document.addEventListener('DOMContentLoaded', function() {
    const memoryItems = document.querySelectorAll('.memory-item');
    memoryItems.forEach(item => {
        // Extract memory ID from the archive/restore button onclick
        const archiveBtn = item.querySelector('[onclick*="archiveMemory"], [onclick*="restoreMemory"]');
        if (archiveBtn) {
            const onclick = archiveBtn.getAttribute('onclick');
            const memoryId = onclick.match(/\d+/)[0];
            item.dataset.memoryId = memoryId;
        }
    });
});
