import os
import secrets
import hashlib
from datetime import datetime, timedelta
from functools import wraps
from flask import request, jsonify
from app import db
from sqlalchemy import String, DateTime, Boolean, Integer, Text
from models import Memory

class APIKey(db.Model):
    """API Key model for authentication"""
    __tablename__ = 'api_keys'
    
    id = db.Column(Integer, primary_key=True)
    name = db.Column(String(100), nullable=False)
    key_hash = db.Column(String(64), unique=True, nullable=False)
    key_prefix = db.Column(String(20), nullable=False)
    
    # Permissions
    can_read = db.Column(Boolean, default=True)
    can_write = db.Column(Boolean, default=True)
    can_delete = db.Column(Boolean, default=False)
    
    # Usage tracking
    usage_count = db.Column(Integer, default=0)
    last_used = db.Column(DateTime)
    
    # Status
    is_active = db.Column(Boolean, default=True)
    created_at = db.Column(DateTime, default=datetime.utcnow)
    expires_at = db.Column(DateTime)
    
    # Metadata
    description = db.Column(Text)
    created_by = db.Column(String(100))
    
    def check_key(self, raw_key):
        """Check if the provided key matches"""
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
        return self.key_hash == key_hash
    
    def is_valid(self):
        """Check if the key is valid and not expired"""
        if not self.is_active:
            return False
        
        if self.expires_at and self.expires_at < datetime.utcnow():
            return False
        
        return True
    
    def update_usage(self):
        """Update usage statistics"""
        self.usage_count += 1
        self.last_used = datetime.utcnow()
        db.session.commit()
    
    def to_dict(self):
        """Convert to dictionary (without sensitive data)"""
        return {
            'id': self.id,
            'name': self.name,
            'key_prefix': self.key_prefix,
            'can_read': self.can_read,
            'can_write': self.can_write,
            'can_delete': self.can_delete,
            'usage_count': self.usage_count,
            'last_used': self.last_used.isoformat() if self.last_used else None,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat(),
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'description': self.description
        }

def generate_api_key():
    """Generate a new API key"""
    # Generate a secure random key
    key = f"mk_{secrets.token_urlsafe(32)}"
    return key

def create_api_key(name, description=None, expires_days=None, permissions=None):
    """Create a new API key"""
    if permissions is None:
        permissions = {'can_read': True, 'can_write': True, 'can_delete': False}
    
    # Generate key
    raw_key = generate_api_key()
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    key_prefix = raw_key[:8] + "..."
    
    # Set expiration
    expires_at = None
    if expires_days:
        expires_at = datetime.utcnow() + timedelta(days=expires_days)
    
    # Create key record
    api_key = APIKey(
        name=name,
        key_hash=key_hash,
        key_prefix=key_prefix,
        can_read=permissions.get('can_read', True),
        can_write=permissions.get('can_write', True),
        can_delete=permissions.get('can_delete', False),
        expires_at=expires_at,
        description=description
    )
    
    db.session.add(api_key)
    db.session.commit()
    
    return raw_key, api_key

def require_api_key(permission='read'):
    """Decorator to require API key authentication"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Get API key from header
            auth_header = request.headers.get('Authorization')
            if not auth_header:
                return jsonify({'error': 'API key required'}), 401
            
            # Extract key from "Bearer <key>" format
            try:
                if auth_header.startswith('Bearer '):
                    raw_key = auth_header[7:]
                else:
                    raw_key = auth_header
            except:
                return jsonify({'error': 'Invalid API key format'}), 401
            
            # Find and validate key
            key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
            api_key = APIKey.query.filter_by(key_hash=key_hash).first()
            
            if not api_key:
                return jsonify({'error': 'Invalid API key'}), 401
            
            if not api_key.is_valid():
                return jsonify({'error': 'API key expired or deactivated'}), 401
            
            # Check permissions
            if permission == 'write' and not api_key.can_write:
                return jsonify({'error': 'Insufficient permissions'}), 403
            
            if permission == 'delete' and not api_key.can_delete:
                return jsonify({'error': 'Insufficient permissions'}), 403
            
            # Update usage
            api_key.update_usage()
            
            # Add key to request context
            request.api_key = api_key
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def get_api_key_info(raw_key):
    """Get API key information"""
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    api_key = APIKey.query.filter_by(key_hash=key_hash).first()
    
    if api_key:
        return api_key.to_dict()
    return None