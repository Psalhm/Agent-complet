#!/usr/bin/env python3
"""
Point d'entrée principal pour l'API FastAPI
Lance le serveur FastAPI sur le port 8000
"""
import uvicorn
from memory_api import app

if __name__ == "__main__":
    print("🚀 Lancement de l'API Memory System")
    print("📍 URL: http://localhost:8000")
    print("📚 Documentation: http://localhost:8000/docs")
    print("🔧 Redoc: http://localhost:8000/redoc")
    print("-" * 50)
    
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=8000,
        reload=True,
        log_level="info"
    )