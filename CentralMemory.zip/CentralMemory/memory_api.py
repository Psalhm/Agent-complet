from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime
import json
import sys
import os

# Add the current directory to path to import existing modules
sys.path.append(os.path.dirname(__file__))

# Import sera fait dynamiquement pour éviter les imports circulaires

# FastAPI app
app = FastAPI(
    title="Memory System API",
    description="API pour interagir avec le système de mémoire d'agents IA",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models
class MemoryCreate(BaseModel):
    type: str
    content: str
    context: Optional[Dict[str, Any]] = None
    tags: Optional[List[str]] = None

class MemoryEntry(BaseModel):
    id: int
    type: str
    content: str
    timestamp: datetime
    context: Optional[Dict[str, Any]] = None
    tags: Optional[List[str]] = None
    agent_id: str
    agent_type: str
    quality_score: float
    relevance_score: float

class ApiResponse(BaseModel):
    success: bool
    message: str
    data: Optional[Any] = None

@app.get("/")
async def root():
    """Root endpoint"""
    return {"message": "Memory System API - Ready"}

@app.post("/memory/{agent_id}", response_model=ApiResponse)
async def add_memory(agent_id: str, memory: MemoryCreate):
    """
    Ajoute une entrée mémoire pour un agent
    
    Args:
        agent_id: ID de l'agent
        memory: Données de la mémoire (type, content, context, tags)
    """
    try:
        # Parse content based on type
        if memory.type == "conversation":
            # For conversation type, expect content to be JSON with prompt/response
            try:
                content_data = json.loads(memory.content)
                prompt = content_data.get("prompt", "")
                response = content_data.get("response", "")
            except json.JSONDecodeError:
                # If not JSON, treat as simple text
                prompt = memory.content
                response = ""
        else:
            # For other types, use content as prompt
            prompt = memory.content
            response = ""
        
        # Import dynamically to avoid circular imports
        from services.memory_service import memory_service
        
        # Create memory using existing service
        new_memory = memory_service.create_memory(
            prompt=prompt,
            response=response,
            agent_id=agent_id,
            agent_type=memory.type,
            context=memory.context,
            tags=memory.tags
        )
        
        if new_memory:
            return ApiResponse(
                success=True,
                message="Memory added successfully",
                data={
                    "id": new_memory.id,
                    "timestamp": new_memory.created_at.isoformat()
                }
            )
        else:
            raise HTTPException(status_code=500, detail="Failed to create memory")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error adding memory: {str(e)}")

@app.get("/memory/{agent_id}", response_model=ApiResponse)
async def get_agent_memory(agent_id: str, limit: int = 50):
    """
    Retourne toute la mémoire d'un agent
    
    Args:
        agent_id: ID de l'agent
        limit: Nombre maximum d'entrées à retourner
    """
    try:
        from models import Memory
        from app import db
        
        # Get all memories for this agent
        memories = Memory.query.filter_by(agent_id=agent_id, status='active')\
                              .order_by(Memory.created_at.desc())\
                              .limit(limit)\
                              .all()
        
        # Convert to response format
        memory_list = []
        for mem in memories:
            memory_list.append({
                "id": mem.id,
                "type": mem.agent_type,
                "content": mem.prompt if mem.response else mem.prompt,
                "response": mem.response if mem.response else None,
                "timestamp": mem.created_at.isoformat(),
                "context": mem.context,
                "tags": mem.tags,
                "agent_id": mem.agent_id,
                "agent_type": mem.agent_type,
                "quality_score": mem.quality_score,
                "relevance_score": mem.relevance_score
            })
        
        return ApiResponse(
            success=True,
            message=f"Retrieved {len(memory_list)} memories for agent {agent_id}",
            data={
                "memories": memory_list,
                "total": len(memory_list),
                "agent_id": agent_id
            }
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving memories: {str(e)}")

@app.get("/memory/{agent_id}/last", response_model=ApiResponse)
async def get_last_memory(agent_id: str):
    """
    Retourne la dernière entrée mémoire d'un agent
    
    Args:
        agent_id: ID de l'agent
    """
    try:
        from models import Memory
        from app import db
        
        # Get last memory for this agent
        last_memory = Memory.query.filter_by(agent_id=agent_id, status='active')\
                                 .order_by(Memory.created_at.desc())\
                                 .first()
        
        if not last_memory:
            return ApiResponse(
                success=False,
                message=f"No memories found for agent {agent_id}",
                data=None
            )
        
        return ApiResponse(
            success=True,
            message="Last memory retrieved successfully",
            data={
                "id": last_memory.id,
                "type": last_memory.agent_type,
                "content": last_memory.prompt,
                "response": last_memory.response,
                "timestamp": last_memory.created_at.isoformat(),
                "context": last_memory.context,
                "tags": last_memory.tags,
                "agent_id": last_memory.agent_id,
                "agent_type": last_memory.agent_type,
                "quality_score": last_memory.quality_score,
                "relevance_score": last_memory.relevance_score
            }
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving last memory: {str(e)}")

@app.delete("/memory/{agent_id}", response_model=ApiResponse)
async def delete_agent_memory(agent_id: str):
    """
    Supprime toute la mémoire d'un agent
    
    Args:
        agent_id: ID de l'agent
    """
    try:
        from models import Memory
        from app import db
        
        # Count memories to delete
        memories_count = Memory.query.filter_by(agent_id=agent_id).count()
        
        if memories_count == 0:
            return ApiResponse(
                success=False,
                message=f"No memories found for agent {agent_id}",
                data={"deleted_count": 0}
            )
        
        # Delete all memories for this agent
        Memory.query.filter_by(agent_id=agent_id).delete()
        db.session.commit()
        
        return ApiResponse(
            success=True,
            message=f"Deleted {memories_count} memories for agent {agent_id}",
            data={"deleted_count": memories_count}
        )
        
    except Exception as e:
        db.session.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting memories: {str(e)}")

@app.get("/memory/{agent_id}/stats", response_model=ApiResponse)
async def get_agent_stats(agent_id: str):
    """
    Retourne les statistiques mémoire d'un agent
    
    Args:
        agent_id: ID de l'agent
    """
    try:
        from models import Memory, Feedback
        from app import db
        from sqlalchemy import func
        
        # Get memory statistics
        total_memories = Memory.query.filter_by(agent_id=agent_id).count()
        active_memories = Memory.query.filter_by(agent_id=agent_id, status='active').count()
        archived_memories = Memory.query.filter_by(agent_id=agent_id, status='archived').count()
        
        # Get feedback statistics
        total_feedbacks = db.session.query(Feedback)\
                                   .join(Memory)\
                                   .filter(Memory.agent_id == agent_id)\
                                   .count()
        
        # Get quality score average
        avg_quality = db.session.query(func.avg(Memory.quality_score))\
                               .filter_by(agent_id=agent_id)\
                               .scalar() or 0.0
        
        # Get last activity
        last_memory = Memory.query.filter_by(agent_id=agent_id)\
                                 .order_by(Memory.created_at.desc())\
                                 .first()
        
        return ApiResponse(
            success=True,
            message="Agent statistics retrieved successfully",
            data={
                "agent_id": agent_id,
                "total_memories": total_memories,
                "active_memories": active_memories,
                "archived_memories": archived_memories,
                "total_feedbacks": total_feedbacks,
                "average_quality_score": round(avg_quality, 2),
                "last_activity": last_memory.created_at.isoformat() if last_memory else None
            }
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving stats: {str(e)}")

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)