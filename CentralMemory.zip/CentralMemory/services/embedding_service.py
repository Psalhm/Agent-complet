import logging
import hashlib
from typing import List, Dict, Any
from config import Config
from utils.logger import get_logger

logger = get_logger('embedding_service')

class EmbeddingService:
    """Service for generating text embeddings"""
    
    def __init__(self):
        self.model_name = Config.EMBEDDING_MODEL
        self.model = None
        self._load_model()
    
    def _load_model(self):
        """Load the embedding model"""
        try:
            # Try to import sentence-transformers
            from sentence_transformers import SentenceTransformer
            
            logger.info(f"Loading embedding model: {self.model_name}")
            self.model = SentenceTransformer(self.model_name)
            logger.info("Embedding model loaded successfully")
        except ImportError:
            logger.warning("sentence-transformers not installed, using fallback")
            self.model = None
        except Exception as e:
            logger.error(f"Failed to load embedding model: {str(e)}")
            self.model = None
    
    def generate_embedding(self, text: str) -> List[float]:
        """Generate embedding for a single text"""
        try:
            if not self.model:
                logger.warning("Embedding model not available, returning empty embedding")
                return [0.0] * 384  # Default dimension
            
            # Clean and normalize text
            cleaned_text = self._clean_text(text)
            
            # Generate embedding
            embedding = self.model.encode(cleaned_text)
            return embedding.tolist()
            
        except Exception as e:
            logger.error(f"Failed to generate embedding: {str(e)}")
            return [0.0] * 384
    
    def generate_embeddings(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for multiple texts"""
        try:
            if not self.model:
                logger.warning("Embedding model not available, returning empty embeddings")
                return [[0.0] * 384 for _ in texts]
            
            # Clean and normalize texts
            cleaned_texts = [self._clean_text(text) for text in texts]
            
            # Generate embeddings
            embeddings = self.model.encode(cleaned_texts)
            return [embedding.tolist() for embedding in embeddings]
            
        except Exception as e:
            logger.error(f"Failed to generate embeddings: {str(e)}")
            return [[0.0] * 384 for _ in texts]
    
    def _clean_text(self, text: str) -> str:
        """Clean and normalize text for embedding"""
        if not text:
            return ""
        
        # Remove extra whitespace and normalize
        cleaned = " ".join(text.split())
        
        # Truncate if too long (model specific limit)
        max_length = 512  # Common limit for sentence transformers
        if len(cleaned) > max_length:
            cleaned = cleaned[:max_length]
        
        return cleaned
    
    def compute_similarity(self, embedding1: List[float], embedding2: List[float]) -> float:
        """Compute cosine similarity between two embeddings"""
        try:
            if not self.model:
                return 0.0
            
            # Convert to numpy arrays if needed
            try:
                import numpy as np
                emb1 = np.array(embedding1)
                emb2 = np.array(embedding2)
                
                # Compute cosine similarity
                dot_product = np.dot(emb1, emb2)
                norm1 = np.linalg.norm(emb1)
                norm2 = np.linalg.norm(emb2)
                
                if norm1 == 0 or norm2 == 0:
                    return 0.0
                
                similarity = dot_product / (norm1 * norm2)
                return float(similarity)
            except ImportError:
                logger.warning("numpy not available for similarity computation")
                return 0.0
            
        except Exception as e:
            logger.error(f"Failed to compute similarity: {str(e)}")
            return 0.0
    
    def generate_content_hash(self, prompt: str, response: str) -> str:
        """Generate a hash for content deduplication"""
        combined_content = f"{prompt.strip()}\n{response.strip()}"
        return hashlib.sha256(combined_content.encode()).hexdigest()
    
    def combine_text_for_embedding(self, prompt: str, response: str) -> str:
        """Combine prompt and response for embedding generation"""
        return f"Prompt: {prompt}\nResponse: {response}"

# Global instance
embedding_service = EmbeddingService()
