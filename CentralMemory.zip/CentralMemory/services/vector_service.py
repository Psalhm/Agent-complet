import os
import logging
import time
from typing import List, Dict, Any, Optional
from config import Config
from utils.logger import get_logger

logger = get_logger('vector_service')

class VectorService:
    """Service for managing vector database operations"""
    
    def __init__(self):
        self.api_key = Config.PINECONE_API_KEY
        self.environment = Config.PINECONE_ENVIRONMENT
        self.index_name = Config.PINECONE_INDEX_NAME
        self.index = None
        self._initialize_pinecone()
    
    def _initialize_pinecone(self):
        """Initialize Pinecone connection"""
        try:
            # Try to import pinecone
            import pinecone
            
            pinecone.init(
                api_key=self.api_key,
                environment=self.environment
            )
            
            # Create index if it doesn't exist
            if self.index_name not in pinecone.list_indexes():
                logger.info(f"Creating new Pinecone index: {self.index_name}")
                pinecone.create_index(
                    name=self.index_name,
                    dimension=384,  # Dimension for all-MiniLM-L6-v2
                    metric="cosine"
                )
                # Wait for index to be ready
                time.sleep(10)
            
            self.index = pinecone.Index(self.index_name)
            logger.info(f"Successfully connected to Pinecone index: {self.index_name}")
            
        except ImportError:
            logger.warning("Pinecone not installed, using fallback storage")
            self.index = None
        except Exception as e:
            logger.error(f"Failed to initialize Pinecone: {str(e)}")
            # Fallback to in-memory storage for development
            self.index = None
    
    def upsert_vector(self, vector_id: str, embedding: List[float], metadata: Dict[str, Any]) -> bool:
        """Store or update a vector in the database"""
        try:
            if not self.index:
                logger.warning("Vector service not available, using fallback storage")
                return True
            
            # Prepare metadata (Pinecone has limitations on metadata)
            filtered_metadata = {
                'agent_id': metadata.get('agent_id', ''),
                'agent_type': metadata.get('agent_type', ''),
                'status': metadata.get('status', 'active'),
                'created_at': metadata.get('created_at', ''),
                'tags': str(metadata.get('tags', [])),  # Convert to string
                'quality_score': metadata.get('quality_score', 0.0)
            }
            
            self.index.upsert([(vector_id, embedding, filtered_metadata)])
            logger.info(f"Successfully upserted vector: {vector_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to upsert vector {vector_id}: {str(e)}")
            return False
    
    def search_vectors(self, query_embedding: List[float], top_k: int = 10, 
                      filter_dict: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Search for similar vectors"""
        try:
            if not self.index:
                logger.warning("Vector service not available, returning empty results")
                return []
            
            # Prepare filter
            search_filter = {}
            if filter_dict:
                if 'agent_id' in filter_dict:
                    search_filter['agent_id'] = filter_dict['agent_id']
                if 'agent_type' in filter_dict:
                    search_filter['agent_type'] = filter_dict['agent_type']
                if 'status' in filter_dict:
                    search_filter['status'] = filter_dict['status']
            
            # Perform search
            results = self.index.query(
                vector=query_embedding,
                top_k=top_k,
                include_metadata=True,
                filter=search_filter if search_filter else None
            )
            
            # Format results
            formatted_results = []
            for match in results['matches']:
                formatted_results.append({
                    'vector_id': match['id'],
                    'score': float(match['score']),
                    'metadata': match.get('metadata', {})
                })
            
            logger.info(f"Vector search returned {len(formatted_results)} results")
            return formatted_results
            
        except Exception as e:
            logger.error(f"Failed to search vectors: {str(e)}")
            return []
    
    def delete_vector(self, vector_id: str) -> bool:
        """Delete a vector from the database"""
        try:
            if not self.index:
                logger.warning("Vector service not available")
                return True
            
            self.index.delete(ids=[vector_id])
            logger.info(f"Successfully deleted vector: {vector_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to delete vector {vector_id}: {str(e)}")
            return False
    
    def get_stats(self) -> Dict[str, Any]:
        """Get statistics about the vector database"""
        try:
            if not self.index:
                return {'total_vectors': 0, 'status': 'unavailable'}
            
            stats = self.index.describe_index_stats()
            return {
                'total_vectors': stats.get('total_vector_count', 0),
                'dimension': stats.get('dimension', 0),
                'status': 'available'
            }
            
        except Exception as e:
            logger.error(f"Failed to get vector stats: {str(e)}")
            return {'total_vectors': 0, 'status': 'error'}

# Global instance
vector_service = VectorService()
