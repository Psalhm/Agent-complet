import logging
import uuid
import time
from typing import List, Dict, Any, Optional
from sqlalchemy import and_, or_, func
from app import db
from models import Memory, Feedback, SearchLog
from services.vector_service import vector_service
from services.embedding_service import embedding_service
from utils.logger import get_logger

logger = get_logger('memory_service')

class MemoryService:
    """Service for managing memory operations"""
    
    def create_memory(self, prompt: str, response: str, agent_id: str, 
                     agent_type: str, context: Optional[Dict] = None, 
                     tags: Optional[List[str]] = None) -> Optional[Memory]:
        """Create a new memory"""
        try:
            # Generate content hash for deduplication
            content_hash = embedding_service.generate_content_hash(prompt, response)
            
            # Check for existing memory with same hash
            existing_memory = Memory.query.filter_by(content_hash=content_hash).first()
            if existing_memory:
                logger.info(f"Memory with hash {content_hash} already exists")
                return existing_memory
            
            # Generate unique vector ID
            vector_id = str(uuid.uuid4())
            
            # Create memory record
            memory = Memory(
                vector_id=vector_id,
                prompt=prompt,
                response=response,
                content_hash=content_hash,
                agent_id=agent_id,
                agent_type=agent_type,
                context=context or {},
                tags=tags or [],
                status='active'
            )
            
            db.session.add(memory)
            db.session.commit()
            
            # Generate and store embedding
            combined_text = embedding_service.combine_text_for_embedding(prompt, response)
            embedding = embedding_service.generate_embedding(combined_text)
            
            # Store in vector database
            metadata = {
                'agent_id': agent_id,
                'agent_type': agent_type,
                'status': 'active',
                'created_at': memory.created_at.isoformat(),
                'tags': tags or [],
                'quality_score': 0.0
            }
            
            success = vector_service.upsert_vector(vector_id, embedding, metadata)
            if not success:
                logger.warning(f"Failed to store vector for memory {memory.id}")
            
            logger.info(f"Successfully created memory {memory.id}")
            return memory
            
        except Exception as e:
            logger.error(f"Failed to create memory: {str(e)}")
            db.session.rollback()
            return None
    
    def get_memory(self, memory_id: int) -> Optional[Memory]:
        """Get a memory by ID"""
        try:
            return Memory.query.get(memory_id)
        except Exception as e:
            logger.error(f"Failed to get memory {memory_id}: {str(e)}")
            return None
    
    def update_memory(self, memory_id: int, **kwargs) -> Optional[Memory]:
        """Update a memory"""
        try:
            memory = Memory.query.get(memory_id)
            if not memory:
                return None
            
            # Update fields
            for key, value in kwargs.items():
                if hasattr(memory, key):
                    setattr(memory, key, value)
            
            db.session.commit()
            
            # Update vector database if needed
            if any(key in kwargs for key in ['status', 'tags', 'quality_score']):
                self._update_vector_metadata(memory)
            
            logger.info(f"Successfully updated memory {memory_id}")
            return memory
            
        except Exception as e:
            logger.error(f"Failed to update memory {memory_id}: {str(e)}")
            db.session.rollback()
            return None
    
    def delete_memory(self, memory_id: int) -> bool:
        """Delete a memory"""
        try:
            memory = Memory.query.get(memory_id)
            if not memory:
                return False
            
            # Delete from vector database
            vector_service.delete_vector(memory.vector_id)
            
            # Delete from SQL database
            db.session.delete(memory)
            db.session.commit()
            
            logger.info(f"Successfully deleted memory {memory_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to delete memory {memory_id}: {str(e)}")
            db.session.rollback()
            return False
    
    def search_memories(self, query: str, search_type: str = 'hybrid', 
                       filters: Optional[Dict] = None, limit: int = 10) -> List[Dict[str, Any]]:
        """Search memories with text or semantic search"""
        try:
            start_time = time.time()
            results = []
            
            if search_type == 'text':
                results = self._text_search(query, filters, limit)
            elif search_type == 'semantic':
                results = self._semantic_search(query, filters, limit)
            elif search_type == 'hybrid':
                results = self._hybrid_search(query, filters, limit)
            
            # Log search
            response_time = time.time() - start_time
            self._log_search(query, search_type, filters, len(results), response_time)
            
            logger.info(f"Search completed: {len(results)} results in {response_time:.2f}s")
            return results
            
        except Exception as e:
            logger.error(f"Failed to search memories: {str(e)}")
            return []
    
    def _text_search(self, query: str, filters: Optional[Dict], limit: int) -> List[Dict[str, Any]]:
        """Perform text-based search"""
        query_obj = Memory.query.filter(
            or_(
                Memory.prompt.contains(query),
                Memory.response.contains(query)
            )
        )
        
        # Apply filters
        query_obj = self._apply_filters(query_obj, filters)
        
        memories = query_obj.order_by(Memory.created_at.desc()).limit(limit).all()
        
        return [self._format_search_result(memory, 0.5) for memory in memories]
    
    def _semantic_search(self, query: str, filters: Optional[Dict], limit: int) -> List[Dict[str, Any]]:
        """Perform semantic search using embeddings"""
        # Generate query embedding
        query_embedding = embedding_service.generate_embedding(query)
        
        # Search vector database
        vector_results = vector_service.search_vectors(
            query_embedding, 
            top_k=limit * 2,  # Get more results for filtering
            filter_dict=filters
        )
        
        # Get corresponding memories
        results = []
        for vector_result in vector_results:
            memory = Memory.get_by_vector_id(vector_result['vector_id'])
            if memory and self._passes_filters(memory, filters):
                results.append(self._format_search_result(memory, vector_result['score']))
        
        return results[:limit]
    
    def _hybrid_search(self, query: str, filters: Optional[Dict], limit: int) -> List[Dict[str, Any]]:
        """Perform hybrid search combining text and semantic"""
        # Get both text and semantic results
        text_results = self._text_search(query, filters, limit)
        semantic_results = self._semantic_search(query, filters, limit)
        
        # Combine and deduplicate
        combined_results = {}
        
        # Add text results with weight
        for result in text_results:
            memory_id = result['memory']['id']
            result['relevance_score'] = result['relevance_score'] * 0.3
            combined_results[memory_id] = result
        
        # Add semantic results with weight
        for result in semantic_results:
            memory_id = result['memory']['id']
            if memory_id in combined_results:
                # Combine scores
                combined_results[memory_id]['relevance_score'] += result['relevance_score'] * 0.7
            else:
                result['relevance_score'] = result['relevance_score'] * 0.7
                combined_results[memory_id] = result
        
        # Sort by combined score
        sorted_results = sorted(combined_results.values(), 
                              key=lambda x: x['relevance_score'], reverse=True)
        
        return sorted_results[:limit]
    
    def _apply_filters(self, query, filters: Optional[Dict]):
        """Apply filters to SQL query"""
        if not filters:
            return query
        
        if 'agent_id' in filters:
            query = query.filter(Memory.agent_id == filters['agent_id'])
        
        if 'agent_type' in filters:
            query = query.filter(Memory.agent_type == filters['agent_type'])
        
        if 'status' in filters:
            query = query.filter(Memory.status == filters['status'])
        
        if 'tags' in filters:
            for tag in filters['tags']:
                query = query.filter(Memory.tags.contains([tag]))
        
        if 'date_from' in filters:
            query = query.filter(Memory.created_at >= filters['date_from'])
        
        if 'date_to' in filters:
            query = query.filter(Memory.created_at <= filters['date_to'])
        
        return query
    
    def _passes_filters(self, memory: Memory, filters: Optional[Dict]) -> bool:
        """Check if memory passes filters"""
        if not filters:
            return True
        
        if 'agent_id' in filters and memory.agent_id != filters['agent_id']:
            return False
        
        if 'agent_type' in filters and memory.agent_type != filters['agent_type']:
            return False
        
        if 'status' in filters and memory.status != filters['status']:
            return False
        
        if 'tags' in filters:
            memory_tags = set(memory.tags or [])
            filter_tags = set(filters['tags'])
            if not filter_tags.issubset(memory_tags):
                return False
        
        return True
    
    def _format_search_result(self, memory: Memory, score: float) -> Dict[str, Any]:
        """Format search result"""
        return {
            'memory': memory.to_dict(),
            'relevance_score': score,
            'search_type': 'hybrid'
        }
    
    def _update_vector_metadata(self, memory: Memory):
        """Update vector metadata"""
        try:
            metadata = {
                'agent_id': memory.agent_id,
                'agent_type': memory.agent_type,
                'status': memory.status,
                'created_at': memory.created_at.isoformat(),
                'tags': memory.tags or [],
                'quality_score': memory.quality_score
            }
            
            # Generate embedding (needed for upsert)
            combined_text = embedding_service.combine_text_for_embedding(memory.prompt, memory.response)
            embedding = embedding_service.generate_embedding(combined_text)
            
            vector_service.upsert_vector(memory.vector_id, embedding, metadata)
            
        except Exception as e:
            logger.error(f"Failed to update vector metadata for memory {memory.id}: {str(e)}")
    
    def _log_search(self, query: str, search_type: str, filters: Optional[Dict], 
                   results_count: int, response_time: float):
        """Log search query"""
        try:
            search_log = SearchLog(
                query=query,
                search_type=search_type,
                filters=filters,
                results_count=results_count,
                response_time=response_time
            )
            db.session.add(search_log)
            db.session.commit()
        except Exception as e:
            logger.error(f"Failed to log search: {str(e)}")
    
    def add_feedback(self, memory_id: int, feedback_type: str, score: Optional[float] = None,
                    comment: Optional[str] = None, source: Optional[str] = None,
                    source_type: str = 'system') -> Optional[Feedback]:
        """Add feedback to a memory"""
        try:
            feedback = Feedback(
                memory_id=memory_id,
                feedback_type=feedback_type,
                score=score,
                comment=comment,
                source=source,
                source_type=source_type
            )
            
            db.session.add(feedback)
            
            # Update memory quality score
            memory = Memory.query.get(memory_id)
            if memory:
                self._update_memory_quality_score(memory)
            
            db.session.commit()
            
            logger.info(f"Successfully added feedback to memory {memory_id}")
            return feedback
            
        except Exception as e:
            logger.error(f"Failed to add feedback to memory {memory_id}: {str(e)}")
            db.session.rollback()
            return None
    
    def _update_memory_quality_score(self, memory: Memory):
        """Update memory quality score based on feedback"""
        try:
            feedbacks = memory.feedbacks.all()
            if not feedbacks:
                return
            
            # Calculate average score
            scores = [f.score for f in feedbacks if f.score is not None]
            if scores:
                memory.quality_score = sum(scores) / len(scores)
            
            # Update vector metadata
            self._update_vector_metadata(memory)
            
        except Exception as e:
            logger.error(f"Failed to update quality score for memory {memory.id}: {str(e)}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get memory system statistics"""
        try:
            stats = {
                'total_memories': Memory.query.count(),
                'active_memories': Memory.query.filter_by(status='active').count(),
                'archived_memories': Memory.query.filter_by(status='archived').count(),
                'error_memories': Memory.query.filter_by(status='error').count(),
                'total_feedbacks': Feedback.query.count(),
                'total_searches': db.session.query(SearchLog).count(),
                'agents': db.session.query(Memory.agent_id).distinct().count(),
                'agent_types': db.session.query(Memory.agent_type).distinct().count()
            }
            
            # Add vector database stats
            vector_stats = vector_service.get_stats()
            stats.update(vector_stats)
            
            return stats
            
        except Exception as e:
            logger.error(f"Failed to get statistics: {str(e)}")
            return {
                'total_memories': 0,
                'active_memories': 0,
                'archived_memories': 0,
                'error_memories': 0,
                'total_feedbacks': 0,
                'total_searches': 0,
                'agents': 0,
                'agent_types': 0,
                'total_vectors': 0,
                'status': 'error'
            }

# Global instance
memory_service = MemoryService()
