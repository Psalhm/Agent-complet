from flask import Blueprint, request, jsonify
from datetime import datetime
from services.memory_service import memory_service
from utils.logger import get_logger
from auth import require_api_key

logger = get_logger('api')

api_bp = Blueprint('api', __name__)

@api_bp.route('/memories', methods=['POST'])
@require_api_key('write')
def create_memory():
    """Create a new memory"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['prompt', 'response', 'agent_id', 'agent_type']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Create memory
        memory = memory_service.create_memory(
            prompt=data['prompt'],
            response=data['response'],
            agent_id=data['agent_id'],
            agent_type=data['agent_type'],
            context=data.get('context'),
            tags=data.get('tags', [])
        )
        
        if memory:
            return jsonify({
                'success': True,
                'memory': memory.to_dict()
            }), 201
        else:
            return jsonify({'error': 'Failed to create memory'}), 500
            
    except Exception as e:
        logger.error(f"Error creating memory: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@api_bp.route('/memories/<int:memory_id>', methods=['GET'])
@require_api_key('read')
def get_memory(memory_id):
    """Get a memory by ID"""
    try:
        memory = memory_service.get_memory(memory_id)
        if memory:
            return jsonify({
                'success': True,
                'memory': memory.to_dict()
            })
        else:
            return jsonify({'error': 'Memory not found'}), 404
            
    except Exception as e:
        logger.error(f"Error getting memory {memory_id}: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@api_bp.route('/memories/<int:memory_id>', methods=['PUT'])
@require_api_key('write')
def update_memory(memory_id):
    """Update a memory"""
    try:
        data = request.get_json()
        
        # Remove immutable fields
        immutable_fields = ['id', 'vector_id', 'created_at', 'content_hash']
        for field in immutable_fields:
            data.pop(field, None)
        
        memory = memory_service.update_memory(memory_id, **data)
        if memory:
            return jsonify({
                'success': True,
                'memory': memory.to_dict()
            })
        else:
            return jsonify({'error': 'Memory not found'}), 404
            
    except Exception as e:
        logger.error(f"Error updating memory {memory_id}: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@api_bp.route('/memories/<int:memory_id>', methods=['DELETE'])
@require_api_key('delete')
def delete_memory(memory_id):
    """Delete a memory"""
    try:
        success = memory_service.delete_memory(memory_id)
        if success:
            return jsonify({'success': True})
        else:
            return jsonify({'error': 'Memory not found'}), 404
            
    except Exception as e:
        logger.error(f"Error deleting memory {memory_id}: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@api_bp.route('/memories/search', methods=['POST'])
@require_api_key('read')
def search_memories():
    """Search memories"""
    try:
        data = request.get_json()
        
        query = data.get('query', '')
        search_type = data.get('search_type', 'hybrid')
        filters = data.get('filters', {})
        limit = min(data.get('limit', 10), 50)  # Cap at 50
        
        if not query:
            return jsonify({'error': 'Query is required'}), 400
        
        results = memory_service.search_memories(
            query=query,
            search_type=search_type,
            filters=filters,
            limit=limit
        )
        
        return jsonify({
            'success': True,
            'results': results,
            'total': len(results),
            'query': query,
            'search_type': search_type
        })
        
    except Exception as e:
        logger.error(f"Error searching memories: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@api_bp.route('/memories/<int:memory_id>/feedback', methods=['POST'])
@require_api_key('write')
def add_feedback(memory_id):
    """Add feedback to a memory"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if 'feedback_type' not in data:
            return jsonify({'error': 'Missing required field: feedback_type'}), 400
        
        feedback = memory_service.add_feedback(
            memory_id=memory_id,
            feedback_type=data['feedback_type'],
            score=data.get('score'),
            comment=data.get('comment'),
            source=data.get('source'),
            source_type=data.get('source_type', 'system')
        )
        
        if feedback:
            return jsonify({
                'success': True,
                'feedback': feedback.to_dict()
            }), 201
        else:
            return jsonify({'error': 'Failed to add feedback'}), 500
            
    except Exception as e:
        logger.error(f"Error adding feedback to memory {memory_id}: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@api_bp.route('/stats', methods=['GET'])
@require_api_key('read')
def get_statistics():
    """Get system statistics"""
    try:
        stats = memory_service.get_statistics()
        return jsonify({
            'success': True,
            'statistics': stats
        })
        
    except Exception as e:
        logger.error(f"Error getting statistics: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@api_bp.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat()
    })

# Error handlers
@api_bp.errorhandler(400)
def bad_request(error):
    return jsonify({'error': 'Bad request'}), 400

@api_bp.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@api_bp.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500
