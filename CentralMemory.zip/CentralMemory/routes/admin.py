from flask import Blueprint, render_template, request, jsonify, redirect, url_for
from services.memory_service import memory_service
from models import Memory, Feedback
from utils.logger import get_logger

logger = get_logger('admin')

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/')
def dashboard():
    """Admin dashboard"""
    try:
        stats = memory_service.get_statistics()
        return render_template('dashboard.html', stats=stats)
    except Exception as e:
        logger.error(f"Error loading dashboard: {str(e)}")
        return render_template('dashboard.html', stats={}, error=str(e))

@admin_bp.route('/memories')
def memories():
    """Memories management page"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = 20
        
        memories = Memory.query.order_by(Memory.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return render_template('memories.html', memories=memories)
    except Exception as e:
        logger.error(f"Error loading memories: {str(e)}")
        return render_template('memories.html', memories=None, error=str(e))

@admin_bp.route('/search')
def search():
    """Search interface"""
    return render_template('search.html')

@admin_bp.route('/memories/<int:memory_id>')
def memory_detail(memory_id):
    """Memory detail page"""
    try:
        memory = memory_service.get_memory(memory_id)
        if not memory:
            return render_template('error.html', error='Memory not found'), 404
        
        feedbacks = memory.feedbacks.order_by(Feedback.created_at.desc()).all()
        return render_template('memory_detail.html', memory=memory, feedbacks=feedbacks)
    except Exception as e:
        logger.error(f"Error loading memory detail {memory_id}: {str(e)}")
        return render_template('error.html', error=str(e)), 500

@admin_bp.route('/memories/<int:memory_id>/archive', methods=['POST'])
def archive_memory(memory_id):
    """Archive a memory"""
    try:
        memory = memory_service.update_memory(memory_id, status='archived')
        if memory:
            return jsonify({'success': True, 'message': 'Memory archived successfully'})
        else:
            return jsonify({'error': 'Memory not found'}), 404
    except Exception as e:
        logger.error(f"Error archiving memory {memory_id}: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@admin_bp.route('/memories/<int:memory_id>/restore', methods=['POST'])
def restore_memory(memory_id):
    """Restore an archived memory"""
    try:
        memory = memory_service.update_memory(memory_id, status='active')
        if memory:
            return jsonify({'success': True, 'message': 'Memory restored successfully'})
        else:
            return jsonify({'error': 'Memory not found'}), 404
    except Exception as e:
        logger.error(f"Error restoring memory {memory_id}: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@admin_bp.route('/internal/search', methods=['POST'])
def internal_search():
    """Search API for admin interface (internal use - no API key required)"""
    try:
        data = request.get_json()
        
        query = data.get('query', '')
        search_type = data.get('search_type', 'hybrid')
        filters = data.get('filters', {})
        limit = min(data.get('limit', 10), 50)
        
        if not query:
            return jsonify({'error': 'Query is required'}), 400
        
        results = memory_service.search_memories(
            query=query,
            search_type=search_type,
            filters=filters,
            limit=limit
        )
        
        return jsonify({
            'success': True,
            'results': results,
            'total': len(results)
        })
        
    except Exception as e:
        logger.error(f"Error in admin search: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@admin_bp.route('/internal/stats', methods=['GET'])
def internal_stats():
    """Get statistics for dashboard (internal admin use - no API key required)"""
    try:
        stats = memory_service.get_statistics()
        return jsonify({
            'success': True,
            'stats': stats
        })
    except Exception as e:
        logger.error(f"Error getting stats: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500
