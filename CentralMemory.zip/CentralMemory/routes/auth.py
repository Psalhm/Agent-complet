from flask import Blueprint, request, jsonify, render_template
from auth import create_api_key, APIKey, get_api_key_info
from app import db
from utils.logger import get_logger

logger = get_logger('auth')

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/keys', methods=['GET'])
def list_api_keys():
    """List all API keys (admin interface)"""
    try:
        keys = APIKey.query.order_by(APIKey.created_at.desc()).all()
        return render_template('api_keys.html', keys=keys)
    except Exception as e:
        logger.error(f"Error listing API keys: {str(e)}")
        return render_template('api_keys.html', keys=[], error=str(e))

@auth_bp.route('/keys', methods=['POST'])
def create_new_api_key():
    """Create a new API key"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data or 'name' not in data:
            return jsonify({'error': 'Name is required'}), 400
        
        # Set permissions
        permissions = {
            'can_read': data.get('can_read', True),
            'can_write': data.get('can_write', True),
            'can_delete': data.get('can_delete', False)
        }
        
        # Create key
        raw_key, api_key = create_api_key(
            name=data['name'],
            description=data.get('description'),
            expires_days=data.get('expires_days'),
            permissions=permissions
        )
        
        logger.info(f"Created new API key: {data['name']}")
        
        return jsonify({
            'success': True,
            'api_key': raw_key,
            'key_info': api_key.to_dict(),
            'warning': 'Save this key securely. It will not be shown again.'
        }), 201
        
    except Exception as e:
        logger.error(f"Error creating API key: {str(e)}")
        return jsonify({'error': 'Failed to create API key'}), 500

@auth_bp.route('/keys/<int:key_id>', methods=['DELETE'])
def delete_api_key(key_id):
    """Delete an API key"""
    try:
        api_key = APIKey.query.get(key_id)
        if not api_key:
            return jsonify({'error': 'API key not found'}), 404
        
        key_name = api_key.name
        db.session.delete(api_key)
        db.session.commit()
        
        logger.info(f"Deleted API key: {key_name}")
        return jsonify({'success': True})
        
    except Exception as e:
        logger.error(f"Error deleting API key: {str(e)}")
        return jsonify({'error': 'Failed to delete API key'}), 500

@auth_bp.route('/keys/<int:key_id>/toggle', methods=['POST'])
def toggle_api_key(key_id):
    """Toggle API key active status"""
    try:
        api_key = APIKey.query.get(key_id)
        if not api_key:
            return jsonify({'error': 'API key not found'}), 404
        
        api_key.is_active = not api_key.is_active
        db.session.commit()
        
        status = 'activated' if api_key.is_active else 'deactivated'
        logger.info(f"API key {api_key.name} {status}")
        
        return jsonify({
            'success': True,
            'is_active': api_key.is_active
        })
        
    except Exception as e:
        logger.error(f"Error toggling API key: {str(e)}")
        return jsonify({'error': 'Failed to toggle API key'}), 500

@auth_bp.route('/keys/info', methods=['POST'])
def get_key_info():
    """Get API key information"""
    try:
        data = request.get_json()
        if not data or 'api_key' not in data:
            return jsonify({'error': 'API key is required'}), 400
        
        key_info = get_api_key_info(data['api_key'])
        if not key_info:
            return jsonify({'error': 'Invalid API key'}), 404
        
        return jsonify({
            'success': True,
            'key_info': key_info
        })
        
    except Exception as e:
        logger.error(f"Error getting key info: {str(e)}")
        return jsonify({'error': 'Failed to get key info'}), 500

# API endpoints for testing
@auth_bp.route('/test', methods=['GET'])
def test_endpoint():
    """Test endpoint (no authentication required)"""
    return jsonify({
        'message': 'API is working',
        'endpoints': {
            'create_key': 'POST /auth/keys',
            'list_keys': 'GET /auth/keys',
            'test_auth': 'GET /auth/test-auth'
        }
    })

@auth_bp.route('/test-auth', methods=['GET'])
def test_auth_endpoint():
    """Test endpoint with authentication"""
    from auth import require_api_key
    
    @require_api_key('read')
    def protected_endpoint():
        return jsonify({
            'message': 'Authentication successful',
            'api_key_info': {
                'name': request.api_key.name,
                'usage_count': request.api_key.usage_count,
                'permissions': {
                    'can_read': request.api_key.can_read,
                    'can_write': request.api_key.can_write,
                    'can_delete': request.api_key.can_delete
                }
            }
        })
    
    return protected_endpoint()