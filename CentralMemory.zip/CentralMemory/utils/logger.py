import logging
import os
from datetime import datetime

def setup_logging():
    """Setup logging configuration"""
    log_level = getattr(logging, os.environ.get('LOG_LEVEL', 'INFO').upper())
    
    # Create logs directory if it doesn't exist
    os.makedirs('logs', exist_ok=True)
    
    # Configure logging
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(f'logs/memory_system_{datetime.now().strftime("%Y%m%d")}.log'),
            logging.StreamHandler()
        ]
    )
    
    # Create logger for the application
    logger = logging.getLogger('memory_system')
    logger.info('Memory system logging initialized')
    
    return logger

def get_logger(name):
    """Get a logger instance"""
    return logging.getLogger(f'memory_system.{name}')
