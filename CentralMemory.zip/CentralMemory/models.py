from datetime import datetime
from app import db
from sqlalchemy import Text, DateTime, String, Integer, Float, Boolean, JSON
from sqlalchemy.sql import func

class Memory(db.Model):
    """Memory model for storing AI interactions and metadata"""
    __tablename__ = 'memories'
    
    id = db.Column(Integer, primary_key=True)
    vector_id = db.Column(String(255), unique=True, nullable=False)  # ID in vector database
    
    # Content
    prompt = db.Column(Text, nullable=False)
    response = db.Column(Text, nullable=False)
    content_hash = db.Column(String(64), nullable=False, index=True)  # For deduplication
    
    # Metadata
    agent_id = db.Column(String(100), nullable=False, index=True)
    agent_type = db.Column(String(50), nullable=False)
    context = db.Column(JSON)  # Additional context data
    tags = db.Column(JSON)  # List of tags
    
    # Status and quality
    status = db.Column(String(20), default='active', index=True)  # active, archived, error
    quality_score = db.Column(Float, default=0.0)
    relevance_score = db.Column(Float, default=0.0)
    
    # Timestamps
    created_at = db.Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    feedbacks = db.relationship('Feedback', backref='memory', lazy='dynamic', cascade='all, delete-orphan')
    
    def to_dict(self):
        """Convert memory to dictionary"""
        return {
            'id': self.id,
            'vector_id': self.vector_id,
            'prompt': self.prompt,
            'response': self.response,
            'agent_id': self.agent_id,
            'agent_type': self.agent_type,
            'context': self.context,
            'tags': self.tags or [],
            'status': self.status,
            'quality_score': self.quality_score,
            'relevance_score': self.relevance_score,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'feedback_count': self.feedbacks.count()
        }
    
    @classmethod
    def get_by_vector_id(cls, vector_id):
        """Get memory by vector ID"""
        return cls.query.filter_by(vector_id=vector_id).first()
    
    @classmethod
    def search_by_agent(cls, agent_id, limit=10):
        """Search memories by agent ID"""
        return cls.query.filter_by(agent_id=agent_id, status='active').order_by(cls.created_at.desc()).limit(limit).all()
    
    @classmethod
    def search_by_tags(cls, tags, limit=10):
        """Search memories by tags"""
        query = cls.query.filter(cls.status == 'active')
        for tag in tags:
            query = query.filter(cls.tags.contains([tag]))
        return query.order_by(cls.created_at.desc()).limit(limit).all()

class Feedback(db.Model):
    """Feedback model for memory quality and relevance"""
    __tablename__ = 'feedbacks'
    
    id = db.Column(Integer, primary_key=True)
    memory_id = db.Column(Integer, db.ForeignKey('memories.id'), nullable=False)
    
    # Feedback data
    feedback_type = db.Column(String(20), nullable=False)  # positive, negative, correction
    score = db.Column(Float)  # Numerical score (-1 to 1)
    comment = db.Column(Text)
    
    # Feedback metadata
    source = db.Column(String(100))  # Who/what provided feedback
    source_type = db.Column(String(50))  # human, agent, system
    
    # Context
    context = db.Column(JSON)  # Additional context for the feedback
    
    # Timestamps
    created_at = db.Column(DateTime, default=datetime.utcnow, nullable=False)
    
    def to_dict(self):
        """Convert feedback to dictionary"""
        return {
            'id': self.id,
            'memory_id': self.memory_id,
            'feedback_type': self.feedback_type,
            'score': self.score,
            'comment': self.comment,
            'source': self.source,
            'source_type': self.source_type,
            'context': self.context,
            'created_at': self.created_at.isoformat()
        }

class SearchLog(db.Model):
    """Log search queries for analytics"""
    __tablename__ = 'search_logs'
    
    id = db.Column(Integer, primary_key=True)
    query = db.Column(Text, nullable=False)
    search_type = db.Column(String(20), nullable=False)  # text, semantic, hybrid
    filters = db.Column(JSON)
    results_count = db.Column(Integer)
    response_time = db.Column(Float)
    
    # Metadata
    agent_id = db.Column(String(100))
    ip_address = db.Column(String(45))
    user_agent = db.Column(String(500))
    
    # Timestamp
    created_at = db.Column(DateTime, default=datetime.utcnow, nullable=False)
    
    def to_dict(self):
        """Convert search log to dictionary"""
        return {
            'id': self.id,
            'query': self.query,
            'search_type': self.search_type,
            'filters': self.filters,
            'results_count': self.results_count,
            'response_time': self.response_time,
            'agent_id': self.agent_id,
            'created_at': self.created_at.isoformat()
        }
