import os
from datetime import timedelta

class Config:
    # Database
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL', 'sqlite:///memory_system.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
    
    # Vector Database
    PINECONE_API_KEY = os.environ.get('PINECONE_API_KEY', 'default-pinecone-key')
    PINECONE_ENVIRONMENT = os.environ.get('PINECONE_ENVIRONMENT', 'us-west1-gcp')
    PINECONE_INDEX_NAME = os.environ.get('PINECONE_INDEX_NAME', 'memory-index')
    
    # Embedding Model
    EMBEDDING_MODEL = os.environ.get('EMBEDDING_MODEL', 'sentence-transformers/all-MiniLM-L6-v2')
    
    # API Configuration
    MAX_SEARCH_RESULTS = int(os.environ.get('MAX_SEARCH_RESULTS', '50'))
    DEFAULT_SEARCH_LIMIT = int(os.environ.get('DEFAULT_SEARCH_LIMIT', '10'))
    
    # Session
    PERMANENT_SESSION_LIFETIME = timedelta(hours=24)
    
    # Logging
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
