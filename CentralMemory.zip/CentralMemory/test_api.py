#!/usr/bin/env python3
"""
Test script pour l'API FastAPI de mémoire
"""
import requests
import json
from datetime import datetime

# Configuration
API_BASE_URL = "http://localhost:8000"
AGENT_ID = "test-agent-1"

def test_api():
    """Test complet de l'API mémoire"""
    print("🧪 Test de l'API Memory System")
    print(f"URL: {API_BASE_URL}")
    print(f"Agent ID: {AGENT_ID}")
    print("-" * 50)
    
    # Test 1: Health check
    print("1. Test health check...")
    try:
        response = requests.get(f"{API_BASE_URL}/health")
        print(f"   Status: {response.status_code}")
        print(f"   Response: {response.json()}")
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # Test 2: Ajouter une mémoire
    print("\n2. Test ajout mémoire...")
    memory_data = {
        "type": "conversation",
        "content": json.dumps({
            "prompt": "Quelle est la capitale de la France?",
            "response": "La capitale de la France est Paris."
        }),
        "context": {"session_id": "test-session-1"},
        "tags": ["géographie", "capitale"]
    }
    
    try:
        response = requests.post(
            f"{API_BASE_URL}/memory/{AGENT_ID}",
            json=memory_data,
            headers={"Content-Type": "application/json"}
        )
        print(f"   Status: {response.status_code}")
        print(f"   Response: {response.json()}")
        
        if response.status_code == 200:
            memory_id = response.json()["data"]["id"]
            print(f"   ✅ Memory créée avec ID: {memory_id}")
        
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # Test 3: Ajouter une deuxième mémoire
    print("\n3. Test ajout deuxième mémoire...")
    memory_data2 = {
        "type": "task",
        "content": "Créer un rapport sur l'IA",
        "context": {"priority": "high"},
        "tags": ["tâche", "IA"]
    }
    
    try:
        response = requests.post(
            f"{API_BASE_URL}/memory/{AGENT_ID}",
            json=memory_data2,
            headers={"Content-Type": "application/json"}
        )
        print(f"   Status: {response.status_code}")
        print(f"   Response: {response.json()}")
        
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # Test 4: Récupérer toute la mémoire
    print("\n4. Test récupération mémoire complète...")
    try:
        response = requests.get(f"{API_BASE_URL}/memory/{AGENT_ID}")
        print(f"   Status: {response.status_code}")
        result = response.json()
        print(f"   Success: {result['success']}")
        print(f"   Message: {result['message']}")
        
        if result['success'] and result['data']:
            memories = result['data']['memories']
            print(f"   Total memories: {len(memories)}")
            for i, memory in enumerate(memories, 1):
                print(f"   Memory {i}: {memory['type']} - {memory['content'][:50]}...")
        
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # Test 5: Récupérer la dernière mémoire
    print("\n5. Test récupération dernière mémoire...")
    try:
        response = requests.get(f"{API_BASE_URL}/memory/{AGENT_ID}/last")
        print(f"   Status: {response.status_code}")
        result = response.json()
        print(f"   Success: {result['success']}")
        print(f"   Message: {result['message']}")
        
        if result['success'] and result['data']:
            last_memory = result['data']
            print(f"   Last memory: {last_memory['type']} - {last_memory['content'][:50]}...")
            print(f"   Timestamp: {last_memory['timestamp']}")
        
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # Test 6: Statistiques agent
    print("\n6. Test statistiques agent...")
    try:
        response = requests.get(f"{API_BASE_URL}/memory/{AGENT_ID}/stats")
        print(f"   Status: {response.status_code}")
        result = response.json()
        print(f"   Success: {result['success']}")
        
        if result['success'] and result['data']:
            stats = result['data']
            print(f"   Total memories: {stats['total_memories']}")
            print(f"   Active memories: {stats['active_memories']}")
            print(f"   Average quality: {stats['average_quality_score']}")
            print(f"   Last activity: {stats['last_activity']}")
        
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # Test 7: Suppression (optionnel - décommenter pour tester)
    print("\n7. Test suppression mémoire (commenté)...")
    print("   (Décommenter dans test_api.py pour tester la suppression)")
    
    # Décommenter pour tester la suppression
    # try:
    #     response = requests.delete(f"{API_BASE_URL}/memory/{AGENT_ID}")
    #     print(f"   Status: {response.status_code}")
    #     print(f"   Response: {response.json()}")
    # except Exception as e:
    #     print(f"   ❌ Error: {e}")
    
    print("\n" + "=" * 50)
    print("🎉 Tests terminés!")

if __name__ == "__main__":
    test_api()