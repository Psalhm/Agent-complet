# Memory System

## Overview

This is a Flask-based AI memory system that enables storage, retrieval, and management of AI agent interactions. The system combines traditional SQL database storage with vector database capabilities for semantic search, providing both structured metadata management and intelligent content discovery.

## User Preferences

Preferred communication style: Simple, everyday language (French).

## Project Status (Dernière mise à jour: 9 juillet 2025)

### ✅ Fonctionnalités terminées
- Système de mémoire complet avec base de données SQLite
- Interface d'administration web avec tableau de bord
- API REST Flask sécurisée avec authentification par clés API
- API FastAPI additionnelle pour intégration externe
- Système de feedback et évaluation de qualité
- Recherche hybride (textuelle + sémantique en mode fallback)
- Gestion des utilisateurs et permissions
- Logging complet du système

### 🔧 Configuration requise
- **PINECONE_API_KEY**: Clé API Pinecone pour la recherche sémantique avancée
- **SESSION_SECRET**: Clé secrète pour les sessions Flask (déjà configurée)

### 🚀 Déploiement
- Application Flask prête sur port 5000
- API FastAPI disponible sur port 8000
- Base de données SQLite opérationnelle
- Système de logs fonctionnel

## System Architecture

### Backend Architecture
- **Framework**: Flask web application with SQLAlchemy ORM
- **Database**: SQLite for development (configurable to other SQL databases)
- **Vector Storage**: Pinecone for semantic search capabilities
- **Embeddings**: Sentence Transformers (all-MiniLM-L6-v2 model)
- **Session Management**: Flask sessions with 24-hour lifetime

### Frontend Architecture
- **Templates**: Jinja2 templating with Bootstrap Dark Theme
- **JavaScript**: Vanilla JS for interactive functionality
- **UI Components**: Bootstrap 5 components with Feather icons
- **Charts**: Chart.js for data visualization

## Key Components

### Models (models.py)
- **Memory**: Core model storing AI interactions with metadata
  - Content: prompt, response, content hash for deduplication
  - Metadata: agent info, context, tags, quality scores
  - Relationships: Links to feedback and search logs
- **Feedback**: User feedback on memory quality
- **SearchLog**: Tracking search queries and results

### Services
- **MemoryService**: Core business logic for memory CRUD operations
- **VectorService**: Pinecone integration for semantic search
- **EmbeddingService**: Text embedding generation using Sentence Transformers

### Routes
- **API Blueprint** (`/api`): RESTful endpoints for memory operations
- **Admin Blueprint** (`/`): Web interface for management and visualization

### Key Features
- **Deduplication**: Content hash-based duplicate prevention
- **Semantic Search**: Vector-based similarity search
- **Multi-agent Support**: Separate tracking per agent/agent type
- **Quality Scoring**: Relevance and quality metrics
- **Admin Interface**: Web-based management dashboard

## Data Flow

1. **Memory Creation**: 
   - API receives prompt/response data
   - Content hash generated for deduplication
   - Embedding created and stored in Pinecone
   - Metadata stored in SQL database

2. **Search Process**:
   - Query embedding generated
   - Vector search performed in Pinecone
   - Results combined with SQL filtering
   - Search logged for analytics

3. **Admin Operations**:
   - Dashboard displays statistics and visualizations
   - Memory management through web interface
   - Search interface for content discovery

## External Dependencies

### Core Dependencies
- **Flask**: Web framework and routing
- **SQLAlchemy**: Database ORM and migrations
- **Pinecone**: Vector database for semantic search
- **Sentence Transformers**: Text embedding generation
- **Bootstrap**: UI framework and theming

### Configuration
- Environment-based configuration system
- Default values for development environment
- Support for production deployment settings

## Deployment Strategy

### Development Setup
- SQLite database for local development
- In-memory fallback for vector operations
- Debug mode enabled with hot reload
- File-based logging with console output

### Production Considerations
- Configurable database URL (supports PostgreSQL, MySQL)
- Pinecone cloud service integration
- Environment variable-based secrets management
- Proxy fix middleware for reverse proxy deployment
- Connection pooling and health checks

### Environment Variables
- `DATABASE_URL`: Database connection string
- `PINECONE_API_KEY`: Pinecone service authentication
- `PINECONE_ENVIRONMENT`: Pinecone deployment region
- `SESSION_SECRET`: Flask session encryption key
- `LOG_LEVEL`: Logging verbosity control

The system is designed to be easily deployable on cloud platforms with minimal configuration changes, supporting both development and production environments through environment-specific settings.