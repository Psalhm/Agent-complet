import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
from config import Config
from utils.logger import setup_logging

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
    app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)
    
    # Setup logging
    setup_logging()
    
    # Initialize database
    db.init_app(app)
    
    with app.app_context():
        # Import models to ensure tables are created
        import models
        import auth
        db.create_all()
        
        # Register blueprints
        from routes.api import api_bp
        from routes.admin import admin_bp
        from routes.auth import auth_bp
        
        app.register_blueprint(api_bp, url_prefix='/api')
        app.register_blueprint(admin_bp, url_prefix='/')
        app.register_blueprint(auth_bp, url_prefix='/auth')
    
    return app

app = create_app()
