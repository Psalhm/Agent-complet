import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Sidebar } from '@/components/sidebar';
import { StatsCards } from '@/components/stats-cards';
import { AgentCard } from '@/components/agent-card';
import { CreateAgentForm } from '@/components/create-agent-form';
import { LogsPanel } from '@/components/logs-panel';
import { PerformancePanel } from '@/components/performance-panel';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, Plus } from 'lucide-react';
import { useWebSocket } from '@/lib/websocket';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Agent, InsertAgent } from '@shared/schema';

export default function Dashboard() {
  const [statusFilter, setStatusFilter] = useState('all');
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch agents
  const { data: agents = [], isLoading: agentsLoading } = useQuery<Agent[]>({
    queryKey: ['/api/agents'],
  });

  // Fetch stats
  const { data: stats = { activeAgents: 0, inactiveAgents: 0, completedTasks: 0, errors: 0 } } = useQuery({
    queryKey: ['/api/stats'],
    refetchInterval: 5000,
  });

  // Fetch logs
  const { data: logs = [] } = useQuery({
    queryKey: ['/api/logs'],
    refetchInterval: 3000,
  });

  // Fetch performance
  const { data: performance = { cpu: 0, memory: 0, network: 0, uptime: '0%', responseTime: '0ms' } } = useQuery({
    queryKey: ['/api/performance'],
    refetchInterval: 5000,
  });

  // WebSocket connection
  const { isConnected } = useWebSocket((message) => {
    switch (message.type) {
      case 'agent-created':
      case 'agent-updated':
      case 'agent-deleted':
        queryClient.invalidateQueries({ queryKey: ['/api/agents'] });
        queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
        break;
      case 'log-created':
        queryClient.invalidateQueries({ queryKey: ['/api/logs'] });
        break;
      case 'stats-updated':
        queryClient.setQueryData(['/api/stats'], message.data);
        break;
    }
  });

  // Create agent mutation
  const createAgentMutation = useMutation({
    mutationFn: (agent: InsertAgent) => apiRequest('POST', '/api/agents', agent),
    onSuccess: () => {
      toast({
        title: 'Agent créé',
        description: 'L\'agent a été créé avec succès',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/agents'] });
    },
    onError: () => {
      toast({
        title: 'Erreur',
        description: 'Impossible de créer l\'agent',
        variant: 'destructive',
      });
    },
  });

  // Agent control mutations
  const startAgentMutation = useMutation({
    mutationFn: (id: number) => apiRequest('POST', `/api/agents/${id}/start`),
    onSuccess: () => {
      toast({
        title: 'Agent démarré',
        description: 'L\'agent a été démarré avec succès',
      });
    },
  });

  const stopAgentMutation = useMutation({
    mutationFn: (id: number) => apiRequest('POST', `/api/agents/${id}/stop`),
    onSuccess: () => {
      toast({
        title: 'Agent arrêté',
        description: 'L\'agent a été arrêté avec succès',
      });
    },
  });

  const restartAgentMutation = useMutation({
    mutationFn: (id: number) => apiRequest('POST', `/api/agents/${id}/restart`),
    onSuccess: () => {
      toast({
        title: 'Agent redémarré',
        description: 'L\'agent a été redémarré avec succès',
      });
    },
  });

  const deleteAgentMutation = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE', `/api/agents/${id}`),
    onSuccess: () => {
      toast({
        title: 'Agent supprimé',
        description: 'L\'agent a été supprimé avec succès',
      });
    },
  });

  // Filter agents based on status
  const filteredAgents = agents.filter(agent => {
    if (statusFilter === 'all') return true;
    return agent.status === statusFilter;
  });

  const handleDeleteAgent = (id: number) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet agent?')) {
      deleteAgentMutation.mutate(id);
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-50">
      <Sidebar />
      
      <div className="flex-1 ml-64 p-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-3xl font-bold text-slate-800">Dashboard des Agents</h2>
              <p className="text-slate-600 mt-1">Gérez et surveillez vos agents IA en temps réel</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="bg-white p-3 rounded-lg shadow-sm border flex items-center space-x-2">
                <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'} animate-pulse`}></span>
                <span className="text-sm font-medium">
                  {isConnected ? 'Système actif' : 'Connexion perdue'}
                </span>
              </div>
              <Button onClick={() => queryClient.invalidateQueries()}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Actualiser
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <StatsCards stats={stats} />

        {/* Agent List */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Agents</CardTitle>
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  <label className="text-sm text-slate-600">Filtre:</label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      <SelectItem value="running">Actifs</SelectItem>
                      <SelectItem value="stopped">Inactifs</SelectItem>
                      <SelectItem value="error">Erreur</SelectItem>
                      <SelectItem value="waiting">En attente</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {agentsLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                <p className="mt-2 text-slate-600">Chargement des agents...</p>
              </div>
            ) : filteredAgents.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-slate-500">Aucun agent trouvé</p>
                {statusFilter !== 'all' && (
                  <Button 
                    variant="outline" 
                    onClick={() => setStatusFilter('all')}
                    className="mt-2"
                  >
                    Voir tous les agents
                  </Button>
                )}
              </div>
            ) : (
              filteredAgents.map((agent) => (
                <AgentCard
                  key={agent.id}
                  agent={agent}
                  onStart={startAgentMutation.mutate}
                  onStop={stopAgentMutation.mutate}
                  onRestart={restartAgentMutation.mutate}
                  onDelete={handleDeleteAgent}
                  onViewLogs={(id) => toast({ title: 'Logs', description: `Affichage des logs pour l'agent ${id}` })}
                />
              ))
            )}
          </CardContent>
        </Card>

        {/* Create Agent Form */}
        <CreateAgentForm 
          onSubmit={createAgentMutation.mutate}
          isLoading={createAgentMutation.isPending}
        />

        {/* Logs and Performance */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <LogsPanel 
            logs={logs}
            onViewAll={() => toast({ title: 'Logs', description: 'Affichage de tous les logs' })}
          />
          <PerformancePanel performance={performance} />
        </div>
      </div>
    </div>
  );
}
