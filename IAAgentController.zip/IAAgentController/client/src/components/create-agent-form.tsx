import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus } from 'lucide-react';
import { InsertAgent } from '@shared/schema';

interface CreateAgentFormProps {
  onSubmit: (agent: InsertAgent) => void;
  isLoading: boolean;
}

export function CreateAgentForm({ onSubmit, isLoading }: CreateAgentFormProps) {
  const [formData, setFormData] = useState<InsertAgent>({
    name: '',
    role: '',
    task: '',
    status: 'stopped',
    priority: 'medium',
    autoStart: 'manual',
    timeout: 30,
    enableMonitoring: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleReset = () => {
    setFormData({
      name: '',
      role: '',
      task: '',
      status: 'stopped',
      priority: 'medium',
      autoStart: 'manual',
      timeout: 30,
      enableMonitoring: false,
    });
  };

  return (
    <Card className="mb-8">
      <CardHeader>
        <CardTitle>Créer un Nouvel Agent</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="name">Nom de l'Agent</Label>
              <Input
                id="name"
                placeholder="Ex: Agent Assistant Marketing"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="role">Rôle</Label>
              <Select value={formData.role} onValueChange={(value) => setFormData({ ...formData, role: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner un rôle" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Assistant virtuel">Assistant virtuel</SelectItem>
                  <SelectItem value="Analyseur de données">Analyseur de données</SelectItem>
                  <SelectItem value="Surveillance système">Surveillance système</SelectItem>
                  <SelectItem value="Traitement de données">Traitement de données</SelectItem>
                  <SelectItem value="Planificateur">Planificateur</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <Label htmlFor="task">Tâche Principale</Label>
            <Textarea
              id="task"
              placeholder="Décrivez la tâche principale que cet agent doit accomplir..."
              value={formData.task}
              onChange={(e) => setFormData({ ...formData, task: e.target.value })}
              rows={3}
              required
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <Label htmlFor="priority">Priorité</Label>
              <Select value={formData.priority} onValueChange={(value: 'low' | 'medium' | 'high') => setFormData({ ...formData, priority: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Faible</SelectItem>
                  <SelectItem value="medium">Moyenne</SelectItem>
                  <SelectItem value="high">Élevée</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="autoStart">Démarrage</Label>
              <Select value={formData.autoStart} onValueChange={(value: 'manual' | 'auto' | 'scheduled') => setFormData({ ...formData, autoStart: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="manual">Manuel</SelectItem>
                  <SelectItem value="auto">Automatique</SelectItem>
                  <SelectItem value="scheduled">Planifié</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="timeout">Timeout (minutes)</Label>
              <Input
                id="timeout"
                type="number"
                placeholder="30"
                value={formData.timeout || ''}
                onChange={(e) => setFormData({ ...formData, timeout: parseInt(e.target.value) || 30 })}
                min={1}
                max={1440}
              />
            </div>
          </div>
          
          <div className="flex items-center justify-between pt-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="enableMonitoring"
                checked={formData.enableMonitoring}
                onCheckedChange={(checked) => setFormData({ ...formData, enableMonitoring: checked as boolean })}
              />
              <Label htmlFor="enableMonitoring">Activer le monitoring avancé</Label>
            </div>
            <div className="flex items-center space-x-3">
              <Button type="button" variant="outline" onClick={handleReset}>
                Annuler
              </Button>
              <Button type="submit" disabled={isLoading}>
                <Plus className="h-4 w-4 mr-2" />
                {isLoading ? 'Création...' : "Créer l'Agent"}
              </Button>
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
