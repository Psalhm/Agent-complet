import { Link, useLocation } from 'wouter';
import { Activity, List, FileText, Settings, Bot } from 'lucide-react';

export function Sidebar() {
  const [location] = useLocation();
  
  const navigation = [
    { name: 'Dashboard', href: '/', icon: Activity },
    { name: 'Agents', href: '/agents', icon: List },
    { name: 'Logs', href: '/logs', icon: FileText },
    { name: 'Paramètres', href: '/settings', icon: Settings },
  ];

  return (
    <div className="w-64 bg-slate-800 text-white p-6 fixed h-full">
      <div className="flex items-center mb-8">
        <Bot className="h-8 w-8 text-blue-400 mr-3" />
        <h1 className="text-xl font-bold">AI Agent Hub</h1>
      </div>
      
      <nav className="space-y-2">
        {navigation.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          
          return (
            <Link key={item.name} href={item.href}>
              <div className={`flex items-center p-3 rounded-lg transition-colors cursor-pointer ${
                isActive 
                  ? 'bg-blue-600' 
                  : 'hover:bg-slate-700'
              }`}>
                <Icon className="h-5 w-5 mr-3" />
                {item.name}
              </div>
            </Link>
          );
        })}
      </nav>
      
      <div className="absolute bottom-6 left-6 right-6">
        <div className="flex items-center p-3 bg-slate-700 rounded-lg">
          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center mr-3">
            <span className="text-sm font-medium">A</span>
          </div>
          <div>
            <p className="font-medium text-sm">Admin User</p>
            <p className="text-xs text-slate-400">En ligne</p>
          </div>
        </div>
      </div>
    </div>
  );
}
