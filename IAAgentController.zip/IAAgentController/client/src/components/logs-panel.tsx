import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ExternalLink } from 'lucide-react';
import { Log } from '@shared/schema';

interface LogsPanelProps {
  logs: Log[];
  onViewAll: () => void;
}

export function LogsPanel({ logs, onViewAll }: LogsPanelProps) {
  const getLevelColor = (level: string) => {
    switch (level) {
      case 'info': return 'bg-green-500';
      case 'warning': return 'bg-amber-500';
      case 'error': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Logs Récents</CardTitle>
          <Button variant="ghost" size="sm" onClick={onViewAll}>
            <ExternalLink className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {logs.length === 0 ? (
            <p className="text-slate-500 text-center py-4">Aucun log disponible</p>
          ) : (
            logs.map((log) => (
              <div key={log.id} className="flex items-start space-x-3 p-3 bg-slate-50 rounded-lg">
                <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${getLevelColor(log.level)}`}></div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-slate-800">{log.agentName}</span>
                    <span className="text-xs text-slate-500">
                      {log.timestamp && new Date(log.timestamp).toLocaleTimeString('fr-FR', {
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit'
                      })}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 mt-1">{log.message}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
