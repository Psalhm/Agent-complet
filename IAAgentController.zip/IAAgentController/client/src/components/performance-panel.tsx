import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface PerformancePanelProps {
  performance: {
    cpu: number;
    memory: number;
    network: number;
    uptime: string;
    responseTime: string;
  };
}

export function PerformancePanel({ performance }: PerformancePanelProps) {
  const getBarColor = (value: number) => {
    if (value < 50) return 'bg-green-500';
    if (value < 80) return 'bg-amber-500';
    return 'bg-red-500';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Performances Système</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-slate-700">Utilisation CPU</span>
              <span className="text-sm text-slate-600">{performance.cpu}%</span>
            </div>
            <div className="w-full h-2 bg-slate-200 rounded-full">
              <div 
                className={`h-2 rounded-full transition-all duration-300 ${getBarColor(performance.cpu)}`}
                style={{ width: `${performance.cpu}%` }}
              ></div>
            </div>
          </div>
          
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-slate-700">Utilisation Mémoire</span>
              <span className="text-sm text-slate-600">{performance.memory}%</span>
            </div>
            <div className="w-full h-2 bg-slate-200 rounded-full">
              <div 
                className={`h-2 rounded-full transition-all duration-300 ${getBarColor(performance.memory)}`}
                style={{ width: `${performance.memory}%` }}
              ></div>
            </div>
          </div>
          
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-slate-700">Trafic Réseau</span>
              <span className="text-sm text-slate-600">{performance.network}%</span>
            </div>
            <div className="w-full h-2 bg-slate-200 rounded-full">
              <div 
                className={`h-2 rounded-full transition-all duration-300 ${getBarColor(performance.network)}`}
                style={{ width: `${performance.network}%` }}
              ></div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 pt-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-slate-800">{performance.uptime}</p>
              <p className="text-sm text-slate-600">Temps de fonctionnement</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-slate-800">{performance.responseTime}</p>
              <p className="text-sm text-slate-600">Temps de réponse</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
