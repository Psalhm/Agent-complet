import { Play, Pause, Check, AlertTriangle } from 'lucide-react';

interface StatsCardsProps {
  stats: {
    activeAgents: number;
    inactiveAgents: number;
    completedTasks: number;
    errors: number;
  };
}

export function StatsCards({ stats }: StatsCardsProps) {
  const cards = [
    {
      title: 'Agents Actifs',
      value: stats.activeAgents,
      icon: Play,
      color: 'bg-green-100 text-green-600',
    },
    {
      title: 'Agents Inactifs',
      value: stats.inactiveAgents,
      icon: Pause,
      color: 'bg-red-100 text-red-600',
    },
    {
      title: 'Tâches Terminées',
      value: stats.completedTasks,
      icon: Check,
      color: 'bg-blue-100 text-blue-600',
    },
    {
      title: 'Erreurs',
      value: stats.errors,
      icon: AlertTriangle,
      color: 'bg-amber-100 text-amber-600',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      {cards.map((card) => {
        const Icon = card.icon;
        return (
          <div key={card.title} className="bg-white p-6 rounded-xl shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">{card.title}</p>
                <p className="text-2xl font-bold text-slate-800">{card.value}</p>
              </div>
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${card.color}`}>
                <Icon className="h-6 w-6" />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
