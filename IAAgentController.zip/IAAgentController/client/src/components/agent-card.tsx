import { Eye, Pause, Play, Trash2, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Agent } from '@shared/schema';

interface AgentCardProps {
  agent: Agent;
  onStart: (id: number) => void;
  onStop: (id: number) => void;
  onRestart: (id: number) => void;
  onDelete: (id: number) => void;
  onViewLogs: (id: number) => void;
}

export function AgentCard({ agent, onStart, onStop, onRestart, onDelete, onViewLogs }: AgentCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'bg-green-500';
      case 'stopped': return 'bg-gray-500';
      case 'error': return 'bg-red-500';
      case 'waiting': return 'bg-amber-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'running': return 'En cours';
      case 'stopped': return 'Arrêté';
      case 'error': return 'Erreur';
      case 'waiting': return 'En attente';
      default: return 'Inconnu';
    }
  };

  const getStatusTextColor = (status: string) => {
    switch (status) {
      case 'running': return 'text-green-600';
      case 'stopped': return 'text-gray-600';
      case 'error': return 'text-red-600';
      case 'waiting': return 'text-amber-600';
      default: return 'text-gray-600';
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'Assistant virtuel': return 'bg-blue-500';
      case 'Analyseur de données': return 'bg-purple-500';
      case 'Surveillance système': return 'bg-red-500';
      case 'Traitement de données': return 'bg-green-500';
      case 'Planificateur': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="bg-slate-50 p-4 rounded-lg mb-4 border border-slate-200 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getRoleColor(agent.role)}`}>
            <span className="text-white font-medium">
              {agent.name.charAt(0).toUpperCase()}
            </span>
          </div>
          <div>
            <h4 className="font-semibold text-slate-800">{agent.name}</h4>
            <p className="text-sm text-slate-600">{agent.role}</p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <span className={`w-2 h-2 rounded-full ${getStatusColor(agent.status)} animate-pulse`}></span>
            <span className={`text-sm font-medium ${getStatusTextColor(agent.status)}`}>
              {getStatusText(agent.status)}
            </span>
          </div>
          <span className="text-sm text-slate-500 max-w-48 truncate">{agent.task}</span>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onViewLogs(agent.id)}
              className="text-blue-600 hover:text-blue-800"
            >
              <Eye className="h-4 w-4" />
            </Button>
            
            {agent.status === 'running' ? (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onStop(agent.id)}
                className="text-amber-600 hover:text-amber-800"
              >
                <Pause className="h-4 w-4" />
              </Button>
            ) : agent.status === 'error' ? (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onRestart(agent.id)}
                className="text-green-600 hover:text-green-800"
              >
                <RotateCcw className="h-4 w-4" />
              </Button>
            ) : (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onStart(agent.id)}
                className="text-green-600 hover:text-green-800"
              >
                <Play className="h-4 w-4" />
              </Button>
            )}
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(agent.id)}
              className="text-red-600 hover:text-red-800"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
      
      <div className="mt-3 pt-3 border-t border-slate-200">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center space-x-4">
            {agent.status === 'running' && agent.startTime && (
              <span className="text-slate-600">
                Démarré: {new Date(agent.startTime).toLocaleTimeString('fr-FR', { 
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}
              </span>
            )}
            {agent.duration && (
              <span className="text-slate-600">Durée: {agent.duration}</span>
            )}
            {agent.status === 'error' && agent.lastError && (
              <span className="text-red-600">Erreur: {agent.lastError}</span>
            )}
          </div>
          <div className="flex items-center space-x-2">
            {agent.status === 'running' && (
              <>
                <span className="text-slate-600">Performance:</span>
                <div className="w-20 h-2 bg-slate-200 rounded-full">
                  <div 
                    className="h-2 bg-green-500 rounded-full transition-all duration-300"
                    style={{ width: `${agent.performance}%` }}
                  ></div>
                </div>
                <span className="text-green-600 font-medium">{agent.performance}%</span>
              </>
            )}
            {agent.priority && (
              <Badge variant={agent.priority === 'high' ? 'destructive' : agent.priority === 'medium' ? 'default' : 'secondary'}>
                {agent.priority === 'high' ? 'Élevée' : agent.priority === 'medium' ? 'Moyenne' : 'Faible'}
              </Badge>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
