# API de Contrôle d'Agents IA - Brique 6

## Vue d'ensemble

Cette API FastAPI permet d'orchestrer et de contrôler des agents IA dans le cadre d'une architecture modulaire. Elle sert d'interface entre le dashboard React et les différents services d'agents.

## Fonctionnalités

### 🎯 Endpoints principaux

- **GET /projects** - Liste tous les projets d'agents
- **POST /projects** - Crée un nouveau projet avec agents
- **GET /projects/{project_id}** - Détails d'un projet spécifique
- **POST /projects/{project_id}/start** - Démarre tous les agents d'un projet
- **POST /projects/{project_id}/stop** - Arrête tous les agents d'un projet
- **GET /projects/{project_id}/logs** - Récupère les logs d'un projet

### 🔧 Endpoints de contrôle des agents

- **GET /projects/{project_id}/agents/{agent_id}/status** - Statut détaillé d'un agent
- **POST /projects/{project_id}/agents/{agent_id}/start** - Démarre un agent spécifique
- **POST /projects/{project_id}/agents/{agent_id}/stop** - Arrête un agent spécifique

### 📊 Endpoints utilitaires

- **GET /health** - Vérification de l'état de l'API et des services externes
- **GET /** - Informations générales sur l'API

## Installation et Configuration

### 1. Prérequis

- Python 3.11+
- Dépendances listées dans `requirements.txt`

### 2. Installation

```bash
# Installer les dépendances
pip install -r requirements.txt

# Copier le fichier de configuration
cp .env.example .env

# Modifier les variables d'environnement selon vos besoins
nano .env
```

### 3. Configuration

Modifier le fichier `.env` avec les URLs des autres briques :

```env
MEMORY_API_URL=http://localhost:8001
LOGS_API_URL=http://localhost:8002
AGENT_GEN_API_URL=http://localhost:8003
```

## Démarrage

### Option 1 : Script de démarrage (recommandé)

```bash
python run_api.py
```

### Option 2 : Uvicorn direct

```bash
uvicorn agent_control_api:app --host 0.0.0.0 --port 8000 --reload
```

L'API sera disponible sur `http://localhost:8000`

## Documentation

- **Interface Swagger** : `http://localhost:8000/docs`
- **ReDoc** : `http://localhost:8000/redoc`

## Tests

### Tests automatiques complets

```bash
# Démarrer l'API d'abord
python run_api.py

# Dans un autre terminal, lancer les tests
python test_agent_control_api.py
```

### Test manuel simple

```bash
python test_agent_control_api.py manual
```

## Structure des données

### Modèle Project

```json
{
  "id": "uuid",
  "name": "Nom du projet",
  "description": "Description du projet",
  "status": "inactive|active|paused|completed",
  "created_at": "2024-01-01T00:00:00",
  "agents": [
    {
      "id": "uuid",
      "name": "Nom de l'agent",
      "role": "Rôle de l'agent",
      "task": "Tâche assignée",
      "status": "stopped|running|error|paused",
      "priority": "low|medium|high",
      "created_at": "2024-01-01T00:00:00",
      "last_activity": "2024-01-01T00:00:00",
      "performance_metrics": {}
    }
  ],
  "total_tasks": 0,
  "completed_tasks": 0,
  "error_count": 0
}
```

## Intégrations avec les autres briques

### 🧠 Brique 1 - API Mémoire

- Récupération des métriques de performance
- Stockage des états des projets
- Synchronisation des données

### 📝 Brique 5 - API Logs

- Récupération des logs en temps réel
- Création d'entrées de logs pour les événements
- Filtrage par projet et agent

### 🤖 Brique 3 - Génération d'agents

- Communication pour la création d'agents
- Récupération des capacités des agents
- Synchronisation des configurations

## Stockage des données

L'API utilise un système de stockage simple basé sur JSON :

- **Fichier** : `data/projects.json`
- **Format** : Liste de projets avec agents intégrés
- **Sauvegarde** : Automatique à chaque modification

## Gestion d'erreurs

- **404** : Ressource non trouvée (projet, agent)
- **400** : Données invalides
- **500** : Erreur interne du serveur
- **503** : Service externe indisponible

## Sécurité

- CORS configuré pour le développement
- Validation des données avec Pydantic
- Gestion des timeouts pour les appels externes

## Monitoring

Utilisez l'endpoint `/health` pour surveiller :

- État de l'API
- Connexions aux services externes
- Performances générales

## Exemples d'utilisation

### Créer un projet

```bash
curl -X POST "http://localhost:8000/projects" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Mon Projet IA",
    "description": "Projet de test",
    "agents": [
      {
        "name": "Assistant Principal",
        "role": "Assistant virtuel",
        "task": "Gérer les interactions utilisateur",
        "priority": "high"
      }
    ]
  }'
```

### Démarrer un projet

```bash
curl -X POST "http://localhost:8000/projects/{project_id}/start"
```

### Récupérer les logs

```bash
curl "http://localhost:8000/projects/{project_id}/logs?limit=100"
```

## Développement

### Structure du code

```
api/
├── agent_control_api.py      # API principale
├── test_agent_control_api.py # Tests
├── run_api.py               # Script de démarrage
├── requirements.txt         # Dépendances
├── .env.example            # Configuration exemple
├── data/
│   └── projects.json       # Stockage des projets
└── README.md              # Documentation
```

### Contribution

1. Créer une branche pour les modifications
2. Tester avec `python test_agent_control_api.py`
3. Vérifier la documentation avec `/docs`
4. Proposer les modifications

## Dépannage

### Problème de connexion aux services externes

Vérifiez que les URLs dans `.env` sont correctes et que les services sont démarrés.

### Erreur de permissions sur le fichier de données

```bash
chmod 644 data/projects.json
```

### L'API ne démarre pas

Vérifiez que le port 8000 n'est pas déjà utilisé :

```bash
lsof -i :8000
```

## Évolutions futures

- Authentification et autorisation
- Base de données persistante
- Monitoring avancé
- Mise en cache des données
- API WebSocket pour les mises à jour en temps réel