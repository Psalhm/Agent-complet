# Configuration de l'intégration avec les briques

## Vue d'ensemble

Ce guide explique comment configurer l'intégration complète avec les 5 briques du système d'agents IA.

## Étapes de configuration

### 1. Installer les dépendances Python supplémentaires

```bash
cd api
pip install httpx python-dotenv
```

### 2. Créer le fichier .env

```bash
cp .env.example .env
```

### 3. Configurer les URLs et clés API

Éditez le fichier `.env` avec vos informations :

```env
# Brique 1 - Mémoire évolutive & unifiée
MEMORY_BRICK_URL=https://votre-url-memoire.com
MEMORY_BRICK_API_KEY=votre_cle_api_memoire

# Brique 2 - Feedback loop autonome
FEEDBACK_BRICK_URL=https://votre-url-feedback.com
FEEDBACK_BRICK_API_KEY=votre_cle_api_feedback

# Brique 3 - Génération d'agents enfants spécialisés
GENERATION_BRICK_URL=https://votre-url-generation.com
GENERATION_BRICK_API_KEY=votre_cle_api_generation

# Brique 4 - Langage d'orchestration inter-agent
ORCHESTRATION_BRICK_URL=https://votre-url-orchestration.com
ORCHESTRATION_BRICK_API_KEY=votre_cle_api_orchestration

# Brique 5 - Suivi des décisions et logs intelligents
LOGS_BRICK_URL=https://votre-url-logs.com
LOGS_BRICK_API_KEY=votre_cle_api_logs
```

### 4. Tester la configuration

```bash
cd api
python3 -c "
import asyncio
from bricks_integration import bricks_manager

async def test():
    health = await bricks_manager.check_all_bricks_health()
    for brick, status in health.items():
        print(f'{brick}: {status[\"status\"]}')

asyncio.run(test())
"
```

## Nouveaux endpoints disponibles

### État des briques
- `GET /bricks/health` - Vérifier l'état de toutes les briques

### Mémoire (Brique 1)
- `POST /projects/{project_id}/agents/{agent_id}/memory` - Mettre à jour la mémoire
- `GET /projects/{project_id}/agents/{agent_id}/memory` - Récupérer la mémoire

### Feedback (Brique 2)
- `POST /projects/{project_id}/agents/{agent_id}/feedback` - Créer une boucle de feedback
- `GET /projects/{project_id}/agents/{agent_id}/feedback/metrics` - Récupérer les métriques

### Génération (Brique 3)
- `POST /projects/{project_id}/agents/{agent_id}/generate-child` - Générer un agent enfant
- `GET /agent-templates` - Récupérer les modèles d'agents

### Orchestration (Brique 4)
- `POST /projects/{project_id}/orchestration/workflow` - Créer un workflow
- `POST /projects/{project_id}/agents/{agent_id}/execute` - Exécuter une commande

### Logs intelligents (Brique 5)
- `GET /projects/{project_id}/agents/{agent_id}/decisions` - Historique des décisions
- `GET /projects/{project_id}/agents/{agent_id}/analyze` - Analyser le comportement

## Exemples d'utilisation

### Créer un agent avec intégration complète

```python
# L'API intègre automatiquement avec toutes les briques lors de la création d'un agent
project_data = {
    "name": "Projet avec intégration",
    "description": "Test des briques intégrées",
    "agents": [
        {
            "name": "Agent Intégré",
            "role": "Assistant virtuel",
            "task": "Tester l'intégration complète",
            "priority": "high"
        }
    ]
}

# POST /projects avec cette configuration activera automatiquement :
# - Mémoire de l'agent
# - Boucle de feedback
# - Logs intelligents
# - Workflow d'orchestration
```

### Utiliser les fonctionnalités avancées

```bash
# Générer un agent enfant spécialisé
curl -X POST http://localhost:8000/projects/{project_id}/agents/{agent_id}/generate-child \
  -H "Content-Type: application/json" \
  -d '{
    "specialization": "data_analysis",
    "inherit_memory": true,
    "performance_threshold": 0.8
  }'

# Analyser le comportement d'un agent
curl http://localhost:8000/projects/{project_id}/agents/{agent_id}/analyze?timeframe=7d

# Créer un workflow d'orchestration
curl -X POST http://localhost:8000/projects/{project_id}/orchestration/workflow \
  -H "Content-Type: application/json" \
  -d '{
    "workflow_type": "collaborative_task",
    "agents": ["agent1", "agent2"],
    "coordination_rules": ["sequential", "parallel"]
  }'
```

## Démarrage avec l'intégration

```bash
# Démarrer l'API avec toutes les intégrations
cd api
python3 simple_api.py
```

L'API sera disponible sur `http://localhost:8000` avec la documentation interactive sur `/docs`.

## Surveillance et monitoring

L'endpoint `/bricks/health` permet de surveiller l'état de toutes les briques en temps réel :

```json
{
  "memory": {"status": "healthy", "data": {...}},
  "feedback": {"status": "healthy", "data": {...}},
  "generation": {"status": "healthy", "data": {...}},
  "orchestration": {"status": "healthy", "data": {...}},
  "logs": {"status": "healthy", "data": {...}}
}
```

## Dépannage

### Problèmes de connexion
- Vérifiez les URLs dans le fichier `.env`
- Testez la connectivité avec `curl` ou `ping`
- Vérifiez les certificats SSL pour les URLs HTTPS

### Problèmes d'authentification
- Vérifiez que les clés API sont correctes
- Assurez-vous que les clés ont les permissions nécessaires
- Testez les clés avec l'API de la brique directement

### Problèmes de performance
- Ajustez les timeouts dans `bricks_integration.py`
- Surveillez les logs pour identifier les goulots d'étranglement
- Utilisez la surveillance en temps réel avec `/bricks/health`