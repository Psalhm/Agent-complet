"""
Script pour démarrer l'API de contrôle d'agents IA

Ce script permet de démarrer facilement l'API avec les bonnes configurations.
"""

import os
import sys
import uvicorn
from dotenv import load_dotenv

# Charger les variables d'environnement
load_dotenv()

def main():
    """Fonction principale pour démarrer l'API"""
    
    # Configuration par défaut
    host = os.getenv("API_HOST", "0.0.0.0")
    port = int(os.getenv("API_PORT", "8000"))
    log_level = os.getenv("LOG_LEVEL", "info").lower()
    
    # Vérifier que le fichier de données existe
    if not os.path.exists("data"):
        os.makedirs("data")
    
    if not os.path.exists("data/projects.json"):
        with open("data/projects.json", "w") as f:
            f.write("[]")
    
    print(f"🚀 Démarrage de l'API de contrôle d'agents IA")
    print(f"   Host: {host}")
    print(f"   Port: {port}")
    print(f"   Log Level: {log_level}")
    print(f"   Data Directory: {os.path.abspath('data')}")
    
    # Afficher les URLs des services externes configurés
    external_services = {
        "API Mémoire": os.getenv("MEMORY_API_URL", "Non configuré"),
        "API Logs": os.getenv("LOGS_API_URL", "Non configuré"),
        "API Génération": os.getenv("AGENT_GEN_API_URL", "Non configuré"),
    }
    
    print("\n🔗 Services externes configurés:")
    for service, url in external_services.items():
        print(f"   {service}: {url}")
    
    print(f"\n📡 API disponible sur: http://{host}:{port}")
    print(f"📚 Documentation: http://{host}:{port}/docs")
    print(f"🔧 Health Check: http://{host}:{port}/health")
    
    # Démarrer l'API
    try:
        uvicorn.run(
            "agent_control_api:app",
            host=host,
            port=port,
            log_level=log_level,
            reload=True,  # Rechargement automatique en développement
            reload_dirs=["api"],  # Surveiller uniquement le dossier api
        )
    except KeyboardInterrupt:
        print("\n👋 Arrêt de l'API...")
    except Exception as e:
        print(f"❌ Erreur lors du démarrage: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()