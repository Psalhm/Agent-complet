#!/usr/bin/env python3
"""
API Simple de Contrôle d'Agents IA - Version Fonctionnelle

API FastAPI simplifiée pour démontrer les fonctionnalités de contrôle d'agents.
"""

import json
import os
import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any
from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from bricks_integration import (
    bricks_manager, memory_brick, feedback_brick, generation_brick, 
    orchestration_brick, logs_brick, integrate_with_all_bricks
)

# Créer l'application FastAPI
app = FastAPI(
    title="Agent Control API",
    description="API pour contrôler et orchestrer les agents IA",
    version="1.0.0"
)

# Configuration CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Modèles Pydantic
class Agent(BaseModel):
    id: str
    name: str
    role: str
    task: str
    status: str = "stopped"
    priority: str = "medium"
    created_at: datetime = Field(default_factory=datetime.now)
    last_activity: Optional[datetime] = None
    performance_metrics: Dict[str, Any] = Field(default_factory=dict)

class CreateProjectRequest(BaseModel):
    name: str
    description: str
    agents: List[Dict[str, Any]] = Field(default_factory=list)

class Project(BaseModel):
    id: str
    name: str
    description: str
    status: str = "inactive"
    created_at: datetime = Field(default_factory=datetime.now)
    agents: List[Agent] = Field(default_factory=list)
    total_tasks: int = 0
    completed_tasks: int = 0
    error_count: int = 0

# Stockage en mémoire pour la démonstration
projects_storage = []

# Fonctions utilitaires
def get_project_by_id(project_id: str) -> Optional[Project]:
    for project in projects_storage:
        if project.id == project_id:
            return project
    return None

def save_project(project: Project):
    for i, p in enumerate(projects_storage):
        if p.id == project.id:
            projects_storage[i] = project
            return
    projects_storage.append(project)

# Endpoints de l'API
@app.get("/")
async def root():
    return {
        "message": "API de contrôle d'agents IA",
        "version": "1.0.0",
        "status": "actif",
        "projects_count": len(projects_storage),
        "endpoints": [
            "GET /projects",
            "POST /projects",
            "GET /projects/{project_id}",
            "POST /projects/{project_id}/start",
            "POST /projects/{project_id}/stop",
            "GET /projects/{project_id}/logs",
            "GET /health"
        ]
    }

@app.get("/health")
async def health_check():
    # Vérifier l'état des briques
    bricks_health = await bricks_manager.check_all_bricks_health()
    
    return {
        "api_status": "healthy",
        "bricks_status": bricks_health,
        "timestamp": datetime.now().isoformat(),
        "projects_count": len(projects_storage),
        "memory_usage": "OK"
    }

@app.get("/projects", response_model=List[Project])
async def get_projects():
    return projects_storage

@app.post("/projects", response_model=Project)
async def create_project(request: CreateProjectRequest):
    project_id = str(uuid.uuid4())
    
    # Créer les agents
    agents = []
    for agent_data in request.agents:
        agent = Agent(
            id=str(uuid.uuid4()),
            name=agent_data.get("name", "Agent sans nom"),
            role=agent_data.get("role", "Assistant"),
            task=agent_data.get("task", "Tâche non définie"),
            status="stopped",
            priority=agent_data.get("priority", "medium")
        )
        agents.append(agent)
    
    # Créer le projet
    new_project = Project(
        id=project_id,
        name=request.name,
        description=request.description,
        agents=agents,
        status="inactive"
    )
    
    save_project(new_project)
    return new_project

@app.get("/projects/{project_id}", response_model=Project)
async def get_project(project_id: str):
    project = get_project_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Projet non trouvé")
    return project

@app.post("/projects/{project_id}/start")
async def start_project(project_id: str):
    project = get_project_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Projet non trouvé")
    
    # Mettre à jour le statut
    project.status = "active"
    started_agents = []
    
    for agent in project.agents:
        if agent.status == "stopped":
            agent.status = "running"
            agent.last_activity = datetime.now()
            started_agents.append(agent.id)
    
    save_project(project)
    
    return {
        "status": "success",
        "message": f"Projet démarré avec {len(started_agents)} agents",
        "project_id": project_id,
        "started_agents": started_agents
    }

@app.post("/projects/{project_id}/stop")
async def stop_project(project_id: str):
    project = get_project_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Projet non trouvé")
    
    # Mettre à jour le statut
    project.status = "inactive"
    stopped_agents = []
    
    for agent in project.agents:
        if agent.status == "running":
            agent.status = "stopped"
            agent.last_activity = datetime.now()
            stopped_agents.append(agent.id)
    
    save_project(project)
    
    return {
        "status": "success",
        "message": f"Projet arrêté - {len(stopped_agents)} agents désactivés",
        "project_id": project_id,
        "stopped_agents": stopped_agents
    }

@app.get("/projects/{project_id}/logs")
async def get_project_logs(project_id: str, limit: int = 50):
    project = get_project_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Projet non trouvé")
    
    # Logs simulés pour la démonstration
    logs = [
        {
            "timestamp": datetime.now().isoformat(),
            "project_id": project_id,
            "agent_id": agent.id,
            "level": "info",
            "message": f"Agent {agent.name} - Status: {agent.status}",
            "source": "agent_control"
        }
        for agent in project.agents
    ]
    
    return {"logs": logs, "total": len(logs)}

@app.get("/projects/{project_id}/agents/{agent_id}/status")
async def get_agent_status(project_id: str, agent_id: str):
    project = get_project_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Projet non trouvé")
    
    agent = next((a for a in project.agents if a.id == agent_id), None)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent non trouvé")
    
    return {
        "agent": agent,
        "project_id": project_id,
        "status": agent.status,
        "last_activity": agent.last_activity
    }

@app.post("/projects/{project_id}/agents/{agent_id}/start")
async def start_agent(project_id: str, agent_id: str):
    project = get_project_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Projet non trouvé")
    
    agent = next((a for a in project.agents if a.id == agent_id), None)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent non trouvé")
    
    agent.status = "running"
    agent.last_activity = datetime.now()
    save_project(project)
    
    return {
        "status": "success",
        "message": f"Agent {agent.name} démarré",
        "agent_id": agent_id,
        "project_id": project_id
    }

@app.post("/projects/{project_id}/agents/{agent_id}/stop")
async def stop_agent(project_id: str, agent_id: str):
    project = get_project_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Projet non trouvé")
    
    agent = next((a for a in project.agents if a.id == agent_id), None)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent non trouvé")
    
    agent.status = "stopped"
    agent.last_activity = datetime.now()
    save_project(project)
    
    # Intégrer avec les briques
    try:
        await logs_brick.create_intelligent_log({
            "agent_id": agent_id,
            "project_id": project_id,
            "event": "agent_stopped",
            "data": {"agent_name": agent.name, "timestamp": datetime.now().isoformat()}
        })
    except Exception as e:
        print(f"Erreur lors de l'intégration avec les logs: {e}")
    
    return {
        "status": "success",
        "message": f"Agent {agent.name} arrêté",
        "agent_id": agent_id,
        "project_id": project_id
    }

# Nouveaux endpoints pour l'intégration avec les briques

@app.get("/bricks/health")
async def get_bricks_health():
    """Vérifier l'état de toutes les briques"""
    return await bricks_manager.check_all_bricks_health()

@app.post("/projects/{project_id}/agents/{agent_id}/memory")
async def update_agent_memory(project_id: str, agent_id: str, memory_data: Dict[str, Any]):
    """Mettre à jour la mémoire d'un agent"""
    try:
        result = await memory_brick.store_agent_memory(agent_id, memory_data)
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/projects/{project_id}/agents/{agent_id}/memory")
async def get_agent_memory(project_id: str, agent_id: str):
    """Récupérer la mémoire d'un agent"""
    try:
        result = await memory_brick.get_agent_memory(agent_id)
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/projects/{project_id}/agents/{agent_id}/feedback")
async def create_feedback_loop(project_id: str, agent_id: str, feedback_config: Dict[str, Any]):
    """Créer une boucle de feedback pour un agent"""
    try:
        result = await feedback_brick.create_feedback_loop(agent_id, feedback_config)
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/projects/{project_id}/agents/{agent_id}/feedback/metrics")
async def get_feedback_metrics(project_id: str, agent_id: str):
    """Récupérer les métriques de feedback d'un agent"""
    try:
        result = await feedback_brick.get_feedback_metrics(agent_id)
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/projects/{project_id}/agents/{agent_id}/generate-child")
async def generate_child_agent(project_id: str, agent_id: str, specification: Dict[str, Any]):
    """Générer un agent enfant spécialisé"""
    try:
        result = await generation_brick.generate_child_agent(agent_id, specification)
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/agent-templates")
async def get_agent_templates():
    """Récupérer les modèles d'agents disponibles"""
    try:
        result = await generation_brick.get_agent_templates()
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/projects/{project_id}/orchestration/workflow")
async def create_orchestration_workflow(project_id: str, workflow_config: Dict[str, Any]):
    """Créer un workflow d'orchestration"""
    try:
        result = await orchestration_brick.create_agent_workflow(project_id, workflow_config)
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/projects/{project_id}/agents/{agent_id}/execute")
async def execute_agent_command(project_id: str, agent_id: str, command: Dict[str, Any]):
    """Exécuter une commande d'orchestration"""
    try:
        result = await orchestration_brick.execute_agent_command(agent_id, command)
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/projects/{project_id}/agents/{agent_id}/decisions")
async def get_agent_decisions(project_id: str, agent_id: str):
    """Récupérer l'historique des décisions d'un agent"""
    try:
        result = await logs_brick.get_decision_history(agent_id)
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/projects/{project_id}/agents/{agent_id}/analyze")
async def analyze_agent_behavior(project_id: str, agent_id: str, timeframe: str = "24h"):
    """Analyser le comportement d'un agent"""
    try:
        result = await logs_brick.analyze_agent_behavior(agent_id, timeframe)
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    print("🚀 Démarrage de l'API de contrôle d'agents IA")
    print("📡 API disponible sur: http://localhost:8000")
    print("📚 Documentation: http://localhost:8000/docs")
    uvicorn.run(app, host="0.0.0.0", port=8000)