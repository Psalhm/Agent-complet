#!/usr/bin/env python3
"""
Intégration avec les briques du système d'agents IA

Ce module gère l'intégration avec les 5 briques principales :
1. Brique 1 - Mémoire évolutive & unifiée
2. Brique 2 - Feedback loop autonome  
3. Brique 3 - Génération d'agents enfants spécialisés
4. Brique 4 - Langage d'orchestration inter-agent
5. Brique 5 - Suivi des décisions et logs intelligents
"""

import os
import httpx
from typing import Dict, Any, Optional, List
from datetime import datetime
import json
import asyncio
from pydantic import BaseModel


class BrickConfig(BaseModel):
    """Configuration d'une brique"""
    name: str
    url: str
    api_key: Optional[str] = None
    timeout: int = 30
    enabled: bool = True


class BricksManager:
    """Gestionnaire des intégrations avec les briques"""
    
    def __init__(self):
        self.bricks = {
            "memory": BrickConfig(
                name="Mémoire évolutive & unifiée",
                url=os.getenv("MEMORY_BRICK_URL", "http://localhost:8001"),
                api_key=os.getenv("MEMORY_BRICK_API_KEY")
            ),
            "feedback": BrickConfig(
                name="Feedback loop autonome",
                url=os.getenv("FEEDBACK_BRICK_URL", "http://localhost:8002"),
                api_key=os.getenv("FEEDBACK_BRICK_API_KEY")
            ),
            "generation": BrickConfig(
                name="Génération d'agents enfants spécialisés",
                url=os.getenv("GENERATION_BRICK_URL", "http://localhost:8003"),
                api_key=os.getenv("GENERATION_BRICK_API_KEY")
            ),
            "orchestration": BrickConfig(
                name="Langage d'orchestration inter-agent",
                url=os.getenv("ORCHESTRATION_BRICK_URL", "http://localhost:8004"),
                api_key=os.getenv("ORCHESTRATION_BRICK_API_KEY")
            ),
            "logs": BrickConfig(
                name="Suivi des décisions et logs intelligents",
                url=os.getenv("LOGS_BRICK_URL", "http://localhost:8005"),
                api_key=os.getenv("LOGS_BRICK_API_KEY")
            )
        }
    
    def get_auth_headers(self, brick_name: str) -> Dict[str, str]:
        """Récupérer les headers d'authentification pour une brique"""
        brick = self.bricks.get(brick_name)
        if not brick or not brick.api_key:
            return {}
        
        return {
            "Authorization": f"Bearer {brick.api_key}",
            "Content-Type": "application/json"
        }
    
    async def call_brick(self, brick_name: str, endpoint: str, method: str = "GET", data: Optional[Dict] = None) -> Dict:
        """Appeler une brique spécifique"""
        brick = self.bricks.get(brick_name)
        if not brick or not brick.enabled:
            raise ValueError(f"Brique '{brick_name}' non disponible ou désactivée")
        
        url = f"{brick.url}{endpoint}"
        headers = self.get_auth_headers(brick_name)
        
        async with httpx.AsyncClient(timeout=brick.timeout) as client:
            try:
                if method.upper() == "GET":
                    response = await client.get(url, headers=headers)
                elif method.upper() == "POST":
                    response = await client.post(url, headers=headers, json=data)
                elif method.upper() == "PUT":
                    response = await client.put(url, headers=headers, json=data)
                elif method.upper() == "DELETE":
                    response = await client.delete(url, headers=headers)
                else:
                    raise ValueError(f"Méthode HTTP non supportée: {method}")
                
                response.raise_for_status()
                return response.json()
                
            except httpx.HTTPError as e:
                raise Exception(f"Erreur lors de l'appel à {brick.name}: {str(e)}")
    
    async def check_brick_health(self, brick_name: str) -> Dict:
        """Vérifier l'état d'une brique"""
        try:
            result = await self.call_brick(brick_name, "/health")
            return {"status": "healthy", "data": result}
        except Exception as e:
            return {"status": "unhealthy", "error": str(e)}
    
    async def check_all_bricks_health(self) -> Dict:
        """Vérifier l'état de toutes les briques"""
        results = {}
        for brick_name in self.bricks.keys():
            results[brick_name] = await self.check_brick_health(brick_name)
        return results


class MemoryBrick:
    """Interface avec la brique de mémoire évolutive"""
    
    def __init__(self, manager: BricksManager):
        self.manager = manager
        self.brick_name = "memory"
    
    async def store_agent_memory(self, agent_id: str, memory_data: Dict) -> Dict:
        """Stocker des données de mémoire pour un agent"""
        return await self.manager.call_brick(
            self.brick_name,
            f"/agents/{agent_id}/memory",
            "POST",
            memory_data
        )
    
    async def get_agent_memory(self, agent_id: str) -> Dict:
        """Récupérer la mémoire d'un agent"""
        return await self.manager.call_brick(
            self.brick_name,
            f"/agents/{agent_id}/memory",
            "GET"
        )
    
    async def update_unified_memory(self, project_id: str, memory_data: Dict) -> Dict:
        """Mettre à jour la mémoire unifiée du projet"""
        return await self.manager.call_brick(
            self.brick_name,
            f"/projects/{project_id}/unified-memory",
            "POST",
            memory_data
        )


class FeedbackBrick:
    """Interface avec la brique de feedback autonome"""
    
    def __init__(self, manager: BricksManager):
        self.manager = manager
        self.brick_name = "feedback"
    
    async def create_feedback_loop(self, agent_id: str, loop_config: Dict) -> Dict:
        """Créer une boucle de feedback pour un agent"""
        return await self.manager.call_brick(
            self.brick_name,
            f"/agents/{agent_id}/feedback-loop",
            "POST",
            loop_config
        )
    
    async def get_feedback_metrics(self, agent_id: str) -> Dict:
        """Récupérer les métriques de feedback d'un agent"""
        return await self.manager.call_brick(
            self.brick_name,
            f"/agents/{agent_id}/metrics",
            "GET"
        )


class GenerationBrick:
    """Interface avec la brique de génération d'agents"""
    
    def __init__(self, manager: BricksManager):
        self.manager = manager
        self.brick_name = "generation"
    
    async def generate_child_agent(self, parent_id: str, specification: Dict) -> Dict:
        """Générer un agent enfant spécialisé"""
        return await self.manager.call_brick(
            self.brick_name,
            f"/agents/{parent_id}/generate-child",
            "POST",
            specification
        )
    
    async def get_agent_templates(self) -> Dict:
        """Récupérer les modèles d'agents disponibles"""
        return await self.manager.call_brick(
            self.brick_name,
            "/templates",
            "GET"
        )


class OrchestrationBrick:
    """Interface avec la brique d'orchestration inter-agent"""
    
    def __init__(self, manager: BricksManager):
        self.manager = manager
        self.brick_name = "orchestration"
    
    async def create_agent_workflow(self, project_id: str, workflow_config: Dict) -> Dict:
        """Créer un workflow d'orchestration"""
        return await self.manager.call_brick(
            self.brick_name,
            f"/projects/{project_id}/workflows",
            "POST",
            workflow_config
        )
    
    async def execute_agent_command(self, agent_id: str, command: Dict) -> Dict:
        """Exécuter une commande d'orchestration"""
        return await self.manager.call_brick(
            self.brick_name,
            f"/agents/{agent_id}/execute",
            "POST",
            command
        )


class LogsBrick:
    """Interface avec la brique de logs intelligents"""
    
    def __init__(self, manager: BricksManager):
        self.manager = manager
        self.brick_name = "logs"
    
    async def create_intelligent_log(self, log_data: Dict) -> Dict:
        """Créer un log intelligent avec analyse"""
        return await self.manager.call_brick(
            self.brick_name,
            "/logs",
            "POST",
            log_data
        )
    
    async def get_decision_history(self, agent_id: str) -> Dict:
        """Récupérer l'historique des décisions d'un agent"""
        return await self.manager.call_brick(
            self.brick_name,
            f"/agents/{agent_id}/decisions",
            "GET"
        )
    
    async def analyze_agent_behavior(self, agent_id: str, timeframe: str = "24h") -> Dict:
        """Analyser le comportement d'un agent"""
        return await self.manager.call_brick(
            self.brick_name,
            f"/agents/{agent_id}/analyze?timeframe={timeframe}",
            "GET"
        )


# Instance globale du gestionnaire
bricks_manager = BricksManager()
memory_brick = MemoryBrick(bricks_manager)
feedback_brick = FeedbackBrick(bricks_manager)
generation_brick = GenerationBrick(bricks_manager)
orchestration_brick = OrchestrationBrick(bricks_manager)
logs_brick = LogsBrick(bricks_manager)


async def integrate_with_all_bricks(project_id: str, agent_data: Dict) -> Dict:
    """Intégrer avec toutes les briques lors de la création d'un agent"""
    results = {}
    
    try:
        # 1. Initialiser la mémoire de l'agent
        results["memory"] = await memory_brick.store_agent_memory(
            agent_data["id"],
            {
                "agent_name": agent_data["name"],
                "role": agent_data["role"],
                "task": agent_data["task"],
                "created_at": datetime.now().isoformat()
            }
        )
        
        # 2. Créer une boucle de feedback
        results["feedback"] = await feedback_brick.create_feedback_loop(
            agent_data["id"],
            {
                "metrics": ["performance", "accuracy", "speed"],
                "threshold": 0.8,
                "auto_adjust": True
            }
        )
        
        # 3. Créer un log intelligent de création
        results["logs"] = await logs_brick.create_intelligent_log({
            "agent_id": agent_data["id"],
            "project_id": project_id,
            "event": "agent_created",
            "data": agent_data,
            "timestamp": datetime.now().isoformat()
        })
        
        # 4. Créer un workflow d'orchestration de base
        results["orchestration"] = await orchestration_brick.create_agent_workflow(
            project_id,
            {
                "agent_id": agent_data["id"],
                "workflow_type": "basic_monitoring",
                "triggers": ["status_change", "error_detected"]
            }
        )
        
        return {"status": "success", "integrations": results}
        
    except Exception as e:
        return {"status": "error", "message": str(e), "partial_results": results}


if __name__ == "__main__":
    # Test de base
    async def test_integration():
        print("🔧 Test d'intégration avec les briques...")
        
        # Vérifier l'état des briques
        health_status = await bricks_manager.check_all_bricks_health()
        for brick_name, status in health_status.items():
            print(f"📡 {brick_name}: {status['status']}")
        
        print("✅ Test terminé")
    
    asyncio.run(test_integration())