#!/usr/bin/env python3
"""
Démonstration de l'API de contrôle d'agents IA

Cette démo montre l'utilisation de l'API avec des exemples concrets.
"""

import json
import uuid
from datetime import datetime

# Simulation des données pour démonstration
def create_demo_data():
    """Créer des données de démonstration"""
    
    # Projet exemple 1
    project1 = {
        "id": str(uuid.uuid4()),
        "name": "Assistant Marketing IA",
        "description": "Système d'agents pour automatiser les tâches marketing",
        "status": "active",
        "created_at": datetime.now().isoformat(),
        "agents": [
            {
                "id": str(uuid.uuid4()),
                "name": "Agent Rédacteur",
                "role": "Assistant virtuel",
                "task": "Générer du contenu marketing personnalisé",
                "status": "running",
                "priority": "high",
                "created_at": datetime.now().isoformat(),
                "last_activity": datetime.now().isoformat(),
                "performance_metrics": {
                    "tasks_completed": 24,
                    "success_rate": 0.95,
                    "avg_response_time": "2.3s"
                }
            },
            {
                "id": str(uuid.uuid4()),
                "name": "Agent Analyseur",
                "role": "Analyseur de données",
                "task": "Analyser les performances des campagnes",
                "status": "running",
                "priority": "medium",
                "created_at": datetime.now().isoformat(),
                "last_activity": datetime.now().isoformat(),
                "performance_metrics": {
                    "tasks_completed": 18,
                    "success_rate": 0.88,
                    "avg_response_time": "3.1s"
                }
            }
        ],
        "total_tasks": 42,
        "completed_tasks": 35,
        "error_count": 2
    }
    
    # Projet exemple 2
    project2 = {
        "id": str(uuid.uuid4()),
        "name": "Surveillance Système",
        "description": "Agents de monitoring et maintenance automatisée",
        "status": "inactive",
        "created_at": datetime.now().isoformat(),
        "agents": [
            {
                "id": str(uuid.uuid4()),
                "name": "Agent Monitoring",
                "role": "Surveillance système",
                "task": "Surveiller les performances du système",
                "status": "stopped",
                "priority": "high",
                "created_at": datetime.now().isoformat(),
                "last_activity": None,
                "performance_metrics": {}
            }
        ],
        "total_tasks": 15,
        "completed_tasks": 12,
        "error_count": 1
    }
    
    return [project1, project2]

def demo_endpoints():
    """Démonstration des endpoints de l'API"""
    
    print("🚀 Démonstration de l'API de contrôle d'agents IA")
    print("=" * 60)
    
    # Créer des données de test
    projects = create_demo_data()
    
    print(f"\n📊 Données générées: {len(projects)} projets")
    
    # Simuler les réponses des endpoints
    print(f"\n🔍 GET /projects")
    print(f"   Status: 200 OK")
    print(f"   Response: {len(projects)} projets trouvés")
    
    for i, project in enumerate(projects):
        print(f"\n📋 Projet {i+1}: {project['name']}")
        print(f"   ID: {project['id']}")
        print(f"   Status: {project['status']}")
        print(f"   Agents: {len(project['agents'])}")
        print(f"   Tâches terminées: {project['completed_tasks']}/{project['total_tasks']}")
        
        # Simuler GET /projects/{id}
        print(f"\n🔍 GET /projects/{project['id']}")
        print(f"   Status: 200 OK")
        print(f"   Description: {project['description']}")
        
        # Simuler les contrôles d'agents
        if project['status'] == 'active':
            print(f"\n⏹️  POST /projects/{project['id']}/stop")
            print(f"   Status: 200 OK")
            print(f"   Message: Projet arrêté - {len(project['agents'])} agents désactivés")
        else:
            print(f"\n▶️  POST /projects/{project['id']}/start")
            print(f"   Status: 200 OK")
            print(f"   Message: Projet démarré avec {len(project['agents'])} agents")
        
        # Simuler les logs
        print(f"\n📝 GET /projects/{project['id']}/logs")
        print(f"   Status: 200 OK")
        print(f"   Logs: {len(project['agents']) * 3} entrées récentes")
        
        # Détails des agents
        for agent in project['agents']:
            print(f"\n🤖 Agent: {agent['name']}")
            print(f"   Status: {agent['status']}")
            print(f"   Rôle: {agent['role']}")
            print(f"   Tâche: {agent['task']}")
            print(f"   Priorité: {agent['priority']}")
            
            if agent['performance_metrics']:
                print(f"   Performance: {agent['performance_metrics']['success_rate']*100:.1f}%")
                print(f"   Tâches terminées: {agent['performance_metrics']['tasks_completed']}")
    
    print(f"\n🏥 GET /health")
    print(f"   Status: 200 OK")
    print(f"   API Status: healthy")
    print(f"   Projets: {len(projects)}")
    print(f"   Services externes: 3 configurés")
    
    print(f"\n✅ Démonstration terminée!")

def demo_create_project():
    """Démonstration de création d'un projet"""
    
    print(f"\n🆕 Démonstration de création d'un projet")
    print("=" * 50)
    
    # Exemple de données pour créer un projet
    new_project_data = {
        "name": "Nouveau Projet IA",
        "description": "Projet créé via l'API de démonstration",
        "agents": [
            {
                "name": "Agent Test 1",
                "role": "Assistant virtuel",
                "task": "Tester les fonctionnalités de base",
                "priority": "medium"
            },
            {
                "name": "Agent Test 2",
                "role": "Analyseur de données",
                "task": "Analyser les résultats de test",
                "priority": "low"
            }
        ]
    }
    
    print(f"📤 POST /projects")
    print(f"   Données envoyées:")
    print(f"   {json.dumps(new_project_data, indent=2, ensure_ascii=False)}")
    
    # Simuler la réponse
    created_project = {
        "id": str(uuid.uuid4()),
        "name": new_project_data["name"],
        "description": new_project_data["description"],
        "status": "inactive",
        "created_at": datetime.now().isoformat(),
        "agents": [
            {
                "id": str(uuid.uuid4()),
                "name": agent["name"],
                "role": agent["role"],
                "task": agent["task"],
                "status": "stopped",
                "priority": agent["priority"],
                "created_at": datetime.now().isoformat(),
                "last_activity": None,
                "performance_metrics": {}
            }
            for agent in new_project_data["agents"]
        ],
        "total_tasks": 0,
        "completed_tasks": 0,
        "error_count": 0
    }
    
    print(f"\n📥 Status: 201 Created")
    print(f"   Projet créé avec ID: {created_project['id']}")
    print(f"   Nombre d'agents: {len(created_project['agents'])}")
    
    return created_project

def demo_external_integrations():
    """Démonstration des intégrations externes"""
    
    print(f"\n🔗 Démonstration des intégrations externes")
    print("=" * 50)
    
    # Simulation des appels aux autres briques
    external_apis = {
        "API Mémoire (Brique 1)": {
            "url": "http://localhost:8001",
            "endpoints": [
                "GET /metrics/{project_id}",
                "POST /projects",
                "POST /projects/{project_id}/start"
            ],
            "status": "configuré"
        },
        "API Logs (Brique 5)": {
            "url": "http://localhost:8002", 
            "endpoints": [
                "GET /logs/project/{project_id}",
                "POST /logs"
            ],
            "status": "configuré"
        },
        "API Génération (Brique 3)": {
            "url": "http://localhost:8003",
            "endpoints": [
                "POST /generate-agent",
                "GET /agent-templates"
            ],
            "status": "configuré"
        }
    }
    
    for api_name, api_info in external_apis.items():
        print(f"\n🌐 {api_name}")
        print(f"   URL: {api_info['url']}")
        print(f"   Status: {api_info['status']}")
        print(f"   Endpoints disponibles:")
        for endpoint in api_info['endpoints']:
            print(f"     - {endpoint}")

def main():
    """Fonction principale de démonstration"""
    
    print("🎯 API de Contrôle d'Agents IA - Brique 6")
    print("📋 Démonstration des fonctionnalités")
    print("=" * 70)
    
    # Démonstration des endpoints principaux
    demo_endpoints()
    
    # Démonstration de création de projet
    demo_create_project()
    
    # Démonstration des intégrations externes
    demo_external_integrations()
    
    print(f"\n🎉 Fin de la démonstration")
    print("=" * 70)
    print("💡 Pour tester l'API en réel:")
    print("   1. Démarrer l'API: python3 simple_api.py")
    print("   2. Ouvrir: http://localhost:8000/docs")
    print("   3. Tester les endpoints via l'interface Swagger")

if __name__ == "__main__":
    main()