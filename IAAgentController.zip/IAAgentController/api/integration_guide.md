# Guide d'intégration - API de Contrôle d'Agents IA

## Vue d'ensemble

L'API de contrôle d'agents IA (Brique 6) fournit une interface REST pour orchestrer et gérer des agents IA dans un environnement distribué. Cette API fait le lien entre votre dashboard React et les autres services d'agents.

## Configuration rapide

### 1. Démarrage de l'API

```bash
# Naviguer vers le dossier API
cd api

# Démarrer l'API (version simple)
python3 simple_api.py

# Ou utiliser la version complète avec intégrations
python3 agent_control_api.py
```

L'API sera accessible sur `http://localhost:8000`

### 2. Documentation interactive

Une fois l'API démarrée, accédez à :
- **Interface Swagger** : `http://localhost:8000/docs`
- **Documentation ReDoc** : `http://localhost:8000/redoc`

### 3. Tests de l'API

```bash
# Test de base
curl http://localhost:8000/health

# Lister les projets
curl http://localhost:8000/projects

# Créer un projet
curl -X POST http://localhost:8000/projects \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Mon Projet Test",
    "description": "Test de l\u0027API",
    "agents": [
      {
        "name": "Agent Test",
        "role": "Assistant virtuel",
        "task": "Tester les fonctionnalités",
        "priority": "medium"
      }
    ]
  }'
```

## Intégration avec le Dashboard React

### 1. Modifier l'API client

Mise à jour du fichier `client/src/lib/queryClient.ts` pour inclure l'API Python :

```typescript
// Ajouter l'URL de l'API Python
const PYTHON_API_URL = 'http://localhost:8000';

// Nouvelle fonction pour appeler l'API Python
export async function pythonApiRequest(
  method: string,
  endpoint: string,
  data?: any
): Promise<any> {
  const url = `${PYTHON_API_URL}${endpoint}`;
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
  };
  
  if (data) {
    options.body = JSON.stringify(data);
  }
  
  const response = await fetch(url, options);
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return response.json();
}
```

### 2. Créer des hooks pour l'API Python

Créer `client/src/hooks/usePythonApi.ts` :

```typescript
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { pythonApiRequest } from '@/lib/queryClient';

export function usePythonProjects() {
  return useQuery({
    queryKey: ['python-projects'],
    queryFn: () => pythonApiRequest('GET', '/projects'),
  });
}

export function useCreatePythonProject() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (projectData: any) => pythonApiRequest('POST', '/projects', projectData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['python-projects'] });
    },
  });
}

export function useStartPythonProject() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (projectId: string) => pythonApiRequest('POST', `/projects/${projectId}/start`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['python-projects'] });
    },
  });
}

export function useStopPythonProject() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (projectId: string) => pythonApiRequest('POST', `/projects/${projectId}/stop`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['python-projects'] });
    },
  });
}
```

### 3. Composant pour les projets Python

Créer `client/src/components/python-projects.tsx` :

```typescript
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Play, Pause, Plus } from 'lucide-react';
import { usePythonProjects, useStartPythonProject, useStopPythonProject } from '@/hooks/usePythonApi';

export function PythonProjects() {
  const { data: projects = [], isLoading } = usePythonProjects();
  const startProject = useStartPythonProject();
  const stopProject = useStopPythonProject();

  if (isLoading) {
    return <div>Chargement des projets...</div>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Projets d'Agents IA</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {projects.map((project: any) => (
            <div key={project.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-semibold">{project.name}</h3>
                <p className="text-sm text-gray-600">{project.description}</p>
                <div className="flex items-center space-x-2 mt-2">
                  <Badge variant={project.status === 'active' ? 'default' : 'secondary'}>
                    {project.status}
                  </Badge>
                  <span className="text-sm text-gray-500">
                    {project.agents.length} agents
                  </span>
                </div>
              </div>
              <div className="flex space-x-2">
                {project.status === 'active' ? (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => stopProject.mutate(project.id)}
                    disabled={stopProject.isPending}
                  >
                    <Pause className="h-4 w-4" />
                  </Button>
                ) : (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => startProject.mutate(project.id)}
                    disabled={startProject.isPending}
                  >
                    <Play className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
```

## Intégrations avec les autres briques

### Brique 1 - API Mémoire
```python
# Configuration dans .env
MEMORY_API_URL=http://localhost:8001

# Utilisation dans l'API
memory_data = await call_external_api(f"{MEMORY_API_URL}/metrics/{project_id}")
```

### Brique 5 - API Logs
```python
# Configuration dans .env
LOGS_API_URL=http://localhost:8002

# Récupération des logs
logs_data = await call_external_api(f"{LOGS_API_URL}/logs/project/{project_id}")
```

### Brique 3 - Génération d'agents
```python
# Configuration dans .env
AGENT_GEN_API_URL=http://localhost:8003

# Création d'agents via l'API
agent_data = await call_external_api(f"{AGENT_GEN_API_URL}/generate-agent", "POST", {...})
```

## Exemples d'utilisation

### Créer un projet via JavaScript/React

```javascript
const projectData = {
  name: "Assistant Support Client",
  description: "Agents pour gérer le support client automatisé",
  agents: [
    {
      name: "Agent Accueil",
      role: "Assistant virtuel",
      task: "Accueillir les clients et router leurs demandes",
      priority: "high"
    },
    {
      name: "Agent Analyse",
      role: "Analyseur de données",
      task: "Analyser les requêtes clients pour améliorer le service",
      priority: "medium"
    }
  ]
};

fetch('http://localhost:8000/projects', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify(projectData)
})
.then(response => response.json())
.then(data => console.log('Projet créé:', data));
```

### Contrôler un projet via cURL

```bash
# Démarrer un projet
curl -X POST http://localhost:8000/projects/{project_id}/start

# Arrêter un projet
curl -X POST http://localhost:8000/projects/{project_id}/stop

# Récupérer les logs
curl http://localhost:8000/projects/{project_id}/logs?limit=100

# Contrôler un agent spécifique
curl -X POST http://localhost:8000/projects/{project_id}/agents/{agent_id}/start
```

## Surveillance et monitoring

### Health check
```bash
curl http://localhost:8000/health
```

### Métriques des projets
```bash
curl http://localhost:8000/projects/{project_id}
```

## Configuration avancée

### Variables d'environnement

Créer un fichier `.env` dans le dossier `api/` :

```env
# APIs des autres briques
MEMORY_API_URL=http://localhost:8001
LOGS_API_URL=http://localhost:8002
AGENT_GEN_API_URL=http://localhost:8003

# Configuration serveur
API_HOST=0.0.0.0
API_PORT=8000
LOG_LEVEL=INFO

# Timeouts et retry
API_TIMEOUT=30
MAX_RETRIES=3
```

### Déploiement

Pour déployer l'API en production :

```bash
# Installer les dépendances
pip install -r requirements.txt

# Démarrer avec Gunicorn (production)
gunicorn -w 4 -k uvicorn.workers.UvicornWorker agent_control_api:app --bind 0.0.0.0:8000

# Ou avec Uvicorn (développement)
uvicorn agent_control_api:app --host 0.0.0.0 --port 8000 --reload
```

## Dépannage

### Problèmes courants

1. **API non accessible** : Vérifier que Python et les dépendances sont installées
2. **Erreurs CORS** : Configurer les origines autorisées dans l'API
3. **Services externes non disponibles** : Vérifier les URLs dans `.env`
4. **Données perdues** : Les données sont stockées en mémoire, redémarrer l'API les efface

### Logs et débogage

```bash
# Voir les logs de l'API
tail -f api.log

# Tester la connectivité
curl -v http://localhost:8000/health
```

## Prochaines étapes

1. Implémenter l'authentification
2. Ajouter une base de données persistante
3. Créer des webhooks pour les notifications
4. Implémenter la mise en cache
5. Ajouter des métriques de performance détaillées