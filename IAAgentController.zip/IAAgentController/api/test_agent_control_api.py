"""
Tests pour l'API de contrôle d'agents IA

Ce fichier contient des tests pour valider le bon fonctionnement de tous les endpoints
de l'API de contrôle d'agents.
"""

import json
import asyncio
import httpx
from datetime import datetime

# Configuration des tests
API_BASE_URL = "http://localhost:8000"
TEST_TIMEOUT = 30

class TestAgentControlAPI:
    """Classe de tests pour l'API de contrôle d'agents"""
    
    def __init__(self):
        self.client = httpx.AsyncClient(base_url=API_BASE_URL, timeout=TEST_TIMEOUT)
        self.test_project_id = None
        self.test_agent_id = None
    
    async def setup(self):
        """Initialiser les tests"""
        print("🔧 Initialisation des tests...")
        
        # Vérifier que l'API est accessible
        try:
            response = await self.client.get("/")
            assert response.status_code == 200
            print("✅ API accessible")
        except Exception as e:
            print(f"❌ API inaccessible: {e}")
            raise
    
    async def cleanup(self):
        """Nettoyer après les tests"""
        print("🧹 Nettoyage des tests...")
        await self.client.aclose()
    
    async def test_root_endpoint(self):
        """Test de l'endpoint racine"""
        print("\n📋 Test de l'endpoint racine...")
        
        response = await self.client.get("/")
        assert response.status_code == 200
        
        data = response.json()
        assert "message" in data
        assert "version" in data
        assert "endpoints" in data
        
        print("✅ Endpoint racine fonctionne correctement")
        return True
    
    async def test_health_check(self):
        """Test du health check"""
        print("\n🏥 Test du health check...")
        
        response = await self.client.get("/health")
        assert response.status_code == 200
        
        data = response.json()
        assert "api_status" in data
        assert "timestamp" in data
        assert "external_services" in data
        
        print("✅ Health check fonctionne correctement")
        return True
    
    async def test_get_projects_empty(self):
        """Test de récupération des projets (liste vide)"""
        print("\n📂 Test de récupération des projets (liste vide)...")
        
        response = await self.client.get("/projects")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
        
        print(f"✅ Récupération des projets réussie ({len(data)} projets)")
        return True
    
    async def test_create_project(self):
        """Test de création d'un projet"""
        print("\n🆕 Test de création d'un projet...")
        
        project_data = {
            "name": "Projet Test API",
            "description": "Projet de test pour l'API de contrôle d'agents",
            "agents": [
                {
                    "name": "Agent Test 1",
                    "role": "Assistant virtuel",
                    "task": "Tâche de test numéro 1",
                    "priority": "high"
                },
                {
                    "name": "Agent Test 2",
                    "role": "Analyseur de données",
                    "task": "Analyser les données de test",
                    "priority": "medium"
                }
            ]
        }
        
        response = await self.client.post("/projects", json=project_data)
        assert response.status_code == 200
        
        data = response.json()
        assert "id" in data
        assert data["name"] == project_data["name"]
        assert data["description"] == project_data["description"]
        assert len(data["agents"]) == 2
        assert data["status"] == "inactive"
        
        # Sauvegarder l'ID pour les tests suivants
        self.test_project_id = data["id"]
        self.test_agent_id = data["agents"][0]["id"]
        
        print(f"✅ Projet créé avec succès (ID: {self.test_project_id})")
        return True
    
    async def test_get_projects_with_data(self):
        """Test de récupération des projets avec données"""
        print("\n📂 Test de récupération des projets avec données...")
        
        response = await self.client.get("/projects")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
        assert len(data) > 0
        
        # Vérifier que notre projet de test est présent
        project_found = any(p["id"] == self.test_project_id for p in data)
        assert project_found, "Projet de test non trouvé dans la liste"
        
        print(f"✅ Récupération des projets réussie ({len(data)} projets)")
        return True
    
    async def test_get_project_detail(self):
        """Test de récupération des détails d'un projet"""
        print("\n🔍 Test de récupération des détails d'un projet...")
        
        response = await self.client.get(f"/projects/{self.test_project_id}")
        assert response.status_code == 200
        
        data = response.json()
        assert data["id"] == self.test_project_id
        assert "name" in data
        assert "description" in data
        assert "agents" in data
        assert "status" in data
        
        print(f"✅ Détails du projet récupérés (Status: {data['status']})")
        return True
    
    async def test_get_project_not_found(self):
        """Test de récupération d'un projet inexistant"""
        print("\n❌ Test de récupération d'un projet inexistant...")
        
        fake_id = "00000000-0000-0000-0000-000000000000"
        response = await self.client.get(f"/projects/{fake_id}")
        assert response.status_code == 404
        
        print("✅ Erreur 404 correctement retournée pour projet inexistant")
        return True
    
    async def test_start_project(self):
        """Test de démarrage d'un projet"""
        print("\n▶️ Test de démarrage d'un projet...")
        
        response = await self.client.post(f"/projects/{self.test_project_id}/start")
        assert response.status_code == 200
        
        data = response.json()
        assert data["status"] == "success"
        assert "started_agents" in data
        assert len(data["started_agents"]) > 0
        
        # Vérifier que le statut du projet a changé
        project_response = await self.client.get(f"/projects/{self.test_project_id}")
        project_data = project_response.json()
        assert project_data["status"] == "active"
        
        print(f"✅ Projet démarré ({len(data['started_agents'])} agents)")
        return True
    
    async def test_stop_project(self):
        """Test d'arrêt d'un projet"""
        print("\n⏹️ Test d'arrêt d'un projet...")
        
        response = await self.client.post(f"/projects/{self.test_project_id}/stop")
        assert response.status_code == 200
        
        data = response.json()
        assert data["status"] == "success"
        assert "stopped_agents" in data
        
        # Vérifier que le statut du projet a changé
        project_response = await self.client.get(f"/projects/{self.test_project_id}")
        project_data = project_response.json()
        assert project_data["status"] == "inactive"
        
        print(f"✅ Projet arrêté ({len(data['stopped_agents'])} agents)")
        return True
    
    async def test_get_project_logs(self):
        """Test de récupération des logs d'un projet"""
        print("\n📝 Test de récupération des logs d'un projet...")
        
        response = await self.client.get(f"/projects/{self.test_project_id}/logs")
        assert response.status_code == 200
        
        data = response.json()
        # Les logs peuvent être vides ou contenir des données mockées
        assert "logs" in data or isinstance(data, list)
        
        print("✅ Logs du projet récupérés")
        return True
    
    async def test_get_agent_status(self):
        """Test de récupération du statut d'un agent"""
        print("\n🤖 Test de récupération du statut d'un agent...")
        
        response = await self.client.get(f"/projects/{self.test_project_id}/agents/{self.test_agent_id}/status")
        assert response.status_code == 200
        
        data = response.json()
        assert "agent" in data
        assert "project_id" in data
        assert data["project_id"] == self.test_project_id
        
        print("✅ Statut de l'agent récupéré")
        return True
    
    async def test_start_individual_agent(self):
        """Test de démarrage d'un agent individuel"""
        print("\n▶️ Test de démarrage d'un agent individuel...")
        
        response = await self.client.post(f"/projects/{self.test_project_id}/agents/{self.test_agent_id}/start")
        assert response.status_code == 200
        
        data = response.json()
        assert data["status"] == "success"
        assert data["agent_id"] == self.test_agent_id
        
        print("✅ Agent individuel démarré")
        return True
    
    async def test_stop_individual_agent(self):
        """Test d'arrêt d'un agent individuel"""
        print("\n⏹️ Test d'arrêt d'un agent individuel...")
        
        response = await self.client.post(f"/projects/{self.test_project_id}/agents/{self.test_agent_id}/stop")
        assert response.status_code == 200
        
        data = response.json()
        assert data["status"] == "success"
        assert data["agent_id"] == self.test_agent_id
        
        print("✅ Agent individuel arrêté")
        return True
    
    async def run_all_tests(self):
        """Exécuter tous les tests"""
        print("🚀 Démarrage des tests de l'API de contrôle d'agents")
        print("=" * 60)
        
        await self.setup()
        
        tests = [
            self.test_root_endpoint,
            self.test_health_check,
            self.test_get_projects_empty,
            self.test_create_project,
            self.test_get_projects_with_data,
            self.test_get_project_detail,
            self.test_get_project_not_found,
            self.test_start_project,
            self.test_stop_project,
            self.test_get_project_logs,
            self.test_get_agent_status,
            self.test_start_individual_agent,
            self.test_stop_individual_agent,
        ]
        
        passed = 0
        failed = 0
        
        for test in tests:
            try:
                await test()
                passed += 1
            except Exception as e:
                print(f"❌ Test échoué: {test.__name__} - {str(e)}")
                failed += 1
        
        print("\n" + "=" * 60)
        print(f"📊 Résultats des tests:")
        print(f"✅ Tests réussis: {passed}")
        print(f"❌ Tests échoués: {failed}")
        print(f"📈 Taux de réussite: {(passed/(passed+failed)*100):.1f}%")
        
        await self.cleanup()
        
        return passed, failed

async def run_manual_test():
    """Fonction pour tester manuellement l'API"""
    print("🔧 Test manuel de l'API de contrôle d'agents")
    print("=" * 50)
    
    async with httpx.AsyncClient(base_url=API_BASE_URL, timeout=TEST_TIMEOUT) as client:
        
        # Test simple de connexion
        print("\n1. Test de connexion...")
        try:
            response = await client.get("/")
            print(f"   Status: {response.status_code}")
            print(f"   Response: {response.json()}")
        except Exception as e:
            print(f"   Erreur: {e}")
        
        # Test health check
        print("\n2. Test health check...")
        try:
            response = await client.get("/health")
            print(f"   Status: {response.status_code}")
            data = response.json()
            print(f"   API Status: {data.get('api_status')}")
            print(f"   Services externes: {len(data.get('external_services', {}))}")
        except Exception as e:
            print(f"   Erreur: {e}")
        
        # Test récupération des projets
        print("\n3. Test récupération des projets...")
        try:
            response = await client.get("/projects")
            print(f"   Status: {response.status_code}")
            data = response.json()
            print(f"   Nombre de projets: {len(data)}")
        except Exception as e:
            print(f"   Erreur: {e}")

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "manual":
        # Test manuel simple
        asyncio.run(run_manual_test())
    else:
        # Tests complets
        tester = TestAgentControlAPI()
        asyncio.run(tester.run_all_tests())