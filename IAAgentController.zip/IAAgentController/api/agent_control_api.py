"""
API de contrôle d'agents IA - Brique 6

Cette API permet d'orchestrer les agents existants et de communiquer avec les autres briques.
Elle sert d'interface entre le dashboard React et les différents services d'agents.
"""

import json
import os
import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any
import httpx
from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from dotenv import load_dotenv

# Charger les variables d'environnement
load_dotenv()

app = FastAPI(
    title="Agent Control API",
    description="API pour contrôler et orchestrer les agents IA",
    version="1.0.0"
)

# Configuration CORS pour permettre les requêtes depuis le frontend React
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # En production, spécifier les domaines autorisés
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configuration des APIs externes
MEMORY_API_URL = os.getenv("MEMORY_API_URL", "http://localhost:8001")
LOGS_API_URL = os.getenv("LOGS_API_URL", "http://localhost:8002")
AGENT_GEN_API_URL = os.getenv("AGENT_GEN_API_URL", "http://localhost:8003")

# Fichier JSON pour stocker les projets (base de données simple)
PROJECTS_FILE = "data/projects.json"

# Modèles Pydantic
class Agent(BaseModel):
    """Modèle pour un agent IA"""
    id: str
    name: str
    role: str
    task: str
    status: str = "stopped"  # stopped, running, error, paused
    priority: str = "medium"  # low, medium, high
    created_at: datetime = Field(default_factory=datetime.now)
    last_activity: Optional[datetime] = None
    performance_metrics: Dict[str, Any] = Field(default_factory=dict)

class CreateProjectRequest(BaseModel):
    """Requête pour créer un nouveau projet"""
    name: str
    description: str
    agents: List[Dict[str, Any]] = Field(default_factory=list)

class Project(BaseModel):
    """Modèle pour un projet d'agents IA"""
    id: str
    name: str
    description: str
    status: str = "inactive"  # inactive, active, paused, completed
    created_at: datetime = Field(default_factory=datetime.now)
    agents: List[Agent] = Field(default_factory=list)
    total_tasks: int = 0
    completed_tasks: int = 0
    error_count: int = 0

class LogEntry(BaseModel):
    """Modèle pour une entrée de log"""
    timestamp: datetime
    project_id: str
    agent_id: str
    level: str  # info, warning, error
    message: str
    source: str = "agent_control"

# Utilitaires pour gérer les données JSON
def ensure_data_directory():
    """Créer le dossier data s'il n'existe pas"""
    os.makedirs("data", exist_ok=True)

def load_projects() -> List[Project]:
    """Charger les projets depuis le fichier JSON"""
    ensure_data_directory()
    if not os.path.exists(PROJECTS_FILE):
        return []
    
    try:
        with open(PROJECTS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return [Project(**project) for project in data]
    except Exception as e:
        print(f"Erreur lors du chargement des projets: {e}")
        return []

def save_projects(projects: List[Project]):
    """Sauvegarder les projets dans le fichier JSON"""
    ensure_data_directory()
    try:
        with open(PROJECTS_FILE, 'w', encoding='utf-8') as f:
            json.dump([project.dict() for project in projects], f, indent=2, default=str)
    except Exception as e:
        print(f"Erreur lors de la sauvegarde des projets: {e}")

def get_project_by_id(project_id: str) -> Optional[Project]:
    """Récupérer un projet par son ID"""
    projects = load_projects()
    return next((p for p in projects if p.id == project_id), None)

# Client HTTP pour les appels aux autres APIs
async def call_external_api(url: str, method: str = "GET", data: dict = None) -> dict:
    """Appeler une API externe avec gestion d'erreurs"""
    try:
        async with httpx.AsyncClient() as client:
            if method == "GET":
                response = await client.get(url)
            elif method == "POST":
                response = await client.post(url, json=data)
            elif method == "PUT":
                response = await client.put(url, json=data)
            elif method == "DELETE":
                response = await client.delete(url)
            else:
                raise HTTPException(status_code=400, detail=f"Méthode HTTP non supportée: {method}")
            
            if response.status_code < 400:
                return response.json()
            else:
                print(f"Erreur API externe {url}: {response.status_code} - {response.text}")
                return {"error": f"Erreur API: {response.status_code}"}
    except httpx.RequestError as e:
        print(f"Erreur de connexion à {url}: {e}")
        return {"error": f"Connexion échouée: {str(e)}"}

# Endpoints de l'API

@app.get("/")
async def root():
    """Endpoint racine pour vérifier le fonctionnement de l'API"""
    return {
        "message": "API de contrôle d'agents IA",
        "version": "1.0.0",
        "status": "actif",
        "endpoints": {
            "projects": "/projects",
            "project_detail": "/projects/{project_id}",
            "start_project": "/projects/{project_id}/start",
            "stop_project": "/projects/{project_id}/stop",
            "project_logs": "/projects/{project_id}/logs"
        }
    }

@app.get("/projects", response_model=List[Project])
async def get_projects():
    """Récupérer la liste de tous les projets"""
    projects = load_projects()
    
    # Enrichir avec des données des autres APIs si disponibles
    for project in projects:
        # Essayer de récupérer des métriques de performance depuis l'API mémoire
        memory_data = await call_external_api(f"{MEMORY_API_URL}/metrics/{project.id}")
        if "error" not in memory_data:
            # Mettre à jour les métriques du projet
            project.total_tasks = memory_data.get("total_tasks", project.total_tasks)
            project.completed_tasks = memory_data.get("completed_tasks", project.completed_tasks)
    
    return projects

@app.post("/projects", response_model=Project)
async def create_project(request: CreateProjectRequest):
    """Créer un nouveau projet d'agents IA"""
    project_id = str(uuid.uuid4())
    
    # Créer les agents à partir de la requête
    agents = []
    for agent_data in request.agents:
        agent = Agent(
            id=str(uuid.uuid4()),
            name=agent_data.get("name", "Agent sans nom"),
            role=agent_data.get("role", "Assistant"),
            task=agent_data.get("task", "Tâche non définie"),
            status="stopped",
            priority=agent_data.get("priority", "medium")
        )
        agents.append(agent)
    
    # Créer le projet
    new_project = Project(
        id=project_id,
        name=request.name,
        description=request.description,
        agents=agents,
        status="inactive"
    )
    
    # Sauvegarder
    projects = load_projects()
    projects.append(new_project)
    save_projects(projects)
    
    # Notifier l'API mémoire si disponible
    await call_external_api(
        f"{MEMORY_API_URL}/projects",
        method="POST",
        data={
            "project_id": project_id,
            "name": request.name,
            "description": request.description,
            "agents_count": len(agents)
        }
    )
    
    return new_project

@app.get("/projects/{project_id}", response_model=Project)
async def get_project(project_id: str):
    """Récupérer les détails d'un projet spécifique"""
    project = get_project_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Projet non trouvé")
    
    # Enrichir avec des données en temps réel des autres APIs
    memory_data = await call_external_api(f"{MEMORY_API_URL}/projects/{project_id}")
    if "error" not in memory_data:
        project.total_tasks = memory_data.get("total_tasks", project.total_tasks)
        project.completed_tasks = memory_data.get("completed_tasks", project.completed_tasks)
        project.error_count = memory_data.get("error_count", project.error_count)
    
    return project

@app.post("/projects/{project_id}/start")
async def start_project(project_id: str):
    """Démarrer tous les agents d'un projet"""
    project = get_project_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Projet non trouvé")
    
    # Mettre à jour le statut du projet et des agents
    project.status = "active"
    started_agents = []
    
    for agent in project.agents:
        if agent.status == "stopped":
            agent.status = "running"
            agent.last_activity = datetime.now()
            started_agents.append(agent.id)
    
    # Sauvegarder les modifications
    projects = load_projects()
    for i, p in enumerate(projects):
        if p.id == project_id:
            projects[i] = project
            break
    save_projects(projects)
    
    # Notifier les autres APIs
    await call_external_api(
        f"{MEMORY_API_URL}/projects/{project_id}/start",
        method="POST"
    )
    
    # Créer un log d'événement
    log_entry = LogEntry(
        timestamp=datetime.now(),
        project_id=project_id,
        agent_id="system",
        level="info",
        message=f"Projet démarré - {len(started_agents)} agents activés",
        source="agent_control"
    )
    
    await call_external_api(
        f"{LOGS_API_URL}/logs",
        method="POST",
        data=log_entry.dict()
    )
    
    return {
        "status": "success",
        "message": f"Projet démarré avec {len(started_agents)} agents",
        "project_id": project_id,
        "started_agents": started_agents
    }

@app.post("/projects/{project_id}/stop")
async def stop_project(project_id: str):
    """Arrêter tous les agents d'un projet"""
    project = get_project_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Projet non trouvé")
    
    # Mettre à jour le statut du projet et des agents
    project.status = "inactive"
    stopped_agents = []
    
    for agent in project.agents:
        if agent.status == "running":
            agent.status = "stopped"
            agent.last_activity = datetime.now()
            stopped_agents.append(agent.id)
    
    # Sauvegarder les modifications
    projects = load_projects()
    for i, p in enumerate(projects):
        if p.id == project_id:
            projects[i] = project
            break
    save_projects(projects)
    
    # Notifier les autres APIs
    await call_external_api(
        f"{MEMORY_API_URL}/projects/{project_id}/stop",
        method="POST"
    )
    
    # Créer un log d'événement
    log_entry = LogEntry(
        timestamp=datetime.now(),
        project_id=project_id,
        agent_id="system",
        level="info",
        message=f"Projet arrêté - {len(stopped_agents)} agents désactivés",
        source="agent_control"
    )
    
    await call_external_api(
        f"{LOGS_API_URL}/logs",
        method="POST",
        data=log_entry.dict()
    )
    
    return {
        "status": "success",
        "message": f"Projet arrêté - {len(stopped_agents)} agents désactivés",
        "project_id": project_id,
        "stopped_agents": stopped_agents
    }

@app.get("/projects/{project_id}/logs")
async def get_project_logs(project_id: str, limit: int = 50):
    """Récupérer les logs d'un projet"""
    project = get_project_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Projet non trouvé")
    
    # Récupérer les logs depuis l'API de logs (brique 5)
    logs_data = await call_external_api(
        f"{LOGS_API_URL}/logs/project/{project_id}?limit={limit}"
    )
    
    if "error" in logs_data:
        # Fallback: logs locaux simulés
        mock_logs = [
            {
                "timestamp": datetime.now().isoformat(),
                "project_id": project_id,
                "agent_id": agent.id,
                "level": "info",
                "message": f"Agent {agent.name} - Status: {agent.status}",
                "source": "agent_control"
            }
            for agent in project.agents
        ]
        return {"logs": mock_logs, "total": len(mock_logs)}
    
    return logs_data

@app.get("/projects/{project_id}/agents/{agent_id}/status")
async def get_agent_status(project_id: str, agent_id: str):
    """Récupérer le statut détaillé d'un agent spécifique"""
    project = get_project_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Projet non trouvé")
    
    agent = next((a for a in project.agents if a.id == agent_id), None)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent non trouvé")
    
    # Enrichir avec des données en temps réel si disponible
    status_data = await call_external_api(f"{MEMORY_API_URL}/agents/{agent_id}/status")
    if "error" not in status_data:
        agent.performance_metrics = status_data.get("metrics", {})
    
    return {
        "agent": agent,
        "project_id": project_id,
        "real_time_data": status_data if "error" not in status_data else None
    }

@app.post("/projects/{project_id}/agents/{agent_id}/start")
async def start_agent(project_id: str, agent_id: str):
    """Démarrer un agent spécifique"""
    project = get_project_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Projet non trouvé")
    
    agent = next((a for a in project.agents if a.id == agent_id), None)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent non trouvé")
    
    # Mettre à jour le statut de l'agent
    agent.status = "running"
    agent.last_activity = datetime.now()
    
    # Sauvegarder
    projects = load_projects()
    for i, p in enumerate(projects):
        if p.id == project_id:
            projects[i] = project
            break
    save_projects(projects)
    
    return {
        "status": "success",
        "message": f"Agent {agent.name} démarré",
        "agent_id": agent_id,
        "project_id": project_id
    }

@app.post("/projects/{project_id}/agents/{agent_id}/stop")
async def stop_agent(project_id: str, agent_id: str):
    """Arrêter un agent spécifique"""
    project = get_project_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Projet non trouvé")
    
    agent = next((a for a in project.agents if a.id == agent_id), None)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent non trouvé")
    
    # Mettre à jour le statut de l'agent
    agent.status = "stopped"
    agent.last_activity = datetime.now()
    
    # Sauvegarder
    projects = load_projects()
    for i, p in enumerate(projects):
        if p.id == project_id:
            projects[i] = project
            break
    save_projects(projects)
    
    return {
        "status": "success",
        "message": f"Agent {agent.name} arrêté",
        "agent_id": agent_id,
        "project_id": project_id
    }

@app.get("/health")
async def health_check():
    """Vérification de l'état de l'API et des connexions aux autres briques"""
    health_status = {
        "api_status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "external_services": {}
    }
    
    # Vérifier les connexions aux autres APIs
    external_apis = {
        "memory_api": MEMORY_API_URL,
        "logs_api": LOGS_API_URL,
        "agent_gen_api": AGENT_GEN_API_URL
    }
    
    for service_name, service_url in external_apis.items():
        try:
            response = await call_external_api(f"{service_url}/health")
            health_status["external_services"][service_name] = {
                "status": "connected" if "error" not in response else "disconnected",
                "url": service_url
            }
        except Exception as e:
            health_status["external_services"][service_name] = {
                "status": "error",
                "error": str(e),
                "url": service_url
            }
    
    return health_status

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)