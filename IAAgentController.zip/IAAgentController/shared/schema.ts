import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const agents = pgTable("agents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  task: text("task").notNull(),
  status: text("status").notNull().default("stopped"), // running, stopped, error, waiting
  priority: text("priority").notNull().default("medium"), // low, medium, high
  autoStart: text("auto_start").notNull().default("manual"), // manual, auto, scheduled
  timeout: integer("timeout").default(30),
  enableMonitoring: boolean("enable_monitoring").default(false),
  startTime: timestamp("start_time"),
  createdAt: timestamp("created_at").defaultNow(),
  lastError: text("last_error"),
  performance: integer("performance").default(0),
  duration: text("duration"),
});

export const logs = pgTable("logs", {
  id: serial("id").primaryKey(),
  agentId: integer("agent_id").references(() => agents.id),
  agentName: text("agent_name").notNull(),
  level: text("level").notNull(), // info, warning, error
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertAgentSchema = createInsertSchema(agents).omit({
  id: true,
  createdAt: true,
  startTime: true,
  lastError: true,
  performance: true,
  duration: true,
});

export const insertLogSchema = createInsertSchema(logs).omit({
  id: true,
  timestamp: true,
});

export type Agent = typeof agents.$inferSelect;
export type InsertAgent = z.infer<typeof insertAgentSchema>;
export type Log = typeof logs.$inferSelect;
export type InsertLog = z.infer<typeof insertLogSchema>;

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
