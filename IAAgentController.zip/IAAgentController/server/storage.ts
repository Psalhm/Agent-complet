import { agents, logs, users, type Agent, type InsertAgent, type Log, type InsertLog, type User, type InsertUser } from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Agent methods
  createAgent(agent: InsertAgent): Promise<Agent>;
  getAgent(id: number): Promise<Agent | undefined>;
  getAllAgents(): Promise<Agent[]>;
  updateAgent(id: number, updates: Partial<Agent>): Promise<Agent | undefined>;
  deleteAgent(id: number): Promise<boolean>;
  
  // Log methods
  createLog(log: InsertLog): Promise<Log>;
  getLogsByAgent(agentId: number): Promise<Log[]>;
  getRecentLogs(limit?: number): Promise<Log[]>;
  
  // Stats methods
  getStats(): Promise<{
    activeAgents: number;
    inactiveAgents: number;
    completedTasks: number;
    errors: number;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private agents: Map<number, Agent>;
  private logs: Map<number, Log>;
  private userCurrentId: number;
  private agentCurrentId: number;
  private logCurrentId: number;

  constructor() {
    this.users = new Map();
    this.agents = new Map();
    this.logs = new Map();
    this.userCurrentId = 1;
    this.agentCurrentId = 1;
    this.logCurrentId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createAgent(insertAgent: InsertAgent): Promise<Agent> {
    const id = this.agentCurrentId++;
    const agent: Agent = {
      ...insertAgent,
      id,
      createdAt: new Date(),
      startTime: null,
      lastError: null,
      performance: 0,
      duration: null,
    };
    this.agents.set(id, agent);
    
    // Create initial log
    await this.createLog({
      agentId: id,
      agentName: agent.name,
      level: "info",
      message: "Agent créé avec succès",
    });
    
    return agent;
  }

  async getAgent(id: number): Promise<Agent | undefined> {
    return this.agents.get(id);
  }

  async getAllAgents(): Promise<Agent[]> {
    return Array.from(this.agents.values());
  }

  async updateAgent(id: number, updates: Partial<Agent>): Promise<Agent | undefined> {
    const agent = this.agents.get(id);
    if (!agent) return undefined;

    const updatedAgent = { ...agent, ...updates };
    this.agents.set(id, updatedAgent);
    
    // Create log for status changes
    if (updates.status && updates.status !== agent.status) {
      await this.createLog({
        agentId: id,
        agentName: agent.name,
        level: updates.status === "error" ? "error" : "info",
        message: `Status changé vers: ${updates.status}`,
      });
    }
    
    return updatedAgent;
  }

  async deleteAgent(id: number): Promise<boolean> {
    const agent = this.agents.get(id);
    if (!agent) return false;
    
    this.agents.delete(id);
    
    // Remove associated logs
    const logsToRemove = Array.from(this.logs.values()).filter(log => log.agentId === id);
    logsToRemove.forEach(log => this.logs.delete(log.id));
    
    return true;
  }

  async createLog(insertLog: InsertLog): Promise<Log> {
    const id = this.logCurrentId++;
    const log: Log = {
      ...insertLog,
      id,
      timestamp: new Date(),
    };
    this.logs.set(id, log);
    return log;
  }

  async getLogsByAgent(agentId: number): Promise<Log[]> {
    return Array.from(this.logs.values())
      .filter(log => log.agentId === agentId)
      .sort((a, b) => (b.timestamp?.getTime() || 0) - (a.timestamp?.getTime() || 0));
  }

  async getRecentLogs(limit: number = 10): Promise<Log[]> {
    return Array.from(this.logs.values())
      .sort((a, b) => (b.timestamp?.getTime() || 0) - (a.timestamp?.getTime() || 0))
      .slice(0, limit);
  }

  async getStats() {
    const agents = await this.getAllAgents();
    const logs = Array.from(this.logs.values());
    
    return {
      activeAgents: agents.filter(a => a.status === "running").length,
      inactiveAgents: agents.filter(a => a.status === "stopped").length,
      completedTasks: logs.filter(l => l.message.includes("terminée") || l.message.includes("completed")).length,
      errors: agents.filter(a => a.status === "error").length,
    };
  }
}

export const storage = new MemStorage();
