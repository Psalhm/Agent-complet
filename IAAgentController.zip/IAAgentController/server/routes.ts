import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertAgentSchema, insertLogSchema } from "@shared/schema";
import { z } from "zod";

interface WebSocketMessage {
  type: string;
  data?: any;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Store connected clients
  const clients = new Set<WebSocket>();
  
  wss.on('connection', (ws) => {
    clients.add(ws);
    
    ws.on('close', () => {
      clients.delete(ws);
    });
    
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(ws);
    });
  });
  
  // Broadcast to all connected clients
  const broadcast = (message: WebSocketMessage) => {
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  };

  // Agent routes
  app.get('/api/agents', async (req, res) => {
    try {
      const agents = await storage.getAllAgents();
      res.json(agents);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch agents' });
    }
  });

  app.get('/api/agents/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const agent = await storage.getAgent(id);
      if (!agent) {
        return res.status(404).json({ message: 'Agent not found' });
      }
      res.json(agent);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch agent' });
    }
  });

  app.post('/api/agents', async (req, res) => {
    try {
      const validatedData = insertAgentSchema.parse(req.body);
      const agent = await storage.createAgent(validatedData);
      
      // Broadcast new agent to all clients
      broadcast({ type: 'agent-created', data: agent });
      
      res.status(201).json(agent);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to create agent' });
    }
  });

  app.patch('/api/agents/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const agent = await storage.updateAgent(id, updates);
      if (!agent) {
        return res.status(404).json({ message: 'Agent not found' });
      }
      
      // Broadcast agent update to all clients
      broadcast({ type: 'agent-updated', data: agent });
      
      res.json(agent);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update agent' });
    }
  });

  app.delete('/api/agents/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteAgent(id);
      
      if (!success) {
        return res.status(404).json({ message: 'Agent not found' });
      }
      
      // Broadcast agent deletion to all clients
      broadcast({ type: 'agent-deleted', data: { id } });
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete agent' });
    }
  });

  // Agent control routes
  app.post('/api/agents/:id/start', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const agent = await storage.updateAgent(id, { 
        status: 'running',
        startTime: new Date(),
        lastError: null
      });
      
      if (!agent) {
        return res.status(404).json({ message: 'Agent not found' });
      }
      
      broadcast({ type: 'agent-updated', data: agent });
      res.json(agent);
    } catch (error) {
      res.status(500).json({ message: 'Failed to start agent' });
    }
  });

  app.post('/api/agents/:id/stop', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const agent = await storage.updateAgent(id, { 
        status: 'stopped',
        duration: calculateDuration(await storage.getAgent(id))
      });
      
      if (!agent) {
        return res.status(404).json({ message: 'Agent not found' });
      }
      
      broadcast({ type: 'agent-updated', data: agent });
      res.json(agent);
    } catch (error) {
      res.status(500).json({ message: 'Failed to stop agent' });
    }
  });

  app.post('/api/agents/:id/restart', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const agent = await storage.updateAgent(id, { 
        status: 'running',
        startTime: new Date(),
        lastError: null
      });
      
      if (!agent) {
        return res.status(404).json({ message: 'Agent not found' });
      }
      
      broadcast({ type: 'agent-updated', data: agent });
      res.json(agent);
    } catch (error) {
      res.status(500).json({ message: 'Failed to restart agent' });
    }
  });

  // Log routes
  app.get('/api/logs', async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const logs = await storage.getRecentLogs(limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch logs' });
    }
  });

  app.get('/api/agents/:id/logs', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const logs = await storage.getLogsByAgent(id);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch agent logs' });
    }
  });

  app.post('/api/logs', async (req, res) => {
    try {
      const validatedData = insertLogSchema.parse(req.body);
      const log = await storage.createLog(validatedData);
      
      // Broadcast new log to all clients
      broadcast({ type: 'log-created', data: log });
      
      res.status(201).json(log);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to create log' });
    }
  });

  // Stats route
  app.get('/api/stats', async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch stats' });
    }
  });

  // Performance route (mock data for demo)
  app.get('/api/performance', async (req, res) => {
    const performance = {
      cpu: Math.floor(Math.random() * 100),
      memory: Math.floor(Math.random() * 100),
      network: Math.floor(Math.random() * 100),
      uptime: '99.8%',
      responseTime: `${Math.floor(Math.random() * 200 + 50)}ms`
    };
    res.json(performance);
  });

  // Simulate agent performance updates
  setInterval(async () => {
    const agents = await storage.getAllAgents();
    const runningAgents = agents.filter(a => a.status === 'running');
    
    for (const agent of runningAgents) {
      const performance = Math.floor(Math.random() * 100);
      await storage.updateAgent(agent.id, { performance });
      
      // Occasionally create logs for running agents
      if (Math.random() > 0.7) {
        const messages = [
          'Traitement en cours...',
          'Tâche terminée avec succès',
          'Analyse des données complète',
          'Monitoring système actif',
          'Connexion établie'
        ];
        
        await storage.createLog({
          agentId: agent.id,
          agentName: agent.name,
          level: 'info',
          message: messages[Math.floor(Math.random() * messages.length)]
        });
      }
    }
    
    // Broadcast updated stats
    const stats = await storage.getStats();
    broadcast({ type: 'stats-updated', data: stats });
  }, 5000);

  return httpServer;
}

function calculateDuration(agent: any): string {
  if (!agent?.startTime) return '0m';
  
  const now = new Date();
  const start = new Date(agent.startTime);
  const diff = now.getTime() - start.getTime();
  
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  
  if (hours > 0) {
    return `${hours}h ${minutes}m`;
  }
  return `${minutes}m`;
}
