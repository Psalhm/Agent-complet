# AI Agent Hub

## Overview

This is a full-stack AI agent management application built with React (frontend) and Express.js (backend). The application provides a dashboard for managing AI agents, viewing logs, and monitoring system performance. It uses PostgreSQL with Drizzle ORM for data persistence and includes real-time updates via WebSockets.

**Recent Update**: Added FastAPI backend for agent orchestration (Brique 6) - A Python-based API that provides project management capabilities and integrates with external agent services.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Real-time Communication**: WebSocket client for live updates

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Real-time**: WebSocket server for broadcasting updates
- **Development**: Hot reloading with Vite integration in development mode

### Python API Backend (Brique 6)
- **Framework**: FastAPI with Pydantic for data validation
- **Purpose**: Agent orchestration and project management
- **Storage**: JSON file-based storage for prototyping
- **Integration**: Communicates with external agent services
- **Features**: Project lifecycle management, agent control, external API integration

## Key Components

### Database Schema
- **Agents Table**: Stores AI agent configurations including name, role, task, status, priority, and monitoring settings
- **Logs Table**: Stores system logs with agent references, log levels, and timestamps
- **Users Table**: Basic user management (partially implemented)

### API Endpoints
- `GET /api/agents` - Retrieve all agents
- `POST /api/agents` - Create new agent
- `PUT /api/agents/:id` - Update agent
- `DELETE /api/agents/:id` - Delete agent
- `GET /api/logs` - Retrieve logs
- `GET /api/stats` - Get system statistics
- `GET /api/performance` - Get performance metrics

### WebSocket Events
- `agent-created` - Broadcast when new agent is created
- `agent-updated` - Broadcast when agent is modified
- `agent-deleted` - Broadcast when agent is removed
- `log-created` - Broadcast when new log entry is added

## Data Flow

1. **Client Requests**: Frontend makes API calls using TanStack Query
2. **Server Processing**: Express routes handle business logic and database operations
3. **Database Operations**: Drizzle ORM manages PostgreSQL interactions
4. **Real-time Updates**: WebSocket server broadcasts changes to all connected clients
5. **State Updates**: Frontend automatically updates UI based on WebSocket events and query invalidation

## External Dependencies

### Frontend Dependencies
- **UI Components**: Radix UI primitives with shadcn/ui styling
- **Form Handling**: React Hook Form with Zod validation
- **Icons**: Lucide React for consistent iconography
- **Date Handling**: date-fns for date formatting and manipulation

### Backend Dependencies
- **Database**: Neon serverless PostgreSQL
- **Session Management**: connect-pg-simple for PostgreSQL session storage
- **Schema Validation**: Zod for runtime type checking
- **WebSocket**: ws library for real-time communication

## Deployment Strategy

### Build Process
1. **Frontend**: Vite builds React app to `dist/public`
2. **Backend**: esbuild bundles server code to `dist/index.js`
3. **Database**: Drizzle Kit handles schema migrations

### Environment Configuration
- **Development**: Uses Vite dev server with Express backend
- **Production**: Serves static files from Express with built frontend
- **Database**: Requires `DATABASE_URL` environment variable for PostgreSQL connection

### Scripts
- `npm run dev` - Start development server with hot reloading
- `npm run build` - Build both frontend and backend for production
- `npm run start` - Start production server
- `npm run db:push` - Push database schema changes

The application is designed to be deployed on platforms like Replit, with automatic database provisioning and seamless development-to-production workflow.