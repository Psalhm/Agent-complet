#!/usr/bin/env python3
"""
Test d'intégration avec l'API mémoire unifiée.
"""

import asyncio
import os
from dotenv import load_dotenv
from utils.memory_client import MemoryAPIClient, AgentInteraction, AgentStatus, TaskExecution

# Charger les variables d'environnement
load_dotenv()

async def test_memory_api():
    """Test de l'API mémoire."""
    print("🧪 Test de l'API mémoire unifiée")
    print("-" * 40)
    
    # Vérifier la configuration
    api_url = os.getenv("MEMORY_API_BASE_URL", "http://localhost:8080/api/v1")
    api_key = os.getenv("MEMORY_API_KEY")
    
    print(f"🔗 URL API : {api_url}")
    print(f"🔑 Clé API : {'✅ Configurée' if api_key else '❌ Manquante'}")
    
    try:
        # Initialiser le client
        memory_client = MemoryAPIClient()
        
        # Test de santé
        print("\n🩺 Test de santé...")
        is_healthy = await memory_client.health_check()
        
        if is_healthy:
            print("✅ API mémoire accessible")
            
            # Test de sauvegarde d'interaction
            print("\n💾 Test de sauvegarde d'interaction...")
            interaction = AgentInteraction(
                agent_id="test_agent_001",
                agent_type="frontend",
                task_id="test_task_001",
                interaction_type="test",
                content="Test d'interaction avec l'API mémoire",
                timestamp="2025-01-09T10:00:00Z",
                metadata={"test": True}
            )
            
            save_success = await memory_client.save_agent_interaction(interaction)
            if save_success:
                print("✅ Interaction sauvegardée")
            else:
                print("❌ Échec de sauvegarde")
            
            # Test de récupération de statistiques
            print("\n📊 Test de récupération de statistiques...")
            stats = await memory_client.get_system_statistics()
            if stats:
                print(f"✅ Statistiques récupérées : {len(stats)} métriques")
                for key, value in stats.items():
                    print(f"   • {key}: {value}")
            else:
                print("❌ Aucune statistique disponible")
            
            return True
            
        else:
            print("❌ API mémoire non accessible")
            return False
            
    except Exception as e:
        print(f"❌ Erreur lors du test : {e}")
        return False

async def test_system_integration():
    """Test d'intégration système."""
    print("\n🔄 Test d'intégration système")
    print("-" * 40)
    
    # Vérifier les clés API
    openrouter_key = os.getenv("OPENROUTER_API_KEY")
    memory_api_key = os.getenv("MEMORY_API_KEY")
    
    if not openrouter_key or openrouter_key == "your-openrouter-api-key-here":
        print("❌ Clé API OpenRouter non configurée")
        return False
    
    if not memory_api_key or memory_api_key == "your-memory-api-key-here":
        print("⚠️  Clé API mémoire non configurée (fonctionnement dégradé)")
    
    try:
        # Test d'import du système
        from agents.langgraph_agents import LangGraphMultiAgentSystem
        print("✅ Import du système LangGraph réussi")
        
        # Test d'initialisation
        system = LangGraphMultiAgentSystem()
        print("✅ Système initialisé avec API mémoire")
        
        # Test de récupération de statistiques
        stats = await system.get_statistics()
        print(f"✅ Statistiques récupérées : {stats}")
        
        return True
        
    except Exception as e:
        print(f"❌ Erreur d'intégration : {e}")
        return False

async def main():
    """Fonction principale de test."""
    print("🚀 Test d'intégration API mémoire unifiée")
    print("=" * 50)
    
    # Test de l'API mémoire
    memory_ok = await test_memory_api()
    
    # Test d'intégration système
    system_ok = await test_system_integration()
    
    # Résumé
    print("\n" + "=" * 50)
    print("📋 RÉSUMÉ DES TESTS")
    print("=" * 50)
    
    print(f"API mémoire : {'✅ OK' if memory_ok else '❌ ÉCHEC'}")
    print(f"Intégration système : {'✅ OK' if system_ok else '❌ ÉCHEC'}")
    
    if memory_ok and system_ok:
        print("\n🎉 Tous les tests passent ! Le système est prêt.")
        print("📖 Vous pouvez maintenant utiliser :")
        print("   • python main_memory_unified.py")
        print("   • python main_langgraph.py")
    else:
        print("\n⚠️  Certains tests échouent.")
        print("📖 Vérifiez la configuration dans .env :")
        print("   • MEMORY_API_BASE_URL")
        print("   • MEMORY_API_KEY")
        print("   • OPENROUTER_API_KEY")

if __name__ == "__main__":
    asyncio.run(main())