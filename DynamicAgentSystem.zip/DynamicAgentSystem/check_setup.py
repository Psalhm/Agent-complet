#!/usr/bin/env python3
"""
Script pour vérifier que le système est correctement configuré.
"""

import os
import sys
from dotenv import load_dotenv
import requests

# Charger les variables d'environnement
load_dotenv()

def check_environment():
    """Vérifie les variables d'environnement."""
    print("🔧 Vérification de la configuration...")
    
    api_key = os.getenv("OPENROUTER_API_KEY")
    if not api_key:
        print("❌ OPENROUTER_API_KEY manquant")
        return False
    
    if api_key == "your-openrouter-api-key-here":
        print("❌ OPENROUTER_API_KEY n'est pas configuré (valeur par défaut)")
        return False
    
    print("✅ OPENROUTER_API_KEY configuré")
    return True

def test_api_connection():
    """Teste la connexion à l'API OpenRouter."""
    print("\n🌐 Test de connexion à OpenRouter...")
    
    api_key = os.getenv("OPENROUTER_API_KEY")
    if not api_key:
        print("❌ Clé API manquante")
        return False
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "http://localhost:5000",
        "X-Title": "Multi-Agent Task System"
    }
    
    data = {
        "model": "mistralai/mistral-7b-instruct",
        "messages": [{"role": "user", "content": "Hello"}],
        "max_tokens": 50
    }
    
    try:
        response = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers=headers,
            json=data,
            timeout=10
        )
        
        if response.status_code == 200:
            print("✅ Connexion OpenRouter réussie")
            return True
        else:
            print(f"❌ Erreur API : {response.status_code}")
            if response.status_code == 401:
                print("   Vérifiez votre clé API OpenRouter")
            elif response.status_code == 429:
                print("   Limite de taux atteinte")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Erreur de connexion : {e}")
        return False

def check_imports():
    """Vérifie que tous les imports nécessaires fonctionnent."""
    print("\n📦 Vérification des imports...")
    
    try:
        import asyncio
        import logging
        import uuid
        import json
        import aiohttp
        import requests
        from dotenv import load_dotenv
        from pydantic import BaseModel
        from langchain.llms.base import LLM
        
        # Vérifier les imports spécifiques au projet
        from agents.langgraph_agents import LangGraphMultiAgentSystem
        from agents.simple_agents import SimpleAgentManager
        from utils.llm_client import LLMClient
        
        print("✅ Tous les imports de base fonctionnent")
        print("✅ LangGraph correctement configuré")
        return True
    except ImportError as e:
        print(f"❌ Erreur d'import : {e}")
        return False

def main():
    """Fonction principale de vérification."""
    print("🤖 Vérification du système multi-agents")
    print("=" * 50)
    
    checks = [
        ("Configuration", check_environment),
        ("Imports", check_imports),
        ("API OpenRouter", test_api_connection)
    ]
    
    all_passed = True
    
    for name, check_func in checks:
        try:
            passed = check_func()
            if not passed:
                all_passed = False
        except Exception as e:
            print(f"❌ Erreur lors de {name} : {e}")
            all_passed = False
    
    print("\n" + "=" * 50)
    if all_passed:
        print("🎉 Système prêt à l'emploi !")
        print("\nCommandes disponibles :")
        print("• python main_simple.py          # Démonstration automatique")
        print("• python demo_interactive.py     # Démonstration interactive")
        print("• python main.py                 # Version originale (si CrewAI fonctionne)")
    else:
        print("❌ Problème de configuration détecté")
        print("\nActions recommandées :")
        print("1. Vérifiez votre clé API OpenRouter dans .env")
        print("2. Assurez-vous d'avoir un crédit sur votre compte OpenRouter")
        print("3. Consultez le fichier instructions.md pour plus de détails")
    
    return all_passed

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)