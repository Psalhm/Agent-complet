#!/usr/bin/env python3
"""
Exemple minimal d'utilisation de l'API Agents Enfants.
Démonstration complète : créer, commander, monitorer et supprimer des agents.
"""

import requests
import json
import time
from typing import Dict, Any

def main():
    """Exemple d'utilisation de l'API Agents Enfants."""
    
    # Configuration de l'API
    base_url = "http://localhost:5001"
    
    print("🚀 Exemple d'utilisation de l'API Agents Enfants")
    print("=" * 50)
    
    # 1. Créer un agent enfant
    print("\n1. Création d'un agent enfant...")
    
    agent_data = {
        "name": "DataProcessor",
        "role": "data_processor",
        "context": "Agent spécialisé dans le traitement de données JSON",
        "agent_type": "thread",
        "parameters": {
            "processing_mode": "batch",
            "output_format": "json",
            "max_records": 1000
        },
        "max_lifetime": 600  # 10 minutes
    }
    
    response = requests.post(f"{base_url}/agents/children", json=agent_data)
    
    if response.status_code == 200:
        result = response.json()
        agent_id = result["agent_id"]
        print(f"✅ Agent créé avec succès!")
        print(f"   ID: {agent_id}")
        print(f"   Nom: {agent_data['name']}")
        print(f"   Rôle: {agent_data['role']}")
    else:
        print(f"❌ Erreur lors de la création: {response.status_code}")
        print(f"   Détails: {response.text}")
        return
    
    # 2. Envoyer une commande à l'agent
    print(f"\n2. Envoi d'une commande à l'agent {agent_id[:8]}...")
    
    command_data = {
        "command": "process_user_data",
        "parameters": {
            "data_source": "user_profiles.json",
            "filters": ["active_users", "premium_members"],
            "aggregation": "count_by_category"
        },
        "timeout": 30
    }
    
    response = requests.post(f"{base_url}/agents/children/{agent_id}/command", json=command_data)
    
    if response.status_code == 200:
        result = response.json()
        print(f"✅ Commande exécutée avec succès!")
        print(f"   Statut: {result.get('status', 'N/A')}")
        print(f"   Résultat: {result.get('result', 'N/A')}")
        print(f"   Traité à: {result.get('processed_at', 'N/A')}")
    else:
        print(f"❌ Erreur lors de l'exécution: {response.status_code}")
        print(f"   Détails: {response.text}")
    
    # 3. Récupérer le statut de l'agent
    print(f"\n3. Récupération du statut de l'agent {agent_id[:8]}...")
    
    response = requests.get(f"{base_url}/agents/children/{agent_id}/status")
    
    if response.status_code == 200:
        status = response.json()
        print(f"✅ Statut récupéré avec succès!")
        print(f"   Nom: {status['name']}")
        print(f"   Statut: {status['status']}")
        print(f"   Type: {status['agent_type']}")
        print(f"   Créé: {status['created_at']}")
        print(f"   Dernière activité: {status['last_activity']}")
        print(f"   Nombre de logs: {len(status['logs'])}")
        print(f"   Nombre de résultats: {len(status['results'])}")
        
        # Afficher les derniers logs
        if status['logs']:
            print("   Derniers logs:")
            for log in status['logs'][-3:]:  # 3 derniers logs
                print(f"     • {log}")
    else:
        print(f"❌ Erreur lors de la récupération: {response.status_code}")
        print(f"   Détails: {response.text}")
    
    # 4. Envoyer une autre commande
    print(f"\n4. Envoi d'une seconde commande...")
    
    command_data2 = {
        "command": "generate_report",
        "parameters": {
            "report_type": "summary",
            "include_charts": True,
            "format": "html"
        },
        "timeout": 20
    }
    
    response = requests.post(f"{base_url}/agents/children/{agent_id}/command", json=command_data2)
    
    if response.status_code == 200:
        result = response.json()
        print(f"✅ Seconde commande exécutée!")
        print(f"   Résultat: {result.get('result', 'N/A')}")
    else:
        print(f"❌ Erreur seconde commande: {response.status_code}")
    
    # 5. Attendre un peu puis vérifier le statut
    print(f"\n5. Attente et vérification finale...")
    time.sleep(2)
    
    response = requests.get(f"{base_url}/agents/children/{agent_id}/status")
    if response.status_code == 200:
        status = response.json()
        print(f"✅ Statut final:")
        print(f"   Statut: {status['status']}")
        print(f"   Total résultats: {len(status['results'])}")
        print(f"   Logs récents: {len(status['logs'])}")
    
    # 6. Supprimer l'agent
    print(f"\n6. Suppression de l'agent {agent_id[:8]}...")
    
    response = requests.delete(f"{base_url}/agents/children/{agent_id}")
    
    if response.status_code == 200:
        result = response.json()
        print(f"✅ Agent supprimé avec succès!")
        print(f"   Message: {result.get('message', 'N/A')}")
    else:
        print(f"❌ Erreur lors de la suppression: {response.status_code}")
        print(f"   Détails: {response.text}")
    
    # 7. Vérification finale
    print(f"\n7. Vérification finale - tentative d'accès à l'agent supprimé...")
    
    response = requests.get(f"{base_url}/agents/children/{agent_id}/status")
    
    if response.status_code == 404:
        print(f"✅ Confirmation: Agent bien supprimé (404 attendu)")
    else:
        print(f"⚠️ Inattendu: {response.status_code} - {response.text}")
    
    print("\n" + "=" * 50)
    print("🎉 Exemple terminé avec succès!")
    print("\n💡 Points clés démontrés:")
    print("   ✅ Création d'agent avec configuration personnalisée")
    print("   ✅ Envoi de commandes avec paramètres")
    print("   ✅ Récupération de statut et monitoring")
    print("   ✅ Gestion des logs et résultats")
    print("   ✅ Suppression propre des agents")
    print("\n📚 Pour plus d'exemples, consultez la documentation Swagger:")
    print("   http://localhost:5001/docs")

if __name__ == "__main__":
    main()