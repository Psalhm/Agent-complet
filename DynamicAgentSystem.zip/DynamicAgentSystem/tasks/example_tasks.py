"""
Example tasks for demonstrating the multi-agent system capabilities.
This module provides predefined tasks for testing and demonstration purposes.
"""

import logging
from typing import Dict, Any

class ExampleTasks:
    """
    Collection of example tasks for system demonstration.
    """
    
    def __init__(self):
        """
        Initialize the example tasks.
        """
        self.logger = logging.getLogger(__name__)
    
    def create_html_page_task(self) -> str:
        """
        Create a task for generating an HTML page.
        
        Returns:
            Task description string
        """
        return """
        Create a professional HTML page for a task management application with the following requirements:
        
        1. Create a responsive HTML page with modern design
        2. Include a header with navigation menu
        3. Add a main content area with task list display
        4. Include a sidebar with task statistics
        5. Add a footer with contact information
        6. Use CSS Grid or Flexbox for layout
        7. Include interactive elements with JavaScript
        8. Ensure mobile responsiveness
        9. Use semantic HTML5 elements
        10. Include proper accessibility attributes
        
        The page should be visually appealing and functional, demonstrating modern web development practices.
        """
    
    def create_sql_schema_task(self) -> str:
        """
        Create a task for generating a SQL database schema.
        
        Returns:
            Task description string
        """
        return """
        Design a comprehensive SQL database schema for a task management system with the following requirements:
        
        1. Create a Users table with authentication fields
        2. Create a Projects table for organizing tasks
        3. Create a Tasks table with status tracking
        4. Create a TaskAssignments table for user-task relationships
        5. Create a TaskComments table for task discussions
        6. Create a TaskHistory table for audit trails
        7. Include proper primary keys and foreign key relationships
        8. Add appropriate indexes for performance optimization
        9. Include data validation constraints
        10. Add sample data insertion queries
        
        The schema should support multi-user task management with proper relationships and constraints.
        """
    
    def create_api_endpoint_task(self) -> str:
        """
        Create a task for generating API endpoints.
        
        Returns:
            Task description string
        """
        return """
        Create a RESTful API endpoint system for a task management application with the following requirements:
        
        1. Design RESTful API endpoints for task CRUD operations
        2. Implement user authentication and authorization
        3. Create endpoints for task assignment and status updates
        4. Include proper HTTP status codes and error handling
        5. Add request validation and sanitization
        6. Implement pagination for task listings
        7. Include API documentation with example requests/responses
        8. Add rate limiting and security measures
        9. Include logging and monitoring capabilities
        10. Provide example client integration code
        
        The API should be secure, scalable, and well-documented for easy integration.
        """
    
    def create_deployment_task(self) -> str:
        """
        Create a task for deployment configuration.
        
        Returns:
            Task description string
        """
        return """
        Create deployment configuration for a task management application with the following requirements:
        
        1. Create Docker configuration files
        2. Set up environment configuration management
        3. Create deployment scripts for different environments
        4. Configure load balancing and scaling
        5. Set up monitoring and logging infrastructure
        6. Create backup and disaster recovery procedures
        7. Include security configurations
        8. Add health check endpoints
        9. Configure CI/CD pipeline integration
        10. Document deployment procedures
        
        The deployment should be production-ready with proper monitoring and security measures.
        """
    
    def create_testing_task(self) -> str:
        """
        Create a task for comprehensive testing.
        
        Returns:
            Task description string
        """
        return """
        Create a comprehensive testing suite for a task management application with the following requirements:
        
        1. Create unit tests for all core functions
        2. Implement integration tests for API endpoints
        3. Add end-to-end tests for user workflows
        4. Include performance and load testing
        5. Create security testing procedures
        6. Add accessibility testing
        7. Implement automated test reporting
        8. Create test data management system
        9. Add continuous testing integration
        10. Include test coverage reporting
        
        The testing suite should ensure high quality and reliability of the application.
        """
    
    def create_complex_multi_agent_task(self) -> str:
        """
        Create a complex task requiring multiple specialized agents.
        
        Returns:
            Task description string
        """
        return """
        Create a complete task management web application with the following comprehensive requirements:
        
        Frontend Requirements:
        - Modern React or Vue.js single-page application
        - Responsive design with mobile-first approach
        - Real-time updates using WebSockets
        - Interactive dashboard with charts and analytics
        - Drag-and-drop task management interface
        
        Backend Requirements:
        - RESTful API with authentication and authorization
        - Real-time notifications system
        - File upload and management capabilities
        - Email notification system
        - Background job processing
        
        Database Requirements:
        - Optimized database schema with proper indexing
        - Data migration scripts
        - Backup and recovery procedures
        - Performance monitoring queries
        - Data analytics and reporting tables
        
        DevOps Requirements:
        - Containerized deployment with Docker
        - CI/CD pipeline configuration
        - Monitoring and logging setup
        - Auto-scaling configuration
        - Security hardening measures
        
        Testing Requirements:
        - Complete test suite with >90% coverage
        - Performance testing and benchmarks
        - Security penetration testing
        - Accessibility compliance testing
        - Cross-browser compatibility testing
        
        This is a comprehensive project requiring coordination between all agent types.
        """
    
    def get_task_metadata(self, task_name: str) -> Dict[str, Any]:
        """
        Get metadata for a specific task.
        
        Args:
            task_name: Name of the task
            
        Returns:
            Task metadata dictionary
        """
        metadata = {
            'html_page': {
                'estimated_duration': 30,  # minutes
                'complexity': 'medium',
                'required_skills': ['HTML', 'CSS', 'JavaScript'],
                'deliverables': ['HTML file', 'CSS file', 'JavaScript file']
            },
            'sql_schema': {
                'estimated_duration': 45,  # minutes
                'complexity': 'high',
                'required_skills': ['SQL', 'Database Design', 'Data Modeling'],
                'deliverables': ['Schema file', 'Migration scripts', 'Sample data']
            },
            'api_endpoint': {
                'estimated_duration': 60,  # minutes
                'complexity': 'high',
                'required_skills': ['API Design', 'Backend Development', 'Security'],
                'deliverables': ['API code', 'Documentation', 'Test cases']
            },
            'deployment': {
                'estimated_duration': 40,  # minutes
                'complexity': 'high',
                'required_skills': ['DevOps', 'Containerization', 'Cloud Platforms'],
                'deliverables': ['Docker files', 'Scripts', 'Documentation']
            },
            'testing': {
                'estimated_duration': 50,  # minutes
                'complexity': 'medium',
                'required_skills': ['Testing', 'QA', 'Automation'],
                'deliverables': ['Test suite', 'Reports', 'Coverage analysis']
            }
        }
        
        return metadata.get(task_name, {})
