"""
Task Manager for handling task lifecycle and coordination.
This module provides utilities for managing tasks across the agent system.
"""

import logging
import uuid
from datetime import datetime
from typing import Dict, List, Any, Optional
from enum import Enum

class TaskStatus(Enum):
    """Enumeration of possible task statuses."""
    PENDING = "pending"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class TaskPriority(Enum):
    """Enumeration of task priorities."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class TaskManager:
    """
    Task Manager class for handling task lifecycle and coordination.
    """
    
    def __init__(self):
        """
        Initialize the task manager.
        """
        self.logger = logging.getLogger(__name__)
        self.tasks: Dict[str, Dict[str, Any]] = {}
        self.task_queue: List[str] = []
        self.completed_tasks: List[str] = []
        self.failed_tasks: List[str] = []
    
    def create_task(self, 
                   description: str, 
                   task_type: str = "general",
                   priority: TaskPriority = TaskPriority.MEDIUM,
                   metadata: Optional[Dict[str, Any]] = None) -> str:
        """
        Create a new task.
        
        Args:
            description: Task description
            task_type: Type of task (e.g., 'frontend', 'backend', 'database')
            priority: Task priority
            metadata: Additional task metadata
            
        Returns:
            Task ID
        """
        task_id = str(uuid.uuid4())
        
        task = {
            'id': task_id,
            'description': description,
            'type': task_type,
            'priority': priority,
            'status': TaskStatus.PENDING,
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat(),
            'assigned_agent': None,
            'result': None,
            'error': None,
            'metadata': metadata or {}
        }
        
        self.tasks[task_id] = task
        self.task_queue.append(task_id)
        
        self.logger.info(f"Created task: {task_id} ({task_type})")
        return task_id
    
    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """
        Get task information by ID.
        
        Args:
            task_id: Task ID
            
        Returns:
            Task information or None if not found
        """
        return self.tasks.get(task_id)
    
    def update_task_status(self, task_id: str, status: TaskStatus, 
                          assigned_agent: Optional[str] = None,
                          result: Optional[Any] = None,
                          error: Optional[str] = None):
        """
        Update task status and related information.
        
        Args:
            task_id: Task ID
            status: New status
            assigned_agent: Agent assigned to the task
            result: Task result (if completed)
            error: Error message (if failed)
        """
        if task_id not in self.tasks:
            self.logger.error(f"Task not found: {task_id}")
            return
        
        task = self.tasks[task_id]
        task['status'] = status
        task['updated_at'] = datetime.now().isoformat()
        
        if assigned_agent:
            task['assigned_agent'] = assigned_agent
        
        if result is not None:
            task['result'] = result
        
        if error:
            task['error'] = error
        
        # Update task queues
        if status == TaskStatus.COMPLETED:
            if task_id in self.task_queue:
                self.task_queue.remove(task_id)
            if task_id not in self.completed_tasks:
                self.completed_tasks.append(task_id)
        elif status == TaskStatus.FAILED:
            if task_id in self.task_queue:
                self.task_queue.remove(task_id)
            if task_id not in self.failed_tasks:
                self.failed_tasks.append(task_id)
        
        self.logger.info(f"Updated task {task_id} status to {status.value}")
    
    def get_pending_tasks(self) -> List[Dict[str, Any]]:
        """
        Get all pending tasks.
        
        Returns:
            List of pending tasks
        """
        return [self.tasks[task_id] for task_id in self.task_queue 
                if self.tasks[task_id]['status'] == TaskStatus.PENDING]
    
    def get_tasks_by_type(self, task_type: str) -> List[Dict[str, Any]]:
        """
        Get tasks by type.
        
        Args:
            task_type: Type of tasks to retrieve
            
        Returns:
            List of tasks of the specified type
        """
        return [task for task in self.tasks.values() 
                if task['type'] == task_type]
    
    def get_tasks_by_status(self, status: TaskStatus) -> List[Dict[str, Any]]:
        """
        Get tasks by status.
        
        Args:
            status: Status to filter by
            
        Returns:
            List of tasks with the specified status
        """
        return [task for task in self.tasks.values() 
                if task['status'] == status]
    
    def get_task_statistics(self) -> Dict[str, Any]:
        """
        Get task statistics.
        
        Returns:
            Dictionary containing task statistics
        """
        total_tasks = len(self.tasks)
        completed_tasks = len(self.completed_tasks)
        failed_tasks = len(self.failed_tasks)
        pending_tasks = len(self.get_pending_tasks())
        
        # Calculate completion rate
        completion_rate = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
        
        # Task type distribution
        type_distribution = {}
        for task in self.tasks.values():
            task_type = task['type']
            type_distribution[task_type] = type_distribution.get(task_type, 0) + 1
        
        # Priority distribution
        priority_distribution = {}
        for task in self.tasks.values():
            priority = task['priority'].value
            priority_distribution[priority] = priority_distribution.get(priority, 0) + 1
        
        return {
            'total_tasks': total_tasks,
            'completed_tasks': completed_tasks,
            'failed_tasks': failed_tasks,
            'pending_tasks': pending_tasks,
            'completion_rate': completion_rate,
            'type_distribution': type_distribution,
            'priority_distribution': priority_distribution
        }
    
    def clear_completed_tasks(self):
        """
        Clear all completed tasks from memory.
        """
        for task_id in self.completed_tasks:
            if task_id in self.tasks:
                del self.tasks[task_id]
        
        self.completed_tasks.clear()
        self.logger.info("Cleared completed tasks")
    
    def clear_failed_tasks(self):
        """
        Clear all failed tasks from memory.
        """
        for task_id in self.failed_tasks:
            if task_id in self.tasks:
                del self.tasks[task_id]
        
        self.failed_tasks.clear()
        self.logger.info("Cleared failed tasks")
