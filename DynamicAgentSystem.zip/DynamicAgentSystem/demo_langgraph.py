#!/usr/bin/env python3
"""
Démonstration interactive du système multi-agents utilisant LangGraph.
"""

import asyncio
import logging
import os
from dotenv import load_dotenv

from agents.langgraph_agents import LangGraphMultiAgentSystem
from utils.logger import setup_logging

# Charger les variables d'environnement
load_dotenv()

async def demo_langgraph_workflow():
    """
    Démonstration du workflow LangGraph avec une tâche personnalisée.
    """
    print("🔄 Démonstration du workflow LangGraph")
    print("-" * 50)
    
    # Demander une tâche personnalisée
    task = input("📝 Décrivez votre tâche : ")
    
    if not task.strip():
        print("❌ Aucune tâche saisie")
        return
    
    # Initialiser le système
    agent_system = LangGraphMultiAgentSystem()
    
    print(f"\n📋 Tâche : {task}")
    print("\n🔄 Exécution du workflow LangGraph...")
    print("   • Analyse de la tâche...")
    print("   • Identification des agents requis...")
    print("   • Coordination des agents...")
    print("   • Compilation des résultats...")
    
    result = await agent_system.execute_task(task)
    
    if result.get('status') == 'completed':
        print("\n✅ Workflow terminé avec succès !")
        print(f"⏱️ Temps d'exécution : {result.get('execution_time', 0):.2f}s")
        print(f"🤖 Agents utilisés : {', '.join(result.get('agents_used', []))}")
        
        # Afficher les résultats détaillés
        print("\n📊 Résultats détaillés :")
        for i, res in enumerate(result.get('results', []), 1):
            print(f"\n{i}. Agent {res['agent_type'].upper()}")
            if res.get('status') == 'completed':
                content = res.get('result', '')
                print(f"   Temps : {res.get('execution_time', 0):.2f}s")
                print(f"   Résultat : {content[:200]}...")
            else:
                print(f"   Erreur : {res.get('error', 'Erreur inconnue')}")
    else:
        print(f"\n❌ Erreur du workflow : {result.get('error', 'Erreur inconnue')}")
    
    return result

async def compare_approaches():
    """
    Compare les approches simple et LangGraph.
    """
    print("\n🔄 Comparaison des approches")
    print("-" * 50)
    
    test_task = "Créez une page web simple avec un formulaire de contact"
    
    # Test avec l'approche simple
    print("1. Test avec l'approche simple...")
    from agents.simple_agents import SimpleAgentManager
    simple_manager = SimpleAgentManager()
    
    start_time = asyncio.get_event_loop().time()
    simple_result = await simple_manager.execute_task(test_task)
    simple_time = asyncio.get_event_loop().time() - start_time
    
    # Test avec LangGraph
    print("2. Test avec LangGraph...")
    langgraph_system = LangGraphMultiAgentSystem()
    
    start_time = asyncio.get_event_loop().time()
    langgraph_result = await langgraph_system.execute_task(test_task)
    langgraph_time = asyncio.get_event_loop().time() - start_time
    
    # Comparaison
    print("\n📊 Comparaison des résultats :")
    print(f"Approche simple    : {simple_time:.2f}s - {simple_result.get('status', 'unknown')}")
    print(f"LangGraph          : {langgraph_time:.2f}s - {langgraph_result.get('status', 'unknown')}")
    
    print("\n🔍 Avantages LangGraph :")
    print("• Workflow structuré et prévisible")
    print("• Gestion d'état avancée")
    print("• Meilleure observabilité")
    print("• Coordination plus sophistiquée")

async def main():
    """
    Fonction principale de démonstration.
    """
    # Configuration des logs
    setup_logging()
    logger = logging.getLogger(__name__)
    
    print("🚀 Système Multi-Agents LangGraph - Démonstration")
    print("=" * 60)
    
    # Vérifier la clé API
    if not os.getenv("OPENROUTER_API_KEY") or os.getenv("OPENROUTER_API_KEY") == "your-openrouter-api-key-here":
        print("❌ Clé API OpenRouter non configurée")
        print("📝 Veuillez configurer OPENROUTER_API_KEY dans le fichier .env")
        print("🔗 Obtenez une clé sur : https://openrouter.ai/")
        return
    
    try:
        # Menu de sélection
        print("\nChoisissez une démonstration :")
        print("1. Workflow LangGraph personnalisé")
        print("2. Comparaison des approches")
        print("3. Démonstration complète")
        print("4. Quitter")
        
        while True:
            choice = input("\n🎯 Votre choix (1-4) : ").strip()
            
            if choice == '1':
                await demo_langgraph_workflow()
                break
            elif choice == '2':
                await compare_approaches()
                break
            elif choice == '3':
                print("\n🚀 Lancement de la démonstration complète...")
                print("Utilisez : python main_langgraph.py")
                break
            elif choice == '4':
                print("👋 Au revoir !")
                break
            else:
                print("❌ Choix invalide, veuillez choisir 1, 2, 3 ou 4")
        
    except KeyboardInterrupt:
        print("\n\n👋 Démonstration interrompue par l'utilisateur")
    except Exception as e:
        logger.error(f"Erreur lors de la démonstration : {e}")
        print(f"❌ Erreur : {e}")

if __name__ == "__main__":
    asyncio.run(main())