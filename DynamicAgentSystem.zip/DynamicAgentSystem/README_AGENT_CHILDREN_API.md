# 🤖 API FastAPI - Gestion Agents Enfants

## 🎯 Description

API FastAPI complète pour gérer la génération et le pilotage dynamique d'agents enfants dans un système multi-agents Python. Cette API permet de créer, commander, surveiller et supprimer des agents enfants avec une gestion complète du cycle de vie.

## ✨ Fonctionnalités

### 🔧 Endpoints Principaux

| Endpoint | Méthode | Description |
|----------|---------|-------------|
| `POST /agents/children` | POST | Créer un agent enfant |
| `GET /agents/children` | GET | Lister tous les agents |
| `POST /agents/children/{agent_id}/command` | POST | Envoyer une commande |
| `GET /agents/children/{agent_id}/status` | GET | Récupérer le statut |
| `DELETE /agents/children/{agent_id}` | DELETE | Supprimer un agent |

### 🏗️ Types d'Agents

- **Thread Agent** : Exécution en thread Python (rapide, partage mémoire)
- **Subprocess Agent** : Exécution en subprocess (isolé, robuste)

### 🔄 États d'Agents

- `created` : Agent créé
- `starting` : Démarrage en cours
- `running` : En fonctionnement
- `busy` : Traitement d'une commande
- `idle` : En attente
- `stopping` : Arrêt en cours
- `stopped` : Arrêté
- `error` : Erreur

## 🚀 Utilisation

### 1. Démarrage de l'API

```bash
python agent_children_api.py
```

L'API sera disponible sur `http://localhost:5001`

### 2. Documentation Swagger

Accédez à la documentation interactive : `http://localhost:5001/docs`

### 3. Exemple d'Usage

```python
import requests

# Créer un agent
response = requests.post('http://localhost:5001/agents/children', json={
    "name": "DataProcessor",
    "role": "data_processor",
    "context": "Agent de traitement de données",
    "agent_type": "thread",
    "parameters": {"batch_size": 100},
    "max_lifetime": 600
})

agent_id = response.json()["agent_id"]

# Envoyer une commande
response = requests.post(f'http://localhost:5001/agents/children/{agent_id}/command', json={
    "command": "process_data",
    "parameters": {"data": "sample_data"},
    "timeout": 30
})

# Récupérer le statut
response = requests.get(f'http://localhost:5001/agents/children/{agent_id}/status')
print(response.json())

# Supprimer l'agent
response = requests.delete(f'http://localhost:5001/agents/children/{agent_id}')
```

## 📁 Structure du Projet

```
agent_children_api.py          # API FastAPI principale
test_agent_children_api.py     # Tests automatisés
example_usage.py               # Exemple d'utilisation
README_AGENT_CHILDREN_API.md   # Documentation
```

## 🧪 Tests

### Tests Automatisés

```bash
python test_agent_children_api.py
```

### Exemple Complet

```bash
python example_usage.py
```

## 🔧 Configuration

### Variables d'Environnement

```env
# Optionnel - Configuration par défaut
AGENT_MAX_LIFETIME=3600        # Durée de vie max (secondes)
AGENT_CLEANUP_INTERVAL=60      # Intervalle de nettoyage (secondes)
MAX_CONCURRENT_AGENTS=50       # Nombre max d'agents simultanés
```

### Paramètres de Création d'Agent

```json
{
  "name": "MonAgent",
  "role": "data_processor|web_scraper|task_executor",
  "context": "Contexte d'exécution",
  "agent_type": "thread|subprocess",
  "parameters": {
    "custom_param": "valeur"
  },
  "max_lifetime": 3600
}
```

## 🎭 Rôles d'Agents Prédéfinis

### `data_processor`
- Traitement de données
- Agrégation et analyse
- Transformation de formats

### `web_scraper`
- Extraction de données web
- Monitoring de sites
- Collecte d'informations

### `task_executor`
- Exécution de tâches génériques
- Traitement par lots
- Workflows automatisés

## 🔒 Sécurité

### Gestion du Cycle de Vie

- ✅ Arrêt propre des agents
- ✅ Nettoyage automatique des ressources
- ✅ Timeout configurable
- ✅ Gestion des erreurs robuste

### Isolation des Processus

- ✅ Subprocess isolés
- ✅ Gestion des signaux
- ✅ Limitation des ressources
- ✅ Monitoring en temps réel

## 📊 Monitoring

### Logs Détaillés

Chaque agent maintient des logs détaillés :

```json
{
  "logs": [
    "[2025-07-09T15:11:05.488360] Agent DataProcessor créé et démarré avec succès",
    "[2025-07-09T15:11:05.494683] Traitement de la commande: process_user_data",
    "[2025-07-09T15:11:05.995342] Commande exécutée: process_user_data"
  ]
}
```

### Métriques

- Nombre d'agents actifs
- Temps de traitement des commandes
- Taux de succès/échec
- Utilisation des ressources

## 🛠️ Extension

### Ajouter un Nouveau Rôle

```python
# Dans _process_command()
elif agent_config['role'] == 'mon_nouveau_role':
    # Logique personnalisée
    return {
        'status': 'success',
        'result': 'Traitement personnalisé',
        'custom_data': custom_processing()
    }
```

### Middleware Personnalisé

```python
@app.middleware("http")
async def custom_middleware(request: Request, call_next):
    # Logique personnalisée
    response = await call_next(request)
    return response
```

## 🔧 Dépannage

### Problèmes Courants

1. **Port occupé** : Changez le port dans `uvicorn.run(app, port=5001)`
2. **Agent bloqué** : Vérifiez les logs et utilisez DELETE
3. **Timeout** : Augmentez le timeout dans les requêtes
4. **Mémoire** : Limitez le nombre d'agents simultanés

### Logs de Debug

```bash
# Activer les logs détaillés
import logging
logging.basicConfig(level=logging.DEBUG)
```

## 🎉 Résultats de Test

```
✅ API accessible: 200 OK
✅ Agent créé avec succès: DataProcessor
✅ Commande exécutée: process_user_data
✅ Statut récupéré: idle
✅ Agent supprimé: avec succès
```

## 📋 Spécifications Techniques

### Contraintes Respectées

- ✅ **Subprocess/Thread** : Gestion complète des deux types
- ✅ **Bibliothèques standard** : Utilisation de threading, subprocess, queue
- ✅ **Cycle de vie** : Création, supervision, suppression propre
- ✅ **Registre d'agents** : Suivi complet des états et logs
- ✅ **Documentation Swagger** : Auto-générée par FastAPI

### Architecture

```
API FastAPI
├── AgentManager (Gestionnaire principal)
├── AgentState (États et transitions)
├── Command Queue (Communication thread)
├── Result Queue (Retour de résultats)
├── Process Manager (Subprocess)
└── Cleanup Service (Nettoyage automatique)
```

## 🎯 Prochaines Améliorations

- [ ] Authentification JWT
- [ ] Métriques Prometheus
- [ ] Clustering d'agents
- [ ] Persistance en base de données
- [ ] Interface web de monitoring
- [ ] Notifications WebSocket

---

**API complètement fonctionnelle et prête à l'usage !**

Pour des questions ou des améliorations, référez-vous à la documentation Swagger : `http://localhost:5001/docs`