// Interface Web Multi-Agents - JavaScript principal
class MultiAgentInterface {
    constructor() {
        this.apiBase = '/api';
        this.updateInterval = null;
        this.filters = {
            status: 'all',
            agent: 'all'
        };
        this.notifications = [];
        
        this.init();
    }
    
    async init() {
        this.setupEventListeners();
        await this.loadInitialData();
        this.startRealTimeUpdates();
    }
    
    setupEventListeners() {
        // Bouton créer tâche
        document.getElementById('createTaskBtn')?.addEventListener('click', () => this.createTask());
        
        // Entrée pour créer tâche avec Enter
        document.getElementById('taskDescription')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && e.ctrlKey) {
                this.createTask();
            }
        });
        
        // Filtres
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.applyFilter(e.target));
        });
        
        // Export
        document.getElementById('exportBtn')?.addEventListener('click', () => this.exportData());
    }
    
    async loadInitialData() {
        try {
            await Promise.all([
                this.loadAgents(),
                this.loadTasks(),
                this.loadStatistics()
            ]);
        } catch (error) {
            this.showNotification('Erreur lors du chargement initial', 'error');
        }
    }
    
    startRealTimeUpdates() {
        this.updateInterval = setInterval(async () => {
            try {
                await Promise.all([
                    this.loadTasks(),
                    this.loadStatistics()
                ]);
                this.updateConnectionStatus(true);
            } catch (error) {
                this.updateConnectionStatus(false);
                console.error('Erreur de mise à jour:', error);
            }
        }, 2000);
    }
    
    updateConnectionStatus(connected) {
        const indicator = document.getElementById('connectionStatus');
        if (indicator) {
            indicator.textContent = connected ? '🟢 Connecté' : '🔴 Déconnecté';
            indicator.className = connected ? 'real-time-indicator' : 'real-time-indicator disconnected';
        }
    }
    
    async createTask() {
        const description = document.getElementById('taskDescription')?.value.trim();
        
        if (!description) {
            this.showNotification('Veuillez entrer une description de tâche', 'error');
            return;
        }
        
        try {
            const response = await fetch(`${this.apiBase}/tasks`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ description })
            });
            
            const result = await response.json();
            
            if (response.ok) {
                document.getElementById('taskDescription').value = '';
                this.showNotification(`Tâche créée avec succès! ID: ${result.task_id.slice(0, 8)}...`, 'success');
                await this.loadTasks();
            } else {
                this.showNotification(`Erreur: ${result.error}`, 'error');
            }
        } catch (error) {
            this.showNotification(`Erreur de connexion: ${error.message}`, 'error');
        }
    }
    
    async loadAgents() {
        try {
            const response = await fetch(`${this.apiBase}/agents`);
            const agents = await response.json();
            
            const agentsGrid = document.getElementById('agentsGrid');
            if (!agentsGrid) return;
            
            agentsGrid.innerHTML = agents.map(agent => `
                <div class="agent-card" data-type="${agent.type}">
                    <div class="agent-icon">${this.getAgentIcon(agent.type)}</div>
                    <div class="agent-name">${agent.name}</div>
                    <div class="agent-description">${agent.description}</div>
                    <div class="agent-status" id="agent-status-${agent.type}">Idle</div>
                </div>
            `).join('');
        } catch (error) {
            console.error('Erreur lors du chargement des agents:', error);
        }
    }
    
    async loadTasks() {
        try {
            const response = await fetch(`${this.apiBase}/tasks`);
            const tasks = await response.json();
            
            const taskList = document.getElementById('taskList');
            if (!taskList) return;
            
            if (tasks.length === 0) {
                taskList.innerHTML = '<div class="loading">Aucune tâche disponible</div>';
                return;
            }
            
            // Filtrer les tâches
            const filteredTasks = this.filterTasks(tasks);
            
            taskList.innerHTML = filteredTasks.map(task => this.renderTask(task)).join('');
            
            // Ajouter les event listeners pour les actions
            this.setupTaskActions();
            
        } catch (error) {
            console.error('Erreur lors du chargement des tâches:', error);
            document.getElementById('taskList').innerHTML = '<div class="loading">Erreur de chargement</div>';
        }
    }
    
    filterTasks(tasks) {
        return tasks.filter(task => {
            const statusMatch = this.filters.status === 'all' || task.status === this.filters.status;
            const agentMatch = this.filters.agent === 'all' || task.agents.includes(this.filters.agent);
            return statusMatch && agentMatch;
        });
    }
    
    renderTask(task) {
        const timelineItems = this.getTaskTimeline(task);
        
        return `
            <div class="task-item" data-task-id="${task.id}">
                <div class="task-header">
                    <div class="task-id">ID: ${task.id.slice(0, 8)}...</div>
                    <div class="task-status status-${task.status}">${this.getStatusLabel(task.status)}</div>
                </div>
                <div class="task-description">${task.description}</div>
                <div class="agent-activity">
                    ${task.agents.map(agent => `
                        <span class="agent-badge agent-${agent} ${task.status === 'running' ? 'active' : ''}">${agent}</span>
                    `).join('')}
                </div>
                ${task.progress !== undefined ? `
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${task.progress}%"></div>
                    </div>
                ` : ''}
                <div class="task-actions">
                    <button class="btn btn-small" onclick="multiAgentInterface.toggleDetails('${task.id}')">
                        Détails
                    </button>
                    ${task.status === 'running' ? `
                        <button class="btn btn-small btn-secondary" onclick="multiAgentInterface.cancelTask('${task.id}')">
                            Annuler
                        </button>
                    ` : ''}
                </div>
                <div class="task-details" id="details-${task.id}">
                    <div class="task-timeline">
                        ${timelineItems.map(item => `
                            <div class="timeline-item">
                                <div class="timeline-dot"></div>
                                <div>${item}</div>
                            </div>
                        `).join('')}
                    </div>
                    ${task.results ? `
                        <div class="task-results">
                            <strong>Résultats:</strong>
                            <pre>${JSON.stringify(task.results, null, 2)}</pre>
                        </div>
                    ` : ''}
                    ${task.errors && task.errors.length > 0 ? `
                        <div class="error-message">
                            <strong>Erreurs:</strong>
                            ${task.errors.map(error => `
                                <div>${error.timestamp}: ${error.message}</div>
                            `).join('')}
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
    }
    
    getTaskTimeline(task) {
        const timeline = [];
        
        if (task.created_at) {
            timeline.push(`Créée le ${new Date(task.created_at).toLocaleString()}`);
        }
        
        if (task.started_at) {
            timeline.push(`Démarrée le ${new Date(task.started_at).toLocaleString()}`);
        }
        
        if (task.completed_at) {
            timeline.push(`Terminée le ${new Date(task.completed_at).toLocaleString()}`);
        }
        
        return timeline;
    }
    
    setupTaskActions() {
        // Les event listeners sont déjà ajoutés via onclick dans le HTML
    }
    
    toggleDetails(taskId) {
        const details = document.getElementById(`details-${taskId}`);
        if (details) {
            details.classList.toggle('show');
        }
    }
    
    async cancelTask(taskId) {
        if (!confirm('Êtes-vous sûr de vouloir annuler cette tâche?')) {
            return;
        }
        
        try {
            const response = await fetch(`${this.apiBase}/tasks/${taskId}/cancel`, {
                method: 'POST'
            });
            
            if (response.ok) {
                this.showNotification('Tâche annulée avec succès', 'success');
                await this.loadTasks();
            } else {
                this.showNotification('Erreur lors de l\'annulation', 'error');
            }
        } catch (error) {
            this.showNotification('Erreur de connexion', 'error');
        }
    }
    
    async loadStatistics() {
        try {
            const response = await fetch(`${this.apiBase}/statistics`);
            const stats = await response.json();
            
            const webStats = stats.web_interface || {};
            
            this.updateElement('activeTasks', webStats.active_tasks || 0);
            this.updateElement('totalTasks', webStats.total_tasks || 0);
            this.updateElement('completedTasks', webStats.completed_tasks || 0);
            this.updateElement('activeAgents', stats.active_agents || 0);
            
        } catch (error) {
            console.error('Erreur lors du chargement des statistiques:', error);
        }
    }
    
    updateElement(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
        }
    }
    
    applyFilter(btn) {
        // Retirer la classe active de tous les boutons du même groupe
        const group = btn.dataset.group;
        document.querySelectorAll(`[data-group="${group}"]`).forEach(b => {
            b.classList.remove('active');
        });
        
        // Ajouter la classe active au bouton cliqué
        btn.classList.add('active');
        
        // Appliquer le filtre
        this.filters[group] = btn.dataset.value;
        
        // Recharger les tâches
        this.loadTasks();
    }
    
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Afficher la notification
        setTimeout(() => notification.classList.add('show'), 100);
        
        // Masquer et supprimer après 3 secondes
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
    
    async exportData() {
        try {
            const response = await fetch(`${this.apiBase}/export`);
            const data = await response.blob();
            
            const url = window.URL.createObjectURL(data);
            const a = document.createElement('a');
            a.href = url;
            a.download = `multi-agent-data-${new Date().toISOString().split('T')[0]}.json`;
            a.click();
            
            window.URL.revokeObjectURL(url);
            this.showNotification('Export terminé avec succès', 'success');
        } catch (error) {
            this.showNotification('Erreur lors de l\'export', 'error');
        }
    }
    
    getAgentIcon(type) {
        const icons = {
            'frontend': '🎨',
            'backend': '⚙️',
            'database': '🗃️',
            'devops': '🚀',
            'testing': '🧪'
        };
        return icons[type] || '🤖';
    }
    
    getStatusLabel(status) {
        const labels = {
            'created': 'Créée',
            'running': 'En cours',
            'completed': 'Terminée',
            'failed': 'Échec'
        };
        return labels[status] || status;
    }
    
    destroy() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
        }
    }
}

// Initialisation globale
let multiAgentInterface;

document.addEventListener('DOMContentLoaded', function() {
    multiAgentInterface = new MultiAgentInterface();
});

// Nettoyage lors de la fermeture
window.addEventListener('beforeunload', function() {
    if (multiAgentInterface) {
        multiAgentInterface.destroy();
    }
});