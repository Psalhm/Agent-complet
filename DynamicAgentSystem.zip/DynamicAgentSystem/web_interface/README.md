# 🖥️ Interface Web Multi-Agents

Une interface web moderne pour visualiser et contrôler votre système multi-agents en temps réel.

## 🎯 Fonctionnalités

### ✅ Gestion des Tâches
- **Création** : Interface simple pour créer des tâches en texte libre
- **Suivi temps réel** : Visualisation du statut des tâches en cours
- **Historique** : Consultation des tâches passées
- **Détails** : Timeline détaillée pour chaque tâche

### 🤖 Visualisation des Agents
- **Agents disponibles** : Vue d'ensemble des 5 types d'agents
- **Statut en temps réel** : Agents actifs/inactifs
- **Activité** : Suivi des agents déclenchés par tâche

### 📊 Statistiques
- **Métriques globales** : Tâches actives, terminées, agents actifs
- **Mise à jour temps réel** : Actualisation automatique toutes les 2 secondes
- **Indicateur de connexion** : Statut de la connexion au système

### 🔍 Filtres et Recherche
- **Filtres par statut** : Toutes, en cours, terminées, échouées
- **Filtres par agent** : Affichage par type d'agent
- **Export** : Sauvegarde des données au format JSON

## 🚀 Démarrage

### Installation
```bash
# Installer les dépendances (déjà fait)
uv add flask flask-cors

# Démarrer l'interface web
cd web_interface
python app.py
```

### Accès
- **Interface** : http://localhost:5000
- **API** : http://localhost:5000/api/

## 🔧 Architecture

### Backend Flask
- **Point d'entrée** : `app.py`
- **Templates** : `templates/index.html`
- **Statiques** : `static/style.css`, `static/app.js`

### API Endpoints
- `POST /api/tasks` - Créer une tâche
- `GET /api/tasks` - Lister toutes les tâches
- `GET /api/tasks/<id>` - Détails d'une tâche
- `GET /api/agents` - Lister les agents
- `GET /api/statistics` - Statistiques système
- `GET /api/health` - Santé du système

### Frontend
- **HTML/CSS/JS** : Interface responsive moderne
- **Temps réel** : Actualisation automatique
- **Notifications** : Feedback utilisateur immédiat
- **Mobile** : Interface adaptée aux petits écrans

## 💡 Utilisation

### 1. Créer une Tâche
1. Saisissez la description dans le champ texte
2. Cliquez sur "🚀 Lancer la Tâche"
3. Suivez le progrès en temps réel

### 2. Suivre les Agents
- Les agents actifs sont marqués d'un point vert
- Chaque tâche affiche les agents déclenchés
- Statut mis à jour automatiquement

### 3. Consulter l'Historique
- Toutes les tâches sont listées avec leur statut
- Cliquez sur "Détails" pour voir la timeline
- Utilisez les filtres pour affiner la vue

### 4. Surveiller les Statistiques
- Compteurs mis à jour en temps réel
- Indicateur de connexion en haut à droite
- Métriques globales du système

## 🔐 Sécurité

### Configuration
- Variables d'environnement pour les API keys
- Validation des entrées utilisateur
- Gestion d'erreurs complète

### Accès
- Interface locale par défaut
- Modification possible pour accès distant
- Pas d'authentification (à ajouter si nécessaire)

## 🎨 Personnalisation

### Styles
- Modifiez `static/style.css` pour l'apparence
- Thème sombre/clair facilement implémentable
- Responsive design inclus

### Fonctionnalités
- `static/app.js` pour les interactions
- API extensible pour nouvelles fonctionnalités
- Système de notifications personnalisable

## 📱 Interface

### Dashboard Principal
```
┌─────────────────────────────────────────────────────┐
│                🤖 Interface Multi-Agents             │
│              Créez et suivez vos tâches             │
├─────────────────────────────────────────────────────┤
│  📝 Créer une Tâche    │    📊 Statistiques        │
│  ┌─────────────────────┐    │  ┌─────┐ ┌─────┐      │
│  │ Description...      │    │  │  3  │ │  15 │      │
│  └─────────────────────┘    │  └─────┘ └─────┘      │
│  🚀 Lancer la Tâche        │  Actives  Total        │
├─────────────────────────────────────────────────────┤
│              🤖 Agents Disponibles                   │
│  🎨 Frontend  ⚙️ Backend  🗃️ Database  🚀 DevOps   │
├─────────────────────────────────────────────────────┤
│              📋 Tâches et Historique                 │
│  ┌─────────────────────────────────────────────────┐ │
│  │ ID: 1234...    [En cours]                       │ │
│  │ Créer une page d'accueil                        │ │
│  │ frontend backend                                 │ │
│  └─────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────┘
```

## 🚀 Déploiement

### Local
```bash
python app.py
# Interface sur http://localhost:5000
```

### Replit
- L'interface s'adapte automatiquement
- Port 5000 configuré pour Replit
- Domaine `.replit.app` disponible

### Production
- Ajouter authentification si nécessaire
- Configurer HTTPS
- Optimiser pour la performance

## 🔧 Maintenance

### Logs
- Logs système dans la console
- Erreurs capturées et affichées
- Monitoring des performances

### Mises à jour
- Actualisation automatique des données
- Gestion des déconnexions
- Reconnexion automatique

### Sauvegarde
- Export des données en JSON
- Historique persistant
- Intégration avec l'API mémoire

---

**L'interface web est maintenant prête !** Lancez `python app.py` et accédez à http://localhost:5000 pour commencer à utiliser votre système multi-agents visuellement.