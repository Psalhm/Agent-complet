#!/usr/bin/env python3
"""
Interface web Flask pour le système multi-agents.
Permet de créer des tâches, suivre les agents et voir l'historique.
"""

import asyncio
import json
import os
import uuid
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_from_directory
from flask_cors import CORS
from dotenv import load_dotenv
import threading
import time

# Import du système multi-agents
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from agents.langgraph_agents import LangGraphMultiAgentSystem
from utils.memory_client import MemoryAPIClient
from utils.logger import setup_logging

# Configuration
load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '.env'))
app = Flask(__name__)
CORS(app)

# Variables globales
agent_system = None
memory_client = None
active_tasks = {}  # {task_id: task_info}
task_history = []  # Historique des tâches

class WebInterfaceManager:
    def __init__(self):
        self.agent_system = LangGraphMultiAgentSystem()
        self.memory_client = MemoryAPIClient()
        self.setup_logging()
    
    def setup_logging(self):
        """Configure les logs."""
        setup_logging()
    
    async def create_task(self, task_description, user_id="web_user"):
        """Crée une nouvelle tâche."""
        task_id = str(uuid.uuid4())
        task_info = {
            'id': task_id,
            'description': task_description,
            'status': 'created',
            'created_at': datetime.now().isoformat(),
            'user_id': user_id,
            'agents': [],
            'results': {},
            'errors': [],
            'progress': 0
        }
        
        active_tasks[task_id] = task_info
        return task_id
    
    async def execute_task(self, task_id):
        """Exécute une tâche de manière asynchrone."""
        if task_id not in active_tasks:
            return {"error": "Task not found"}
        
        task_info = active_tasks[task_id]
        task_info['status'] = 'running'
        task_info['started_at'] = datetime.now().isoformat()
        
        try:
            # Exécuter la tâche
            result = await self.agent_system.execute_task(task_info['description'])
            
            # Mettre à jour les informations
            task_info['status'] = 'completed'
            task_info['completed_at'] = datetime.now().isoformat()
            task_info['results'] = result
            task_info['agents'] = result.get('agents_used', [])
            task_info['progress'] = 100
            
            # Archiver la tâche
            task_history.append(task_info.copy())
            
            return result
            
        except Exception as e:
            task_info['status'] = 'failed'
            task_info['error'] = str(e)
            task_info['completed_at'] = datetime.now().isoformat()
            task_info['errors'].append({
                'message': str(e),
                'timestamp': datetime.now().isoformat()
            })
            
            # Archiver même en cas d'erreur
            task_history.append(task_info.copy())
            
            return {"error": str(e)}
    
    async def get_task_status(self, task_id):
        """Récupère le statut d'une tâche."""
        if task_id in active_tasks:
            return active_tasks[task_id]
        
        # Chercher dans l'historique
        for task in task_history:
            if task['id'] == task_id:
                return task
        
        return None
    
    async def get_system_stats(self):
        """Récupère les statistiques du système."""
        try:
            stats = await self.agent_system.get_statistics()
            return stats
        except Exception as e:
            return {"error": str(e)}

# Instance globale
web_manager = WebInterfaceManager()

@app.route('/')
def index():
    """Page principale."""
    return render_template('index.html')

@app.route('/api/tasks', methods=['POST'])
def create_task():
    """Crée une nouvelle tâche."""
    data = request.json
    if not data or 'description' not in data:
        return jsonify({'error': 'Description required'}), 400
    
    # Créer la tâche de manière synchrone
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    try:
        task_id = loop.run_until_complete(
            web_manager.create_task(data['description'])
        )
        
        # Lancer l'exécution en arrière-plan
        def run_task():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(web_manager.execute_task(task_id))
        
        thread = threading.Thread(target=run_task)
        thread.daemon = True
        thread.start()
        
        return jsonify({'task_id': task_id})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        loop.close()

@app.route('/api/tasks/<task_id>', methods=['GET'])
def get_task_status(task_id):
    """Récupère le statut d'une tâche."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    try:
        task_info = loop.run_until_complete(
            web_manager.get_task_status(task_id)
        )
        
        if task_info is None:
            return jsonify({'error': 'Task not found'}), 404
        
        return jsonify(task_info)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        loop.close()

@app.route('/api/tasks', methods=['GET'])
def get_all_tasks():
    """Récupère toutes les tâches."""
    all_tasks = []
    
    # Tâches actives
    for task_id, task_info in active_tasks.items():
        all_tasks.append(task_info)
    
    # Historique
    all_tasks.extend(task_history)
    
    # Trier par date de création
    all_tasks.sort(key=lambda x: x['created_at'], reverse=True)
    
    return jsonify(all_tasks)

@app.route('/api/statistics', methods=['GET'])
def get_statistics():
    """Récupère les statistiques du système."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    try:
        stats = loop.run_until_complete(web_manager.get_system_stats())
        
        # Ajouter des statistiques locales
        stats['web_interface'] = {
            'active_tasks': len(active_tasks),
            'total_tasks': len(active_tasks) + len(task_history),
            'completed_tasks': len(task_history)
        }
        
        return jsonify(stats)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        loop.close()

@app.route('/api/agents', methods=['GET'])
def get_agents():
    """Récupère la liste des agents disponibles."""
    agents = [
        {'type': 'frontend', 'name': 'Agent Frontend', 'description': 'HTML, CSS, JavaScript, UI/UX'},
        {'type': 'backend', 'name': 'Agent Backend', 'description': 'APIs, logique métier, serveurs'},
        {'type': 'database', 'name': 'Agent Database', 'description': 'SQL, modélisation, requêtes'},
        {'type': 'devops', 'name': 'Agent DevOps', 'description': 'Déploiement, infrastructure'},
        {'type': 'testing', 'name': 'Agent Testing', 'description': 'Tests, QA, validation'}
    ]
    
    return jsonify(agents)

@app.route('/api/health', methods=['GET'])
def health_check():
    """Vérification de santé du système."""
    health_status = {
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'services': {}
    }
    
    # Vérifier OpenRouter
    openrouter_key = os.getenv('OPENROUTER_API_KEY')
    health_status['services']['openrouter'] = {
        'status': 'configured' if openrouter_key and openrouter_key != 'your-openrouter-api-key-here' else 'not_configured'
    }
    
    # Vérifier API mémoire
    memory_url = os.getenv('MEMORY_API_BASE_URL')
    memory_key = os.getenv('MEMORY_API_KEY')
    health_status['services']['memory_api'] = {
        'status': 'configured' if memory_url and memory_key else 'not_configured'
    }
    
    return jsonify(health_status)

if __name__ == '__main__':
    print("🚀 Démarrage de l'interface web multi-agents...")
    print("📱 Interface accessible sur : http://localhost:5000")
    print("🔧 API disponible sur : http://localhost:5000/api/")
    
    # Servir sur 0.0.0.0 pour Replit
    app.run(host='0.0.0.0', port=5000, debug=True)