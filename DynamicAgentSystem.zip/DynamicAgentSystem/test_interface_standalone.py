#!/usr/bin/env python3
"""
Test autonome de l'interface web sans APIs externes.
"""

import asyncio
import requests
import json
import time

def test_interface_endpoints():
    """Test les endpoints de l'interface web."""
    base_url = "http://localhost:5000"
    
    print("🧪 Test des endpoints de l'interface web")
    print("=" * 50)
    
    # Test 1: Santé du système
    print("\n1. Test de santé...")
    try:
        response = requests.get(f"{base_url}/api/health")
        print(f"✅ Health check: {response.status_code}")
        print(f"   Réponse: {response.json()}")
    except Exception as e:
        print(f"❌ Health check échoué: {e}")
    
    # Test 2: Liste des agents
    print("\n2. Test des agents...")
    try:
        response = requests.get(f"{base_url}/api/agents")
        agents = response.json()
        print(f"✅ Agents: {len(agents)} agents disponibles")
        for agent in agents:
            print(f"   • {agent['name']}: {agent['description']}")
    except Exception as e:
        print(f"❌ Agents échoué: {e}")
    
    # Test 3: Statistiques
    print("\n3. Test des statistiques...")
    try:
        response = requests.get(f"{base_url}/api/statistics")
        stats = response.json()
        print(f"✅ Statistiques: {response.status_code}")
        if 'web_interface' in stats:
            web_stats = stats['web_interface']
            print(f"   • Tâches actives: {web_stats.get('active_tasks', 0)}")
            print(f"   • Total tâches: {web_stats.get('total_tasks', 0)}")
    except Exception as e:
        print(f"❌ Statistiques échoué: {e}")
    
    # Test 4: Liste des tâches
    print("\n4. Test des tâches...")
    try:
        response = requests.get(f"{base_url}/api/tasks")
        tasks = response.json()
        print(f"✅ Tâches: {len(tasks)} tâches")
    except Exception as e:
        print(f"❌ Tâches échoué: {e}")
    
    # Test 5: Création d'une tâche
    print("\n5. Test de création de tâche...")
    try:
        task_data = {
            "description": "Test de création d'une tâche simple pour vérifier l'interface"
        }
        response = requests.post(f"{base_url}/api/tasks", json=task_data)
        result = response.json()
        
        if response.status_code == 200:
            print(f"✅ Création de tâche réussie: {result.get('task_id', 'ID manquant')}")
            task_id = result.get('task_id')
            
            # Attendre un peu puis vérifier le statut
            print("   Attente de 3 secondes pour vérifier le statut...")
            time.sleep(3)
            
            # Vérifier le statut de la tâche
            status_response = requests.get(f"{base_url}/api/tasks/{task_id}")
            if status_response.status_code == 200:
                task_info = status_response.json()
                print(f"   Statut: {task_info.get('status', 'Inconnu')}")
                print(f"   Agents: {task_info.get('agents', [])}")
            else:
                print(f"   ❌ Impossible de récupérer le statut: {status_response.status_code}")
                
        else:
            print(f"❌ Création de tâche échouée: {result.get('error', 'Erreur inconnue')}")
            
    except Exception as e:
        print(f"❌ Création de tâche échouée: {e}")
    
    print("\n" + "=" * 50)
    print("✅ Test terminé !")

if __name__ == "__main__":
    test_interface_endpoints()