#!/usr/bin/env python3
"""
Script de test pour l'API de gestion des agents enfants.
Valide les endpoints de création, commande, statut et suppression.
"""

import requests
import json
import time
import asyncio
from typing import Dict, Any

class AgentAPITester:
    """Testeur pour l'API des agents enfants."""
    
    def __init__(self, base_url: str = "http://localhost:5001"):
        self.base_url = base_url
        self.session = requests.Session()
    
    def test_api_health(self) -> bool:
        """Test de santé de l'API."""
        try:
            response = self.session.get(f"{self.base_url}/")
            return response.status_code == 200
        except Exception as e:
            print(f"❌ Erreur de connexion API: {e}")
            return False
    
    def create_agent(self, name: str, role: str, context: str, agent_type: str = "thread") -> str:
        """Crée un agent enfant."""
        data = {
            "name": name,
            "role": role,
            "context": context,
            "agent_type": agent_type,
            "parameters": {"test_param": "test_value"},
            "max_lifetime": 300  # 5 minutes
        }
        
        response = self.session.post(f"{self.base_url}/agents/children", json=data)
        
        if response.status_code == 200:
            result = response.json()
            agent_id = result["agent_id"]
            print(f"✅ Agent créé: {name} (ID: {agent_id})")
            return agent_id
        else:
            print(f"❌ Erreur création agent: {response.status_code} - {response.text}")
            return None
    
    def send_command(self, agent_id: str, command: str, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """Envoie une commande à un agent."""
        if parameters is None:
            parameters = {}
        
        data = {
            "command": command,
            "parameters": parameters,
            "timeout": 30
        }
        
        response = self.session.post(f"{self.base_url}/agents/children/{agent_id}/command", json=data)
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Commande envoyée à {agent_id}: {command}")
            print(f"   Résultat: {result.get('result', 'N/A')}")
            return result
        else:
            print(f"❌ Erreur envoi commande: {response.status_code} - {response.text}")
            return None
    
    def get_agent_status(self, agent_id: str) -> Dict[str, Any]:
        """Récupère le statut d'un agent."""
        response = self.session.get(f"{self.base_url}/agents/children/{agent_id}/status")
        
        if response.status_code == 200:
            status = response.json()
            print(f"✅ Statut récupéré pour {agent_id}")
            print(f"   Status: {status['status']}")
            print(f"   Logs: {len(status['logs'])} entrées")
            print(f"   Résultats: {len(status['results'])} résultats")
            return status
        else:
            print(f"❌ Erreur récupération statut: {response.status_code} - {response.text}")
            return None
    
    def list_agents(self) -> list:
        """Liste tous les agents."""
        response = self.session.get(f"{self.base_url}/agents/children")
        
        if response.status_code == 200:
            agents = response.json()
            print(f"✅ {len(agents)} agents listés")
            for agent in agents:
                print(f"   • {agent['name']} ({agent['id'][:8]}...): {agent['status']}")
            return agents
        else:
            print(f"❌ Erreur listing agents: {response.status_code} - {response.text}")
            return []
    
    def delete_agent(self, agent_id: str) -> bool:
        """Supprime un agent."""
        response = self.session.delete(f"{self.base_url}/agents/children/{agent_id}")
        
        if response.status_code == 200:
            print(f"✅ Agent {agent_id} supprimé avec succès")
            return True
        else:
            print(f"❌ Erreur suppression agent: {response.status_code} - {response.text}")
            return False
    
    def run_comprehensive_test(self):
        """Exécute un test complet de l'API."""
        print("🧪 Test complet de l'API Agents Enfants")
        print("=" * 50)
        
        # 1. Test de santé
        print("\n1. Test de santé de l'API...")
        if not self.test_api_health():
            print("❌ API non disponible, arrêt des tests")
            return False
        
        # 2. Création d'agents
        print("\n2. Création d'agents...")
        agent_thread = self.create_agent("TestAgent1", "data_processor", "Test context", "thread")
        agent_subprocess = self.create_agent("TestAgent2", "web_scraper", "Scraping context", "subprocess")
        
        if not agent_thread or not agent_subprocess:
            print("❌ Erreur lors de la création des agents")
            return False
        
        # 3. Listing des agents
        print("\n3. Listing des agents...")
        agents = self.list_agents()
        
        # 4. Envoi de commandes
        print("\n4. Envoi de commandes...")
        
        # Commande à l'agent thread
        result1 = self.send_command(agent_thread, "process_data", {"data": "test_data_123"})
        
        # Commande à l'agent subprocess
        result2 = self.send_command(agent_subprocess, "scrape_website", {"url": "https://example.com"})
        
        # 5. Vérification des statuts
        print("\n5. Vérification des statuts...")
        status1 = self.get_agent_status(agent_thread)
        status2 = self.get_agent_status(agent_subprocess)
        
        # 6. Attente et nouvelles commandes
        print("\n6. Tests additionnels...")
        time.sleep(1)
        
        # Commandes supplémentaires
        self.send_command(agent_thread, "analyze_results", {"analysis_type": "statistical"})
        self.send_command(agent_subprocess, "extract_links", {"domain": "example.com"})
        
        # 7. Statuts finaux
        print("\n7. Statuts finaux...")
        final_status1 = self.get_agent_status(agent_thread)
        final_status2 = self.get_agent_status(agent_subprocess)
        
        # 8. Suppression des agents
        print("\n8. Suppression des agents...")
        success1 = self.delete_agent(agent_thread)
        success2 = self.delete_agent(agent_subprocess)
        
        # 9. Vérification finale
        print("\n9. Vérification finale...")
        final_agents = self.list_agents()
        
        # Résumé
        print("\n" + "=" * 50)
        print("📊 Résumé des tests:")
        print(f"✅ API disponible: Oui")
        print(f"✅ Agents créés: {2 if agent_thread and agent_subprocess else 'Échec'}")
        print(f"✅ Commandes envoyées: {2 if result1 and result2 else 'Échec'}")
        print(f"✅ Statuts récupérés: {2 if status1 and status2 else 'Échec'}")
        print(f"✅ Agents supprimés: {2 if success1 and success2 else 'Échec'}")
        print(f"✅ Nettoyage final: {len(final_agents) == 0}")
        
        return True

def main():
    """Fonction principale du test."""
    print("🚀 Démarrage des tests API Agents Enfants")
    
    # Vérification que l'API est démarrée
    tester = AgentAPITester()
    
    if not tester.test_api_health():
        print("❌ L'API n'est pas disponible sur http://localhost:5001")
        print("💡 Assurez-vous que l'API est démarrée avec: python agent_children_api.py")
        return
    
    # Exécution des tests
    success = tester.run_comprehensive_test()
    
    if success:
        print("\n🎉 Tous les tests sont terminés avec succès!")
    else:
        print("\n❌ Certains tests ont échoué")

if __name__ == "__main__":
    main()