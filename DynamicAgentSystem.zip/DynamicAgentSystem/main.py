#!/usr/bin/env python3
"""
Main entry point for the multi-agent system using CrewAI and OpenRouter.
This script initializes the main agent and demonstrates dynamic agent creation.
"""

import asyncio
import logging
import os
from dotenv import load_dotenv

from agents.main_agent import MainAgent
from tasks.example_tasks import ExampleTasks
from utils.logger import setup_logging

# Load environment variables
load_dotenv()

async def main():
    """
    Main function to initialize and run the multi-agent system.
    """
    # Setup logging
    setup_logging()
    logger = logging.getLogger(__name__)
    
    logger.info("Starting Multi-Agent System with CrewAI and OpenRouter")
    
    # Verify required environment variables
    if not os.getenv("OPENROUTER_API_KEY"):
        logger.error("OPENROUTER_API_KEY not found in environment variables")
        print("Please set OPENROUTER_API_KEY in your .env file")
        print("You can get an API key at: https://openrouter.ai/")
        return
    
    try:
        # Initialize the main agent
        main_agent = MainAgent()
        
        # Initialize example tasks
        example_tasks = ExampleTasks()
        
        # Demonstrate the system with example tasks
        logger.info("Demonstrating system with example tasks...")
        
        # Example 1: Create HTML page
        print("\n" + "="*50)
        print("EXAMPLE 1: Creating HTML Page")
        print("="*50)
        
        html_task = example_tasks.create_html_page_task()
        html_result = await main_agent.execute_task(html_task)
        print(f"HTML Task Result: {html_result}")
        
        # Example 2: Create SQL schema
        print("\n" + "="*50)
        print("EXAMPLE 2: Creating SQL Schema")
        print("="*50)
        
        sql_task = example_tasks.create_sql_schema_task()
        sql_result = await main_agent.execute_task(sql_task)
        print(f"SQL Task Result: {sql_result}")
        
        # Example 3: Create API endpoint
        print("\n" + "="*50)
        print("EXAMPLE 3: Creating API Endpoint")
        print("="*50)
        
        api_task = example_tasks.create_api_endpoint_task()
        api_result = await main_agent.execute_task(api_task)
        print(f"API Task Result: {api_result}")
        
        # Display agent statistics
        print("\n" + "="*50)
        print("AGENT STATISTICS")
        print("="*50)
        main_agent.display_statistics()
        
        # Cleanup all agents
        print("\n" + "="*50)
        print("CLEANUP")
        print("="*50)
        await main_agent.cleanup_all_agents()
        
        logger.info("Multi-Agent System demonstration completed successfully")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        print(f"Error: {e}")
        return

if __name__ == "__main__":
    # Run the async main function
    asyncio.run(main())
