#!/usr/bin/env python3
"""
Système multi-agents utilisant l'API mémoire unifiée.
Cette version remplace toute gestion locale par des appels API vers votre système mémoire.
"""

import asyncio
import logging
import os
from dotenv import load_dotenv

from agents.langgraph_agents import LangGraphMultiAgentSystem
from tasks.example_tasks import ExampleTasks
from utils.logger import setup_logging
from utils.memory_client import MemoryAPIClient

# Charger les variables d'environnement
load_dotenv()

async def check_memory_api_connection():
    """Vérifie la connexion à l'API mémoire."""
    memory_client = MemoryAPIClient()
    
    try:
        is_healthy = await memory_client.health_check()
        if is_healthy:
            print("✅ API mémoire connectée et fonctionnelle")
            return True
        else:
            print("❌ API mémoire non accessible")
            return False
    except Exception as e:
        print(f"❌ Erreur de connexion à l'API mémoire : {e}")
        return False

async def main():
    """
    Fonction principale pour initialiser et exécuter le système multi-agents avec API mémoire.
    """
    # Configuration des logs
    setup_logging()
    logger = logging.getLogger(__name__)
    
    logger.info("Démarrage du système multi-agents avec API mémoire unifiée")
    
    print("🚀 Système Multi-Agents avec API Mémoire Unifiée")
    print("=" * 60)
    
    # Vérifier les variables d'environnement requises
    if not os.getenv("OPENROUTER_API_KEY"):
        logger.error("OPENROUTER_API_KEY not found in environment variables")
        print("❌ Erreur : OPENROUTER_API_KEY manquant")
        print("📝 Veuillez configurer votre clé API OpenRouter dans le fichier .env")
        return
    
    # Vérifier l'API mémoire
    print("🔍 Vérification de l'API mémoire...")
    memory_connected = await check_memory_api_connection()
    
    if not memory_connected:
        print("⚠️  L'API mémoire n'est pas disponible")
        print("📝 Veuillez vérifier la configuration MEMORY_API_BASE_URL dans .env")
        print("🔗 Assurez-vous que votre API mémoire est démarrée")
        
        # Continuer avec un mode dégradé
        print("\n📊 Mode dégradé : Fonctionnement sans persistance mémoire")
    
    try:
        # Initialiser le système multi-agents
        agent_system = LangGraphMultiAgentSystem()
        
        # Initialiser les tâches d'exemple
        example_tasks = ExampleTasks()
        
        # Démontrer le système avec des tâches d'exemple
        logger.info("Démonstration du système avec API mémoire...")
        
        # Exemple 1 : Créer une page HTML
        print("\n" + "="*70)
        print("🎨 EXEMPLE 1 : Création d'une page HTML")
        print("="*70)
        
        html_task = example_tasks.create_html_page_task()
        print(f"📋 Tâche : {html_task[:120]}...")
        
        print("\n🔄 Exécution avec intégration mémoire...")
        html_result = await agent_system.execute_task(html_task)
        
        if html_result.get('status') == 'completed':
            print("✅ Tâche HTML terminée avec succès !")
            print(f"⏱️ Temps d'exécution : {html_result.get('execution_time', 0):.2f}s")
            print(f"🤖 Agents utilisés : {', '.join(html_result.get('agents_used', []))}")
            print(f"💾 Données sauvegardées dans l'API mémoire")
        else:
            print(f"❌ Erreur lors de la tâche HTML : {html_result.get('error', 'Erreur inconnue')}")
        
        # Exemple 2 : Créer un système API complet
        print("\n" + "="*70)
        print("🔌 EXEMPLE 2 : Création d'un système API")
        print("="*70)
        
        api_task = example_tasks.create_api_endpoint_task()
        print(f"📋 Tâche : {api_task[:120]}...")
        
        print("\n🔄 Exécution avec traçabilité complète...")
        api_result = await agent_system.execute_task(api_task)
        
        if api_result.get('status') == 'completed':
            print("✅ Tâche API terminée avec succès !")
            print(f"⏱️ Temps d'exécution : {api_result.get('execution_time', 0):.2f}s")
            print(f"🤖 Agents utilisés : {', '.join(api_result.get('agents_used', []))}")
            print(f"💾 Historique complet dans l'API mémoire")
        else:
            print(f"❌ Erreur lors de la tâche API : {api_result.get('error', 'Erreur inconnue')}")
        
        # Récupérer les statistiques depuis l'API mémoire
        print("\n" + "="*70)
        print("📊 STATISTIQUES DEPUIS L'API MÉMOIRE")
        print("="*70)
        
        stats = await agent_system.get_statistics()
        print(f"🤖 Agents actifs : {stats.get('active_agents', 0)}")
        print(f"📋 Tâches totales : {stats.get('total_tasks', 0)}")
        print(f"✅ Tâches réussies : {stats.get('successful_tasks', 0)}")
        print(f"❌ Tâches échouées : {stats.get('failed_tasks', 0)}")
        print(f"🔧 Types d'agents : {', '.join(stats.get('agent_types', []))}")
        
        if stats.get('error'):
            print(f"⚠️  {stats['error']}")
        
        # Démonstration des fonctionnalités mémoire avancées
        if memory_connected:
            print("\n" + "="*70)
            print("💾 FONCTIONNALITÉS MÉMOIRE AVANCÉES")
            print("="*70)
            
            memory_client = MemoryAPIClient()
            
            # Récupérer les tâches récentes
            recent_tasks = await memory_client.get_recent_tasks(limit=5)
            print(f"📋 Tâches récentes : {len(recent_tasks)}")
            
            # Récupérer les agents actifs
            active_agents = await memory_client.get_all_active_agents()
            print(f"🤖 Agents actifs dans la mémoire : {len(active_agents)}")
            
            # Afficher les métriques système
            system_stats = await memory_client.get_system_statistics()
            if system_stats:
                print("📈 Métriques système :")
                for key, value in system_stats.items():
                    print(f"   • {key}: {value}")
        
        # Nettoyage des agents
        print("\n" + "="*70)
        print("🧹 NETTOYAGE ET ARCHIVAGE")
        print("="*70)
        
        await agent_system.cleanup_agents()
        print("✅ Agents archivés dans l'API mémoire")
        
        print("\n" + "="*70)
        print("🎉 Démonstration terminée avec succès !")
        print("="*70)
        
        print("\n📖 Avantages de l'API mémoire unifiée :")
        print("• Centralisation de toutes les données d'agents")
        print("• Persistance et traçabilité complètes")
        print("• Statistiques et métriques avancées")
        print("• Partage de données entre instances")
        print("• Archivage et nettoyage automatiques")
        
        logger.info("Démonstration du système avec API mémoire terminée avec succès")
        
    except Exception as e:
        logger.error(f"Erreur lors de l'exécution principale : {e}")
        print(f"❌ Erreur : {e}")
        import traceback
        traceback.print_exc()
        return

if __name__ == "__main__":
    # Exécuter la fonction principale asynchrone
    asyncio.run(main())