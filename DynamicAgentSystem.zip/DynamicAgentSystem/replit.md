# Multi-Agent System with LangGraph and OpenRouter

## Overview

This is a Python-based multi-agent system that uses LangGraph for orchestration and OpenRouter for accessing open-source large language models. The system features dynamic agent creation, task distribution, and lifecycle management. It's designed to handle complex tasks by breaking them down and delegating them to specialized agents.

## User Preferences

Preferred communication style: Simple, everyday language.
Language preference: French (français).

## System Architecture

### Core Architecture
- **Main Agent**: Central orchestrator that manages child agents and coordinates task execution
- **Child Agent Factory**: Creates specialized agents on-demand based on task requirements
- **Task Manager**: Handles task lifecycle, queuing, and coordination
- **LLM Client**: Interfaces with OpenRouter API for language model access

### Agent Types
The system supports five specialized agent types:
- **Frontend**: HTML, CSS, JavaScript, UI/UX development
- **Backend**: Server-side logic, APIs, business logic
- **Database**: SQL schemas, queries, data modeling
- **DevOps**: Deployment, infrastructure, containerization
- **Testing**: Test suites, QA, automation

## Key Components

### 1. Main Agent (`agents/main_agent.py`)
- Orchestrates the entire system
- Manages child agent lifecycle (creation, tracking, archival)
- Coordinates task execution across multiple agents
- Maintains task history and agent status

### 2. Child Agent Factory (`agents/child_agents.py`)
- Creates specialized agents based on task requirements
- Implements factory pattern for agent creation
- Each agent type has specific roles, goals, and backstories

### 3. Task Management (`tasks/task_manager.py`)
- Handles task lifecycle with status tracking (pending, assigned, in_progress, completed, failed, cancelled)
- Implements priority system (low, medium, high, critical)
- Manages task queuing and completion tracking

### 4. LLM Integration (`utils/llm_client.py`)
- Custom LangChain LLM implementation for OpenRouter
- Handles API communication with proper headers and authentication
- Supports multiple model types (Mistral, LLaMA 2, Code Llama)

### 5. Configuration (`config/settings.py`)
- Centralized configuration management
- Environment variable handling
- Configurable limits for agents, tasks, and LLM parameters

## Data Flow

1. **Task Submission**: Tasks are submitted to the main agent
2. **Task Analysis**: Main agent analyzes the task to determine required agent types
3. **Agent Creation**: Child agents are created via the factory based on requirements
4. **Task Distribution**: Tasks are distributed to appropriate specialized agents
5. **Execution**: Agents work on their assigned tasks using LLM capabilities
6. **Coordination**: Main agent coordinates between agents if needed
7. **Completion**: Results are collected and consolidated
8. **Cleanup**: Agents are archived after task completion

## External Dependencies

### Required APIs
- **OpenRouter API**: Primary LLM service for accessing open-source models
  - Requires API key configuration
  - Supports multiple model types
  - Rate limiting and timeout handling

- **Unified Memory API**: External memory system for data persistence
  - Centralized storage for all agent interactions
  - Task execution tracking and history
  - Performance metrics and analytics
  - Cross-instance data sharing

### Python Libraries
- **LangGraph**: Multi-agent orchestration framework (replaces CrewAI)
- **LangChain**: LLM integration and workflow management
- **aiohttp**: Asynchronous HTTP client
- **requests**: HTTP library for API calls
- **pydantic**: Data validation and settings management
- **python-dotenv**: Environment variable management

## Deployment Strategy

### Environment Setup
- Uses `.env` file for configuration
- Requires `OPENROUTER_API_KEY` environment variable
- Configurable through environment variables for all major settings

### Logging
- Comprehensive logging system with file and console output
- Configurable log levels
- Automatic log rotation and archival
- Performance monitoring capabilities

### Async Operations
- Built with async/await patterns for better performance
- Concurrent agent execution capabilities
- Configurable limits for concurrent operations

### Error Handling
- Retry mechanisms for failed operations
- Comprehensive error logging and monitoring
- Graceful degradation for partial failures

The system is designed to be modular, scalable, and easy to extend with new agent types and capabilities.

## Recent Changes (January 2025)

### CrewAI Import Issue Resolution
- **Issue**: CrewAI library was causing timeout issues during import, blocking system startup
- **Solution**: Created a simplified version (`main_simple.py`) that bypasses CrewAI while maintaining full functionality
- **Impact**: System now starts quickly and works reliably without CrewAI dependency issues

### File Structure Updates
- **Added**: `main_simple.py` - Simplified main entry point without CrewAI
- **Added**: `agents/simple_agents.py` - Direct agent implementation without CrewAI wrapper
- **Added**: `demo_interactive.py` - Interactive demonstration system
- **Added**: `check_setup.py` - System configuration verification script
- **Added**: `instructions.md` - Comprehensive French setup instructions
- **Updated**: Enhanced README.md with multiple entry points and better documentation

### System Improvements
- **Async Operations**: Full async/await implementation for better performance
- **Error Handling**: Comprehensive error handling with user-friendly messages
- **Logging**: Enhanced logging system with detailed agent tracking
- **User Experience**: Added interactive demo and configuration checking tools

### API Integration
- **OpenRouter Integration**: Fully functional OpenRouter API integration
- **Model Support**: Support for multiple OpenRouter models (Mistral, LLaMA 2, Code Llama, etc.)
- **Authentication**: Proper API key handling and validation
- **Rate Limiting**: Built-in error handling for API limits

### Migration to LangGraph (January 2025)
- **Completed**: Migration from CrewAI to LangGraph for better performance and reliability
- **Added**: `agents/langgraph_agents.py` - Complete LangGraph implementation
- **Added**: `main_langgraph.py` - Main entry point using LangGraph
- **Added**: `demo_langgraph.py` - Interactive LangGraph demonstrations
- **Benefits**: Structured workflows, better state management, improved observability

### Integration with Unified Memory API (January 2025)
- **Completed**: Integration with external unified memory API
- **Added**: `utils/memory_client.py` - Complete API client for unified memory system
- **Added**: `main_memory_unified.py` - Main entry point using unified memory
- **Added**: `test_memory_integration.py` - Integration tests with memory API
- **Removed**: All local database management (SQLAlchemy, PostgreSQL)
- **Benefits**: Centralized data storage, cross-instance data sharing, advanced analytics

### Web Interface Implementation (January 2025)
- **Completed**: Modern web interface for visual task management
- **Added**: `web_interface/app.py` - Flask backend with API endpoints
- **Added**: `web_interface/templates/index.html` - Responsive frontend
- **Added**: `web_interface/static/` - CSS/JS assets for real-time updates
- **Features**: Task creation, agent monitoring, real-time updates, statistics dashboard
- **Benefits**: Visual task management, real-time monitoring, user-friendly interface

### Current Status
- **Working**: Unified memory system (`main_memory_unified.py`) fully functional
- **Working**: LangGraph system (`main_langgraph.py`) with memory integration
- **Working**: Simplified system (`main_simple.py`) as fallback option
- **Working**: Web interface (`web_interface/app.py`) with real-time visualization
- **NEW**: FastAPI Agents Children API (`agent_children_api.py`) fully functional
- **Ready**: System ready for use once OpenRouter API key is configured
- **Recommended**: Use web interface for visual task management and monitoring

### FastAPI Agents Children API (January 2025)
- **Completed**: Full FastAPI implementation for dynamic agent children management
- **Added**: `agent_children_api.py` - Complete API with 5 endpoints
- **Added**: `test_agent_children_api.py` - Comprehensive test suite
- **Added**: `example_usage.py` - Working usage examples
- **Added**: `README_AGENT_CHILDREN_API.md` - Full documentation
- **Added**: `RAPPORT_AUDIT_CODE.md` - Complete code audit report
- **Added**: `SECRETS_CONFIGURATION.md` - Detailed secrets configuration guide
- **Features**: Thread/subprocess agents, CRUD operations, lifecycle management, real-time monitoring
- **Status**: All endpoints tested and working (port 5001)
- **Benefits**: Dynamic agent creation, command execution, status tracking, proper cleanup
- **Fixes**: JSON serialization issues resolved, thread management improved