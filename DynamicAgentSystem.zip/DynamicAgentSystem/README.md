# Multi-Agent System with CrewAI and OpenRouter

A Python-based multi-agent system that uses CrewAI for coordination and OpenRouter for accessing open-source large language models. The system can dynamically create specialized agents for different tasks (frontend, backend, database, DevOps, testing) and manage their complete lifecycle.

## Features

- **Dynamic Agent Creation**: Create specialized agents on-demand based on task requirements
- **Task Distribution**: Intelligent task assignment to appropriate agent types
- **Lifecycle Management**: Complete agent lifecycle from creation to archival
- **Open-Source LLMs**: Integration with OpenRouter for accessing models like Mistral, LLaMA 2, and Code Llama
- **Modular Architecture**: Clean separation of concerns with dedicated modules
- **Comprehensive Logging**: Detailed logging for monitoring and debugging
- **Asynchronous Operations**: Efficient async/await pattern for better performance

## Available Agent Types

- **Frontend**: HTML, CSS, JavaScript, UI/UX development
- **Backend**: Server-side logic, APIs, business logic
- **Database**: SQL schemas, queries, data modeling
- **DevOps**: Deployment, infrastructure, containerization
- **Testing**: Test suites, QA, automation

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd multi-agent-system
```

2. Configure your environment:
```bash
# Copy the example environment file
cp .env.example .env

# Edit .env and add your OpenRouter API key
# OPENROUTER_API_KEY=your-actual-api-key-here
```

3. Get your OpenRouter API key:
   - Go to https://openrouter.ai/
   - Create an account
   - Generate an API key
   - Add it to your `.env` file

## Quick Start

### Basic Usage
```bash
python main_simple.py
```

### Interactive Demo
```bash
python demo_interactive.py
```

### Original Version (requires CrewAI fix)
```bash
python main.py
```

## Project Structure
