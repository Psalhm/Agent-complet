"""
Child Agent Factory and specialized agent definitions.
This module contains the factory for creating specialized child agents.
"""

import logging
from typing import Dict, Any

from crewai import Agent
from utils.llm_client import LLMClient

class ChildAgentFactory:
    """
    Factory class for creating specialized child agents.
    """
    
    def __init__(self, llm_client: LLMClient):
        """
        Initialize the factory with LLM client.
        
        Args:
            llm_client: LLM client instance
        """
        self.llm_client = llm_client
        self.logger = logging.getLogger(__name__)
    
    def create_agent(self, agent_type: str) -> Agent:
        """
        Create a specialized agent based on the type.
        
        Args:
            agent_type: Type of agent to create
            
        Returns:
            CrewAI Agent instance
        """
        agent_creators = {
            'frontend': self._create_frontend_agent,
            'backend': self._create_backend_agent,
            'database': self._create_database_agent,
            'devops': self._create_devops_agent,
            'testing': self._create_testing_agent
        }
        
        creator = agent_creators.get(agent_type, self._create_generic_agent)
        agent = creator()
        
        self.logger.info(f"Created {agent_type} agent")
        return agent
    
    def _create_frontend_agent(self) -> Agent:
        """
        Create a frontend specialized agent.
        
        Returns:
            Frontend Agent instance
        """
        return Agent(
            role="Frontend Developer",
            goal="Create responsive, user-friendly frontend interfaces using HTML, CSS, and JavaScript",
            backstory="""You are an expert frontend developer with extensive experience in creating 
            modern web interfaces. You excel at HTML5, CSS3, JavaScript, and responsive design. 
            You understand user experience principles and can create intuitive interfaces that 
            work across different devices and browsers. You're skilled in modern frameworks and 
            libraries, and you always consider accessibility and performance.""",
            verbose=True,
            allow_delegation=False,
            llm=self.llm_client.get_llm()
        )
    
    def _create_backend_agent(self) -> Agent:
        """
        Create a backend specialized agent.
        
        Returns:
            Backend Agent instance
        """
        return Agent(
            role="Backend Developer",
            goal="Design and implement robust server-side logic, APIs, and business logic",
            backstory="""You are a skilled backend developer with deep expertise in server-side 
            programming, API design, and system architecture. You excel at creating scalable, 
            secure, and performant backend systems. You understand database integration, 
            authentication, authorization, and can design RESTful APIs and microservices. 
            You're experienced with various backend frameworks and always consider security, 
            scalability, and maintainability.""",
            verbose=True,
            allow_delegation=False,
            llm=self.llm_client.get_llm()
        )
    
    def _create_database_agent(self) -> Agent:
        """
        Create a database specialized agent.
        
        Returns:
            Database Agent instance
        """
        return Agent(
            role="Database Specialist",
            goal="Design efficient database schemas, optimize queries, and ensure data integrity",
            backstory="""You are a database expert with comprehensive knowledge of relational 
            and NoSQL databases. You excel at database design, query optimization, indexing, 
            and performance tuning. You understand data modeling, normalization, and can create 
            efficient database schemas that support application requirements. You're skilled in 
            SQL, database administration, and can handle complex data relationships while 
            ensuring data integrity and security.""",
            verbose=True,
            allow_delegation=False,
            llm=self.llm_client.get_llm()
        )
    
    def _create_devops_agent(self) -> Agent:
        """
        Create a DevOps specialized agent.
        
        Returns:
            DevOps Agent instance
        """
        return Agent(
            role="DevOps Engineer",
            goal="Handle deployment, infrastructure, and operational aspects of applications",
            backstory="""You are a DevOps expert with extensive experience in deployment 
            automation, infrastructure management, and operational excellence. You excel at 
            containerization, CI/CD pipelines, cloud platforms, and infrastructure as code. 
            You understand monitoring, logging, and can create robust deployment strategies 
            that ensure high availability and scalability. You're skilled in various DevOps 
            tools and always consider security, automation, and operational efficiency.""",
            verbose=True,
            allow_delegation=False,
            llm=self.llm_client.get_llm()
        )
    
    def _create_testing_agent(self) -> Agent:
        """
        Create a testing specialized agent.
        
        Returns:
            Testing Agent instance
        """
        return Agent(
            role="QA Engineer",
            goal="Create comprehensive test suites and ensure software quality",
            backstory="""You are a quality assurance expert with deep knowledge of testing 
            methodologies, test automation, and quality processes. You excel at creating 
            comprehensive test plans, writing automated tests, and ensuring software meets 
            quality standards. You understand unit testing, integration testing, end-to-end 
            testing, and performance testing. You're skilled in various testing frameworks 
            and tools, and always consider test coverage, maintainability, and reliability.""",
            verbose=True,
            allow_delegation=False,
            llm=self.llm_client.get_llm()
        )
    
    def _create_generic_agent(self) -> Agent:
        """
        Create a generic agent for unknown types.
        
        Returns:
            Generic Agent instance
        """
        return Agent(
            role="General Purpose Developer",
            goal="Handle various development tasks with adaptability and expertise",
            backstory="""You are a versatile developer with broad knowledge across multiple 
            domains. You can adapt to different requirements and handle various types of 
            development tasks. You have experience in frontend, backend, database, and 
            operational aspects of software development. You're skilled at learning new 
            technologies quickly and can provide solutions across different domains.""",
            verbose=True,
            allow_delegation=False,
            llm=self.llm_client.get_llm()
        )
