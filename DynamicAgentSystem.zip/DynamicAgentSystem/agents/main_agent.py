"""
Main Agent class that manages the lifecycle of child agents and coordinates tasks.
This agent is responsible for creating, managing, and supervising child agents.
"""

import asyncio
import logging
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Any

from crewai import Agent, Crew, Task, Process
from agents.child_agents import ChildAgentFactory
from tasks.task_manager import TaskManager
from utils.llm_client import LLMClient

class MainAgent:
    """
    Main orchestrator agent that manages child agents and coordinates task execution.
    """
    
    def __init__(self):
        """
        Initialize the main agent with necessary components.
        """
        self.logger = logging.getLogger(__name__)
        self.llm_client = LLMClient()
        self.child_agent_factory = ChildAgentFactory(self.llm_client)
        self.task_manager = TaskManager()
        
        # Agent tracking
        self.active_agents: Dict[str, Any] = {}
        self.archived_agents: List[Dict[str, Any]] = []
        self.task_history: List[Dict[str, Any]] = []
        
        # Initialize the main CrewAI agent
        self.agent = Agent(
            role="Main Orchestrator",
            goal="Coordinate and manage specialized child agents to complete complex tasks",
            backstory="You are an expert system orchestrator capable of breaking down complex tasks and delegating them to specialized agents. You excel at coordination, supervision, and quality control.",
            verbose=True,
            allow_delegation=True,
            llm=self.llm_client.get_llm()
        )
        
        self.logger.info("Main Agent initialized successfully")
    
    async def execute_task(self, task_description: str) -> Dict[str, Any]:
        """
        Execute a task by creating appropriate child agents and coordinating their work.
        
        Args:
            task_description: Description of the task to execute
            
        Returns:
            Dictionary containing task results and metadata
        """
        task_id = str(uuid.uuid4())
        start_time = datetime.now()
        
        self.logger.info(f"Starting task execution: {task_id}")
        
        try:
            # Analyze the task to determine required agents
            required_agents = await self._analyze_task_requirements(task_description)
            
            # Create child agents
            child_agents = []
            for agent_type in required_agents:
                agent = await self._create_child_agent(agent_type, task_id)
                child_agents.append(agent)
            
            # Create CrewAI tasks for each agent
            crew_tasks = []
            for agent in child_agents:
                crew_task = Task(
                    description=self._get_agent_specific_task(agent['type'], task_description),
                    agent=agent['crew_agent'],
                    expected_output=f"Detailed output for {agent['type']} task"
                )
                crew_tasks.append(crew_task)
            
            # Create and execute crew
            crew = Crew(
                agents=[agent['crew_agent'] for agent in child_agents],
                tasks=crew_tasks,
                process=Process.sequential,
                verbose=True
            )
            
            # Execute the crew
            result = crew.kickoff()
            
            # Process results
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            
            task_result = {
                'task_id': task_id,
                'description': task_description,
                'result': result,
                'agents_used': [agent['type'] for agent in child_agents],
                'execution_time': execution_time,
                'start_time': start_time.isoformat(),
                'end_time': end_time.isoformat(),
                'status': 'completed'
            }
            
            # Store in task history
            self.task_history.append(task_result)
            
            # Archive child agents
            await self._archive_agents(child_agents, task_id)
            
            self.logger.info(f"Task {task_id} completed successfully in {execution_time:.2f} seconds")
            
            return task_result
            
        except Exception as e:
            self.logger.error(f"Error executing task {task_id}: {e}")
            
            error_result = {
                'task_id': task_id,
                'description': task_description,
                'error': str(e),
                'status': 'failed',
                'start_time': start_time.isoformat(),
                'end_time': datetime.now().isoformat()
            }
            
            self.task_history.append(error_result)
            return error_result
    
    async def _analyze_task_requirements(self, task_description: str) -> List[str]:
        """
        Analyze task description to determine required agent types.
        
        Args:
            task_description: Description of the task
            
        Returns:
            List of required agent types
        """
        analysis_prompt = f"""
        Analyze the following task and determine which specialized agents are needed:
        
        Task: {task_description}
        
        Available agent types:
        - frontend: HTML, CSS, JavaScript, UI/UX
        - backend: APIs, server logic, business logic
        - database: SQL schemas, queries, data modeling
        - devops: Configuration, deployment, infrastructure
        - testing: Test cases, quality assurance
        
        Respond with a JSON array of required agent types.
        Example: ["frontend", "backend", "database"]
        """
        
        try:
            response = await self.llm_client.generate_response(analysis_prompt)
            # Extract JSON from response
            import json
            import re
            
            json_match = re.search(r'\[.*\]', response)
            if json_match:
                agent_types = json.loads(json_match.group())
                return agent_types
            else:
                # Fallback: simple keyword matching
                return self._fallback_agent_detection(task_description)
                
        except Exception as e:
            self.logger.warning(f"Error analyzing task requirements: {e}")
            return self._fallback_agent_detection(task_description)
    
    def _fallback_agent_detection(self, task_description: str) -> List[str]:
        """
        Fallback method for detecting required agents using keyword matching.
        
        Args:
            task_description: Description of the task
            
        Returns:
            List of required agent types
        """
        agents = []
        task_lower = task_description.lower()
        
        if any(keyword in task_lower for keyword in ['html', 'css', 'javascript', 'ui', 'frontend', 'webpage']):
            agents.append('frontend')
        
        if any(keyword in task_lower for keyword in ['api', 'server', 'backend', 'endpoint', 'service']):
            agents.append('backend')
        
        if any(keyword in task_lower for keyword in ['database', 'sql', 'schema', 'table', 'query']):
            agents.append('database')
        
        if any(keyword in task_lower for keyword in ['deploy', 'config', 'infrastructure', 'devops']):
            agents.append('devops')
        
        if any(keyword in task_lower for keyword in ['test', 'testing', 'qa', 'quality']):
            agents.append('testing')
        
        # Default to frontend if no specific agents detected
        if not agents:
            agents.append('frontend')
        
        return agents
    
    async def _create_child_agent(self, agent_type: str, task_id: str) -> Dict[str, Any]:
        """
        Create a specialized child agent for the given type.
        
        Args:
            agent_type: Type of agent to create
            task_id: ID of the task this agent will work on
            
        Returns:
            Dictionary containing agent information
        """
        agent_id = f"{agent_type}_{task_id}_{str(uuid.uuid4())[:8]}"
        
        # Create the agent using the factory
        crew_agent = self.child_agent_factory.create_agent(agent_type)
        
        agent_info = {
            'id': agent_id,
            'type': agent_type,
            'task_id': task_id,
            'crew_agent': crew_agent,
            'created_at': datetime.now().isoformat(),
            'status': 'active'
        }
        
        self.active_agents[agent_id] = agent_info
        self.logger.info(f"Created {agent_type} agent: {agent_id}")
        
        return agent_info
    
    def _get_agent_specific_task(self, agent_type: str, task_description: str) -> str:
        """
        Generate agent-specific task description based on agent type.
        
        Args:
            agent_type: Type of the agent
            task_description: Original task description
            
        Returns:
            Agent-specific task description
        """
        task_templates = {
            'frontend': f"Create the frontend components for: {task_description}. Focus on HTML structure, CSS styling, and JavaScript functionality. Ensure responsive design and user experience.",
            
            'backend': f"Develop the backend logic for: {task_description}. Create APIs, business logic, and server-side functionality. Focus on scalability and performance.",
            
            'database': f"Design the database schema and queries for: {task_description}. Create tables, relationships, and optimized queries. Focus on data integrity and performance.",
            
            'devops': f"Handle deployment and infrastructure for: {task_description}. Create configuration files, deployment scripts, and infrastructure setup.",
            
            'testing': f"Create comprehensive tests for: {task_description}. Include unit tests, integration tests, and quality assurance procedures."
        }
        
        return task_templates.get(agent_type, f"Handle {agent_type} aspects of: {task_description}")
    
    async def _archive_agents(self, agents: List[Dict[str, Any]], task_id: str):
        """
        Archive agents after task completion.
        
        Args:
            agents: List of agents to archive
            task_id: ID of the completed task
        """
        for agent in agents:
            agent_id = agent['id']
            
            # Update agent status
            if agent_id in self.active_agents:
                self.active_agents[agent_id]['status'] = 'archived'
                self.active_agents[agent_id]['archived_at'] = datetime.now().isoformat()
                
                # Move to archived agents
                self.archived_agents.append(self.active_agents[agent_id])
                del self.active_agents[agent_id]
                
                self.logger.info(f"Archived agent: {agent_id}")
    
    async def cleanup_all_agents(self):
        """
        Cleanup all active agents and move them to archived state.
        """
        self.logger.info("Cleaning up all active agents...")
        
        for agent_id, agent_info in list(self.active_agents.items()):
            agent_info['status'] = 'cleaned_up'
            agent_info['cleaned_up_at'] = datetime.now().isoformat()
            
            self.archived_agents.append(agent_info)
            del self.active_agents[agent_id]
        
        self.logger.info(f"Cleaned up {len(self.archived_agents)} agents")
    
    def display_statistics(self):
        """
        Display system statistics and performance metrics.
        """
        print(f"Active Agents: {len(self.active_agents)}")
        print(f"Archived Agents: {len(self.archived_agents)}")
        print(f"Total Tasks Executed: {len(self.task_history)}")
        
        if self.task_history:
            successful_tasks = [task for task in self.task_history if task['status'] == 'completed']
            print(f"Successful Tasks: {len(successful_tasks)}")
            
            if successful_tasks:
                avg_execution_time = sum(task['execution_time'] for task in successful_tasks) / len(successful_tasks)
                print(f"Average Execution Time: {avg_execution_time:.2f} seconds")
        
        # Agent type distribution
        agent_types = {}
        for agent in self.archived_agents:
            agent_type = agent['type']
            agent_types[agent_type] = agent_types.get(agent_type, 0) + 1
        
        if agent_types:
            print("Agent Type Distribution:")
            for agent_type, count in agent_types.items():
                print(f"  {agent_type}: {count}")
