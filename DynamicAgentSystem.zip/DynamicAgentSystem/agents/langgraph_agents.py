"""
Agents utilisant LangGraph pour l'orchestration multi-agents.
Cette version utilise LangGraph au lieu de CrewAI pour une meilleure performance.
"""

import asyncio
import logging
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Any, TypedDict, Annotated
from operator import add

from langgraph.graph import StateGraph, END
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

from utils.llm_client import LLMClient
from utils.memory_client import MemoryAPIClient, AgentInteraction, AgentStatus, TaskExecution


class AgentState(TypedDict):
    """État partagé entre les agents dans LangGraph."""
    messages: Annotated[List[Dict[str, str]], add]
    task_description: str
    task_id: str
    required_agents: List[str]
    agent_results: Dict[str, Any]
    current_agent: Optional[str]
    iteration_count: int
    max_iterations: int


class LangGraphAgent:
    """
    Agent individuel utilisant LangGraph pour la coordination.
    """
    
    def __init__(self, agent_type: str, llm_client: LLMClient, memory_client: MemoryAPIClient):
        """
        Initialise l'agent LangGraph.
        
        Args:
            agent_type: Type d'agent (frontend, backend, etc.)
            llm_client: Client LLM pour générer les réponses
            memory_client: Client pour l'API mémoire unifiée
        """
        self.agent_type = agent_type
        self.llm_client = llm_client
        self.memory_client = memory_client
        self.agent_id = f"{agent_type}_{str(uuid.uuid4())[:8]}"
        self.logger = logging.getLogger(f"LangGraphAgent.{agent_type}")
        
        # Configuration spécifique par type d'agent
        self.agent_configs = {
            'frontend': {
                'role': 'Frontend Developer Expert',
                'expertise': 'HTML5, CSS3, JavaScript, React, Vue.js, responsive design, accessibilité',
                'system_prompt': """Vous êtes un développeur frontend expert spécialisé dans la création d'interfaces utilisateur modernes et interactives.
                
Vos compétences incluent :
- HTML5 sémantique et structure
- CSS3 avancé, Flexbox, Grid
- JavaScript moderne (ES6+)
- Frameworks (React, Vue.js, Angular)
- Design responsive et mobile-first
- Accessibilité (WCAG)
- Performance et optimisation
- UX/UI design

Vous devez fournir des solutions complètes, du code fonctionnel et des bonnes pratiques."""
            },
            'backend': {
                'role': 'Backend Developer Expert',
                'expertise': 'Python, Node.js, APIs REST, GraphQL, microservices, sécurité',
                'system_prompt': """Vous êtes un développeur backend expert spécialisé dans la création de systèmes serveur robustes et scalables.

Vos compétences incluent :
- Python (Django, FastAPI, Flask)
- Node.js (Express, NestJS)
- APIs REST et GraphQL
- Bases de données (SQL, NoSQL)
- Microservices et architecture
- Sécurité et authentification
- Performance et scalabilité
- DevOps et déploiement

Vous devez fournir des solutions sécurisées, performantes et bien architecturées."""
            },
            'database': {
                'role': 'Database Specialist Expert',
                'expertise': 'SQL, NoSQL, modélisation, optimisation, PostgreSQL, MongoDB',
                'system_prompt': """Vous êtes un spécialiste en bases de données expert dans la conception et l'optimisation de systèmes de données.

Vos compétences incluent :
- Modélisation de données relationnelles
- SQL avancé et optimisation
- NoSQL (MongoDB, Redis, etc.)
- Indexation et performance
- Migrations et versioning
- Sécurité des données
- Sauvegarde et récupération
- Analyse et reporting

Vous devez fournir des schémas optimisés, des requêtes performantes et des solutions scalables."""
            },
            'devops': {
                'role': 'DevOps Engineer Expert',
                'expertise': 'Docker, Kubernetes, CI/CD, monitoring, infrastructure as code',
                'system_prompt': """Vous êtes un ingénieur DevOps expert spécialisé dans l'automatisation et l'infrastructure.

Vos compétences incluent :
- Containerisation (Docker, Kubernetes)
- CI/CD (GitHub Actions, GitLab CI)
- Infrastructure as Code (Terraform, Ansible)
- Monitoring et logging
- Sécurité infrastructure
- Cloud (AWS, Azure, GCP)
- Automatisation des déploiements
- Scalabilité et haute disponibilité

Vous devez fournir des solutions d'infrastructure robustes, automatisées et sécurisées."""
            },
            'testing': {
                'role': 'QA Engineer Expert',
                'expertise': 'Tests unitaires, intégration, E2E, automatisation, performance',
                'system_prompt': """Vous êtes un ingénieur QA expert spécialisé dans les tests et l'assurance qualité.

Vos compétences incluent :
- Tests unitaires et d'intégration
- Tests end-to-end (E2E)
- Automatisation des tests
- Tests de performance
- Tests de sécurité
- TDD et BDD
- Frameworks de test
- CI/CD et tests automatisés

Vous devez fournir des stratégies de test complètes et des suites de tests robustes."""
            }
        }
        
        self.config = self.agent_configs.get(agent_type, self.agent_configs['frontend'])
    
    async def process_task(self, state: AgentState) -> Dict[str, Any]:
        """
        Traite une tâche spécifique à ce type d'agent.
        
        Args:
            state: État partagé du système
            
        Returns:
            Résultat du traitement
        """
        start_time = datetime.now()
        task_id = state['task_id']
        
        try:
            # Enregistrer le début de traitement dans la mémoire
            await self.memory_client.save_agent_interaction(
                AgentInteraction(
                    agent_id=self.agent_id,
                    agent_type=self.agent_type,
                    task_id=task_id,
                    interaction_type='task_received',
                    content=state['task_description'],
                    timestamp=start_time.isoformat(),
                    metadata={'status': 'processing'}
                )
            )
            
            # Mettre à jour le statut de l'agent
            await self.memory_client.update_agent_status(
                AgentStatus(
                    agent_id=self.agent_id,
                    agent_type=self.agent_type,
                    status='processing',
                    current_task_id=task_id,
                    last_activity=start_time.isoformat(),
                    performance_metrics={}
                )
            )
            
            # Créer le prompt spécialisé
            prompt = self._create_specialized_prompt(state['task_description'])
            
            # Générer la réponse
            result = await self.llm_client.generate_response(prompt)
            
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            
            agent_result = {
                'agent_id': self.agent_id,
                'agent_type': self.agent_type,
                'task_description': state['task_description'],
                'result': result,
                'execution_time': execution_time,
                'status': 'completed',
                'timestamp': end_time.isoformat()
            }
            
            # Enregistrer la completion dans la mémoire
            await self.memory_client.save_agent_interaction(
                AgentInteraction(
                    agent_id=self.agent_id,
                    agent_type=self.agent_type,
                    task_id=task_id,
                    interaction_type='completed',
                    content=result,
                    timestamp=end_time.isoformat(),
                    metadata={
                        'execution_time': execution_time,
                        'status': 'completed'
                    }
                )
            )
            
            # Mettre à jour le statut de l'agent
            await self.memory_client.update_agent_status(
                AgentStatus(
                    agent_id=self.agent_id,
                    agent_type=self.agent_type,
                    status='idle',
                    current_task_id=None,
                    last_activity=end_time.isoformat(),
                    performance_metrics={'last_execution_time': execution_time}
                )
            )
            
            self.logger.info(f"Agent {self.agent_id} a terminé sa tâche en {execution_time:.2f}s")
            return agent_result
            
        except Exception as e:
            error_time = datetime.now()
            self.logger.error(f"Erreur dans l'agent {self.agent_id}: {e}")
            
            # Enregistrer l'erreur dans la mémoire
            await self.memory_client.log_error(
                agent_id=self.agent_id,
                task_id=task_id,
                error_type='task_processing_error',
                error_message=str(e),
                context={
                    'agent_type': self.agent_type,
                    'task_description': state['task_description'],
                    'execution_time': (error_time - start_time).total_seconds()
                }
            )
            
            await self.memory_client.save_agent_interaction(
                AgentInteraction(
                    agent_id=self.agent_id,
                    agent_type=self.agent_type,
                    task_id=task_id,
                    interaction_type='failed',
                    content=str(e),
                    timestamp=error_time.isoformat(),
                    metadata={'status': 'failed', 'error_type': 'task_processing_error'}
                )
            )
            
            # Mettre à jour le statut de l'agent
            await self.memory_client.update_agent_status(
                AgentStatus(
                    agent_id=self.agent_id,
                    agent_type=self.agent_type,
                    status='idle',
                    current_task_id=None,
                    last_activity=error_time.isoformat(),
                    performance_metrics={'last_error': str(e)}
                )
            )
            
            return {
                'agent_id': self.agent_id,
                'agent_type': self.agent_type,
                'task_description': state['task_description'],
                'error': str(e),
                'status': 'failed',
                'timestamp': error_time.isoformat()
            }
    
    def _create_specialized_prompt(self, task_description: str) -> str:
        """
        Crée un prompt spécialisé pour ce type d'agent.
        
        Args:
            task_description: Description de la tâche
            
        Returns:
            Prompt spécialisé
        """
        return f"""
{self.config['system_prompt']}

TÂCHE À ACCOMPLIR :
{task_description}

INSTRUCTIONS SPÉCIFIQUES :
1. Analysez la tâche du point de vue de votre spécialité ({self.config['role']})
2. Fournissez une solution détaillée et pratique
3. Incluez des exemples de code concrets et fonctionnels
4. Expliquez les bonnes pratiques et considérations importantes
5. Structurez votre réponse de manière claire et organisée

EXPERTISE REQUISE :
{self.config['expertise']}

Votre réponse doit être complète, professionnelle et directement applicable.
"""


class LangGraphMultiAgentSystem:
    """
    Système multi-agents utilisant LangGraph pour l'orchestration.
    """
    
    def __init__(self):
        """
        Initialise le système multi-agents LangGraph.
        """
        self.llm_client = LLMClient()
        self.memory_client = MemoryAPIClient()
        self.agents: Dict[str, LangGraphAgent] = {}
        self.logger = logging.getLogger(__name__)
        
        # Créer le graphe de workflow
        self.workflow_graph = None
        self._setup_workflow_graph()
    
    def _setup_workflow_graph(self):
        """
        Configure le graphe de workflow LangGraph.
        """
        # Créer le graphe d'états
        workflow = StateGraph(AgentState)
        
        # Ajouter les nœuds
        workflow.add_node("task_analyzer", self._analyze_task_node)
        workflow.add_node("agent_coordinator", self._coordinate_agents_node)
        workflow.add_node("result_compiler", self._compile_results_node)
        
        # Définir les transitions
        workflow.set_entry_point("task_analyzer")
        workflow.add_edge("task_analyzer", "agent_coordinator")
        workflow.add_edge("agent_coordinator", "result_compiler")
        workflow.add_edge("result_compiler", END)
        
        # Compiler le graphe
        self.workflow_graph = workflow.compile()
    
    async def _analyze_task_node(self, state: AgentState) -> AgentState:
        """
        Nœud pour analyser la tâche et déterminer les agents requis.
        
        Args:
            state: État actuel du système
            
        Returns:
            État mis à jour
        """
        task_description = state['task_description']
        
        # Analyser la tâche pour déterminer les agents requis
        required_agents = self._analyze_task_requirements(task_description)
        
        # Créer les agents nécessaires
        for agent_type in required_agents:
            if agent_type not in self.agents:
                self.agents[agent_type] = LangGraphAgent(agent_type, self.llm_client, self.memory_client)
        
        # Mettre à jour l'état
        state['required_agents'] = required_agents
        state['messages'].append({
            'role': 'system',
            'content': f"Agents requis identifiés: {', '.join(required_agents)}"
        })
        
        self.logger.info(f"Analyse terminée. Agents requis: {required_agents}")
        return state
    
    async def _coordinate_agents_node(self, state: AgentState) -> AgentState:
        """
        Nœud pour coordonner l'exécution des agents.
        
        Args:
            state: État actuel du système
            
        Returns:
            État mis à jour
        """
        required_agents = state['required_agents']
        
        # Exécuter les agents en parallèle
        tasks = []
        for agent_type in required_agents:
            agent = self.agents[agent_type]
            # Créer une tâche spécifique pour chaque agent
            agent_task = self._create_agent_specific_task(agent_type, state['task_description'])
            agent_state = state.copy()
            agent_state['task_description'] = agent_task
            tasks.append(agent.process_task(agent_state))
        
        # Attendre les résultats
        results = await asyncio.gather(*tasks)
        
        # Stocker les résultats
        state['agent_results'] = {}
        for result in results:
            agent_type = result['agent_type']
            state['agent_results'][agent_type] = result
        
        state['messages'].append({
            'role': 'system',
            'content': f"Exécution terminée pour {len(results)} agents"
        })
        
        self.logger.info(f"Coordination terminée. {len(results)} agents ont terminé.")
        return state
    
    async def _compile_results_node(self, state: AgentState) -> AgentState:
        """
        Nœud pour compiler les résultats des agents.
        
        Args:
            state: État actuel du système
            
        Returns:
            État mis à jour avec résultats compilés
        """
        agent_results = state['agent_results']
        
        # Compiler les résultats
        compiled_results = {
            'task_id': state['task_id'],
            'task_description': state['task_description'],
            'agents_used': list(agent_results.keys()),
            'results': list(agent_results.values()),
            'status': 'completed',
            'timestamp': datetime.now().isoformat()
        }
        
        # Calculer le temps total
        execution_times = [r.get('execution_time', 0) for r in agent_results.values() if r.get('execution_time')]
        if execution_times:
            compiled_results['total_execution_time'] = max(execution_times)
        
        state['compiled_results'] = compiled_results
        state['messages'].append({
            'role': 'system',
            'content': f"Résultats compilés avec succès"
        })
        
        self.logger.info(f"Compilation terminée pour la tâche {state['task_id']}")
        return state
    
    def _analyze_task_requirements(self, task_description: str) -> List[str]:
        """
        Analyse la tâche pour déterminer les agents requis.
        
        Args:
            task_description: Description de la tâche
            
        Returns:
            Liste des types d'agents requis
        """
        agents = []
        task_lower = task_description.lower()
        
        # Mots-clés pour chaque type d'agent
        keywords = {
            'frontend': ['html', 'css', 'javascript', 'ui', 'frontend', 'webpage', 'interface', 'page', 'web'],
            'backend': ['api', 'server', 'backend', 'endpoint', 'service', 'logique', 'rest', 'graphql'],
            'database': ['database', 'sql', 'schema', 'table', 'query', 'base de données', 'bdd', 'données'],
            'devops': ['deploy', 'config', 'infrastructure', 'devops', 'déploiement', 'docker', 'kubernetes'],
            'testing': ['test', 'testing', 'qa', 'quality', 'qualité', 'tests']
        }
        
        for agent_type, words in keywords.items():
            if any(keyword in task_lower for keyword in words):
                agents.append(agent_type)
        
        # Si aucun agent spécifique détecté, utiliser frontend par défaut
        if not agents:
            agents.append('frontend')
        
        return agents
    
    def _create_agent_specific_task(self, agent_type: str, task_description: str) -> str:
        """
        Crée une tâche spécifique pour un type d'agent.
        
        Args:
            agent_type: Type d'agent
            task_description: Description originale de la tâche
            
        Returns:
            Tâche spécialisée
        """
        templates = {
            'frontend': f"""
En tant qu'expert frontend, créez les composants d'interface utilisateur pour :
{task_description}

Concentrez-vous sur :
- Structure HTML sémantique
- Styles CSS modernes et responsive
- Interactions JavaScript
- Accessibilité et UX
- Performance et optimisation
""",
            'backend': f"""
En tant qu'expert backend, développez la logique serveur pour :
{task_description}

Concentrez-vous sur :
- Architecture et APIs
- Logique métier
- Sécurité et authentification
- Performance et scalabilité
- Integration avec la base de données
""",
            'database': f"""
En tant qu'expert base de données, concevez la solution de données pour :
{task_description}

Concentrez-vous sur :
- Modélisation et schéma
- Requêtes optimisées
- Indexation et performance
- Migrations et versioning
- Sécurité des données
""",
            'devops': f"""
En tant qu'expert DevOps, gérez l'infrastructure et le déploiement pour :
{task_description}

Concentrez-vous sur :
- Containerisation et orchestration
- CI/CD et automatisation
- Monitoring et logging
- Sécurité infrastructure
- Scalabilité et haute disponibilité
""",
            'testing': f"""
En tant qu'expert QA, créez la stratégie de test pour :
{task_description}

Concentrez-vous sur :
- Tests unitaires et d'intégration
- Tests end-to-end
- Automatisation des tests
- Tests de performance
- Couverture et qualité
"""
        }
        
        return templates.get(agent_type, f"Gérez les aspects {agent_type} de : {task_description}")
    
    async def execute_task(self, task_description: str) -> Dict[str, Any]:
        """
        Exécute une tâche en utilisant le système multi-agents LangGraph.
        
        Args:
            task_description: Description de la tâche à exécuter
            
        Returns:
            Résultats de l'exécution
        """
        task_id = str(uuid.uuid4())
        start_time = datetime.now()
        
        try:
            # Enregistrer le début de la tâche dans la mémoire
            task_execution = TaskExecution(
                task_id=task_id,
                task_description=task_description,
                status='pending',
                assigned_agents=[],
                start_time=start_time.isoformat(),
                end_time=None,
                results={},
                errors=[]
            )
            await self.memory_client.save_task_execution(task_execution)
            
            # Créer l'état initial
            initial_state: AgentState = {
                'messages': [],
                'task_description': task_description,
                'task_id': task_id,
                'required_agents': [],
                'agent_results': {},
                'current_agent': None,
                'iteration_count': 0,
                'max_iterations': 3
            }
            
            # Mettre à jour le statut de la tâche
            await self.memory_client.update_task_status(task_id, 'in_progress')
            
            # Exécuter le workflow
            final_state = await self.workflow_graph.ainvoke(initial_state)
            
            # Récupérer les résultats
            result = final_state.get('compiled_results', {})
            
            # Ajouter les métadonnées
            end_time = datetime.now()
            result['execution_time'] = (end_time - start_time).total_seconds()
            result['start_time'] = start_time.isoformat()
            result['end_time'] = end_time.isoformat()
            
            # Mettre à jour la tâche dans la mémoire
            await self.memory_client.update_task_status(
                task_id, 
                'completed', 
                results=result, 
                errors=[]
            )
            
            self.logger.info(f"Tâche {task_id} terminée avec succès")
            return result
            
        except Exception as e:
            error_time = datetime.now()
            self.logger.error(f"Erreur lors de l'exécution de la tâche {task_id}: {e}")
            
            # Enregistrer l'erreur dans la mémoire
            await self.memory_client.log_error(
                agent_id='system',
                task_id=task_id,
                error_type='task_execution_error',
                error_message=str(e),
                context={'task_description': task_description}
            )
            
            error_result = {
                'task_id': task_id,
                'task_description': task_description,
                'error': str(e),
                'status': 'failed',
                'start_time': start_time.isoformat(),
                'end_time': error_time.isoformat()
            }
            
            # Mettre à jour le statut de la tâche
            await self.memory_client.update_task_status(
                task_id, 
                'failed', 
                results={}, 
                errors=[str(e)]
            )
            
            return error_result
    
    async def get_statistics(self) -> Dict[str, Any]:
        """
        Retourne les statistiques du système depuis l'API mémoire.
        
        Returns:
            Statistiques du système
        """
        try:
            # Récupérer les statistiques depuis l'API mémoire
            system_stats = await self.memory_client.get_system_statistics()
            
            # Ajouter les statistiques locales
            local_stats = {
                'active_agents': len(self.agents),
                'agent_types': list(self.agents.keys())
            }
            
            # Fusionner les statistiques
            return {**system_stats, **local_stats}
            
        except Exception as e:
            self.logger.error(f"Erreur lors de la récupération des statistiques: {e}")
            # Fallback vers les statistiques locales
            return {
                'active_agents': len(self.agents),
                'agent_types': list(self.agents.keys()),
                'error': 'Impossible de récupérer les statistiques complètes'
            }
    
    async def cleanup_agents(self):
        """
        Nettoie les agents du système et archive leur statut.
        """
        agent_count = len(self.agents)
        
        # Archiver tous les agents dans la mémoire
        for agent_id, agent in self.agents.items():
            await self.memory_client.update_agent_status(
                AgentStatus(
                    agent_id=agent.agent_id,
                    agent_type=agent.agent_type,
                    status='archived',
                    current_task_id=None,
                    last_activity=datetime.now().isoformat(),
                    performance_metrics={}
                )
            )
        
        # Nettoyer les agents locaux
        self.agents.clear()
        self.logger.info(f"Nettoyage terminé. {agent_count} agents archivés.")