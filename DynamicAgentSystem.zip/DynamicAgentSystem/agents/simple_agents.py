"""
Agents simplifiés sans CrewAI pour éviter les problèmes d'import.
Cette version utilise une approche plus directe pour créer des agents.
"""

import asyncio
import logging
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Any
from utils.llm_client import LLMClient
from utils.memory_client import MemoryAPIClient, AgentInteraction, AgentStatus, TaskExecution

class SimpleAgent:
    """
    Agent simple qui peut exécuter des tâches spécialisées.
    """
    
    def __init__(self, agent_type: str, llm_client: LLMClient, memory_client: MemoryAPIClient):
        """
        Initialise l'agent.
        
        Args:
            agent_type: Type d'agent (frontend, backend, etc.)
            llm_client: Client LLM pour générer les réponses
            memory_client: Client pour l'API mémoire unifiée
        """
        self.agent_type = agent_type
        self.llm_client = llm_client
        self.memory_client = memory_client
        self.agent_id = f"{agent_type}_{str(uuid.uuid4())[:8]}"
        self.logger = logging.getLogger(f"Agent.{agent_type}")
        
        # Configuration spécifique par type d'agent
        self.agent_configs = {
            'frontend': {
                'role': 'Frontend Developer',
                'goal': 'Créer des interfaces utilisateur modernes avec HTML, CSS, et JavaScript',
                'expertise': 'HTML5, CSS3, JavaScript, frameworks modernes, design responsive'
            },
            'backend': {
                'role': 'Backend Developer', 
                'goal': 'Développer la logique serveur, APIs, et logique métier',
                'expertise': 'Python, Node.js, APIs REST, bases de données, architecture'
            },
            'database': {
                'role': 'Database Specialist',
                'goal': 'Concevoir des schémas de base de données efficaces et optimiser les requêtes',
                'expertise': 'SQL, NoSQL, modélisation de données, optimisation de requêtes'
            },
            'devops': {
                'role': 'DevOps Engineer',
                'goal': 'Gérer le déploiement, l\'infrastructure et les opérations',
                'expertise': 'Docker, Kubernetes, CI/CD, cloud, monitoring'
            },
            'testing': {
                'role': 'QA Engineer',
                'goal': 'Créer des suites de tests complètes et assurer la qualité',
                'expertise': 'Tests unitaires, tests d\'intégration, automatisation, QA'
            }
        }
        
        self.config = self.agent_configs.get(agent_type, self.agent_configs['frontend'])
    
    async def execute_task(self, task_description: str) -> Dict[str, Any]:
        """
        Exécute une tâche spécialisée.
        
        Args:
            task_description: Description de la tâche à exécuter
            
        Returns:
            Résultat de la tâche
        """
        start_time = datetime.now()
        
        try:
            # Créer un prompt spécialisé pour ce type d'agent
            prompt = self._create_specialized_prompt(task_description)
            
            # Générer la réponse
            result = await self.llm_client.generate_response(prompt)
            
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            
            return {
                'agent_id': self.agent_id,
                'agent_type': self.agent_type,
                'task_description': task_description,
                'result': result,
                'execution_time': execution_time,
                'status': 'completed',
                'start_time': start_time.isoformat(),
                'end_time': end_time.isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Erreur lors de l'exécution de la tâche: {e}")
            return {
                'agent_id': self.agent_id,
                'agent_type': self.agent_type,
                'task_description': task_description,
                'error': str(e),
                'status': 'failed',
                'start_time': start_time.isoformat(),
                'end_time': datetime.now().isoformat()
            }
    
    def _create_specialized_prompt(self, task_description: str) -> str:
        """
        Crée un prompt spécialisé basé sur le type d'agent.
        
        Args:
            task_description: Description de la tâche
            
        Returns:
            Prompt spécialisé
        """
        base_prompt = f"""
Vous êtes un {self.config['role']} expert.

Votre objectif : {self.config['goal']}

Vos compétences : {self.config['expertise']}

Tâche à accomplir : {task_description}

Instructions :
1. Analysez la tâche du point de vue de votre spécialité
2. Fournissez une solution détaillée et pratique
3. Incluez des exemples de code si pertinent
4. Expliquez les bonnes pratiques à suivre
5. Mentionnez les considérations importantes pour cette tâche

Réponse :
"""
        return base_prompt

class SimpleAgentManager:
    """
    Gestionnaire d'agents simplifiés.
    """
    
    def __init__(self):
        """
        Initialise le gestionnaire d'agents.
        """
        self.llm_client = LLMClient()
        self.memory_client = MemoryAPIClient()
        self.active_agents: Dict[str, SimpleAgent] = {}
        self.logger = logging.getLogger(__name__)
    
    def create_agent(self, agent_type: str) -> SimpleAgent:
        """
        Crée un agent spécialisé.
        
        Args:
            agent_type: Type d'agent à créer
            
        Returns:
            Instance de l'agent créé
        """
        agent = SimpleAgent(agent_type, self.llm_client, self.memory_client)
        self.active_agents[agent.agent_id] = agent
        
        self.logger.info(f"Agent créé : {agent_type} ({agent.agent_id})")
        return agent
    
    async def execute_task(self, task_description: str) -> Dict[str, Any]:
        """
        Exécute une tâche en créant les agents appropriés.
        
        Args:
            task_description: Description de la tâche
            
        Returns:
            Résultats de l'exécution
        """
        task_id = str(uuid.uuid4())
        start_time = datetime.now()
        
        try:
            # Analyser la tâche pour déterminer les agents requis
            required_agents = self._analyze_task_requirements(task_description)
            
            # Créer les agents
            agents = []
            for agent_type in required_agents:
                agent = self.create_agent(agent_type)
                agents.append(agent)
            
            # Exécuter les tâches en parallèle
            tasks = []
            for agent in agents:
                specialized_task = self._get_agent_specific_task(agent.agent_type, task_description)
                tasks.append(agent.execute_task(specialized_task))
            
            # Attendre les résultats
            results = await asyncio.gather(*tasks)
            
            # Compiler les résultats
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            
            task_result = {
                'task_id': task_id,
                'description': task_description,
                'agents_used': required_agents,
                'results': results,
                'execution_time': execution_time,
                'status': 'completed',
                'start_time': start_time.isoformat(),
                'end_time': end_time.isoformat()
            }
            
            self.task_history.append(task_result)
            
            # Nettoyer les agents
            self._cleanup_agents(agents)
            
            return task_result
            
        except Exception as e:
            self.logger.error(f"Erreur lors de l'exécution de la tâche: {e}")
            return {
                'task_id': task_id,
                'description': task_description,
                'error': str(e),
                'status': 'failed',
                'start_time': start_time.isoformat(),
                'end_time': datetime.now().isoformat()
            }
    
    def _analyze_task_requirements(self, task_description: str) -> List[str]:
        """
        Analyse la tâche pour déterminer les agents requis.
        
        Args:
            task_description: Description de la tâche
            
        Returns:
            Liste des types d'agents requis
        """
        agents = []
        task_lower = task_description.lower()
        
        # Mots-clés pour chaque type d'agent
        keywords = {
            'frontend': ['html', 'css', 'javascript', 'ui', 'frontend', 'webpage', 'interface', 'page'],
            'backend': ['api', 'server', 'backend', 'endpoint', 'service', 'logique'],
            'database': ['database', 'sql', 'schema', 'table', 'query', 'base de données'],
            'devops': ['deploy', 'config', 'infrastructure', 'devops', 'déploiement'],
            'testing': ['test', 'testing', 'qa', 'quality', 'qualité']
        }
        
        for agent_type, words in keywords.items():
            if any(keyword in task_lower for keyword in words):
                agents.append(agent_type)
        
        # Si aucun agent spécifique détecté, utiliser frontend par défaut
        if not agents:
            agents.append('frontend')
        
        return agents
    
    def _get_agent_specific_task(self, agent_type: str, task_description: str) -> str:
        """
        Génère une tâche spécifique pour un type d'agent.
        
        Args:
            agent_type: Type d'agent
            task_description: Description originale de la tâche
            
        Returns:
            Tâche spécialisée
        """
        templates = {
            'frontend': f"Créez les composants frontend pour : {task_description}. Concentrez-vous sur la structure HTML, le style CSS et les fonctionnalités JavaScript.",
            'backend': f"Développez la logique backend pour : {task_description}. Créez les APIs, la logique métier et les fonctionnalités côté serveur.",
            'database': f"Concevez le schéma de base de données pour : {task_description}. Créez les tables, relations et requêtes optimisées.",
            'devops': f"Gérez le déploiement et l'infrastructure pour : {task_description}. Créez les configurations, scripts de déploiement et setup d'infrastructure.",
            'testing': f"Créez les tests complets pour : {task_description}. Incluez les tests unitaires, d'intégration et les procédures de QA."
        }
        
        return templates.get(agent_type, f"Gérez les aspects {agent_type} de : {task_description}")
    
    def _cleanup_agents(self, agents: List[SimpleAgent]):
        """
        Nettoie les agents après utilisation.
        
        Args:
            agents: Liste des agents à nettoyer
        """
        for agent in agents:
            if agent.agent_id in self.active_agents:
                del self.active_agents[agent.agent_id]
                self.logger.info(f"Agent nettoyé : {agent.agent_id}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Retourne les statistiques du système.
        
        Returns:
            Statistiques du système
        """
        return {
            'active_agents': len(self.active_agents),
            'total_tasks': len(self.task_history),
            'successful_tasks': len([t for t in self.task_history if t['status'] == 'completed']),
            'failed_tasks': len([t for t in self.task_history if t['status'] == 'failed'])
        }