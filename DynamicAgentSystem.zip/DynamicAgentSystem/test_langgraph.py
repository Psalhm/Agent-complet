#!/usr/bin/env python3
"""
Test du système LangGraph pour vérifier son fonctionnement.
"""

import asyncio
import os
from dotenv import load_dotenv
from agents.langgraph_agents import LangGraphMultiAgentSystem

# Charger les variables d'environnement
load_dotenv()

async def test_langgraph_system():
    """Test basique du système LangGraph."""
    print("🧪 Test du système LangGraph")
    print("-" * 40)
    
    # Vérifier la clé API
    if not os.getenv("OPENROUTER_API_KEY") or os.getenv("OPENROUTER_API_KEY") == "your-openrouter-api-key-here":
        print("❌ Clé API OpenRouter non configurée")
        return False
    
    try:
        # Initialiser le système
        system = LangGraphMultiAgentSystem()
        print("✅ Système LangGraph initialisé")
        
        # Test avec une tâche simple
        task = "Créez un simple titre HTML avec le texte 'Hello World'"
        print(f"📝 Tâche de test : {task}")
        
        result = await system.execute_task(task)
        
        if result.get('status') == 'completed':
            print("✅ Test terminé avec succès")
            print(f"⏱️ Temps : {result.get('execution_time', 0):.2f}s")
            print(f"🤖 Agents : {', '.join(result.get('agents_used', []))}")
            return True
        else:
            print(f"❌ Test échoué : {result.get('error', 'Erreur inconnue')}")
            return False
            
    except Exception as e:
        print(f"❌ Erreur lors du test : {e}")
        return False

async def main():
    """Fonction principale."""
    success = await test_langgraph_system()
    
    if success:
        print("\n🎉 Le système LangGraph fonctionne correctement !")
        print("📖 Vous pouvez maintenant utiliser :")
        print("   • python main_langgraph.py")
        print("   • python demo_langgraph.py")
    else:
        print("\n⚠️ Le système nécessite une configuration supplémentaire")
        print("📖 Consultez le fichier DEMARRAGE.md pour plus d'informations")

if __name__ == "__main__":
    asyncio.run(main())