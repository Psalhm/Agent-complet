# 🚀 Démarrage Rapide - Système Multi-Agents

## ✅ Étapes de Configuration

### 1. Configurer les APIs
```bash
# Copier le fichier d'exemple
cp .env.example .env

# Éditez le fichier .env et configurez :
# OPENROUTER_API_KEY=your-openrouter-api-key-here
# MEMORY_API_BASE_URL=http://localhost:8080/api/v1
# MEMORY_API_KEY=your-memory-api-key-here
```

### 2. Vérifier la configuration
```bash
# Vérification générale
python check_setup.py

# Test d'intégration mémoire
python test_memory_integration.py
```

### 3. Lancer le système
```bash
# Système avec API mémoire unifiée (recommandé)
python main_memory_unified.py

# Système LangGraph standard
python main_langgraph.py

# Démonstration interactive
python demo_langgraph.py

# Système simple (fallback)
python main_simple.py
```

## 🤖 Types d'Agents Disponibles

- **Frontend** : HTML, CSS, JavaScript, interfaces utilisateur
- **Backend** : APIs, logique serveur, services
- **Database** : Schémas SQL, requêtes, modélisation
- **DevOps** : Déploiement, infrastructure, configuration
- **Testing** : Tests unitaires, QA, automatisation

## 📋 Exemples de Tâches

### Tâche Simple
```
"Créez une page web avec un formulaire de contact"
```

### Tâche Multi-Agents
```
"Créez un système de blog avec interface web, API REST et base de données"
```

### Tâche Spécialisée
```
"Concevez un schéma de base de données pour un système e-commerce"
```

## 🔧 Dépannage

### Erreur 401 (Unauthorized)
- Vérifiez votre clé API OpenRouter dans `.env`
- Assurez-vous d'avoir du crédit sur votre compte OpenRouter

### Erreur de connexion
- Vérifiez votre connexion internet
- Testez avec `python check_setup.py`

### Import timeout (main.py)
- Utilisez `main_simple.py` à la place (version sans CrewAI)

## 📚 Documentation Complète

- `README.md` : Documentation technique complète
- `instructions.md` : Instructions détaillées en français
- `replit.md` : Architecture et préférences du projet

## 🎯 Commandes Utiles

```bash
# Vérification du système
python check_setup.py

# Démonstration complète
python main_simple.py

# Mode interactif
python demo_interactive.py

# Version LangGraph (recommandé)
python main_langgraph.py

# Version originale (si CrewAI fonctionne)
python main.py
```

## 💡 Conseil

Le système détecte automatiquement les types d'agents nécessaires selon votre tâche. Plus votre description est précise, meilleur sera le résultat !

---

**Prêt à démarrer ?** Configurez votre clé API et lancez `python main_langgraph.py` ! 🎉

## 🚀 Pourquoi l'API Mémoire Unifiée ?

- **Centralisation** : Toutes les données d'agents en un lieu
- **Persistance** : Historique complet et durable
- **Partage** : Données accessibles entre instances
- **Analytics** : Métriques et statistiques avancées
- **Scalabilité** : Gestion distribuée des agents

## 🔧 Architecture Hybride

- **LangGraph** : Workflows structurés et gestion d'état
- **API Mémoire** : Stockage centralisé et persistance
- **OpenRouter** : Modèles open source (Mistral, LLaMA 2)
- **Mode dégradé** : Fonctionnement même sans API mémoire