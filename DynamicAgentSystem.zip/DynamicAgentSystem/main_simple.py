#!/usr/bin/env python3
"""
Version simplifiée du système multi-agents sans CrewAI.
Cette version utilise une approche plus directe pour éviter les problèmes d'import.
"""

import asyncio
import logging
import os
from dotenv import load_dotenv

from agents.simple_agents import SimpleAgentManager
from tasks.example_tasks import ExampleTasks
from utils.logger import setup_logging

# Charger les variables d'environnement
load_dotenv()

async def main():
    """
    Fonction principale pour initialiser et exécuter le système multi-agents simplifié.
    """
    # Configuration des logs
    setup_logging()
    logger = logging.getLogger(__name__)
    
    logger.info("Démarrage du système multi-agents simplifié avec OpenRouter")
    
    # Vérifier les variables d'environnement requises
    if not os.getenv("OPENROUTER_API_KEY"):
        logger.error("OPENROUTER_API_KEY not found in environment variables")
        print("❌ Erreur : OPENROUTER_API_KEY manquant")
        print("📝 Veuillez configurer votre clé API OpenRouter dans le fichier .env")
        print("🔗 Vous pouvez obtenir une clé sur : https://openrouter.ai/")
        return
    
    try:
        # Initialiser le gestionnaire d'agents
        agent_manager = SimpleAgentManager()
        
        # Initialiser les tâches d'exemple
        example_tasks = ExampleTasks()
        
        # Démontrer le système avec des tâches d'exemple
        logger.info("Démonstration du système avec des tâches d'exemple...")
        
        # Exemple 1 : Créer une page HTML
        print("\n" + "="*60)
        print("🎨 EXEMPLE 1 : Création d'une page HTML")
        print("="*60)
        
        html_task = example_tasks.create_html_page_task()
        print(f"📋 Tâche : {html_task[:100]}...")
        html_result = await agent_manager.execute_task(html_task)
        
        if html_result['status'] == 'completed':
            print("✅ Tâche HTML complétée avec succès")
            print(f"⏱️ Temps d'exécution : {html_result['execution_time']:.2f}s")
            print(f"🤖 Agents utilisés : {', '.join(html_result['agents_used'])}")
            
            # Afficher un extrait du résultat
            for result in html_result['results']:
                if result['status'] == 'completed':
                    print(f"\n📝 Résultat de l'agent {result['agent_type']} :")
                    print(result['result'][:300] + "..." if len(result['result']) > 300 else result['result'])
        else:
            print(f"❌ Erreur lors de la tâche HTML : {html_result.get('error', 'Erreur inconnue')}")
        
        # Exemple 2 : Créer un schéma SQL
        print("\n" + "="*60)
        print("🗄️ EXEMPLE 2 : Création d'un schéma SQL")
        print("="*60)
        
        sql_task = example_tasks.create_sql_schema_task()
        print(f"📋 Tâche : {sql_task[:100]}...")
        sql_result = await agent_manager.execute_task(sql_task)
        
        if sql_result['status'] == 'completed':
            print("✅ Tâche SQL complétée avec succès")
            print(f"⏱️ Temps d'exécution : {sql_result['execution_time']:.2f}s")
            print(f"🤖 Agents utilisés : {', '.join(sql_result['agents_used'])}")
            
            # Afficher un extrait du résultat
            for result in sql_result['results']:
                if result['status'] == 'completed':
                    print(f"\n📝 Résultat de l'agent {result['agent_type']} :")
                    print(result['result'][:300] + "..." if len(result['result']) > 300 else result['result'])
        else:
            print(f"❌ Erreur lors de la tâche SQL : {sql_result.get('error', 'Erreur inconnue')}")
        
        # Exemple 3 : Créer des endpoints API
        print("\n" + "="*60)
        print("🔌 EXEMPLE 3 : Création d'endpoints API")
        print("="*60)
        
        api_task = example_tasks.create_api_endpoint_task()
        print(f"📋 Tâche : {api_task[:100]}...")
        api_result = await agent_manager.execute_task(api_task)
        
        if api_result['status'] == 'completed':
            print("✅ Tâche API complétée avec succès")
            print(f"⏱️ Temps d'exécution : {api_result['execution_time']:.2f}s")
            print(f"🤖 Agents utilisés : {', '.join(api_result['agents_used'])}")
            
            # Afficher un extrait du résultat
            for result in api_result['results']:
                if result['status'] == 'completed':
                    print(f"\n📝 Résultat de l'agent {result['agent_type']} :")
                    print(result['result'][:300] + "..." if len(result['result']) > 300 else result['result'])
        else:
            print(f"❌ Erreur lors de la tâche API : {api_result.get('error', 'Erreur inconnue')}")
        
        # Afficher les statistiques
        print("\n" + "="*60)
        print("📊 STATISTIQUES DU SYSTÈME")
        print("="*60)
        
        stats = agent_manager.get_statistics()
        print(f"🤖 Agents actifs : {stats['active_agents']}")
        print(f"📋 Tâches totales : {stats['total_tasks']}")
        print(f"✅ Tâches réussies : {stats['successful_tasks']}")
        print(f"❌ Tâches échouées : {stats['failed_tasks']}")
        
        if stats['total_tasks'] > 0:
            success_rate = (stats['successful_tasks'] / stats['total_tasks']) * 100
            print(f"📈 Taux de réussite : {success_rate:.1f}%")
        
        print("\n" + "="*60)
        print("🎉 Démonstration terminée avec succès !")
        print("="*60)
        
        logger.info("Démonstration du système multi-agents terminée avec succès")
        
    except Exception as e:
        logger.error(f"Erreur lors de l'exécution principale : {e}")
        print(f"❌ Erreur : {e}")
        return

if __name__ == "__main__":
    # Exécuter la fonction principale asynchrone
    asyncio.run(main())