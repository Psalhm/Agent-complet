"""
LLM Client for OpenRouter integration.
This module provides the interface for communicating with OpenRouter API.
"""

import os
import logging
import json
import asyncio
from typing import Dict, Any, Optional, List
import aiohttp
import requests
from langchain.llms.base import LLM
from langchain.callbacks.manager import CallbackManagerForLLMRun
from pydantic import BaseModel

class OpenRouterLLM(LLM, BaseModel):
    """
    Custom LangChain LLM implementation for OpenRouter API.
    """
    
    api_key: str
    model_name: str = "mistralai/mistral-7b-instruct"
    base_url: str = "https://openrouter.ai/api/v1"
    max_tokens: int = 2048
    temperature: float = 0.7
    
    class Config:
        """Pydantic configuration."""
        extra = "forbid"
    
    @property
    def _llm_type(self) -> str:
        """Return identifier of llm type."""
        return "openrouter"
    
    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        """Call the OpenRouter API."""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://localhost:5000",
            "X-Title": "Multi-Agent Task System"
        }
        
        data = {
            "model": self.model_name,
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "max_tokens": self.max_tokens,
            "temperature": self.temperature
        }
        
        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=data,
                timeout=30
            )
            response.raise_for_status()
            
            result = response.json()
            return result["choices"][0]["message"]["content"]
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"OpenRouter API call failed: {e}")
        except (KeyError, IndexError) as e:
            raise Exception(f"Invalid response format from OpenRouter: {e}")

class LLMClient:
    """
    Client for managing LLM interactions with OpenRouter.
    """
    
    def __init__(self):
        """
        Initialize the LLM client.
        """
        self.logger = logging.getLogger(__name__)
        self.api_key = os.getenv("OPENROUTER_API_KEY", "your-api-key-here")
        self.model_name = os.getenv("OPENROUTER_MODEL", "mistralai/mistral-7b-instruct")
        self.base_url = "https://openrouter.ai/api/v1"
        
        # Available models on OpenRouter
        self.available_models = {
            "mistral-7b": "mistralai/mistral-7b-instruct",
            "mistral-8x7b": "mistralai/mixtral-8x7b-instruct",
            "llama2-70b": "meta-llama/llama-2-70b-chat",
            "llama2-13b": "meta-llama/llama-2-13b-chat",
            "codellama-34b": "codellama/codellama-34b-instruct",
            "yi-34b": "01-ai/yi-34b-chat"
        }
        
        self.logger.info(f"LLM Client initialized with model: {self.model_name}")
    
    def get_llm(self) -> OpenRouterLLM:
        """
        Get a LangChain-compatible LLM instance.
        
        Returns:
            OpenRouterLLM instance
        """
        return OpenRouterLLM(
            api_key=self.api_key,
            model_name=self.model_name,
            max_tokens=2048,
            temperature=0.7
        )
    
    async def generate_response(self, prompt: str, **kwargs) -> str:
        """
        Generate a response using the LLM.
        
        Args:
            prompt: Input prompt
            **kwargs: Additional parameters
            
        Returns:
            Generated response
        """
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "HTTP-Referer": "http://localhost:5000",
                "X-Title": "Multi-Agent Task System"
            }
            
            data = {
                "model": self.model_name,
                "messages": [
                    {"role": "user", "content": prompt}
                ],
                "max_tokens": kwargs.get("max_tokens", 2048),
                "temperature": kwargs.get("temperature", 0.7)
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.base_url}/chat/completions",
                    headers=headers,
                    json=data,
                    timeout=30
                ) as response:
                    response.raise_for_status()
                    result = await response.json()
                    return result["choices"][0]["message"]["content"]
                    
        except Exception as e:
            self.logger.error(f"Error generating response: {e}")
            raise Exception(f"Failed to generate response: {e}")
    
    def generate_response_sync(self, prompt: str, **kwargs) -> str:
        """
        Generate a response using the LLM synchronously.
        
        Args:
            prompt: Input prompt
            **kwargs: Additional parameters
            
        Returns:
            Generated response
        """
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "HTTP-Referer": "http://localhost:5000",
                "X-Title": "Multi-Agent Task System"
            }
            
            data = {
                "model": self.model_name,
                "messages": [
                    {"role": "user", "content": prompt}
                ],
                "max_tokens": kwargs.get("max_tokens", 2048),
                "temperature": kwargs.get("temperature", 0.7)
            }
            
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=data,
                timeout=30
            )
            response.raise_for_status()
            
            result = response.json()
            return result["choices"][0]["message"]["content"]
            
        except Exception as e:
            self.logger.error(f"Error generating response: {e}")
            raise Exception(f"Failed to generate response: {e}")
    
    def set_model(self, model_name: str):
        """
        Set the model to use for generation.
        
        Args:
            model_name: Name of the model to use
        """
        if model_name in self.available_models:
            self.model_name = self.available_models[model_name]
        else:
            self.model_name = model_name
        
        self.logger.info(f"Model set to: {self.model_name}")
    
    def get_available_models(self) -> Dict[str, str]:
        """
        Get available models.
        
        Returns:
            Dictionary of available models
        """
        return self.available_models
    
    def test_connection(self) -> bool:
        """
        Test the connection to OpenRouter API.
        
        Returns:
            True if connection is successful, False otherwise
        """
        try:
            test_prompt = "Hello, this is a test message. Please respond with 'Connection successful!'"
            response = self.generate_response_sync(test_prompt)
            self.logger.info("OpenRouter connection test successful")
            return True
        except Exception as e:
            self.logger.error(f"OpenRouter connection test failed: {e}")
            return False
