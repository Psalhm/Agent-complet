"""
Logging utilities for the multi-agent system.
This module provides centralized logging configuration and utilities.
"""

import logging
import os
from datetime import datetime
from typing import Optional

def setup_logging(log_level: str = "INFO", log_file: Optional[str] = None):
    """
    Setup logging configuration for the application.
    
    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Optional log file path
    """
    # Create logs directory if it doesn't exist
    if not os.path.exists("logs"):
        os.makedirs("logs")
    
    # Default log file with timestamp
    if log_file is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = f"logs/multi_agent_system_{timestamp}.log"
    
    # Configure logging format
    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"
    
    # Configure logging
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format=log_format,
        datefmt=date_format,
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler()  # Console output
        ]
    )
    
    # Set specific logger levels
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("aiohttp").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    
    logger = logging.getLogger(__name__)
    logger.info(f"Logging initialized - Level: {log_level}, File: {log_file}")

class AgentLogger:
    """
    Specialized logger for agent activities.
    """
    
    def __init__(self, agent_name: str):
        """
        Initialize agent logger.
        
        Args:
            agent_name: Name of the agent
        """
        self.agent_name = agent_name
        self.logger = logging.getLogger(f"Agent.{agent_name}")
    
    def log_creation(self, agent_id: str, task_id: str):
        """
        Log agent creation.
        
        Args:
            agent_id: Agent identifier
            task_id: Task identifier
        """
        self.logger.info(f"Agent created - ID: {agent_id}, Task: {task_id}")
    
    def log_task_start(self, agent_id: str, task_description: str):
        """
        Log task start.
        
        Args:
            agent_id: Agent identifier
            task_description: Task description
        """
        self.logger.info(f"Task started - Agent: {agent_id}, Task: {task_description[:100]}...")
    
    def log_task_completion(self, agent_id: str, execution_time: float, result_summary: str):
        """
        Log task completion.
        
        Args:
            agent_id: Agent identifier
            execution_time: Time taken to complete the task
            result_summary: Summary of the result
        """
        self.logger.info(f"Task completed - Agent: {agent_id}, Time: {execution_time:.2f}s, Result: {result_summary[:100]}...")
    
    def log_task_failure(self, agent_id: str, error_message: str):
        """
        Log task failure.
        
        Args:
            agent_id: Agent identifier
            error_message: Error message
        """
        self.logger.error(f"Task failed - Agent: {agent_id}, Error: {error_message}")
    
    def log_archival(self, agent_id: str):
        """
        Log agent archival.
        
        Args:
            agent_id: Agent identifier
        """
        self.logger.info(f"Agent archived - ID: {agent_id}")

class TaskLogger:
    """
    Specialized logger for task activities.
    """
    
    def __init__(self):
        """
        Initialize task logger.
        """
        self.logger = logging.getLogger("TaskManager")
    
    def log_task_creation(self, task_id: str, task_type: str, description: str):
        """
        Log task creation.
        
        Args:
            task_id: Task identifier
            task_type: Type of task
            description: Task description
        """
        self.logger.info(f"Task created - ID: {task_id}, Type: {task_type}, Description: {description[:50]}...")
    
    def log_task_assignment(self, task_id: str, agent_id: str):
        """
        Log task assignment.
        
        Args:
            task_id: Task identifier
            agent_id: Agent identifier
        """
        self.logger.info(f"Task assigned - Task: {task_id}, Agent: {agent_id}")
    
    def log_task_status_change(self, task_id: str, old_status: str, new_status: str):
        """
        Log task status change.
        
        Args:
            task_id: Task identifier
            old_status: Previous status
            new_status: New status
        """
        self.logger.info(f"Task status changed - Task: {task_id}, {old_status} -> {new_status}")
    
    def log_task_statistics(self, stats: dict):
        """
        Log task statistics.
        
        Args:
            stats: Task statistics dictionary
        """
        self.logger.info(f"Task statistics - {stats}")

class SystemLogger:
    """
    Specialized logger for system-level activities.
    """
    
    def __init__(self):
        """
        Initialize system logger.
        """
        self.logger = logging.getLogger("System")
    
    def log_system_start(self):
        """
        Log system startup.
        """
        self.logger.info("Multi-Agent System started")
    
    def log_system_shutdown(self):
        """
        Log system shutdown.
        """
        self.logger.info("Multi-Agent System shutting down")
    
    def log_agent_creation(self, agent_type: str, agent_id: str):
        """
        Log agent creation at system level.
        
        Args:
            agent_type: Type of agent
            agent_id: Agent identifier
        """
        self.logger.info(f"System created agent - Type: {agent_type}, ID: {agent_id}")
    
    def log_agent_cleanup(self, agent_count: int):
        """
        Log agent cleanup.
        
        Args:
            agent_count: Number of agents cleaned up
        """
        self.logger.info(f"System cleanup completed - {agent_count} agents archived")
    
    def log_error(self, error_type: str, error_message: str):
        """
        Log system error.
        
        Args:
            error_type: Type of error
            error_message: Error message
        """
        self.logger.error(f"System error - Type: {error_type}, Message: {error_message}")
    
    def log_performance_metrics(self, metrics: dict):
        """
        Log performance metrics.
        
        Args:
            metrics: Performance metrics dictionary
        """
        self.logger.info(f"Performance metrics - {metrics}")
