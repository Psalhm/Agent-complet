"""
Client pour l'API mémoire unifiée.
Ce module remplace toute gestion locale de base de données.
"""

import asyncio
import json
import logging
import os
from datetime import datetime
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass
import aiohttp
from dotenv import load_dotenv

load_dotenv()

@dataclass
class AgentInteraction:
    """Représente une interaction d'agent."""
    agent_id: str
    agent_type: str
    task_id: str
    interaction_type: str  # 'task_received', 'processing', 'completed', 'failed'
    content: str
    timestamp: str
    metadata: Dict[str, Any]

@dataclass
class AgentStatus:
    """Représente le statut d'un agent."""
    agent_id: str
    agent_type: str
    status: str  # 'active', 'idle', 'processing', 'archived'
    current_task_id: Optional[str]
    last_activity: str
    performance_metrics: Dict[str, Any]

@dataclass
class TaskExecution:
    """Représente l'exécution d'une tâche."""
    task_id: str
    task_description: str
    status: str  # 'pending', 'in_progress', 'completed', 'failed'
    assigned_agents: List[str]
    start_time: str
    end_time: Optional[str]
    results: Dict[str, Any]
    errors: List[str]

class MemoryAPIClient:
    """
    Client pour l'API mémoire unifiée.
    Remplace toute gestion locale de base de données.
    """
    
    def __init__(self, api_base_url: Optional[str] = None):
        """
        Initialise le client API mémoire.
        
        Args:
            api_base_url: URL de base de l'API mémoire (optionnel)
        """
        self.api_base_url = api_base_url or os.getenv("MEMORY_API_BASE_URL", "http://localhost:8080/api/v1")
        self.api_key = os.getenv("MEMORY_API_KEY")
        self.logger = logging.getLogger(__name__)
        
        # Configuration HTTP
        self.timeout = aiohttp.ClientTimeout(total=30)
        self.headers = {
            "Content-Type": "application/json",
            "User-Agent": "MultiAgentSystem/1.0"
        }
        
        if self.api_key:
            self.headers["Authorization"] = f"Bearer {self.api_key}"
    
    async def _make_request(self, method: str, endpoint: str, data: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Effectue une requête HTTP vers l'API mémoire.
        
        Args:
            method: Méthode HTTP (GET, POST, PUT, DELETE)
            endpoint: Endpoint API
            data: Données à envoyer (optionnel)
            
        Returns:
            Réponse de l'API
        """
        url = f"{self.api_base_url}/{endpoint.lstrip('/')}"
        
        try:
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.request(
                    method=method,
                    url=url,
                    headers=self.headers,
                    json=data if data else None
                ) as response:
                    
                    if response.status == 200:
                        return await response.json()
                    elif response.status == 404:
                        return {"error": "Not found", "status": 404}
                    elif response.status == 401:
                        raise Exception("API authentication failed")
                    else:
                        error_text = await response.text()
                        raise Exception(f"API error {response.status}: {error_text}")
                        
        except aiohttp.ClientError as e:
            self.logger.error(f"Erreur de connexion à l'API mémoire: {e}")
            raise Exception(f"Connexion API échouée: {e}")
        except Exception as e:
            self.logger.error(f"Erreur lors de la requête API: {e}")
            raise
    
    # === Gestion des Interactions d'Agents ===
    
    async def save_agent_interaction(self, interaction: AgentInteraction) -> bool:
        """
        Sauvegarde une interaction d'agent.
        
        Args:
            interaction: Interaction à sauvegarder
            
        Returns:
            True si sauvegarde réussie
        """
        try:
            data = {
                "agent_id": interaction.agent_id,
                "agent_type": interaction.agent_type,
                "task_id": interaction.task_id,
                "interaction_type": interaction.interaction_type,
                "content": interaction.content,
                "timestamp": interaction.timestamp,
                "metadata": interaction.metadata
            }
            
            result = await self._make_request("POST", "/agents/interactions", data)
            return result.get("success", False)
            
        except Exception as e:
            self.logger.error(f"Erreur lors de la sauvegarde d'interaction: {e}")
            return False
    
    async def get_agent_interactions(self, agent_id: str, limit: int = 100) -> List[AgentInteraction]:
        """
        Récupère les interactions d'un agent.
        
        Args:
            agent_id: ID de l'agent
            limit: Nombre maximum d'interactions à récupérer
            
        Returns:
            Liste des interactions
        """
        try:
            result = await self._make_request("GET", f"/agents/{agent_id}/interactions?limit={limit}")
            
            interactions = []
            for item in result.get("interactions", []):
                interactions.append(AgentInteraction(
                    agent_id=item["agent_id"],
                    agent_type=item["agent_type"],
                    task_id=item["task_id"],
                    interaction_type=item["interaction_type"],
                    content=item["content"],
                    timestamp=item["timestamp"],
                    metadata=item.get("metadata", {})
                ))
            
            return interactions
            
        except Exception as e:
            self.logger.error(f"Erreur lors de la récupération des interactions: {e}")
            return []
    
    # === Gestion des Statuts d'Agents ===
    
    async def update_agent_status(self, status: AgentStatus) -> bool:
        """
        Met à jour le statut d'un agent.
        
        Args:
            status: Nouveau statut
            
        Returns:
            True si mise à jour réussie
        """
        try:
            data = {
                "agent_id": status.agent_id,
                "agent_type": status.agent_type,
                "status": status.status,
                "current_task_id": status.current_task_id,
                "last_activity": status.last_activity,
                "performance_metrics": status.performance_metrics
            }
            
            result = await self._make_request("PUT", f"/agents/{status.agent_id}/status", data)
            return result.get("success", False)
            
        except Exception as e:
            self.logger.error(f"Erreur lors de la mise à jour du statut: {e}")
            return False
    
    async def get_agent_status(self, agent_id: str) -> Optional[AgentStatus]:
        """
        Récupère le statut d'un agent.
        
        Args:
            agent_id: ID de l'agent
            
        Returns:
            Statut de l'agent ou None si non trouvé
        """
        try:
            result = await self._make_request("GET", f"/agents/{agent_id}/status")
            
            if result.get("status") == 404:
                return None
            
            status_data = result.get("status", {})
            return AgentStatus(
                agent_id=status_data["agent_id"],
                agent_type=status_data["agent_type"],
                status=status_data["status"],
                current_task_id=status_data.get("current_task_id"),
                last_activity=status_data["last_activity"],
                performance_metrics=status_data.get("performance_metrics", {})
            )
            
        except Exception as e:
            self.logger.error(f"Erreur lors de la récupération du statut: {e}")
            return None
    
    async def get_all_active_agents(self) -> List[AgentStatus]:
        """
        Récupère tous les agents actifs.
        
        Returns:
            Liste des agents actifs
        """
        try:
            result = await self._make_request("GET", "/agents/active")
            
            agents = []
            for item in result.get("agents", []):
                agents.append(AgentStatus(
                    agent_id=item["agent_id"],
                    agent_type=item["agent_type"],
                    status=item["status"],
                    current_task_id=item.get("current_task_id"),
                    last_activity=item["last_activity"],
                    performance_metrics=item.get("performance_metrics", {})
                ))
            
            return agents
            
        except Exception as e:
            self.logger.error(f"Erreur lors de la récupération des agents actifs: {e}")
            return []
    
    # === Gestion des Tâches ===
    
    async def save_task_execution(self, task: TaskExecution) -> bool:
        """
        Sauvegarde l'exécution d'une tâche.
        
        Args:
            task: Tâche à sauvegarder
            
        Returns:
            True si sauvegarde réussie
        """
        try:
            data = {
                "task_id": task.task_id,
                "task_description": task.task_description,
                "status": task.status,
                "assigned_agents": task.assigned_agents,
                "start_time": task.start_time,
                "end_time": task.end_time,
                "results": task.results,
                "errors": task.errors
            }
            
            result = await self._make_request("POST", "/tasks/executions", data)
            return result.get("success", False)
            
        except Exception as e:
            self.logger.error(f"Erreur lors de la sauvegarde de tâche: {e}")
            return False
    
    async def update_task_status(self, task_id: str, status: str, results: Optional[Dict] = None, errors: Optional[List[str]] = None) -> bool:
        """
        Met à jour le statut d'une tâche.
        
        Args:
            task_id: ID de la tâche
            status: Nouveau statut
            results: Résultats (optionnel)
            errors: Erreurs (optionnel)
            
        Returns:
            True si mise à jour réussie
        """
        try:
            data = {
                "status": status,
                "timestamp": datetime.now().isoformat()
            }
            
            if results:
                data["results"] = results
            if errors:
                data["errors"] = errors
            if status in ["completed", "failed"]:
                data["end_time"] = datetime.now().isoformat()
            
            result = await self._make_request("PUT", f"/tasks/{task_id}/status", data)
            return result.get("success", False)
            
        except Exception as e:
            self.logger.error(f"Erreur lors de la mise à jour de tâche: {e}")
            return False
    
    async def get_task_execution(self, task_id: str) -> Optional[TaskExecution]:
        """
        Récupère l'exécution d'une tâche.
        
        Args:
            task_id: ID de la tâche
            
        Returns:
            Exécution de la tâche ou None si non trouvée
        """
        try:
            result = await self._make_request("GET", f"/tasks/{task_id}")
            
            if result.get("status") == 404:
                return None
            
            task_data = result.get("task", {})
            return TaskExecution(
                task_id=task_data["task_id"],
                task_description=task_data["task_description"],
                status=task_data["status"],
                assigned_agents=task_data.get("assigned_agents", []),
                start_time=task_data["start_time"],
                end_time=task_data.get("end_time"),
                results=task_data.get("results", {}),
                errors=task_data.get("errors", [])
            )
            
        except Exception as e:
            self.logger.error(f"Erreur lors de la récupération de tâche: {e}")
            return None
    
    async def get_recent_tasks(self, limit: int = 50) -> List[TaskExecution]:
        """
        Récupère les tâches récentes.
        
        Args:
            limit: Nombre maximum de tâches à récupérer
            
        Returns:
            Liste des tâches récentes
        """
        try:
            result = await self._make_request("GET", f"/tasks/recent?limit={limit}")
            
            tasks = []
            for item in result.get("tasks", []):
                tasks.append(TaskExecution(
                    task_id=item["task_id"],
                    task_description=item["task_description"],
                    status=item["status"],
                    assigned_agents=item.get("assigned_agents", []),
                    start_time=item["start_time"],
                    end_time=item.get("end_time"),
                    results=item.get("results", {}),
                    errors=item.get("errors", [])
                ))
            
            return tasks
            
        except Exception as e:
            self.logger.error(f"Erreur lors de la récupération des tâches récentes: {e}")
            return []
    
    # === Gestion des Erreurs ===
    
    async def log_error(self, agent_id: str, task_id: str, error_type: str, error_message: str, context: Dict[str, Any]) -> bool:
        """
        Enregistre une erreur dans le système.
        
        Args:
            agent_id: ID de l'agent
            task_id: ID de la tâche
            error_type: Type d'erreur
            error_message: Message d'erreur
            context: Contexte de l'erreur
            
        Returns:
            True si enregistrement réussi
        """
        try:
            data = {
                "agent_id": agent_id,
                "task_id": task_id,
                "error_type": error_type,
                "error_message": error_message,
                "context": context,
                "timestamp": datetime.now().isoformat()
            }
            
            result = await self._make_request("POST", "/errors", data)
            return result.get("success", False)
            
        except Exception as e:
            self.logger.error(f"Erreur lors de l'enregistrement d'erreur: {e}")
            return False
    
    # === Statistiques et Métriques ===
    
    async def get_system_statistics(self) -> Dict[str, Any]:
        """
        Récupère les statistiques du système.
        
        Returns:
            Statistiques du système
        """
        try:
            result = await self._make_request("GET", "/statistics")
            return result.get("statistics", {})
            
        except Exception as e:
            self.logger.error(f"Erreur lors de la récupération des statistiques: {e}")
            return {}
    
    async def get_agent_performance(self, agent_id: str) -> Dict[str, Any]:
        """
        Récupère les métriques de performance d'un agent.
        
        Args:
            agent_id: ID de l'agent
            
        Returns:
            Métriques de performance
        """
        try:
            result = await self._make_request("GET", f"/agents/{agent_id}/performance")
            return result.get("performance", {})
            
        except Exception as e:
            self.logger.error(f"Erreur lors de la récupération des performances: {e}")
            return {}
    
    # === Méthodes utilitaires ===
    
    async def health_check(self) -> bool:
        """
        Vérifie la santé de l'API mémoire.
        
        Returns:
            True si l'API est accessible
        """
        try:
            result = await self._make_request("GET", "/health")
            return result.get("status") == "healthy"
            
        except Exception as e:
            self.logger.error(f"Erreur lors du health check: {e}")
            return False
    
    async def cleanup_old_data(self, days: int = 30) -> bool:
        """
        Nettoie les données anciennes.
        
        Args:
            days: Nombre de jours à conserver
            
        Returns:
            True si nettoyage réussi
        """
        try:
            data = {"retention_days": days}
            result = await self._make_request("POST", "/cleanup", data)
            return result.get("success", False)
            
        except Exception as e:
            self.logger.error(f"Erreur lors du nettoyage: {e}")
            return False