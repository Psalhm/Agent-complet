#!/usr/bin/env python3
"""
Système multi-agents utilisant LangGraph pour l'orchestration.
Cette version remplace CrewAI par LangGraph pour une meilleure performance et fiabilité.
"""

import asyncio
import logging
import os
from dotenv import load_dotenv

from agents.langgraph_agents import LangGraphMultiAgentSystem
from tasks.example_tasks import ExampleTasks
from utils.logger import setup_logging

# Charger les variables d'environnement
load_dotenv()

async def main():
    """
    Fonction principale pour initialiser et exécuter le système multi-agents LangGraph.
    """
    # Configuration des logs
    setup_logging()
    logger = logging.getLogger(__name__)
    
    logger.info("Démarrage du système multi-agents avec LangGraph et OpenRouter")
    
    # Vérifier les variables d'environnement requises
    if not os.getenv("OPENROUTER_API_KEY"):
        logger.error("OPENROUTER_API_KEY not found in environment variables")
        print("❌ Erreur : OPENROUTER_API_KEY manquant")
        print("📝 Veuillez configurer votre clé API OpenRouter dans le fichier .env")
        print("🔗 Vous pouvez obtenir une clé sur : https://openrouter.ai/")
        return
    
    try:
        # Initialiser le système multi-agents LangGraph
        agent_system = LangGraphMultiAgentSystem()
        
        # Initialiser les tâches d'exemple
        example_tasks = ExampleTasks()
        
        # Démontrer le système avec des tâches d'exemple
        logger.info("Démonstration du système avec des tâches d'exemple...")
        
        # Exemple 1 : Créer une page HTML
        print("\n" + "="*70)
        print("🎨 EXEMPLE 1 : Création d'une page HTML avec LangGraph")
        print("="*70)
        
        html_task = example_tasks.create_html_page_task()
        print(f"📋 Tâche : {html_task[:120]}...")
        
        print("\n🔄 Exécution du workflow LangGraph...")
        html_result = await agent_system.execute_task(html_task)
        
        if html_result.get('status') == 'completed':
            print("✅ Tâche HTML terminée avec succès !")
            print(f"⏱️ Temps d'exécution : {html_result.get('execution_time', 0):.2f}s")
            print(f"🤖 Agents utilisés : {', '.join(html_result.get('agents_used', []))}")
            
            # Afficher les résultats des agents
            for result in html_result.get('results', []):
                if result.get('status') == 'completed':
                    print(f"\n📝 Résultat de l'agent {result['agent_type']} :")
                    content = result.get('result', '')
                    print(content[:400] + "..." if len(content) > 400 else content)
        else:
            print(f"❌ Erreur lors de la tâche HTML : {html_result.get('error', 'Erreur inconnue')}")
        
        # Exemple 2 : Créer un système API complet
        print("\n" + "="*70)
        print("🔌 EXEMPLE 2 : Création d'un système API avec LangGraph")
        print("="*70)
        
        api_task = example_tasks.create_api_endpoint_task()
        print(f"📋 Tâche : {api_task[:120]}...")
        
        print("\n🔄 Exécution du workflow LangGraph...")
        api_result = await agent_system.execute_task(api_task)
        
        if api_result.get('status') == 'completed':
            print("✅ Tâche API terminée avec succès !")
            print(f"⏱️ Temps d'exécution : {api_result.get('execution_time', 0):.2f}s")
            print(f"🤖 Agents utilisés : {', '.join(api_result.get('agents_used', []))}")
            
            # Afficher les résultats des agents
            for result in api_result.get('results', []):
                if result.get('status') == 'completed':
                    print(f"\n📝 Résultat de l'agent {result['agent_type']} :")
                    content = result.get('result', '')
                    print(content[:400] + "..." if len(content) > 400 else content)
        else:
            print(f"❌ Erreur lors de la tâche API : {api_result.get('error', 'Erreur inconnue')}")
        
        # Exemple 3 : Tâche complexe multi-agents
        print("\n" + "="*70)
        print("🚀 EXEMPLE 3 : Tâche complexe multi-agents avec LangGraph")
        print("="*70)
        
        complex_task = example_tasks.create_complex_multi_agent_task()
        print(f"📋 Tâche : {complex_task[:120]}...")
        
        print("\n🔄 Exécution du workflow LangGraph...")
        complex_result = await agent_system.execute_task(complex_task)
        
        if complex_result.get('status') == 'completed':
            print("✅ Tâche complexe terminée avec succès !")
            print(f"⏱️ Temps d'exécution : {complex_result.get('execution_time', 0):.2f}s")
            print(f"🤖 Agents utilisés : {', '.join(complex_result.get('agents_used', []))}")
            
            # Afficher les résultats des agents
            for result in complex_result.get('results', []):
                if result.get('status') == 'completed':
                    print(f"\n📝 Résultat de l'agent {result['agent_type']} :")
                    content = result.get('result', '')
                    print(content[:300] + "..." if len(content) > 300 else content)
        else:
            print(f"❌ Erreur lors de la tâche complexe : {complex_result.get('error', 'Erreur inconnue')}")
        
        # Afficher les statistiques du système
        print("\n" + "="*70)
        print("📊 STATISTIQUES DU SYSTÈME LANGGRAPH")
        print("="*70)
        
        stats = agent_system.get_statistics()
        print(f"🤖 Agents actifs : {stats['active_agents']}")
        print(f"📋 Tâches totales : {stats['total_tasks']}")
        print(f"✅ Tâches réussies : {stats['successful_tasks']}")
        print(f"❌ Tâches échouées : {stats['failed_tasks']}")
        print(f"🔧 Types d'agents : {', '.join(stats['agent_types'])}")
        
        if stats['total_tasks'] > 0:
            success_rate = (stats['successful_tasks'] / stats['total_tasks']) * 100
            print(f"📈 Taux de réussite : {success_rate:.1f}%")
        
        # Nettoyage des agents
        print("\n" + "="*70)
        print("🧹 NETTOYAGE DU SYSTÈME")
        print("="*70)
        
        agent_system.cleanup_agents()
        print("✅ Nettoyage terminé")
        
        print("\n" + "="*70)
        print("🎉 Démonstration LangGraph terminée avec succès !")
        print("="*70)
        
        print("\n📖 Avantages de LangGraph par rapport à CrewAI :")
        print("• Workflow plus structuré et prévisible")
        print("• Gestion d'état avancée")
        print("• Meilleure performance et fiabilité")
        print("• Debugging et monitoring améliorés")
        print("• Intégration native avec LangChain")
        
        logger.info("Démonstration du système LangGraph terminée avec succès")
        
    except Exception as e:
        logger.error(f"Erreur lors de l'exécution principale : {e}")
        print(f"❌ Erreur : {e}")
        import traceback
        traceback.print_exc()
        return

if __name__ == "__main__":
    # Exécuter la fonction principale asynchrone
    asyncio.run(main())