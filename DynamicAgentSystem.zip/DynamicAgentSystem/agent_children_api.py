#!/usr/bin/env python3
"""
API FastAPI pour gérer la génération et le pilotage dynamique d'agents enfants.
Système multi-agents avec gestion complète du cycle de vie des agents.
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
import asyncio
import threading
import subprocess
import json
import uuid
import time
import logging
from datetime import datetime
from enum import Enum
import queue
import os
import signal
import sys
from contextlib import asynccontextmanager

# Configuration du logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AgentStatus(str, Enum):
    """États possibles d'un agent enfant."""
    CREATED = "created"
    STARTING = "starting"
    RUNNING = "running"
    BUSY = "busy"
    IDLE = "idle"
    STOPPING = "stopping"
    STOPPED = "stopped"
    ERROR = "error"

class AgentType(str, Enum):
    """Types d'agents disponibles."""
    THREAD = "thread"
    SUBPROCESS = "subprocess"

class AgentCreateRequest(BaseModel):
    """Requête pour créer un agent enfant."""
    name: str = Field(..., description="Nom de l'agent")
    role: str = Field(..., description="Rôle de l'agent (ex: 'data_processor', 'web_scraper')")
    context: str = Field(..., description="Contexte d'exécution de l'agent")
    agent_type: AgentType = Field(AgentType.THREAD, description="Type d'agent (thread ou subprocess)")
    parameters: Dict[str, Any] = Field(default_factory=dict, description="Paramètres spécifiques")
    max_lifetime: int = Field(default=3600, description="Durée de vie max en secondes")

class AgentCommandRequest(BaseModel):
    """Requête pour envoyer une commande à un agent."""
    command: str = Field(..., description="Commande à exécuter")
    parameters: Dict[str, Any] = Field(default_factory=dict, description="Paramètres de la commande")
    timeout: int = Field(default=30, description="Timeout en secondes")

class AgentInfo(BaseModel):
    """Informations sur un agent enfant."""
    id: str
    name: str
    role: str
    context: str
    agent_type: AgentType
    status: AgentStatus
    created_at: datetime
    last_activity: datetime
    parameters: Dict[str, Any]
    logs: List[str]
    results: List[Dict[str, Any]]
    error_message: Optional[str] = None

class AgentManager:
    """Gestionnaire des agents enfants."""
    
    def __init__(self):
        self.agents: Dict[str, Dict[str, Any]] = {}
        self.command_queues: Dict[str, queue.Queue] = {}
        self.result_queues: Dict[str, queue.Queue] = {}
        self.cleanup_task = None
        
    async def create_agent(self, request: AgentCreateRequest) -> str:
        """Crée un nouvel agent enfant."""
        agent_id = str(uuid.uuid4())
        
        # Configuration de l'agent
        agent_config = {
            "id": agent_id,
            "name": request.name,
            "role": request.role,
            "context": request.context,
            "agent_type": request.agent_type,
            "status": AgentStatus.CREATED,
            "created_at": datetime.now(),
            "last_activity": datetime.now(),
            "parameters": request.parameters,
            "logs": [],
            "results": [],
            "error_message": None,
            "max_lifetime": request.max_lifetime
        }
        
        # Création des queues de communication
        self.command_queues[agent_id] = queue.Queue()
        self.result_queues[agent_id] = queue.Queue()
        
        # Sauvegarde de la configuration
        self.agents[agent_id] = agent_config
        
        # Lancement de l'agent selon le type
        try:
            if request.agent_type == AgentType.THREAD:
                await self._start_thread_agent(agent_id, agent_config)
            elif request.agent_type == AgentType.SUBPROCESS:
                await self._start_subprocess_agent(agent_id, agent_config)
                
            agent_config["status"] = AgentStatus.RUNNING
            self._log_agent(agent_id, f"Agent {request.name} créé et démarré avec succès")
            
        except Exception as e:
            agent_config["status"] = AgentStatus.ERROR
            agent_config["error_message"] = str(e)
            self._log_agent(agent_id, f"Erreur lors de la création: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Erreur lors de la création de l'agent: {str(e)}")
        
        return agent_id
    
    async def _start_thread_agent(self, agent_id: str, config: Dict[str, Any]):
        """Démarre un agent en tant que thread."""
        def agent_worker():
            """Worker thread pour l'agent."""
            try:
                self._log_agent(agent_id, f"Thread agent {config['name']} démarré")
                
                # Boucle principale de l'agent
                while self.agents[agent_id]["status"] not in [AgentStatus.STOPPING, AgentStatus.STOPPED]:
                    try:
                        # Vérification que l'agent existe encore
                        if agent_id not in self.agents:
                            break
                            
                        # Vérification des commandes en attente
                        command_queue = self.command_queues.get(agent_id)
                        if not command_queue:
                            break
                        
                        try:
                            # Attendre une commande avec timeout
                            command_data = command_queue.get(timeout=1.0)
                            
                            # Vérifier que l'agent existe encore
                            if agent_id not in self.agents:
                                break
                            
                            # Traitement de la commande
                            self.agents[agent_id]["status"] = AgentStatus.BUSY
                            self._log_agent(agent_id, f"Traitement de la commande: {command_data['command']}")
                            
                            # Simulation du traitement (à remplacer par la logique réelle)
                            result = self._process_command(agent_id, command_data)
                            
                            # Retourner le résultat
                            if agent_id in self.result_queues:
                                self.result_queues[agent_id].put(result)
                            if agent_id in self.agents:
                                self.agents[agent_id]["results"].append(result)
                                self.agents[agent_id]["status"] = AgentStatus.IDLE
                                self.agents[agent_id]["last_activity"] = datetime.now()
                            
                        except queue.Empty:
                            # Pas de commande, agent en idle
                            if agent_id in self.agents and self.agents[agent_id]["status"] != AgentStatus.IDLE:
                                self.agents[agent_id]["status"] = AgentStatus.IDLE
                            
                        # Vérification du timeout de vie
                        if self._check_lifetime_expired(agent_id):
                            self._log_agent(agent_id, "Durée de vie expirée, arrêt de l'agent")
                            break
                            
                    except Exception as e:
                        if agent_id in self.agents:
                            self.agents[agent_id]["status"] = AgentStatus.ERROR
                            self.agents[agent_id]["error_message"] = str(e)
                            self._log_agent(agent_id, f"Erreur dans le thread: {str(e)}")
                        break
                
                # Nettoyage
                if agent_id in self.agents:
                    self.agents[agent_id]["status"] = AgentStatus.STOPPED
                    self._log_agent(agent_id, "Thread agent arrêté")
                
            except Exception as e:
                if agent_id in self.agents:
                    self.agents[agent_id]["status"] = AgentStatus.ERROR
                    self.agents[agent_id]["error_message"] = str(e)
                    self._log_agent(agent_id, f"Erreur fatale dans le thread: {str(e)}")
        
        # Lancement du thread
        thread = threading.Thread(target=agent_worker, daemon=True)
        thread.start()
        config["thread"] = thread
    
    async def _start_subprocess_agent(self, agent_id: str, config: Dict[str, Any]):
        """Démarre un agent en tant que subprocess."""
        # Script Python pour l'agent subprocess
        config_str = json.dumps({
            'id': config['id'],
            'name': config['name'],
            'role': config['role'],
            'context': config['context'],
            'parameters': config['parameters']
        }, default=str)
        
        agent_script = f"""
import sys
import json
import time
import signal
import os
from datetime import datetime

class SubprocessAgent:
    def __init__(self, agent_id, config):
        self.agent_id = agent_id
        self.config = config
        self.running = True
        
        # Handler pour arrêt propre
        signal.signal(signal.SIGTERM, self.signal_handler)
        signal.signal(signal.SIGINT, self.signal_handler)
    
    def signal_handler(self, signum, frame):
        print(f"Agent {{self.agent_id}} reçu signal {{signum}}, arrêt en cours...")
        self.running = False
    
    def log(self, message):
        timestamp = datetime.now().isoformat()
        print(f"[{{timestamp}}] {{self.agent_id}}: {{message}}")
    
    def process_command(self, command_data):
        # Simulation du traitement de commande
        command = command_data.get('command', '')
        parameters = command_data.get('parameters', {{}})
        
        self.log(f"Traitement commande: {{command}}")
        
        # Logique de traitement selon le rôle
        if self.config['role'] == 'data_processor':
            return {{
                'status': 'success',
                'result': f'Données traitées: {{command}}',
                'processed_at': datetime.now().isoformat(),
                'parameters': parameters
            }}
        elif self.config['role'] == 'web_scraper':
            return {{
                'status': 'success',
                'result': f'Scraping terminé: {{command}}',
                'scraped_at': datetime.now().isoformat(),
                'parameters': parameters
            }}
        else:
            return {{
                'status': 'success',
                'result': f'Commande exécutée: {{command}}',
                'executed_at': datetime.now().isoformat(),
                'parameters': parameters
            }}
    
    def run(self):
        self.log("Agent subprocess démarré")
        
        while self.running:
            try:
                # Lecture des commandes depuis stdin
                line = sys.stdin.readline()
                if not line:
                    time.sleep(0.1)
                    continue
                
                try:
                    command_data = json.loads(line.strip())
                    
                    if command_data.get('type') == 'command':
                        result = self.process_command(command_data)
                        print(json.dumps(result))
                        sys.stdout.flush()
                    elif command_data.get('type') == 'ping':
                        ping_response = {{'status': 'alive', 'timestamp': datetime.now().isoformat()}}
                        print(json.dumps(ping_response))
                        sys.stdout.flush()
                    elif command_data.get('type') == 'stop':
                        self.log("Commande d'arrêt reçue")
                        break
                        
                except json.JSONDecodeError:
                    self.log(f"Erreur JSON: {{line}}")
                    
            except Exception as e:
                self.log(f"Erreur: {{str(e)}}")
                
        self.log("Agent subprocess arrêté")

if __name__ == "__main__":
    agent_config = {config_str}
    agent = SubprocessAgent("{agent_id}", agent_config)
    agent.run()
"""
        
        # Lancement du subprocess
        try:
            process = subprocess.Popen(
                [sys.executable, '-c', agent_script],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1
            )
            
            config["process"] = process
            self._log_agent(agent_id, f"Subprocess agent {config['name']} démarré (PID: {process.pid})")
            
        except Exception as e:
            raise Exception(f"Erreur lors du lancement du subprocess: {str(e)}")
    
    def _process_command(self, agent_id: str, command_data: Dict[str, Any]) -> Dict[str, Any]:
        """Traite une commande pour un agent thread."""
        command = command_data.get('command', '')
        parameters = command_data.get('parameters', {})
        agent_config = self.agents[agent_id]
        
        # Simulation du traitement selon le rôle
        if agent_config['role'] == 'data_processor':
            # Simulation traitement de données
            time.sleep(0.5)  # Simulation du temps de traitement
            return {
                'status': 'success',
                'result': f'Données traitées: {command}',
                'processed_at': datetime.now().isoformat(),
                'parameters': parameters
            }
        elif agent_config['role'] == 'web_scraper':
            # Simulation scraping web
            time.sleep(1.0)
            return {
                'status': 'success',
                'result': f'Scraping terminé: {command}',
                'scraped_at': datetime.now().isoformat(),
                'parameters': parameters
            }
        else:
            # Traitement générique
            time.sleep(0.2)
            return {
                'status': 'success',
                'result': f'Commande exécutée: {command}',
                'executed_at': datetime.now().isoformat(),
                'parameters': parameters
            }
    
    async def send_command(self, agent_id: str, request: AgentCommandRequest) -> Dict[str, Any]:
        """Envoie une commande à un agent."""
        if agent_id not in self.agents:
            raise HTTPException(status_code=404, detail="Agent non trouvé")
        
        agent_config = self.agents[agent_id]
        
        if agent_config["status"] in [AgentStatus.STOPPED, AgentStatus.ERROR]:
            raise HTTPException(status_code=400, detail="Agent non disponible")
        
        command_data = {
            'type': 'command',
            'command': request.command,
            'parameters': request.parameters,
            'timeout': request.timeout,
            'timestamp': datetime.now().isoformat()
        }
        
        try:
            if agent_config["agent_type"] == AgentType.THREAD:
                # Envoi via queue pour thread
                self.command_queues[agent_id].put(command_data)
                
                # Attente du résultat
                try:
                    result = self.result_queues[agent_id].get(timeout=request.timeout)
                    self._log_agent(agent_id, f"Commande exécutée: {request.command}")
                    return result
                except queue.Empty:
                    raise HTTPException(status_code=408, detail="Timeout lors de l'exécution")
                    
            elif agent_config["agent_type"] == AgentType.SUBPROCESS:
                # Envoi via stdin pour subprocess
                process = agent_config["process"]
                if process.poll() is not None:
                    raise HTTPException(status_code=400, detail="Subprocess terminé")
                
                process.stdin.write(json.dumps(command_data) + '\n')
                process.stdin.flush()
                
                # Lecture du résultat
                result_line = process.stdout.readline()
                if result_line:
                    result = json.loads(result_line.strip())
                    self._log_agent(agent_id, f"Commande subprocess exécutée: {request.command}")
                    return result
                else:
                    raise HTTPException(status_code=500, detail="Pas de réponse du subprocess")
                    
        except Exception as e:
            agent_config["status"] = AgentStatus.ERROR
            agent_config["error_message"] = str(e)
            self._log_agent(agent_id, f"Erreur lors de l'envoi de commande: {str(e)}")
            raise HTTPException(status_code=500, detail=str(e))
    
    def get_agent_status(self, agent_id: str) -> AgentInfo:
        """Récupère le statut d'un agent."""
        if agent_id not in self.agents:
            raise HTTPException(status_code=404, detail="Agent non trouvé")
        
        agent_config = self.agents[agent_id]
        
        return AgentInfo(
            id=agent_config["id"],
            name=agent_config["name"],
            role=agent_config["role"],
            context=agent_config["context"],
            agent_type=agent_config["agent_type"],
            status=agent_config["status"],
            created_at=agent_config["created_at"],
            last_activity=agent_config["last_activity"],
            parameters=agent_config["parameters"],
            logs=agent_config["logs"],
            results=agent_config["results"],
            error_message=agent_config.get("error_message")
        )
    
    async def delete_agent(self, agent_id: str) -> Dict[str, str]:
        """Supprime proprement un agent."""
        if agent_id not in self.agents:
            raise HTTPException(status_code=404, detail="Agent non trouvé")
        
        agent_config = self.agents[agent_id]
        
        try:
            # Arrêt selon le type
            if agent_config["agent_type"] == AgentType.THREAD:
                agent_config["status"] = AgentStatus.STOPPING
                self._log_agent(agent_id, "Arrêt du thread agent demandé")
                
                # Attendre l'arrêt du thread
                if "thread" in agent_config:
                    thread = agent_config["thread"]
                    thread.join(timeout=5.0)
                    
            elif agent_config["agent_type"] == AgentType.SUBPROCESS:
                if "process" in agent_config:
                    process = agent_config["process"]
                    
                    # Tentative d'arrêt propre
                    try:
                        stop_command = {'type': 'stop', 'timestamp': datetime.now().isoformat()}
                        process.stdin.write(json.dumps(stop_command) + '\n')
                        process.stdin.flush()
                        
                        # Attendre l'arrêt propre
                        try:
                            process.wait(timeout=5.0)
                        except subprocess.TimeoutExpired:
                            # Force l'arrêt
                            process.terminate()
                            try:
                                process.wait(timeout=2.0)
                            except subprocess.TimeoutExpired:
                                process.kill()
                                
                    except Exception:
                        # En cas d'erreur, force l'arrêt
                        process.terminate()
                        
                    self._log_agent(agent_id, f"Subprocess agent arrêté (PID: {process.pid})")
            
            # Nettoyage
            self._cleanup_agent(agent_id)
            
            return {"message": f"Agent {agent_id} supprimé avec succès"}
            
        except Exception as e:
            self._log_agent(agent_id, f"Erreur lors de la suppression: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Erreur lors de la suppression: {str(e)}")
    
    def list_agents(self) -> List[AgentInfo]:
        """Liste tous les agents."""
        return [self.get_agent_status(agent_id) for agent_id in self.agents.keys()]
    
    def _log_agent(self, agent_id: str, message: str):
        """Ajoute un log à un agent."""
        timestamp = datetime.now().isoformat()
        log_entry = f"[{timestamp}] {message}"
        
        if agent_id in self.agents:
            self.agents[agent_id]["logs"].append(log_entry)
            # Garder seulement les 100 derniers logs
            if len(self.agents[agent_id]["logs"]) > 100:
                self.agents[agent_id]["logs"] = self.agents[agent_id]["logs"][-100:]
        
        logger.info(f"Agent {agent_id}: {message}")
    
    def _check_lifetime_expired(self, agent_id: str) -> bool:
        """Vérifie si la durée de vie d'un agent est expirée."""
        if agent_id not in self.agents:
            return True
        
        agent_config = self.agents[agent_id]
        created_at = agent_config["created_at"]
        max_lifetime = agent_config["max_lifetime"]
        
        elapsed = (datetime.now() - created_at).total_seconds()
        return elapsed > max_lifetime
    
    def _cleanup_agent(self, agent_id: str):
        """Nettoie les ressources d'un agent."""
        if agent_id in self.agents:
            del self.agents[agent_id]
        if agent_id in self.command_queues:
            del self.command_queues[agent_id]
        if agent_id in self.result_queues:
            del self.result_queues[agent_id]
    
    async def cleanup_expired_agents(self):
        """Nettoie les agents expirés."""
        expired_agents = []
        
        for agent_id, agent_config in self.agents.items():
            if self._check_lifetime_expired(agent_id):
                expired_agents.append(agent_id)
        
        for agent_id in expired_agents:
            try:
                await self.delete_agent(agent_id)
                logger.info(f"Agent expiré {agent_id} nettoyé")
            except Exception as e:
                logger.error(f"Erreur lors du nettoyage de l'agent {agent_id}: {str(e)}")

# Gestionnaire global
agent_manager = AgentManager()

# Fonction de nettoyage périodique
async def cleanup_task():
    """Tâche de nettoyage périodique."""
    while True:
        await asyncio.sleep(60)  # Nettoyage toutes les minutes
        await agent_manager.cleanup_expired_agents()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gestionnaire de cycle de vie de l'application."""
    # Démarrage
    cleanup_task_handle = asyncio.create_task(cleanup_task())
    yield
    # Arrêt
    cleanup_task_handle.cancel()
    
    # Nettoyage de tous les agents
    for agent_id in list(agent_manager.agents.keys()):
        try:
            await agent_manager.delete_agent(agent_id)
        except Exception as e:
            logger.error(f"Erreur lors du nettoyage final de l'agent {agent_id}: {str(e)}")

# Application FastAPI
app = FastAPI(
    title="API Gestion Agents Enfants",
    description="API pour gérer la génération et le pilotage dynamique d'agents enfants",
    version="1.0.0",
    lifespan=lifespan
)

@app.get("/", summary="Page d'accueil")
async def root():
    """Page d'accueil de l'API."""
    return {
        "message": "API Gestion Agents Enfants",
        "version": "1.0.0",
        "endpoints": [
            "POST /agents/children - Créer un agent enfant",
            "GET /agents/children - Lister tous les agents",
            "POST /agents/children/{agent_id}/command - Envoyer une commande",
            "GET /agents/children/{agent_id}/status - Récupérer le statut",
            "DELETE /agents/children/{agent_id} - Supprimer un agent"
        ]
    }

@app.post("/agents/children", response_model=Dict[str, str], summary="Créer un agent enfant")
async def create_child_agent(request: AgentCreateRequest):
    """
    Crée un nouvel agent enfant avec un contexte, un rôle et des paramètres spécifiques.
    
    - **name**: Nom de l'agent
    - **role**: Rôle de l'agent (data_processor, web_scraper, etc.)
    - **context**: Contexte d'exécution
    - **agent_type**: Type d'agent (thread ou subprocess)
    - **parameters**: Paramètres spécifiques
    - **max_lifetime**: Durée de vie maximum en secondes
    """
    agent_id = await agent_manager.create_agent(request)
    return {"agent_id": agent_id, "message": "Agent créé avec succès"}

@app.get("/agents/children", response_model=List[AgentInfo], summary="Lister tous les agents")
async def list_child_agents():
    """
    Récupère la liste de tous les agents enfants actifs.
    """
    return agent_manager.list_agents()

@app.post("/agents/children/{agent_id}/command", response_model=Dict[str, Any], summary="Envoyer une commande à un agent")
async def send_command_to_agent(agent_id: str, request: AgentCommandRequest):
    """
    Envoie une commande à un agent enfant actif.
    
    - **agent_id**: ID de l'agent cible
    - **command**: Commande à exécuter
    - **parameters**: Paramètres de la commande
    - **timeout**: Timeout d'exécution en secondes
    """
    return await agent_manager.send_command(agent_id, request)

@app.get("/agents/children/{agent_id}/status", response_model=AgentInfo, summary="Récupérer le statut d'un agent")
async def get_agent_status(agent_id: str):
    """
    Récupère le statut, les logs et les résultats actuels d'un agent enfant.
    
    - **agent_id**: ID de l'agent
    """
    return agent_manager.get_agent_status(agent_id)

@app.delete("/agents/children/{agent_id}", response_model=Dict[str, str], summary="Supprimer un agent")
async def delete_child_agent(agent_id: str):
    """
    Supprime proprement un agent enfant du système.
    
    - **agent_id**: ID de l'agent à supprimer
    """
    return await agent_manager.delete_agent(agent_id)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5001)