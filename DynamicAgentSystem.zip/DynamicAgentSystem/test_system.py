#!/usr/bin/env python3
"""
Test simple pour vérifier que le système fonctionne correctement.
"""

import os
import sys
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def test_imports():
    """Test que tous les imports fonctionnent."""
    try:
        import crewai
        print("✓ CrewAI importé avec succès")
        
        import langchain
        print("✓ LangChain importé avec succès")
        
        import aiohttp
        print("✓ aiohttp importé avec succès")
        
        import requests
        print("✓ requests importé avec succès")
        
        return True
    except ImportError as e:
        print(f"✗ Erreur d'import: {e}")
        return False

def test_configuration():
    """Test que la configuration est correcte."""
    try:
        from config.settings import Settings
        print("✓ Configuration chargée avec succès")
        
        # Test des variables d'environnement
        api_key = os.getenv("OPENROUTER_API_KEY")
        if api_key and api_key != "your-openrouter-api-key-here":
            print("✓ Clé API OpenRouter configurée")
        else:
            print("⚠ Clé API OpenRouter pas encore configurée")
        
        return True
    except Exception as e:
        print(f"✗ Erreur de configuration: {e}")
        return False

def test_llm_client():
    """Test que le client LLM peut être initialisé."""
    try:
        from utils.llm_client import LLMClient
        client = LLMClient()
        print("✓ Client LLM initialisé avec succès")
        
        llm = client.get_llm()
        print("✓ Instance LLM créée avec succès")
        
        return True
    except Exception as e:
        print(f"✗ Erreur du client LLM: {e}")
        return False

def test_agents():
    """Test que les agents peuvent être créés."""
    try:
        from utils.llm_client import LLMClient
        from agents.child_agents import ChildAgentFactory
        
        client = LLMClient()
        factory = ChildAgentFactory(client)
        
        # Test création d'un agent frontend
        agent = factory.create_agent('frontend')
        print("✓ Agent frontend créé avec succès")
        
        return True
    except Exception as e:
        print(f"✗ Erreur création agent: {e}")
        return False

def main():
    """Fonction principale de test."""
    print("=== Test du système multi-agents ===")
    print()
    
    tests = [
        ("Imports", test_imports),
        ("Configuration", test_configuration),
        ("Client LLM", test_llm_client),
        ("Agents", test_agents)
    ]
    
    results = []
    for name, test_func in tests:
        print(f"Test {name}:")
        try:
            result = test_func()
            results.append(result)
        except Exception as e:
            print(f"✗ Erreur inattendue: {e}")
            results.append(False)
        print()
    
    print("=== Résultats ===")
    passed = sum(results)
    total = len(results)
    print(f"Tests réussis: {passed}/{total}")
    
    if passed == total:
        print("✓ Tous les tests sont passés ! Le système est prêt.")
        print("Pour lancer le système complet: python main.py")
    else:
        print("⚠ Certains tests ont échoué. Vérifiez la configuration.")
        
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)