"""
Configuration settings for the multi-agent system.
This module contains all configuration parameters and environment variable handling.
"""

import os
from typing import Dict, Any, List
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Settings:
    """
    Application settings and configuration.
    """
    
    # API Configuration
    OPENROUTER_API_KEY: str = os.getenv("OPENROUTER_API_KEY", "your-api-key-here")
    OPENROUTER_BASE_URL: str = os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")
    OPENROUTER_MODEL: str = os.getenv("OPENROUTER_MODEL", "mistralai/mistral-7b-instruct")
    
    # Agent Configuration
    MAX_CONCURRENT_AGENTS: int = int(os.getenv("MAX_CONCURRENT_AGENTS", "10"))
    AGENT_TIMEOUT: int = int(os.getenv("AGENT_TIMEOUT", "300"))  # seconds
    AGENT_MAX_RETRIES: int = int(os.getenv("AGENT_MAX_RETRIES", "3"))
    
    # Task Configuration
    MAX_TASK_QUEUE_SIZE: int = int(os.getenv("MAX_TASK_QUEUE_SIZE", "100"))
    TASK_TIMEOUT: int = int(os.getenv("TASK_TIMEOUT", "600"))  # seconds
    DEFAULT_TASK_PRIORITY: str = os.getenv("DEFAULT_TASK_PRIORITY", "medium")
    
    # LLM Configuration
    LLM_MAX_TOKENS: int = int(os.getenv("LLM_MAX_TOKENS", "2048"))
    LLM_TEMPERATURE: float = float(os.getenv("LLM_TEMPERATURE", "0.7"))
    LLM_REQUEST_TIMEOUT: int = int(os.getenv("LLM_REQUEST_TIMEOUT", "30"))
    
    # Logging Configuration
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE: str = os.getenv("LOG_FILE", "")
    LOG_MAX_SIZE: int = int(os.getenv("LOG_MAX_SIZE", "10485760"))  # 10MB
    LOG_BACKUP_COUNT: int = int(os.getenv("LOG_BACKUP_COUNT", "5"))
    
    # System Configuration
    SYSTEM_NAME: str = os.getenv("SYSTEM_NAME", "Multi-Agent Task System")
    SYSTEM_VERSION: str = os.getenv("SYSTEM_VERSION", "1.0.0")
    DEBUG_MODE: bool = os.getenv("DEBUG_MODE", "False").lower() == "true"
    
    # Performance Configuration
    ENABLE_PERFORMANCE_MONITORING: bool = os.getenv("ENABLE_PERFORMANCE_MONITORING", "True").lower() == "true"
    PERFORMANCE_LOG_INTERVAL: int = int(os.getenv("PERFORMANCE_LOG_INTERVAL", "60"))  # seconds
    
    # Available Models
    AVAILABLE_MODELS: Dict[str, str] = {
        "mistral-7b": "mistralai/mistral-7b-instruct",
        "mistral-8x7b": "mistralai/mixtral-8x7b-instruct",
        "llama2-70b": "meta-llama/llama-2-70b-chat",
        "llama2-13b": "meta-llama/llama-2-13b-chat",
        "codellama-34b": "codellama/codellama-34b-instruct",
        "yi-34b": "01-ai/yi-34b-chat"
    }
    
    # Agent Types Configuration
    AGENT_TYPES: Dict[str, Dict[str, Any]] = {
        "frontend": {
            "name": "Frontend Developer",
            "description": "Specializes in HTML, CSS, JavaScript, and UI/UX",
            "skills": ["HTML", "CSS", "JavaScript", "React", "Vue.js", "Angular"],
            "max_concurrent_tasks": 3
        },
        "backend": {
            "name": "Backend Developer",
            "description": "Specializes in server-side logic, APIs, and business logic",
            "skills": ["Python", "Node.js", "API Design", "Database Integration"],
            "max_concurrent_tasks": 5
        },
        "database": {
            "name": "Database Specialist",
            "description": "Specializes in database design, optimization, and queries",
            "skills": ["SQL", "NoSQL", "Database Design", "Query Optimization"],
            "max_concurrent_tasks": 3
        },
        "devops": {
            "name": "DevOps Engineer",
            "description": "Specializes in deployment, infrastructure, and operations",
            "skills": ["Docker", "Kubernetes", "CI/CD", "Cloud Platforms"],
            "max_concurrent_tasks": 2
        },
        "testing": {
            "name": "QA Engineer",
            "description": "Specializes in testing, quality assurance, and automation",
            "skills": ["Unit Testing", "Integration Testing", "Test Automation"],
            "max_concurrent_tasks": 4
        }
    }
    
    # Task Types Configuration
    TASK_TYPES: Dict[str, Dict[str, Any]] = {
        "frontend": {
            "estimated_duration": 30,  # minutes
            "complexity": "medium",
            "required_agents": ["frontend"],
            "deliverables": ["HTML", "CSS", "JavaScript"]
        },
        "backend": {
            "estimated_duration": 45,  # minutes
            "complexity": "high",
            "required_agents": ["backend"],
            "deliverables": ["API Code", "Documentation", "Tests"]
        },
        "database": {
            "estimated_duration": 35,  # minutes
            "complexity": "high",
            "required_agents": ["database"],
            "deliverables": ["Schema", "Queries", "Migration Scripts"]
        },
        "fullstack": {
            "estimated_duration": 90,  # minutes
            "complexity": "very_high",
            "required_agents": ["frontend", "backend", "database"],
            "deliverables": ["Complete Application", "Documentation", "Tests"]
        },
        "deployment": {
            "estimated_duration": 40,  # minutes
            "complexity": "high",
            "required_agents": ["devops"],
            "deliverables": ["Deployment Scripts", "Configuration", "Documentation"]
        }
    }
    
    # Security Configuration
    ENABLE_API_KEY_VALIDATION: bool = os.getenv("ENABLE_API_KEY_VALIDATION", "True").lower() == "true"
    ENABLE_REQUEST_LOGGING: bool = os.getenv("ENABLE_REQUEST_LOGGING", "True").lower() == "true"
    ENABLE_RATE_LIMITING: bool = os.getenv("ENABLE_RATE_LIMITING", "False").lower() == "true"
    
    @classmethod
    def validate_configuration(cls) -> List[str]:
        """
        Validate configuration and return any errors.
        
        Returns:
            List of validation errors
        """
        errors = []
        
        # Check required environment variables
        if cls.OPENROUTER_API_KEY == "your-api-key-here":
            errors.append("OPENROUTER_API_KEY is not properly configured")
        
        # Validate numeric values
        if cls.MAX_CONCURRENT_AGENTS <= 0:
            errors.append("MAX_CONCURRENT_AGENTS must be greater than 0")
        
        if cls.AGENT_TIMEOUT <= 0:
            errors.append("AGENT_TIMEOUT must be greater than 0")
        
        if cls.LLM_MAX_TOKENS <= 0:
            errors.append("LLM_MAX_TOKENS must be greater than 0")
        
        if not 0 <= cls.LLM_TEMPERATURE <= 2:
            errors.append("LLM_TEMPERATURE must be between 0 and 2")
        
        # Validate model selection
        if cls.OPENROUTER_MODEL not in cls.AVAILABLE_MODELS.values():
            # Check if it's a valid model name key
            if cls.OPENROUTER_MODEL not in cls.AVAILABLE_MODELS:
                errors.append(f"OPENROUTER_MODEL '{cls.OPENROUTER_MODEL}' is not recognized")
        
        return errors
    
    @classmethod
    def get_agent_config(cls, agent_type: str) -> Dict[str, Any]:
        """
        Get configuration for a specific agent type.
        
        Args:
            agent_type: Type of agent
            
        Returns:
            Agent configuration dictionary
        """
        return cls.AGENT_TYPES.get(agent_type, {})
    
    @classmethod
    def get_task_config(cls, task_type: str) -> Dict[str, Any]:
        """
        Get configuration for a specific task type.
        
        Args:
            task_type: Type of task
            
        Returns:
            Task configuration dictionary
        """
        return cls.TASK_TYPES.get(task_type, {})
    
    @classmethod
    def get_model_name(cls, model_key: str) -> str:
        """
        Get the full model name from a key.
        
        Args:
            model_key: Model key or full name
            
        Returns:
            Full model name
        """
        return cls.AVAILABLE_MODELS.get(model_key, model_key)
    
    @classmethod
    def print_configuration(cls):
        """
        Print current configuration settings.
        """
        print("=" * 50)
        print("MULTI-AGENT SYSTEM CONFIGURATION")
        print("=" * 50)
        
        print(f"System Name: {cls.SYSTEM_NAME}")
        print(f"System Version: {cls.SYSTEM_VERSION}")
        print(f"Debug Mode: {cls.DEBUG_MODE}")
        print(f"Model: {cls.OPENROUTER_MODEL}")
        print(f"Max Concurrent Agents: {cls.MAX_CONCURRENT_AGENTS}")
        print(f"Agent Timeout: {cls.AGENT_TIMEOUT}s")
        print(f"LLM Max Tokens: {cls.LLM_MAX_TOKENS}")
        print(f"LLM Temperature: {cls.LLM_TEMPERATURE}")
        print(f"Log Level: {cls.LOG_LEVEL}")
        
        print("\nAvailable Agent Types:")
        for agent_type, config in cls.AGENT_TYPES.items():
            print(f"  - {agent_type}: {config['name']}")
        
        print("\nAvailable Models:")
        for model_key, model_name in cls.AVAILABLE_MODELS.items():
            print(f"  - {model_key}: {model_name}")
        
        print("=" * 50)
