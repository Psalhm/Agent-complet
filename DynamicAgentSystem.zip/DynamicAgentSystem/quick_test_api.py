#!/usr/bin/env python3
"""
Test rapide de l'API pour vérifier qu'elle fonctionne correctement.
"""

import requests
import json
import time

def test_api():
    base_url = "http://localhost:5001"
    
    print("🧪 Test rapide de l'API Agents Enfants")
    print("=" * 40)
    
    # Test santé
    response = requests.get(f"{base_url}/")
    print(f"✅ API Health: {response.status_code}")
    
    # Test création agent thread
    agent_data = {
        "name": "TestAgent",
        "role": "data_processor",
        "context": "Test context",
        "agent_type": "thread",
        "parameters": {"test": "value"},
        "max_lifetime": 300
    }
    
    response = requests.post(f"{base_url}/agents/children", json=agent_data)
    print(f"✅ Create Thread Agent: {response.status_code}")
    
    if response.status_code == 200:
        agent_id = response.json()["agent_id"]
        print(f"   Agent ID: {agent_id[:8]}...")
        
        # Test commande
        command_data = {
            "command": "test_command",
            "parameters": {"param1": "value1"},
            "timeout": 10
        }
        
        response = requests.post(f"{base_url}/agents/children/{agent_id}/command", json=command_data)
        print(f"✅ Send Command: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print(f"   Result: {result.get('result', 'N/A')}")
        
        # Test statut
        response = requests.get(f"{base_url}/agents/children/{agent_id}/status")
        print(f"✅ Get Status: {response.status_code}")
        
        if response.status_code == 200:
            status = response.json()
            print(f"   Status: {status['status']}")
            print(f"   Logs: {len(status['logs'])}")
        
        # Test suppression
        response = requests.delete(f"{base_url}/agents/children/{agent_id}")
        print(f"✅ Delete Agent: {response.status_code}")
    
    # Test création agent subprocess
    agent_data["agent_type"] = "subprocess"
    agent_data["name"] = "TestSubprocess"
    
    response = requests.post(f"{base_url}/agents/children", json=agent_data)
    print(f"✅ Create Subprocess Agent: {response.status_code}")
    
    if response.status_code == 200:
        agent_id = response.json()["agent_id"]
        print(f"   Agent ID: {agent_id[:8]}...")
        
        # Test commande subprocess
        time.sleep(1)  # Attendre que le subprocess démarre
        
        response = requests.post(f"{base_url}/agents/children/{agent_id}/command", json=command_data)
        print(f"✅ Send Command to Subprocess: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print(f"   Result: {result.get('result', 'N/A')}")
        
        # Test suppression subprocess
        response = requests.delete(f"{base_url}/agents/children/{agent_id}")
        print(f"✅ Delete Subprocess Agent: {response.status_code}")
    
    print("\n✅ Test terminé avec succès!")

if __name__ == "__main__":
    test_api()