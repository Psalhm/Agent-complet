#!/usr/bin/env python3
"""
Test simple pour vérifier les imports un par un.
"""

import sys
import os
from dotenv import load_dotenv

# Charger les variables d'environnement
load_dotenv()

print("=== Test des imports ===")
print()

# Test 1: Imports basiques
print("1. Test des imports basiques...")
try:
    import json
    import asyncio
    import logging
    print("✓ Imports basiques OK")
except Exception as e:
    print(f"✗ Erreur imports basiques: {e}")
    sys.exit(1)

# Test 2: Imports externes
print("2. Test des imports externes...")
try:
    import requests
    print("✓ requests OK")
    
    import aiohttp
    print("✓ aiohttp OK")
    
    from dotenv import load_dotenv
    print("✓ python-dotenv OK")
    
    from pydantic import BaseModel
    print("✓ pydantic OK")
    
except Exception as e:
    print(f"✗ Erreur imports externes: {e}")
    sys.exit(1)

# Test 3: LangChain
print("3. Test LangChain...")
try:
    from langchain.llms.base import LLM
    from langchain.callbacks.manager import CallbackManagerForLLMRun
    print("✓ LangChain OK")
except Exception as e:
    print(f"✗ Erreur LangChain: {e}")
    sys.exit(1)

# Test 4: CrewAI (celui qui pose problème)
print("4. Test CrewAI...")
try:
    import crewai
    print("✓ CrewAI importé")
    
    from crewai import Agent, Crew, Task, Process
    print("✓ CrewAI composants OK")
    
except Exception as e:
    print(f"✗ Erreur CrewAI: {e}")
    print("Ceci est probablement la cause du problème")
    sys.exit(1)

print()
print("✓ Tous les imports fonctionnent correctement !")
print("Le système devrait pouvoir démarrer normalement.")