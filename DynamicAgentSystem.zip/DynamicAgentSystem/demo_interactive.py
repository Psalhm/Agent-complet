#!/usr/bin/env python3
"""
Démonstration interactive du système multi-agents.
Permet de tester le système avec des tâches personnalisées.
"""

import asyncio
import logging
import os
from dotenv import load_dotenv

from agents.simple_agents import SimpleAgentManager
from utils.logger import setup_logging

# Charger les variables d'environnement
load_dotenv()

async def demo_simple_task():
    """
    Démonstration avec une tâche simple.
    """
    print("🎯 Test avec une tâche simple")
    print("-" * 40)
    
    # Tâche simple pour tester
    simple_task = """
    Créez une page web simple avec :
    - Un titre "Bonjour le monde"
    - Un paragraphe expliquant ce qu'est cette page
    - Un bouton qui affiche une alerte
    """
    
    agent_manager = SimpleAgentManager()
    
    print(f"📋 Tâche : {simple_task.strip()}")
    print("\n🚀 Exécution en cours...")
    
    result = await agent_manager.execute_task(simple_task)
    
    if result['status'] == 'completed':
        print("✅ Tâche terminée avec succès !")
        print(f"⏱️ Temps : {result['execution_time']:.2f}s")
        print(f"🤖 Agents : {', '.join(result['agents_used'])}")
        
        for res in result['results']:
            if res['status'] == 'completed':
                print(f"\n📝 Résultat ({res['agent_type']}) :")
                print(res['result'][:500] + "..." if len(res['result']) > 500 else res['result'])
    else:
        print(f"❌ Erreur : {result.get('error', 'Erreur inconnue')}")

async def demo_multi_agent_task():
    """
    Démonstration avec une tâche multi-agents.
    """
    print("\n🎯 Test avec une tâche multi-agents")
    print("-" * 40)
    
    # Tâche nécessitant plusieurs agents
    multi_task = """
    Créez un système de gestion de tâches simple avec :
    - Une page web pour afficher les tâches
    - Une API pour créer/lire/modifier/supprimer des tâches
    - Une base de données pour stocker les tâches
    """
    
    agent_manager = SimpleAgentManager()
    
    print(f"📋 Tâche : {multi_task.strip()}")
    print("\n🚀 Exécution en cours...")
    
    result = await agent_manager.execute_task(multi_task)
    
    if result['status'] == 'completed':
        print("✅ Tâche terminée avec succès !")
        print(f"⏱️ Temps : {result['execution_time']:.2f}s")
        print(f"🤖 Agents : {', '.join(result['agents_used'])}")
        
        for res in result['results']:
            if res['status'] == 'completed':
                print(f"\n📝 Résultat ({res['agent_type']}) :")
                print(res['result'][:400] + "..." if len(res['result']) > 400 else res['result'])
    else:
        print(f"❌ Erreur : {result.get('error', 'Erreur inconnue')}")

async def demo_custom_task():
    """
    Démonstration avec une tâche personnalisée.
    """
    print("\n🎯 Test avec une tâche personnalisée")
    print("-" * 40)
    
    # Demander à l'utilisateur une tâche personnalisée
    custom_task = input("📝 Entrez votre tâche personnalisée : ")
    
    if not custom_task.strip():
        print("❌ Aucune tâche saisie")
        return
    
    agent_manager = SimpleAgentManager()
    
    print(f"\n📋 Tâche : {custom_task}")
    print("\n🚀 Exécution en cours...")
    
    result = await agent_manager.execute_task(custom_task)
    
    if result['status'] == 'completed':
        print("✅ Tâche terminée avec succès !")
        print(f"⏱️ Temps : {result['execution_time']:.2f}s")
        print(f"🤖 Agents : {', '.join(result['agents_used'])}")
        
        for res in result['results']:
            if res['status'] == 'completed':
                print(f"\n📝 Résultat ({res['agent_type']}) :")
                print(res['result'][:600] + "..." if len(res['result']) > 600 else res['result'])
    else:
        print(f"❌ Erreur : {result.get('error', 'Erreur inconnue')}")

async def main():
    """
    Fonction principale de démonstration.
    """
    # Configuration des logs
    setup_logging()
    logger = logging.getLogger(__name__)
    
    print("🤖 Système Multi-Agents - Démonstration Interactive")
    print("=" * 60)
    
    # Vérifier la clé API
    if not os.getenv("OPENROUTER_API_KEY") or os.getenv("OPENROUTER_API_KEY") == "your-openrouter-api-key-here":
        print("❌ Clé API OpenRouter non configurée")
        print("📝 Veuillez configurer OPENROUTER_API_KEY dans le fichier .env")
        print("🔗 Obtenez une clé sur : https://openrouter.ai/")
        return
    
    try:
        # Menu de sélection
        print("\nChoisissez une démonstration :")
        print("1. Tâche simple (page web)")
        print("2. Tâche multi-agents (système complet)")
        print("3. Tâche personnalisée")
        print("4. Quitter")
        
        while True:
            choice = input("\n🎯 Votre choix (1-4) : ").strip()
            
            if choice == '1':
                await demo_simple_task()
                break
            elif choice == '2':
                await demo_multi_agent_task()
                break
            elif choice == '3':
                await demo_custom_task()
                break
            elif choice == '4':
                print("👋 Au revoir !")
                break
            else:
                print("❌ Choix invalide, veuillez choisir 1, 2, 3 ou 4")
        
    except KeyboardInterrupt:
        print("\n\n👋 Démonstration interrompue par l'utilisateur")
    except Exception as e:
        logger.error(f"Erreur lors de la démonstration : {e}")
        print(f"❌ Erreur : {e}")

if __name__ == "__main__":
    asyncio.run(main())