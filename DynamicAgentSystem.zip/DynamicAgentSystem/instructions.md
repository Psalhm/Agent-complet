# Instructions pour lancer le système multi-agents

## 1. Configuration initiale

### Étape 1 : Créer le fichier .env
```bash
cp .env.example .env
```

### Étape 2 : Configurer votre clé API OpenRouter
1. Allez sur https://openrouter.ai/
2. Créez un compte si vous n'en avez pas
3. Générez une clé API dans la section "API Keys"
4. Éditez le fichier `.env` et remplacez `your-openrouter-api-key-here` par votre vraie clé

### Étape 3 : (Optionnel) Choisir un modèle
Dans le fichier `.env`, vous pouvez changer le modèle utilisé :
- `mistralai/mistral-7b-instruct` (par défaut)
- `mistralai/mixtral-8x7b-instruct`
- `meta-llama/llama-2-70b-chat`
- `meta-llama/llama-2-13b-chat`
- `codellama/codellama-34b-instruct`

## 2. Lancement du système

### Méthode simple :
```bash
python main.py
```

### Méthode avec logs détaillés :
```bash
LOG_LEVEL=DEBUG python main.py
```

## 3. Ce qui se passe au lancement

Le système va :
1. Initialiser l'agent principal
2. Démontrer le système avec des exemples de tâches :
   - Création d'une page HTML
   - Création d'un schéma SQL
   - Création d'endpoints API
3. Afficher les statistiques des agents
4. Nettoyer automatiquement les agents

## 4. Structure du projet

```
├── agents/              # Agents principaux et enfants
│   ├── main_agent.py    # Agent orchestrateur principal
│   └── child_agents.py  # Factory pour créer des agents spécialisés
├── tasks/               # Gestion des tâches
│   ├── task_manager.py  # Gestionnaire de cycle de vie des tâches
│   └── example_tasks.py # Exemples de tâches prédéfinies
├── utils/               # Utilitaires
│   ├── llm_client.py    # Client pour OpenRouter
│   └── logger.py        # Configuration des logs
├── config/              # Configuration
│   └── settings.py      # Paramètres du système
├── main.py              # Point d'entrée principal
├── .env.example         # Exemple de configuration
└── README.md            # Documentation
```

## 5. Types d'agents disponibles

- **Frontend** : HTML, CSS, JavaScript, UI/UX
- **Backend** : APIs, logique serveur, logique métier
- **Database** : Schémas SQL, requêtes, modélisation de données
- **DevOps** : Déploiement, infrastructure, conteneurisation
- **Testing** : Suites de tests, QA, automatisation

## 6. Personnalisation

### Changer le modèle :
```bash
export OPENROUTER_MODEL="mistralai/mixtral-8x7b-instruct"
python main.py
```

### Ajuster les paramètres :
Modifiez les variables dans `.env` :
- `MAX_CONCURRENT_AGENTS` : Nombre max d'agents simultanés
- `LLM_TEMPERATURE` : Créativité des réponses (0.0-1.0)
- `LLM_MAX_TOKENS` : Longueur maximale des réponses

## 7. Dépannage

### Erreur "OPENROUTER_API_KEY not found"
- Vérifiez que le fichier `.env` existe
- Vérifiez que la clé API est bien configurée dans `.env`

### Erreur de connexion
- Vérifiez votre connexion internet
- Vérifiez que votre clé API OpenRouter est valide

### Erreur de modèle
- Vérifiez que le modèle spécifié existe sur OpenRouter
- Essayez avec le modèle par défaut `mistralai/mistral-7b-instruct`

## 8. Exemples d'utilisation

Le système inclut des exemples prêts à l'emploi :
- Création de pages web complètes
- Génération de schémas de base de données
- Création d'APIs REST
- Configuration de déploiement
- Suites de tests complètes

Ces exemples s'exécutent automatiquement au lancement pour démontrer les capacités du système.