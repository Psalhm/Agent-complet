"""
Test suite for Feedback Loop API
"""

import pytest
import json
from fastapi.testclient import TestClient
from feedback_api import app
import os
import tempfile

# Create test client
client = TestClient(app)

# Test data
test_agent_id = "test_agent_001"
test_task_id = "test_task_001"

class TestFeedbackAPI:
    
    def test_health_check(self):
        """Test health check endpoint"""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert "timestamp" in data
    
    def test_root_endpoint(self):
        """Test root endpoint"""
        response = client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Feedback Loop API"
        assert "endpoints" in data
    
    def test_evaluate_feedback_basic(self):
        """Test basic feedback evaluation"""
        payload = {
            "agent_id": test_agent_id,
            "input": "What is the capital of France?",
            "output": "The capital of France is Paris.",
            "expected": "Paris is the capital of France.",
            "method": "autoeval",
            "metrics": ["accuracy", "relevance", "fluency"]
        }
        
        response = client.post("/feedback/evaluate", json=payload)
        assert response.status_code == 200
        
        data = response.json()
        assert data["agent_id"] == test_agent_id
        assert "feedback_id" in data
        assert "overall_score" in data
        assert "detailed_scores" in data
        assert "recommendations" in data
        assert isinstance(data["needs_retry"], bool)
        
        # Check that all requested metrics are present
        for metric in payload["metrics"]:
            assert metric in data["detailed_scores"]
    
    def test_evaluate_feedback_with_task_id(self):
        """Test feedback evaluation with task ID"""
        payload = {
            "agent_id": test_agent_id,
            "input": "Explain quantum computing",
            "output": "Quantum computing uses qubits.",
            "method": "rules",
            "metrics": ["accuracy", "completeness"],
            "task_id": test_task_id
        }
        
        response = client.post("/feedback/evaluate", json=payload)
        assert response.status_code == 200
        
        data = response.json()
        assert data["task_id"] == test_task_id
        assert data["agent_id"] == test_agent_id
    
    def test_evaluate_feedback_poor_quality(self):
        """Test feedback evaluation with poor quality output"""
        payload = {
            "agent_id": test_agent_id,
            "input": "What is machine learning?",
            "output": "ML.",  # Very short, poor quality response
            "method": "autoeval",
            "metrics": ["accuracy", "relevance", "fluency", "completeness"]
        }
        
        response = client.post("/feedback/evaluate", json=payload)
        assert response.status_code == 200
        
        data = response.json()
        assert data["needs_retry"] == True
        assert data["status"] == "retry_needed"
        assert len(data["recommendations"]) > 0
    
    def test_retry_task(self):
        """Test task retry functionality"""
        # First create a task that needs retry
        eval_payload = {
            "agent_id": test_agent_id,
            "input": "Explain AI ethics",
            "output": "Ethics good.",
            "method": "autoeval",
            "metrics": ["accuracy", "completeness"],
            "task_id": "retry_test_task"
        }
        
        eval_response = client.post("/feedback/evaluate", json=eval_payload)
        assert eval_response.status_code == 200
        
        # Now retry the task
        retry_payload = {
            "agent_id": test_agent_id,
            "task_id": "retry_test_task",
            "strategy": "modify_prompt",
            "last_attempt": {
                "prompt": "Explain AI ethics",
                "response": "Ethics good.",
                "error": "Response too short and incomplete"
            }
        }
        
        response = client.post("/feedback/retry", json=retry_payload)
        assert response.status_code == 200
        
        data = response.json()
        assert data["agent_id"] == test_agent_id
        assert data["task_id"] == "retry_test_task"
        assert data["attempt_number"] == 2
        assert data["strategy_applied"] == "modify_prompt"
        assert "corrected_prompt" in data
        assert "retry_id" in data
    
    def test_retry_nonexistent_task(self):
        """Test retry for non-existent task"""
        retry_payload = {
            "agent_id": test_agent_id,
            "task_id": "nonexistent_task",
            "strategy": "modify_prompt",
            "last_attempt": {
                "prompt": "Test",
                "response": "Test response",
                "error": "Test error"
            }
        }
        
        response = client.post("/feedback/retry", json=retry_payload)
        assert response.status_code == 404
        assert "Task not found" in response.json()["detail"]
    
    def test_train_agent(self):
        """Test agent training functionality"""
        payload = {
            "agent_id": test_agent_id,
            "prompt": "What is Python?",
            "bad_response": "Python is an animal.",
            "expected_correction": "Python is a programming language.",
            "feedback_type": "user_correction"
        }
        
        response = client.post("/feedback/train", json=payload)
        assert response.status_code == 200
        
        data = response.json()
        assert data["agent_id"] == test_agent_id
        assert data["status"] == "success"
        assert "training_id" in data
    
    def test_feedback_history(self):
        """Test feedback history retrieval"""
        # First create some feedback entries
        for i in range(3):
            payload = {
                "agent_id": test_agent_id,
                "input": f"Test question {i}",
                "output": f"Test answer {i}",
                "method": "autoeval",
                "metrics": ["accuracy", "relevance"]
            }
            client.post("/feedback/evaluate", json=payload)
        
        # Get history
        response = client.get(f"/feedback/history/{test_agent_id}")
        assert response.status_code == 200
        
        data = response.json()
        assert data["agent_id"] == test_agent_id
        assert data["total_feedbacks"] >= 3
        assert "average_score" in data
        assert len(data["feedbacks"]) >= 3
        
        # Check feedback structure
        feedback = data["feedbacks"][0]
        assert "id" in feedback
        assert "input" in feedback
        assert "output" in feedback
        assert "overall_score" in feedback
        assert "status" in feedback
        assert "created_at" in feedback
    
    def test_feedback_history_with_limit(self):
        """Test feedback history with limit parameter"""
        response = client.get(f"/feedback/history/{test_agent_id}?limit=2")
        assert response.status_code == 200
        
        data = response.json()
        assert len(data["feedbacks"]) <= 2
    
    def test_task_status(self):
        """Test task status retrieval"""
        # Create a task first
        task_id = "status_test_task"
        eval_payload = {
            "agent_id": test_agent_id,
            "input": "Test status",
            "output": "Test response",
            "method": "autoeval",
            "metrics": ["accuracy"],
            "task_id": task_id
        }
        
        eval_response = client.post("/feedback/evaluate", json=eval_payload)
        assert eval_response.status_code == 200
        
        # Get task status
        response = client.get(f"/feedback/status/{task_id}")
        assert response.status_code == 200
        
        data = response.json()
        assert data["task_id"] == task_id
        assert data["agent_id"] == test_agent_id
        assert data["status"] in ["completed", "retrying", "in_progress", "failed"]
        assert "current_attempt" in data
        assert "max_attempts" in data
        assert "history" in data
    
    def test_task_status_nonexistent(self):
        """Test task status for non-existent task"""
        response = client.get("/feedback/status/nonexistent_task")
        assert response.status_code == 404
        assert "Task not found" in response.json()["detail"]
    
    def test_evaluation_methods(self):
        """Test different evaluation methods"""
        methods = ["llm", "rules", "autoeval"]
        
        for method in methods:
            payload = {
                "agent_id": test_agent_id,
                "input": "Test input",
                "output": "Test output",
                "method": method,
                "metrics": ["accuracy", "relevance"]
            }
            
            response = client.post("/feedback/evaluate", json=payload)
            assert response.status_code == 200
            
            data = response.json()
            assert "overall_score" in data
            assert "detailed_scores" in data
    
    def test_retry_strategies(self):
        """Test different retry strategies"""
        strategies = ["modify_prompt", "change_parameters", "add_context", "simplify_task"]
        
        for i, strategy in enumerate(strategies):
            # Create a task that needs retry
            task_id = f"strategy_test_{i}"
            eval_payload = {
                "agent_id": test_agent_id,
                "input": f"Test {strategy}",
                "output": "Short",
                "method": "autoeval",
                "metrics": ["completeness"],
                "task_id": task_id
            }
            
            client.post("/feedback/evaluate", json=eval_payload)
            
            # Test retry with strategy
            retry_payload = {
                "agent_id": test_agent_id,
                "task_id": task_id,
                "strategy": strategy,
                "last_attempt": {
                    "prompt": f"Test {strategy}",
                    "response": "Short",
                    "error": "Too short"
                }
            }
            
            response = client.post("/feedback/retry", json=retry_payload)
            assert response.status_code == 200
            
            data = response.json()
            assert data["strategy_applied"] == strategy
    
    def test_invalid_payload(self):
        """Test API with invalid payloads"""
        # Missing required fields
        invalid_payload = {
            "agent_id": test_agent_id,
            "input": "Test"
            # Missing output field
        }
        
        response = client.post("/feedback/evaluate", json=invalid_payload)
        assert response.status_code == 422  # Validation error
    
    def test_edge_cases(self):
        """Test edge cases"""
        # Empty strings
        payload = {
            "agent_id": test_agent_id,
            "input": "",
            "output": "",
            "method": "autoeval",
            "metrics": ["accuracy"]
        }
        
        response = client.post("/feedback/evaluate", json=payload)
        assert response.status_code == 200
        
        # Very long input/output
        long_text = "a" * 1000
        payload = {
            "agent_id": test_agent_id,
            "input": long_text,
            "output": long_text,
            "method": "autoeval",
            "metrics": ["fluency"]
        }
        
        response = client.post("/feedback/evaluate", json=payload)
        assert response.status_code == 200

# Run tests
if __name__ == "__main__":
    pytest.main([__file__, "-v"])