import logging
import time
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from models import (
    EvaluationSession, EvaluationStatus, RetryAttempt, 
    Agent, Correction, CorrectionStatus, db
)
from config import Config
from evaluation_engine import EvaluationEngine
from correction_engine import CorrectionEngine

class RetryController:
    """Controller for managing retry attempts with exponential backoff"""
    
    def __init__(self):
        self.config = Config()
        self.evaluation_engine = EvaluationEngine()
        self.correction_engine = CorrectionEngine()
        self.logger = logging.getLogger(__name__)
    
    def initiate_retry_cycle(self, session_id: int) -> Dict:
        """
        Initiate a complete retry cycle for a session
        
        Args:
            session_id: ID of the evaluation session
            
        Returns:
            Dictionary containing retry cycle results
        """
        try:
            session = EvaluationSession.query.get(session_id)
            if not session:
                raise ValueError(f"Session {session_id} not found")
            
            # Check if retry limit reached
            if session.retry_count >= session.max_retries:
                session.status = EvaluationStatus.RETRY_LIMIT_REACHED
                db.session.commit()
                return {
                    'success': False,
                    'reason': 'retry_limit_reached',
                    'retry_count': session.retry_count,
                    'max_retries': session.max_retries
                }
            
            # Generate corrections if not already done
            corrections = self.correction_engine.get_correction_suggestions(session_id)
            if not corrections:
                self.correction_engine.generate_corrections(session_id)
                corrections = self.correction_engine.get_correction_suggestions(session_id)
            
            # Select high-priority corrections to apply
            high_priority_corrections = [
                c for c in corrections 
                if c['priority'] >= 2 and c['status'] == 'pending'
            ]
            
            if not high_priority_corrections:
                # No high-priority corrections available
                session.status = EvaluationStatus.FAILED
                db.session.commit()
                return {
                    'success': False,
                    'reason': 'no_corrections_available',
                    'available_corrections': len(corrections)
                }
            
            # Apply corrections
            correction_ids = [c['id'] for c in high_priority_corrections[:3]]  # Limit to top 3
            correction_result = self.correction_engine.apply_corrections(
                session_id, correction_ids
            )
            
            # Execute retry attempt
            retry_result = self._execute_retry_attempt(
                session, correction_result['modified_input'], correction_ids
            )
            
            return retry_result
            
        except Exception as e:
            self.logger.error(f"Error in initiate_retry_cycle: {str(e)}")
            return {
                'success': False,
                'reason': 'error',
                'error': str(e)
            }
    
    def _execute_retry_attempt(self, session: EvaluationSession, 
                             modified_input: str, applied_corrections: List[int]) -> Dict:
        """
        Execute a single retry attempt
        
        Args:
            session: The evaluation session
            modified_input: Modified input with corrections applied
            applied_corrections: List of correction IDs applied
            
        Returns:
            Dictionary containing retry attempt results
        """
        try:
            # Simulate agent execution (in real implementation, this would call the actual agent)
            agent_output = self._simulate_agent_execution(
                session.agent, modified_input, session.retry_count
            )
            
            # Record retry attempt
            retry_attempt = RetryAttempt(
                session_id=session.id,
                attempt_number=session.retry_count + 1,
                input_used=modified_input,
                output_received=agent_output,
                corrections_applied=applied_corrections
            )
            db.session.add(retry_attempt)
            
            # Update session retry count
            session.retry_count += 1
            
            # Evaluate the new output
            evaluation_results = self.evaluation_engine.evaluate_output(
                session.id, modified_input, agent_output
            )
            
            # Check if improvement achieved
            if evaluation_results['overall_score'] >= self.config.SCORE_THRESHOLDS['acceptable']:
                session.status = EvaluationStatus.CORRECTED
                session.completed_at = datetime.utcnow()
                
                result = {
                    'success': True,
                    'improved': True,
                    'new_score': evaluation_results['overall_score'],
                    'retry_count': session.retry_count,
                    'agent_output': agent_output
                }
            else:
                # Check if we should continue retrying
                if session.retry_count >= session.max_retries:
                    session.status = EvaluationStatus.RETRY_LIMIT_REACHED
                    session.completed_at = datetime.utcnow()
                    
                    result = {
                        'success': False,
                        'reason': 'retry_limit_reached',
                        'final_score': evaluation_results['overall_score'],
                        'retry_count': session.retry_count
                    }
                else:
                    # Schedule next retry with exponential backoff
                    delay = self._calculate_retry_delay(session.retry_count)
                    result = {
                        'success': False,
                        'reason': 'insufficient_improvement',
                        'current_score': evaluation_results['overall_score'],
                        'retry_count': session.retry_count,
                        'next_retry_delay': delay
                    }
            
            db.session.commit()
            return result
            
        except Exception as e:
            self.logger.error(f"Error in _execute_retry_attempt: {str(e)}")
            db.session.rollback()
            raise
    
    def _simulate_agent_execution(self, agent: Agent, input_text: str, attempt_number: int) -> str:
        """
        Simulate agent execution (placeholder for actual agent integration)
        
        Args:
            agent: The agent to execute
            input_text: Input text for the agent
            attempt_number: Current attempt number
            
        Returns:
            Simulated agent output
        """
        # In a real implementation, this would:
        # 1. Call the agent's API endpoint
        # 2. Pass the modified input
        # 3. Return the agent's response
        
        # For now, simulate improved output based on attempt number
        base_output = f"Agent {agent.name} processing: {input_text[:100]}..."
        
        if attempt_number == 0:
            return base_output + " (Initial attempt)"
        else:
            return base_output + f" (Retry attempt {attempt_number} with corrections applied)"
    
    def _calculate_retry_delay(self, retry_count: int) -> int:
        """
        Calculate delay for next retry using exponential backoff
        
        Args:
            retry_count: Current retry count
            
        Returns:
            Delay in seconds
        """
        if retry_count >= len(self.config.RETRY_DELAYS):
            return self.config.RETRY_DELAYS[-1]
        
        return self.config.RETRY_DELAYS[retry_count]
    
    def schedule_retry(self, session_id: int, delay_seconds: int) -> Dict:
        """
        Schedule a retry attempt after specified delay
        
        Args:
            session_id: ID of the evaluation session
            delay_seconds: Delay in seconds before retry
            
        Returns:
            Dictionary containing scheduling results
        """
        try:
            # For now, we'll use a simple immediate retry instead of scheduling
            # This can be extended later if needed
            return {
                'success': True,
                'message': 'Retry scheduled for immediate execution',
                'delay_seconds': delay_seconds
            }
            
        except Exception as e:
            self.logger.error(f"Error scheduling retry: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    

    
    def get_retry_status(self, session_id: int) -> Dict:
        """
        Get retry status for a session
        
        Args:
            session_id: ID of the evaluation session
            
        Returns:
            Dictionary containing retry status
        """
        try:
            session = EvaluationSession.query.get(session_id)
            if not session:
                return {'error': 'Session not found'}
            
            retry_attempts = RetryAttempt.query.filter_by(
                session_id=session_id
            ).order_by(RetryAttempt.attempt_number.desc()).all()
            
            return {
                'session_id': session_id,
                'status': session.status.value,
                'retry_count': session.retry_count,
                'max_retries': session.max_retries,
                'can_retry': session.retry_count < session.max_retries,
                'retry_attempts': [
                    {
                        'attempt_number': attempt.attempt_number,
                        'created_at': attempt.created_at.isoformat(),
                        'corrections_applied': attempt.corrections_applied,
                        'input_length': len(attempt.input_used),
                        'output_length': len(attempt.output_received)
                    }
                    for attempt in retry_attempts
                ]
            }
            
        except Exception as e:
            self.logger.error(f"Error getting retry status: {str(e)}")
            return {'error': str(e)}
    
    def cancel_scheduled_retries(self, session_id: int) -> Dict:
        """
        Cancel any scheduled retries for a session
        
        Args:
            session_id: ID of the evaluation session
            
        Returns:
            Dictionary containing cancellation results
        """
        try:
            # For now, we'll just return success since we don't have a scheduler
            return {
                'success': True,
                'message': 'No scheduled job to cancel'
            }
                
        except Exception as e:
            self.logger.error(f"Error cancelling scheduled retries: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
