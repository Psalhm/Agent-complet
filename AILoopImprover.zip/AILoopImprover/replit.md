# AI Agent Evaluation System

## Overview

This is a Flask-based web application designed to evaluate AI agent outputs across multiple criteria. The system provides a comprehensive evaluation framework with automatic retry mechanisms, correction suggestions, and detailed reporting dashboards.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (Latest)

### 2025-07-09 - Final Code Verification and Corrections
- **Fixed Missing Template**: Created `templates/agent_form.html` for agent creation/editing
- **Fixed JavaScript Error**: Added error handling fallback in `static/js/dashboard.js` 
- **Fixed Data Structure**: Added missing fields in `evaluation_engine.py` error handling
- **Test Verification**: Confirmed all 16 FastAPI tests passing (100% success rate)
- **API Endpoints**: Verified all main API endpoints functioning correctly
- **Database**: PostgreSQL and SQLite systems both operational
- **Secret Status**: SESSION_SECRET configured, OPENROUTER_API_KEY needed for AI evaluation

## System Architecture

### Backend Architecture
- **Framework**: Flask web application with SQLAlchemy ORM + FastAPI Feedback Loop API
- **Database**: SQLite (default) with support for PostgreSQL via environment variables
- **Simple Processing**: Direct execution without complex background scheduling
- **AI Integration**: OpenRouter with open source models (Llama 2, Falcon, etc.) for evaluation and correction generation
- **FastAPI Module**: Autonomous feedback loop with SQLite storage for evaluation, retry, and training data

### Frontend Architecture
- **Template Engine**: Jinja2 templates with Bootstrap 5 (dark theme)
- **JavaScript**: Vanilla JavaScript with Chart.js for data visualization
- **Styling**: Custom CSS with Bootstrap components and Feather icons

### Database Schema
The system uses SQLAlchemy models with the following core entities:
- **Agent**: Represents AI agents being evaluated
- **EvaluationSession**: Groups multiple evaluations for a single agent output
- **Evaluation**: Individual criterion-based evaluations
- **Correction**: AI-generated suggestions for improvement
- **RetryAttempt**: Tracks retry attempts with exponential backoff

## Key Components

### Evaluation Engine (`evaluation_engine.py`)
- Evaluates AI outputs across 5 criteria: relevance, completeness, accuracy, coherence, and safety
- Integrates with OpenAI GPT-4o for intelligent scoring
- Provides confidence scores and detailed feedback
- Supports weighted scoring based on configurable criteria weights

### FastAPI Feedback Loop (`feedback_api.py`)
- Autonomous feedback system with evaluation, retry, and training capabilities
- 5 main endpoints: evaluate, retry, train, history, status
- SQLite database for independent data storage
- DummyEvaluator with rule-based scoring for demonstration
- Comprehensive test suite with 16 test cases

### Correction Engine (`correction_engine.py`)
- Generates improvement suggestions based on evaluation results
- Creates actionable correction recommendations
- Tracks correction application status
- Provides detailed explanations for suggested changes

### Retry Controller (`retry_controller.py`)
- Manages retry attempts with exponential backoff
- Enforces retry limits and timeout policies
- Coordinates between evaluation and correction engines
- Handles session state management during retries

### API Routes (`api_routes.py`)
- RESTful API endpoints for agent management
- Session creation and monitoring endpoints
- Evaluation and correction result access
- System metrics and monitoring APIs

### Web Routes (`routes.py`)
- Dashboard for system overview and metrics
- Session management and detailed views
- Agent configuration and monitoring
- Administrative functions and controls

### FastAPI Routes (`feedback_api.py`)
- POST /feedback/evaluate: Multi-criteria agent evaluation
- POST /feedback/retry: Intelligent retry with correction strategies
- POST /feedback/train: Training data collection for improvement
- GET /feedback/history/{agent_id}: Agent performance history
- GET /feedback/status/{task_id}: Task lifecycle tracking

## Data Flow

1. **Agent Registration**: AI agents register via API with name, description, and endpoint
2. **Session Creation**: New evaluation sessions created with original input/output pairs
3. **Evaluation Process**: Multiple criteria evaluated simultaneously using OpenAI
4. **Scoring & Feedback**: Weighted scores calculated with detailed feedback generation
5. **Correction Generation**: AI-generated improvement suggestions based on evaluation results
6. **Retry Management**: Automatic retry with exponential backoff for failed evaluations
7. **Reporting**: Real-time dashboard updates with session status and metrics

## External Dependencies

### OpenRouter Integration
- **Models**: Llama 2 70B (primary), Falcon 7B, MPT, GPT4All (fallback)
- **API Key**: Required via `OPENROUTER_API_KEY` environment variable
- **Usage**: Evaluation scoring and correction generation with open source models
- **Timeout**: 60 seconds for evaluation, 30 seconds for corrections

### Third-Party Libraries
- **Flask**: Web framework with SQLAlchemy ORM
- **FastAPI**: Modern API framework with automatic documentation
- **APScheduler**: Background task scheduling
- **Chart.js**: Frontend data visualization
- **Bootstrap 5**: UI framework with dark theme
- **Feather Icons**: Icon library for consistent UI
- **Uvicorn**: ASGI server for FastAPI
- **Pydantic**: Data validation and serialization

## Deployment Strategy

### Environment Configuration
- **Database**: Configurable via `DATABASE_URL` environment variable
- **Session Secret**: Required via `SESSION_SECRET` environment variable
- **OpenRouter API Key**: Required via `OPENROUTER_API_KEY` environment variable

### Database Migration
- Automatic table creation on application startup
- SQLAlchemy model-based schema management
- Support for SQLite (development) and PostgreSQL (production)

### Scaling Considerations
- Direct execution for immediate response
- Configurable rate limiting (100 requests per minute)
- Connection pooling with pre-ping health checks
- Simple retry mechanism without complex scheduling

### Monitoring & Logging
- Comprehensive logging throughout application
- Real-time dashboard with manual refresh capabilities
- Error tracking and retry attempt monitoring

The system is designed to be deployed on Replit with minimal configuration, requiring only the OpenRouter API key to be set. The database will automatically initialize, and the web interface will be accessible immediately upon deployment.