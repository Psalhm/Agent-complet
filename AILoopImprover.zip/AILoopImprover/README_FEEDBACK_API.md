# Feedback Loop API

## Vue d'ensemble

L'API Feedback Loop est une brique autonome pour votre système multi-agents qui permet l'évaluation, la correction, et l'amélioration automatique des réponses d'agents IA. Elle fournit un cycle de feedback complet sans supervision humaine.

## Fonctionnalités principales

### 🔍 Évaluation automatique
- Évaluation selon multiples critères (accuracy, relevance, fluency, completeness, coherence)
- Méthodes d'évaluation: LLM, règles, auto-évaluation
- Scores détaillés et recommandations d'amélioration

### 🔄 Système de retry intelligent
- Stratégies de correction automatique
- Backoff exponentiel avec limites configurables
- Suivi des tentatives et historique

### 📚 Apprentissage adaptatif
- Stockage des corrections utilisateur
- Amélioration continue basée sur les feedbacks
- Historique d'apprentissage par agent

### 📊 Suivi et métriques
- Historique complet des évaluations
- Statut des tâches en temps réel
- Métriques de performance par agent

## Architecture

### Structure des fichiers
```
feedback_api.py          # API FastAPI principale
fastapi_main.py         # Point d'entrée
test_feedback_api.py    # Suite de tests
feedback_api_examples.py # Exemples d'utilisation
feedback_system.db      # Base SQLite (créée automatiquement)
```

### Base de données
- **feedbacks**: Stockage des évaluations
- **retry_attempts**: Historique des tentatives
- **training_data**: Données d'apprentissage
- **task_status**: Statut des tâches

## Installation

```bash
# Installer les dépendances
pip install fastapi uvicorn pydantic

# Démarrer l'API
python -m uvicorn feedback_api:app --host 0.0.0.0 --port 8000 --reload
```

## Endpoints API

### POST /feedback/evaluate
Évalue une réponse d'agent selon plusieurs critères.

**Paramètres:**
```json
{
  "agent_id": "string",
  "input": "string",
  "output": "string", 
  "expected": "string (optionnel)",
  "method": "llm|rules|autoeval",
  "metrics": ["accuracy", "relevance", "fluency"],
  "task_id": "string (optionnel)"
}
```

**Réponse:**
```json
{
  "feedback_id": "uuid",
  "agent_id": "string",
  "task_id": "string",
  "overall_score": 0.85,
  "detailed_scores": {
    "accuracy": 0.9,
    "relevance": 0.8,
    "fluency": 0.85
  },
  "recommendations": ["Improve completeness"],
  "status": "completed|retry_needed",
  "needs_retry": false
}
```

### POST /feedback/retry
Relance une tentative corrigée d'une tâche échouée.

**Paramètres:**
```json
{
  "agent_id": "string",
  "task_id": "string",
  "strategy": "modify_prompt|change_parameters|add_context|simplify_task",
  "last_attempt": {
    "prompt": "string",
    "response": "string",
    "error": "string"
  }
}
```

**Réponse:**
```json
{
  "retry_id": "uuid",
  "agent_id": "string",
  "task_id": "string",
  "attempt_number": 2,
  "corrected_prompt": "string",
  "strategy_applied": "modify_prompt",
  "success": true,
  "new_response": "string"
}
```

### POST /feedback/train
Ajoute des données d'apprentissage basées sur les corrections.

**Paramètres:**
```json
{
  "agent_id": "string",
  "prompt": "string",
  "bad_response": "string",
  "expected_correction": "string",
  "feedback_type": "user_correction"
}
```

### GET /feedback/history/{agent_id}
Récupère l'historique des feedbacks pour un agent.

**Paramètres de requête:**
- `limit`: Nombre maximum d'entrées (défaut: 50)

**Réponse:**
```json
{
  "agent_id": "string",
  "total_feedbacks": 25,
  "average_score": 0.72,
  "feedbacks": [
    {
      "id": "uuid",
      "task_id": "string",
      "input": "string",
      "output": "string",
      "overall_score": 0.8,
      "status": "completed",
      "created_at": "2025-01-01T00:00:00"
    }
  ]
}
```

### GET /feedback/status/{task_id}
Obtient le statut du cycle de feedback pour une tâche.

**Réponse:**
```json
{
  "task_id": "string",
  "agent_id": "string",
  "status": "in_progress|completed|failed|retrying",
  "current_attempt": 2,
  "max_attempts": 3,
  "last_feedback_id": "uuid",
  "history": [
    {
      "retry_id": "uuid",
      "attempt_number": 1,
      "strategy": "modify_prompt",
      "success": false,
      "created_at": "2025-01-01T00:00:00"
    }
  ]
}
```

## Utilisation

### Exemple basique d'évaluation
```python
import requests

# Évaluer une réponse d'agent
payload = {
    "agent_id": "chatbot_001",
    "input": "What is machine learning?",
    "output": "ML is a subset of AI that learns from data.",
    "expected": "Machine learning is a subset of artificial intelligence...",
    "method": "autoeval",
    "metrics": ["accuracy", "relevance", "completeness"]
}

response = requests.post("http://localhost:8000/feedback/evaluate", json=payload)
result = response.json()

print(f"Score: {result['overall_score']}")
print(f"Needs retry: {result['needs_retry']}")
```

### Exemple de cycle complet
```python
# 1. Évaluer
eval_response = requests.post("/feedback/evaluate", json=eval_payload)
task_id = eval_response.json()["task_id"]

# 2. Vérifier le statut
status_response = requests.get(f"/feedback/status/{task_id}")
status = status_response.json()["status"]

# 3. Retry si nécessaire
if status == "retrying":
    retry_payload = {
        "agent_id": "chatbot_001",
        "task_id": task_id,
        "strategy": "modify_prompt",
        "last_attempt": {...}
    }
    retry_response = requests.post("/feedback/retry", json=retry_payload)

# 4. Ajouter des données d'apprentissage
train_payload = {
    "agent_id": "chatbot_001",
    "prompt": "What is ML?",
    "bad_response": "ML is hard.",
    "expected_correction": "Machine learning is a subset of AI..."
}
requests.post("/feedback/train", json=train_payload)
```

## Métriques d'évaluation

### Critères disponibles
- **accuracy**: Exactitude factuelle de la réponse
- **relevance**: Pertinence par rapport à la question
- **fluency**: Qualité linguistique et fluidité
- **completeness**: Complétude de la réponse
- **coherence**: Cohérence logique

### Méthodes d'évaluation
- **autoeval**: Évaluation automatique basée sur des règles
- **rules**: Évaluation selon des règles prédéfinies
- **llm**: Évaluation par modèle de langage (placeholder)

### Seuils de scoring
- **> 0.8**: Excellent
- **0.6-0.8**: Bon
- **0.4-0.6**: Acceptable
- **< 0.4**: Nécessite retry

## Stratégies de retry

### Stratégies disponibles
- **modify_prompt**: Modifie le prompt pour plus de clarté
- **add_context**: Ajoute du contexte supplémentaire
- **simplify_task**: Simplifie la tâche demandée
- **change_parameters**: Modifie les paramètres d'évaluation

### Configuration des retries
- **max_attempts**: 3 tentatives par défaut
- **backoff**: Délai exponentiel entre tentatives
- **timeout**: Timeout configurable par évaluation

## Tests

```bash
# Lancer tous les tests
python -m pytest test_feedback_api.py -v

# Lancer les exemples
python feedback_api_examples.py

# Test de santé
curl http://localhost:8000/health
```

## Intégration avec le système existant

### Avec votre système Flask
```python
from feedback_api import DummyEvaluator
from your_evaluation_engine import EvaluationEngine

# Remplacer l'évaluateur par défaut
evaluator = EvaluationEngine()  # Votre évaluateur existant
```

### Avec votre base de données
```python
# Modifier DATABASE_PATH dans feedback_api.py
DATABASE_PATH = os.environ.get("DATABASE_URL", "feedback_system.db")
```

## Monitoring

### Endpoints de monitoring
- `GET /health`: Vérification de santé
- `GET /`: Informations sur l'API
- `GET /feedback/history/{agent_id}`: Métriques par agent

### Logs
- Évaluations complétées
- Tentatives de retry
- Erreurs d'évaluation
- Données d'apprentissage ajoutées

## Sécurité

### Authentification
- Prêt pour intégration avec votre système de clés API
- Validation des paramètres d'entrée
- Gestion des erreurs sécurisée

### Limites
- Rate limiting (à configurer)
- Validation des taille de payload
- Sanitization des entrées

## Développement

### Ajouter un nouveau critère d'évaluation
```python
def evaluate_new_metric(input_text, output_text, expected=None):
    # Logique d'évaluation
    return score  # 0.0 à 1.0
```

### Ajouter une nouvelle stratégie de retry
```python
def new_retry_strategy(original_prompt, error_message):
    # Logique de correction
    return corrected_prompt
```

## Déploiement

### Production
```bash
# Avec Gunicorn
gunicorn -w 4 -k uvicorn.workers.UvicornWorker feedback_api:app

# Avec Docker
docker run -p 8000:8000 feedback-api
```

### Variables d'environnement
- `DATABASE_URL`: URL de la base de données
- `LOG_LEVEL`: Niveau de logging
- `MAX_RETRIES`: Nombre max de tentatives

## Support

### Dépannage
- Vérifier que l'API est démarrée sur le port 8000
- Vérifier les logs pour les erreurs d'évaluation
- Valider la structure des payloads JSON

### Contribution
- Tests requis pour toute nouvelle fonctionnalité
- Documentation à jour
- Code style Python (PEP 8)

Cette API constitue une brique autonome et réutilisable pour votre système multi-agents, permettant une amélioration continue et automatique des performances.