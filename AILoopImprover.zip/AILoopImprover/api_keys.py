import secrets
import string
import hashlib
import logging
from datetime import datetime, timedelta
from typing import Dict, Optional
from models import db, APIKey
from flask import request

class APIKeyManager:
    """Manager for API key generation and validation"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def generate_api_key(self, name: str, description: str = "", expires_in_days: int = 365) -> Dict:
        """
        Generate a new API key
        
        Args:
            name: Name/identifier for the API key
            description: Optional description
            expires_in_days: Days until expiration (default: 365)
            
        Returns:
            Dictionary containing the API key and metadata
        """
        try:
            # Generate random API key
            alphabet = string.ascii_letters + string.digits
            api_key = 'aies_' + ''.join(secrets.choice(alphabet) for _ in range(40))
            
            # Hash the key for storage
            key_hash = hashlib.sha256(api_key.encode()).hexdigest()
            
            # Calculate expiration date
            expires_at = datetime.utcnow() + timedelta(days=expires_in_days)
            
            # Store in database
            api_key_record = APIKey(
                name=name,
                description=description,
                key_hash=key_hash,
                expires_at=expires_at,
                is_active=True,
                created_at=datetime.utcnow()
            )
            
            db.session.add(api_key_record)
            db.session.commit()
            
            self.logger.info(f"Generated new API key: {name}")
            
            return {
                'success': True,
                'api_key': api_key,
                'key_id': api_key_record.id,
                'name': name,
                'expires_at': expires_at.isoformat(),
                'created_at': api_key_record.created_at.isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error generating API key: {str(e)}")
            db.session.rollback()
            return {
                'success': False,
                'error': str(e)
            }
    
    def validate_api_key(self, api_key: str) -> Dict:
        """
        Validate an API key
        
        Args:
            api_key: The API key to validate
            
        Returns:
            Dictionary with validation result
        """
        try:
            if not api_key or not api_key.startswith('aies_'):
                return {'valid': False, 'reason': 'Invalid key format'}
            
            # Hash the provided key
            key_hash = hashlib.sha256(api_key.encode()).hexdigest()
            
            # Find the key in database
            api_key_record = APIKey.query.filter_by(key_hash=key_hash).first()
            
            if not api_key_record:
                return {'valid': False, 'reason': 'Key not found'}
            
            if not api_key_record.is_active:
                return {'valid': False, 'reason': 'Key is inactive'}
            
            if api_key_record.expires_at < datetime.utcnow():
                return {'valid': False, 'reason': 'Key has expired'}
            
            # Update last used timestamp
            api_key_record.last_used_at = datetime.utcnow()
            api_key_record.usage_count += 1
            db.session.commit()
            
            return {
                'valid': True,
                'key_id': api_key_record.id,
                'name': api_key_record.name,
                'expires_at': api_key_record.expires_at.isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error validating API key: {str(e)}")
            return {'valid': False, 'reason': 'Validation error'}
    
    def revoke_api_key(self, key_id: int) -> Dict:
        """
        Revoke an API key
        
        Args:
            key_id: ID of the API key to revoke
            
        Returns:
            Dictionary with revocation result
        """
        try:
            api_key_record = APIKey.query.get(key_id)
            
            if not api_key_record:
                return {'success': False, 'error': 'Key not found'}
            
            api_key_record.is_active = False
            api_key_record.revoked_at = datetime.utcnow()
            db.session.commit()
            
            self.logger.info(f"Revoked API key: {api_key_record.name}")
            
            return {
                'success': True,
                'message': f'API key {api_key_record.name} revoked successfully'
            }
            
        except Exception as e:
            self.logger.error(f"Error revoking API key: {str(e)}")
            db.session.rollback()
            return {'success': False, 'error': str(e)}
    
    def list_api_keys(self) -> Dict:
        """
        List all API keys
        
        Returns:
            Dictionary with list of API keys
        """
        try:
            api_keys = APIKey.query.order_by(APIKey.created_at.desc()).all()
            
            keys_data = []
            for key in api_keys:
                keys_data.append({
                    'id': key.id,
                    'name': key.name,
                    'description': key.description,
                    'is_active': key.is_active,
                    'created_at': key.created_at.isoformat(),
                    'expires_at': key.expires_at.isoformat(),
                    'last_used_at': key.last_used_at.isoformat() if key.last_used_at else None,
                    'usage_count': key.usage_count
                })
            
            return {
                'success': True,
                'api_keys': keys_data
            }
            
        except Exception as e:
            self.logger.error(f"Error listing API keys: {str(e)}")
            return {'success': False, 'error': str(e)}

def require_api_key(f):
    """Decorator to require API key for endpoint access"""
    def decorated_function(*args, **kwargs):
        api_key = request.headers.get('X-API-Key') or request.args.get('api_key')
        
        if not api_key:
            return {'error': 'API key required'}, 401
        
        api_key_manager = APIKeyManager()
        validation_result = api_key_manager.validate_api_key(api_key)
        
        if not validation_result['valid']:
            return {'error': validation_result['reason']}, 401
        
        # Add key info to request context
        request.api_key_info = validation_result
        
        return f(*args, **kwargs)
    
    decorated_function.__name__ = f.__name__
    return decorated_function