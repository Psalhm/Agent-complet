import json
import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import os
import requests
from models import Evaluation, EvaluationCriteria, EvaluationSession, db
from config import Config

class EvaluationEngine:
    """Core evaluation engine for assessing AI agent outputs"""
    
    def __init__(self):
        self.api_key = os.environ.get("OPENROUTER_API_KEY")
        self.config = Config()
        self.logger = logging.getLogger(__name__)
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        })
    
    def evaluate_output(self, session_id: int, original_input: str, agent_output: str) -> Dict:
        """
        Evaluate an AI agent's output across multiple criteria
        
        Args:
            session_id: ID of the evaluation session
            original_input: The original input to the agent
            agent_output: The agent's output to evaluate
            
        Returns:
            Dictionary containing evaluation results
        """
        try:
            results = {}
            overall_score = 0.0
            
            # Evaluate each criteria
            for criteria in EvaluationCriteria:
                try:
                    evaluation_result = self._evaluate_single_criteria(
                        criteria, original_input, agent_output
                    )
                    
                    # Store evaluation in database
                    evaluation = Evaluation(
                        session_id=session_id,
                        criteria=criteria,
                        score=evaluation_result['score'],
                        confidence=evaluation_result['confidence'],
                        feedback=evaluation_result['feedback'],
                        evaluator_name="OpenRouter-OpenSource",
                        details=evaluation_result
                    )
                    db.session.add(evaluation)
                    
                    results[criteria.value] = evaluation_result
                    
                    # Calculate weighted score
                    weight = self.config.CRITERIA_WEIGHTS.get(criteria.value, 0.2)
                    overall_score += evaluation_result['score'] * weight
                    
                except Exception as e:
                    self.logger.error(f"Error evaluating {criteria.value}: {str(e)}")
                    results[criteria.value] = {
                        'score': 0.0,
                        'confidence': 0.0,
                        'feedback': f"Evaluation failed: {str(e)}",
                        'specific_issues': [],
                        'suggestions': [],
                        'criteria': criteria.value,
                        'error': True
                    }
            
            db.session.commit()
            
            # Compile overall results
            results['overall_score'] = overall_score
            results['recommendation'] = self._get_recommendation(overall_score)
            results['needs_correction'] = overall_score < self.config.SCORE_THRESHOLDS['acceptable']
            
            return results
            
        except Exception as e:
            self.logger.error(f"Error in evaluate_output: {str(e)}")
            db.session.rollback()
            raise
    
    def _evaluate_single_criteria(self, criteria: EvaluationCriteria, 
                                 original_input: str, agent_output: str) -> Dict:
        """
        Evaluate output against a single criteria using OpenAI
        
        Args:
            criteria: The evaluation criteria
            original_input: Original input to the agent
            agent_output: Agent's output to evaluate
            
        Returns:
            Dictionary containing evaluation results
        """
        try:
            if not self.api_key:
                raise Exception("OpenRouter API key not configured")
                
            prompt = self.config.get_evaluation_prompt_template().format(
                criteria=criteria.value,
                input=original_input,
                output=agent_output
            )
            
            # Try primary model first, then fallback models
            models_to_try = [self.config.EVALUATION_MODEL] + self.config.FALLBACK_MODELS
            
            for model in models_to_try:
                try:
                    payload = {
                        "model": model,
                        "messages": [
                            {"role": "system", "content": "You are an expert AI evaluator. Respond with valid JSON only."},
                            {"role": "user", "content": prompt}
                        ],
                        "temperature": 0.3,
                        "max_tokens": 1000
                    }
                    
                    response = self.session.post(
                        f"{self.config.OPENROUTER_BASE_URL}/chat/completions",
                        json=payload,
                        timeout=self.config.EVALUATION_TIMEOUT
                    )
                    
                    if response.status_code == 200:
                        data = response.json()
                        result = json.loads(data["choices"][0]["message"]["content"])
                        
                        # Validate and clean result
                        cleaned_result = {
                            'score': max(0.0, min(1.0, float(result.get('score', 0.0)))),
                            'confidence': max(0.0, min(1.0, float(result.get('confidence', 0.0)))),
                            'feedback': result.get('feedback', ''),
                            'specific_issues': result.get('specific_issues', []),
                            'suggestions': result.get('suggestions', []),
                            'criteria': criteria.value,
                            'model_used': model
                        }
                        
                        return cleaned_result
                    else:
                        self.logger.warning(f"Model {model} returned status {response.status_code}")
                        continue
                        
                except Exception as e:
                    self.logger.warning(f"Failed to use model {model}: {str(e)}")
                    continue
            
            # If all models failed, return default response
            return {
                'score': 0.0,
                'confidence': 0.0,
                'feedback': "All evaluation models failed to respond",
                'specific_issues': [],
                'suggestions': [],
                'criteria': criteria.value,
                'model_used': "none"
            }
            
        except Exception as e:
            self.logger.error(f"Error in _evaluate_single_criteria for {criteria.value}: {str(e)}")
            return {
                'score': 0.0,
                'confidence': 0.0,
                'feedback': f"Evaluation failed: {str(e)}",
                'specific_issues': [],
                'suggestions': [],
                'criteria': criteria.value,
                'error': True
            }
    
    def _get_recommendation(self, score: float) -> str:
        """Get recommendation based on overall score"""
        if score >= self.config.SCORE_THRESHOLDS['excellent']:
            return "Excellent performance - no corrections needed"
        elif score >= self.config.SCORE_THRESHOLDS['good']:
            return "Good performance - minor improvements suggested"
        elif score >= self.config.SCORE_THRESHOLDS['acceptable']:
            return "Acceptable performance - some corrections recommended"
        else:
            return "Poor performance - significant corrections required"
    
    def get_evaluation_summary(self, session_id: int) -> Dict:
        """
        Get a summary of all evaluations for a session
        
        Args:
            session_id: ID of the evaluation session
            
        Returns:
            Dictionary containing evaluation summary
        """
        try:
            evaluations = Evaluation.query.filter_by(session_id=session_id).all()
            
            if not evaluations:
                return {"error": "No evaluations found for session"}
            
            summary = {
                'total_evaluations': len(evaluations),
                'criteria_scores': {},
                'overall_score': 0.0,
                'average_confidence': 0.0,
                'critical_issues': [],
                'suggestions': []
            }
            
            total_confidence = 0.0
            weighted_score = 0.0
            
            for evaluation in evaluations:
                criteria_name = evaluation.criteria.value
                summary['criteria_scores'][criteria_name] = {
                    'score': evaluation.score,
                    'confidence': evaluation.confidence,
                    'feedback': evaluation.feedback
                }
                
                # Calculate weighted score
                weight = self.config.CRITERIA_WEIGHTS.get(criteria_name, 0.2)
                weighted_score += evaluation.score * weight
                total_confidence += evaluation.confidence
                
                # Collect critical issues and suggestions
                if evaluation.details:
                    details = evaluation.details if isinstance(evaluation.details, dict) else {}
                    
                    if evaluation.score < 0.5:  # Critical threshold
                        issues = details.get('specific_issues', [])
                        summary['critical_issues'].extend(issues)
                    
                    suggestions = details.get('suggestions', [])
                    summary['suggestions'].extend(suggestions)
            
            summary['overall_score'] = weighted_score
            summary['average_confidence'] = total_confidence / len(evaluations)
            summary['recommendation'] = self._get_recommendation(weighted_score)
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Error in get_evaluation_summary: {str(e)}")
            return {"error": str(e)}
    
    def batch_evaluate(self, sessions: List[Tuple[int, str, str]]) -> Dict:
        """
        Evaluate multiple sessions in batch
        
        Args:
            sessions: List of tuples (session_id, original_input, agent_output)
            
        Returns:
            Dictionary containing batch evaluation results
        """
        results = {}
        
        for session_id, original_input, agent_output in sessions:
            try:
                result = self.evaluate_output(session_id, original_input, agent_output)
                results[session_id] = result
            except Exception as e:
                self.logger.error(f"Error evaluating session {session_id}: {str(e)}")
                results[session_id] = {"error": str(e)}
        
        return results
