"""
FastAPI Feedback Loop API for Multi-Agent System
Provides autonomous evaluation, correction, retry, and learning capabilities
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any
from datetime import datetime
import json
import sqlite3
import os
import logging
from enum import Enum
import uuid

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Feedback Loop API",
    description="Autonomous feedback system for multi-agent evaluation and improvement",
    version="1.0.0"
)

# Database setup
DATABASE_PATH = "feedback_system.db"

def init_database():
    """Initialize SQLite database for feedback system"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Feedbacks table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS feedbacks (
            id TEXT PRIMARY KEY,
            agent_id TEXT NOT NULL,
            task_id TEXT,
            input_text TEXT NOT NULL,
            output_text TEXT NOT NULL,
            expected_output TEXT,
            evaluation_method TEXT NOT NULL,
            metrics TEXT NOT NULL,
            scores TEXT NOT NULL,
            overall_score REAL NOT NULL,
            status TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Retry attempts table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS retry_attempts (
            id TEXT PRIMARY KEY,
            agent_id TEXT NOT NULL,
            task_id TEXT NOT NULL,
            strategy TEXT NOT NULL,
            original_prompt TEXT NOT NULL,
            original_response TEXT NOT NULL,
            error_message TEXT,
            corrected_prompt TEXT,
            corrected_response TEXT,
            attempt_number INTEGER NOT NULL,
            success BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Training data table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS training_data (
            id TEXT PRIMARY KEY,
            agent_id TEXT NOT NULL,
            prompt TEXT NOT NULL,
            bad_response TEXT NOT NULL,
            expected_correction TEXT NOT NULL,
            feedback_type TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Task status table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS task_status (
            task_id TEXT PRIMARY KEY,
            agent_id TEXT NOT NULL,
            status TEXT NOT NULL,
            current_attempt INTEGER DEFAULT 1,
            max_attempts INTEGER DEFAULT 3,
            last_feedback_id TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()

# Initialize database on startup
init_database()

# Enums
class EvaluationMethod(str, Enum):
    llm = "llm"
    rules = "rules"
    autoeval = "autoeval"

class FeedbackStatus(str, Enum):
    pending = "pending"
    completed = "completed"
    failed = "failed"
    retry_needed = "retry_needed"

class TaskStatus(str, Enum):
    in_progress = "in_progress"
    completed = "completed"
    failed = "failed"
    retrying = "retrying"

class RetryStrategy(str, Enum):
    modify_prompt = "modify_prompt"
    change_parameters = "change_parameters"
    add_context = "add_context"
    simplify_task = "simplify_task"

# Pydantic models
class EvaluationRequest(BaseModel):
    agent_id: str
    input: str = Field(..., description="The input prompt given to the agent")
    output: str = Field(..., description="The agent's response")
    expected: Optional[str] = Field(None, description="Expected output for comparison")
    method: EvaluationMethod = Field(EvaluationMethod.autoeval, description="Evaluation method")
    metrics: List[str] = Field(default=["accuracy", "relevance", "fluency"], description="Metrics to evaluate")
    task_id: Optional[str] = Field(None, description="Task identifier for tracking")

class RetryRequest(BaseModel):
    agent_id: str
    task_id: str
    strategy: RetryStrategy
    last_attempt: Dict[str, Any] = Field(..., description="Last attempt details (prompt, response, error)")

class TrainingRequest(BaseModel):
    agent_id: str
    prompt: str
    bad_response: str
    expected_correction: str
    feedback_type: str = Field(default="user_correction", description="Type of feedback")

class EvaluationResponse(BaseModel):
    feedback_id: str
    agent_id: str
    task_id: Optional[str]
    overall_score: float
    detailed_scores: Dict[str, float]
    recommendations: List[str]
    status: FeedbackStatus
    needs_retry: bool

class RetryResponse(BaseModel):
    retry_id: str
    agent_id: str
    task_id: str
    attempt_number: int
    corrected_prompt: str
    strategy_applied: str
    success: bool
    new_response: Optional[str] = None

class TrainingResponse(BaseModel):
    training_id: str
    agent_id: str
    status: str
    message: str

class FeedbackHistory(BaseModel):
    agent_id: str
    total_feedbacks: int
    average_score: float
    feedbacks: List[Dict[str, Any]]

class TaskStatusResponse(BaseModel):
    task_id: str
    agent_id: str
    status: TaskStatus
    current_attempt: int
    max_attempts: int
    last_feedback_id: Optional[str]
    history: List[Dict[str, Any]]

# Evaluation engine
class DummyEvaluator:
    """Dummy evaluator for demonstration purposes"""
    
    def __init__(self):
        self.metrics_weights = {
            "accuracy": 0.3,
            "relevance": 0.25,
            "fluency": 0.2,
            "completeness": 0.15,
            "coherence": 0.1
        }
    
    def evaluate(self, input_text: str, output_text: str, expected: Optional[str] = None, 
                 metrics: List[str] = None) -> Dict[str, float]:
        """
        Evaluate agent output using rule-based approach
        In production, this would integrate with your existing evaluation_engine.py
        """
        if metrics is None:
            metrics = ["accuracy", "relevance", "fluency"]
        
        scores = {}
        
        for metric in metrics:
            if metric == "accuracy":
                # Simple accuracy check based on keyword matching
                if expected:
                    common_words = set(expected.lower().split()) & set(output_text.lower().split())
                    scores[metric] = min(1.0, len(common_words) / max(1, len(expected.split())) * 2)
                else:
                    scores[metric] = 0.7  # Default when no expected output
            
            elif metric == "relevance":
                # Check if output is relevant to input
                input_words = set(input_text.lower().split())
                output_words = set(output_text.lower().split())
                overlap = len(input_words & output_words)
                scores[metric] = min(1.0, overlap / max(1, len(input_words)) * 2)
            
            elif metric == "fluency":
                # Simple fluency check based on length and structure
                words = output_text.split()
                if len(words) < 3:
                    scores[metric] = 0.3
                elif len(words) > 100:
                    scores[metric] = 0.8
                else:
                    scores[metric] = 0.7
            
            elif metric == "completeness":
                # Check if response seems complete
                if output_text.strip().endswith(('.', '!', '?')):
                    scores[metric] = 0.8
                else:
                    scores[metric] = 0.5
            
            elif metric == "coherence":
                # Basic coherence check
                sentences = output_text.split('.')
                if len(sentences) > 1:
                    scores[metric] = 0.75
                else:
                    scores[metric] = 0.6
            
            else:
                scores[metric] = 0.5  # Default score for unknown metrics
        
        return scores
    
    def get_recommendations(self, scores: Dict[str, float]) -> List[str]:
        """Generate recommendations based on scores"""
        recommendations = []
        
        if scores.get("accuracy", 0) < 0.5:
            recommendations.append("Improve accuracy by providing more precise information")
        
        if scores.get("relevance", 0) < 0.5:
            recommendations.append("Ensure response is more relevant to the input question")
        
        if scores.get("fluency", 0) < 0.5:
            recommendations.append("Improve language fluency and sentence structure")
        
        if scores.get("completeness", 0) < 0.5:
            recommendations.append("Provide more complete and detailed responses")
        
        if scores.get("coherence", 0) < 0.5:
            recommendations.append("Improve logical flow and coherence")
        
        if not recommendations:
            recommendations.append("Good performance overall, keep up the quality")
        
        return recommendations

# Initialize evaluator
evaluator = DummyEvaluator()

# Database helpers
def save_feedback(feedback_data: Dict[str, Any]) -> str:
    """Save feedback to database"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    feedback_id = str(uuid.uuid4())
    
    cursor.execute('''
        INSERT INTO feedbacks (id, agent_id, task_id, input_text, output_text, expected_output,
                             evaluation_method, metrics, scores, overall_score, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        feedback_id,
        feedback_data['agent_id'],
        feedback_data.get('task_id'),
        feedback_data['input'],
        feedback_data['output'],
        feedback_data.get('expected'),
        feedback_data['method'],
        json.dumps(feedback_data['metrics']),
        json.dumps(feedback_data['scores']),
        feedback_data['overall_score'],
        feedback_data['status']
    ))
    
    conn.commit()
    conn.close()
    return feedback_id

def save_retry_attempt(retry_data: Dict[str, Any]) -> str:
    """Save retry attempt to database"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    retry_id = str(uuid.uuid4())
    
    cursor.execute('''
        INSERT INTO retry_attempts (id, agent_id, task_id, strategy, original_prompt,
                                  original_response, error_message, corrected_prompt,
                                  corrected_response, attempt_number, success)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        retry_id,
        retry_data['agent_id'],
        retry_data['task_id'],
        retry_data['strategy'],
        retry_data['original_prompt'],
        retry_data['original_response'],
        retry_data.get('error_message'),
        retry_data.get('corrected_prompt'),
        retry_data.get('corrected_response'),
        retry_data['attempt_number'],
        retry_data.get('success', False)
    ))
    
    conn.commit()
    conn.close()
    return retry_id

def save_training_data(training_data: Dict[str, Any]) -> str:
    """Save training data to database"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    training_id = str(uuid.uuid4())
    
    cursor.execute('''
        INSERT INTO training_data (id, agent_id, prompt, bad_response, expected_correction, feedback_type)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (
        training_id,
        training_data['agent_id'],
        training_data['prompt'],
        training_data['bad_response'],
        training_data['expected_correction'],
        training_data['feedback_type']
    ))
    
    conn.commit()
    conn.close()
    return training_id

def update_task_status(task_id: str, agent_id: str, status: str, attempt: int = 1, 
                      feedback_id: Optional[str] = None):
    """Update task status in database"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT OR REPLACE INTO task_status (task_id, agent_id, status, current_attempt, 
                                          last_feedback_id, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (task_id, agent_id, status, attempt, feedback_id, datetime.now().isoformat()))
    
    conn.commit()
    conn.close()

# API Endpoints

@app.post("/feedback/evaluate", response_model=EvaluationResponse)
async def evaluate_feedback(request: EvaluationRequest):
    """
    Evaluate agent response according to specified criteria
    """
    try:
        # Generate task_id if not provided
        task_id = request.task_id or str(uuid.uuid4())
        
        # Evaluate using the evaluator
        scores = evaluator.evaluate(
            request.input, 
            request.output, 
            request.expected, 
            request.metrics
        )
        
        # Calculate overall score
        overall_score = sum(scores.values()) / len(scores)
        
        # Get recommendations
        recommendations = evaluator.get_recommendations(scores)
        
        # Determine if retry is needed
        needs_retry = overall_score < 0.6
        status = FeedbackStatus.retry_needed if needs_retry else FeedbackStatus.completed
        
        # Save feedback to database
        feedback_data = {
            'agent_id': request.agent_id,
            'task_id': task_id,
            'input': request.input,
            'output': request.output,
            'expected': request.expected,
            'method': request.method.value,
            'metrics': request.metrics,
            'scores': scores,
            'overall_score': overall_score,
            'status': status.value
        }
        
        feedback_id = save_feedback(feedback_data)
        
        # Update task status
        task_status = TaskStatus.retrying if needs_retry else TaskStatus.completed
        update_task_status(task_id, request.agent_id, task_status.value, 1, feedback_id)
        
        logger.info(f"Evaluation completed for agent {request.agent_id}, score: {overall_score:.2f}")
        
        return EvaluationResponse(
            feedback_id=feedback_id,
            agent_id=request.agent_id,
            task_id=task_id,
            overall_score=overall_score,
            detailed_scores=scores,
            recommendations=recommendations,
            status=status,
            needs_retry=needs_retry
        )
        
    except Exception as e:
        logger.error(f"Error in evaluate_feedback: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Evaluation failed: {str(e)}")

@app.post("/feedback/retry", response_model=RetryResponse)
async def retry_task(request: RetryRequest):
    """
    Retry a failed task with corrected approach
    """
    try:
        # Get current attempt number
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT current_attempt, max_attempts FROM task_status WHERE task_id = ?
        ''', (request.task_id,))
        
        result = cursor.fetchone()
        if not result:
            raise HTTPException(status_code=404, detail="Task not found")
        
        current_attempt, max_attempts = result
        
        if current_attempt >= max_attempts:
            raise HTTPException(status_code=400, detail="Maximum retry attempts reached")
        
        conn.close()
        
        # Apply retry strategy
        corrected_prompt = apply_retry_strategy(
            request.strategy,
            request.last_attempt.get('prompt', ''),
            request.last_attempt.get('response', ''),
            request.last_attempt.get('error', '')
        )
        
        # Simulate agent execution with corrected prompt
        # In production, this would call your actual agent
        corrected_response = simulate_agent_response(corrected_prompt)
        
        # Save retry attempt
        retry_data = {
            'agent_id': request.agent_id,
            'task_id': request.task_id,
            'strategy': request.strategy.value,
            'original_prompt': request.last_attempt.get('prompt', ''),
            'original_response': request.last_attempt.get('response', ''),
            'error_message': request.last_attempt.get('error', ''),
            'corrected_prompt': corrected_prompt,
            'corrected_response': corrected_response,
            'attempt_number': current_attempt + 1,
            'success': True  # Placeholder - would be determined by actual execution
        }
        
        retry_id = save_retry_attempt(retry_data)
        
        # Update task status
        update_task_status(request.task_id, request.agent_id, TaskStatus.retrying.value, 
                          current_attempt + 1)
        
        logger.info(f"Retry initiated for task {request.task_id}, attempt {current_attempt + 1}")
        
        return RetryResponse(
            retry_id=retry_id,
            agent_id=request.agent_id,
            task_id=request.task_id,
            attempt_number=current_attempt + 1,
            corrected_prompt=corrected_prompt,
            strategy_applied=request.strategy.value,
            success=True,
            new_response=corrected_response
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in retry_task: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Retry failed: {str(e)}")

@app.post("/feedback/train", response_model=TrainingResponse)
async def train_agent(request: TrainingRequest):
    """
    Add training data for agent improvement
    """
    try:
        # Save training data
        training_data = {
            'agent_id': request.agent_id,
            'prompt': request.prompt,
            'bad_response': request.bad_response,
            'expected_correction': request.expected_correction,
            'feedback_type': request.feedback_type
        }
        
        training_id = save_training_data(training_data)
        
        logger.info(f"Training data added for agent {request.agent_id}")
        
        return TrainingResponse(
            training_id=training_id,
            agent_id=request.agent_id,
            status="success",
            message="Training data added successfully"
        )
        
    except Exception as e:
        logger.error(f"Error in train_agent: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Training failed: {str(e)}")

@app.get("/feedback/history/{agent_id}", response_model=FeedbackHistory)
async def get_feedback_history(agent_id: str, limit: int = 50):
    """
    Get feedback history for an agent
    """
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT * FROM feedbacks WHERE agent_id = ? 
            ORDER BY created_at DESC LIMIT ?
        ''', (agent_id, limit))
        
        feedbacks = cursor.fetchall()
        
        # Calculate average score
        if feedbacks:
            avg_score = sum(row[9] for row in feedbacks) / len(feedbacks)
        else:
            avg_score = 0.0
        
        # Format feedback data
        feedback_list = []
        for row in feedbacks:
            feedback_list.append({
                'id': row[0],
                'task_id': row[2],
                'input': row[3],
                'output': row[4],
                'overall_score': row[9],
                'status': row[10],
                'created_at': row[11]
            })
        
        conn.close()
        
        return FeedbackHistory(
            agent_id=agent_id,
            total_feedbacks=len(feedbacks),
            average_score=avg_score,
            feedbacks=feedback_list
        )
        
    except Exception as e:
        logger.error(f"Error in get_feedback_history: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get history: {str(e)}")

@app.get("/feedback/status/{task_id}", response_model=TaskStatusResponse)
async def get_task_status(task_id: str):
    """
    Get status of feedback cycle for a task
    """
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Get task status
        cursor.execute('''
            SELECT * FROM task_status WHERE task_id = ?
        ''', (task_id,))
        
        task_row = cursor.fetchone()
        if not task_row:
            raise HTTPException(status_code=404, detail="Task not found")
        
        # Get retry history
        cursor.execute('''
            SELECT * FROM retry_attempts WHERE task_id = ?
            ORDER BY created_at DESC
        ''', (task_id,))
        
        retry_history = cursor.fetchall()
        
        # Format history
        history = []
        for row in retry_history:
            history.append({
                'retry_id': row[0],
                'attempt_number': row[9],
                'strategy': row[3],
                'success': bool(row[10]),
                'created_at': row[11]
            })
        
        conn.close()
        
        return TaskStatusResponse(
            task_id=task_id,
            agent_id=task_row[1],
            status=TaskStatus(task_row[2]),
            current_attempt=task_row[3],
            max_attempts=task_row[4],
            last_feedback_id=task_row[5],
            history=history
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in get_task_status: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get status: {str(e)}")

# Helper functions
def apply_retry_strategy(strategy: RetryStrategy, original_prompt: str, 
                        original_response: str, error_message: str) -> str:
    """Apply retry strategy to modify prompt"""
    
    if strategy == RetryStrategy.modify_prompt:
        return f"{original_prompt}\n\nPlease be more specific and accurate in your response."
    
    elif strategy == RetryStrategy.add_context:
        return f"Context: This is a retry attempt due to insufficient response quality.\n\n{original_prompt}"
    
    elif strategy == RetryStrategy.simplify_task:
        return f"Simplified task: {original_prompt}\n\nPlease provide a simple, direct answer."
    
    elif strategy == RetryStrategy.change_parameters:
        return f"{original_prompt}\n\nNote: Please focus on accuracy and relevance."
    
    else:
        return original_prompt

def simulate_agent_response(prompt: str) -> str:
    """Simulate agent response for testing purposes"""
    # In production, this would call your actual agent
    return f"Corrected response to: {prompt[:50]}..."

# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "name": "Feedback Loop API",
        "version": "1.0.0",
        "description": "Autonomous feedback system for multi-agent evaluation and improvement",
        "endpoints": {
            "evaluate": "/feedback/evaluate",
            "retry": "/feedback/retry",
            "train": "/feedback/train",
            "history": "/feedback/history/{agent_id}",
            "status": "/feedback/status/{task_id}"
        }
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)