# AI Agent Evaluation System API

Ce système d'évaluation d'agents IA fournit une API REST complète pour évaluer, corriger et améliorer les sorties d'agents IA de manière autonome.

## Démarrage rapide

### 1. Obtenir une clé API

1. Accédez à l'interface web du système
2. Naviguez vers **System > API Keys**
3. Cliquez sur **"Create New API Key"**
4. Remplissez le nom et la description
5. Copiez la clé générée (format: `aies_...`)

### 2. Utilisation de base

```python
import requests

# Configuration
API_BASE_URL = "http://localhost:5000"
API_KEY = "aies_your_key_here"

headers = {
    "X-API-Key": API_KEY,
    "Content-Type": "application/json"
}

# Créer un agent
agent_data = {
    "name": "Mon Agent IA",
    "description": "Agent de test",
    "api_endpoint": "https://api.exemple.com/agent"
}

response = requests.post(
    f"{API_BASE_URL}/api/agents",
    json=agent_data,
    headers=headers
)

agent = response.json()
```

## Endpoints disponibles

### Gestion des agents

#### `POST /api/agents`
Créer un nouvel agent
```json
{
  "name": "Nom de l'agent",
  "description": "Description",
  "api_endpoint": "https://api.exemple.com"
}
```

#### `GET /api/agents`
Lister tous les agents

### Évaluation

#### `POST /api/evaluate`
Évaluer la sortie d'un agent
```json
{
  "agent_id": 1,
  "original_input": "Question originale",
  "agent_output": "Réponse de l'agent"
}
```

**Réponse:**
```json
{
  "session_id": 123,
  "status": "completed",
  "results": {
    "overall_score": 0.85,
    "recommendation": "good",
    "relevance": {"score": 0.9, "confidence": 0.8},
    "completeness": {"score": 0.8, "confidence": 0.9}
  }
}
```

### Sessions

#### `GET /api/sessions`
Lister toutes les sessions d'évaluation

#### `GET /api/sessions/{session_id}/status`
Obtenir le statut détaillé d'une session

### Corrections

#### `POST /api/sessions/{session_id}/corrections`
Générer des corrections pour une session
```json
{
  "corrections": [
    {
      "type": "prompt",
      "reasoning": "Améliorer la clarté",
      "suggested_value": "Texte amélioré",
      "priority": 2
    }
  ]
}
```

#### `POST /api/sessions/{session_id}/retry`
Relancer une session avec les corrections

### Métriques

#### `GET /api/metrics`
Obtenir les métriques système
```json
{
  "total_sessions": 150,
  "active_sessions": 5,
  "average_score": 0.78,
  "success_rate": 85.3
}
```

## Authentification

Deux méthodes d'authentification sont supportées:

### 1. Header HTTP
```
X-API-Key: aies_your_key_here
```

### 2. Paramètre de requête
```
GET /api/sessions?api_key=aies_your_key_here
```

## Critères d'évaluation

Le système évalue les sorties selon 5 critères:

1. **Pertinence** (30%) - Adéquation avec la question
2. **Complétude** (25%) - Exhaustivité de la réponse
3. **Exactitude** (25%) - Précision factuelle
4. **Cohérence** (15%) - Logique et structure
5. **Sécurité** (5%) - Absence de contenu dangereux

## Système de scoring

- **Score global**: 0.0 à 1.0
- **Seuils de recommandation**:
  - 0.9+ : Excellent
  - 0.7+ : Bon
  - 0.5+ : Acceptable
  - 0.3+ : Pauvre
  - <0.3 : Très pauvre

## Gestion des erreurs

Toutes les erreurs retournent du JSON avec un champ `error`:

```json
{
  "error": "Description de l'erreur"
}
```

Codes de statut HTTP:
- `200` : Succès
- `201` : Créé avec succès
- `400` : Requête invalide
- `401` : Clé API manquante ou invalide
- `404` : Ressource non trouvée
- `500` : Erreur serveur

## Exemple complet

Voir le fichier `api_examples.py` pour des exemples d'utilisation complets en Python.

## Limites et quotas

- Taux de requêtes: 100 requêtes/minute par clé API
- Timeout d'évaluation: 60 secondes
- Timeout de correction: 30 secondes
- Nombre maximum de retries: 3 par session

## Modèles utilisés

Le système utilise des modèles open source via OpenRouter:
- **Modèle principal**: Llama 2 70B Chat
- **Modèles de fallback**: Falcon 7B, GPT4All, DialoGPT

## Support

Pour toute question ou problème, consultez les logs du système ou contactez l'administrateur.