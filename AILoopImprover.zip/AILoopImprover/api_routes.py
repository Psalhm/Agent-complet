from flask import request, jsonify
from app import app, db
from models import (
    Agent, EvaluationSession, EvaluationStatus, 
    Evaluation, Correction, RetryAttempt, APIKey
)
from evaluation_engine import EvaluationEngine
from correction_engine import CorrectionEngine
from retry_controller import RetryController
from api_keys import APIKeyManager, require_api_key
from datetime import datetime, timedelta
import logging

# Initialize engines
evaluation_engine = EvaluationEngine()
correction_engine = CorrectionEngine()
retry_controller = RetryController()

logger = logging.getLogger(__name__)

@app.route('/api/agents', methods=['GET', 'POST'])
def api_agents():
    """Manage AI agents"""
    if request.method == 'GET':
        agents = Agent.query.all()
        return jsonify([{
            'id': agent.id,
            'name': agent.name,
            'description': agent.description,
            'api_endpoint': agent.api_endpoint,
            'created_at': agent.created_at.isoformat()
        } for agent in agents])
    
    elif request.method == 'POST':
        try:
            data = request.get_json()
            
            if not data or not data.get('name'):
                return jsonify({'error': 'Agent name is required'}), 400
            
            agent = Agent(
                name=data['name'],
                description=data.get('description', ''),
                api_endpoint=data.get('api_endpoint', '')
            )
            
            db.session.add(agent)
            db.session.commit()
            
            return jsonify({
                'id': agent.id,
                'name': agent.name,
                'description': agent.description,
                'api_endpoint': agent.api_endpoint,
                'created_at': agent.created_at.isoformat()
            }), 201
            
        except Exception as e:
            logger.error(f"Error creating agent: {str(e)}")
            db.session.rollback()
            return jsonify({'error': str(e)}), 500

@app.route('/api/evaluate', methods=['POST'])
@require_api_key
def api_evaluate():
    """Start evaluation process for an agent's output"""
    try:
        data = request.get_json()
        
        if not data or not all(k in data for k in ['agent_id', 'input', 'output']):
            return jsonify({'error': 'agent_id, input, and output are required'}), 400
        
        agent = Agent.query.get(data['agent_id'])
        if not agent:
            return jsonify({'error': 'Agent not found'}), 404
        
        # Create evaluation session
        session = EvaluationSession(
            agent_id=data['agent_id'],
            original_input=data['input'],
            original_output=data['output'],
            max_retries=data.get('max_retries', 3)
        )
        
        db.session.add(session)
        db.session.commit()
        
        # Start evaluation
        evaluation_results = evaluation_engine.evaluate_output(
            session.id, data['input'], data['output']
        )
        
        # Update session status
        if evaluation_results['needs_correction']:
            session.status = EvaluationStatus.PENDING
        else:
            session.status = EvaluationStatus.COMPLETED
            session.completed_at = datetime.utcnow()
        
        db.session.commit()
        
        response = {
            'session_id': session.id,
            'evaluation_results': evaluation_results,
            'needs_correction': evaluation_results['needs_correction'],
            'overall_score': evaluation_results['overall_score'],
            'recommendation': evaluation_results['recommendation']
        }
        
        return jsonify(response), 200
        
    except Exception as e:
        logger.error(f"Error in evaluation: {str(e)}")
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<int:session_id>/corrections', methods=['GET', 'POST'])
@require_api_key
def api_session_corrections(session_id):
    """Get or generate corrections for a session"""
    if request.method == 'GET':
        try:
            corrections = correction_engine.get_correction_suggestions(session_id)
            return jsonify({'corrections': corrections})
        except Exception as e:
            logger.error(f"Error getting corrections: {str(e)}")
            return jsonify({'error': str(e)}), 500
    
    elif request.method == 'POST':
        try:
            result = correction_engine.generate_corrections(session_id)
            return jsonify(result)
        except Exception as e:
            logger.error(f"Error generating corrections: {str(e)}")
            return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<int:session_id>/retry', methods=['POST'])
@require_api_key
def api_session_retry(session_id):
    """Initiate retry process for a session"""
    try:
        data = request.get_json() or {}
        
        # Check if specific corrections should be applied
        correction_ids = data.get('correction_ids', [])
        
        if correction_ids:
            # Apply specific corrections before retry
            correction_result = correction_engine.apply_corrections(
                session_id, correction_ids
            )
            
            if correction_result['successful_applications'] == 0:
                return jsonify({'error': 'No corrections could be applied'}), 400
        
        # Initiate retry cycle
        retry_result = retry_controller.initiate_retry_cycle(session_id)
        
        return jsonify(retry_result)
        
    except Exception as e:
        logger.error(f"Error in retry: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<int:session_id>/status', methods=['GET'])
def api_session_status(session_id):
    """Get detailed status of an evaluation session"""
    try:
        session = EvaluationSession.query.get(session_id)
        if not session:
            return jsonify({'error': 'Session not found'}), 404
        
        # Get evaluation summary
        evaluation_summary = evaluation_engine.get_evaluation_summary(session_id)
        
        # Get retry status
        retry_status = retry_controller.get_retry_status(session_id)
        
        # Get corrections
        corrections = correction_engine.get_correction_suggestions(session_id)
        
        response = {
            'session_id': session_id,
            'agent_name': session.agent.name,
            'status': session.status.value,
            'created_at': session.created_at.isoformat(),
            'completed_at': session.completed_at.isoformat() if session.completed_at else None,
            'evaluation_summary': evaluation_summary,
            'retry_status': retry_status,
            'corrections_available': len(corrections),
            'corrections': corrections[:5]  # Limit to first 5 for API response
        }
        
        return jsonify(response)
        
    except Exception as e:
        logger.error(f"Error getting session status: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions', methods=['GET'])
def api_sessions():
    """Get list of evaluation sessions"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status')
        agent_id = request.args.get('agent_id', type=int)
        
        query = EvaluationSession.query
        
        if status:
            query = query.filter_by(status=EvaluationStatus(status))
        
        if agent_id:
            query = query.filter_by(agent_id=agent_id)
        
        sessions = query.order_by(EvaluationSession.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        response = {
            'sessions': [{
                'id': session.id,
                'agent_name': session.agent.name,
                'status': session.status.value,
                'retry_count': session.retry_count,
                'max_retries': session.max_retries,
                'created_at': session.created_at.isoformat(),
                'completed_at': session.completed_at.isoformat() if session.completed_at else None,
                'input_preview': session.original_input[:100] + '...' if len(session.original_input) > 100 else session.original_input,
                'output_preview': session.original_output[:100] + '...' if len(session.original_output) > 100 else session.original_output
            } for session in sessions.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': sessions.total,
                'pages': sessions.pages,
                'has_next': sessions.has_next,
                'has_prev': sessions.has_prev
            }
        }
        
        return jsonify(response)
        
    except Exception as e:
        logger.error(f"Error getting sessions: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/metrics', methods=['GET'])
def api_metrics():
    """Get system metrics for dashboard"""
    try:
        # Calculate timeframe
        timeframe = request.args.get('timeframe', '24h')
        
        if timeframe == '24h':
            since = datetime.utcnow() - timedelta(hours=24)
        elif timeframe == '7d':
            since = datetime.utcnow() - timedelta(days=7)
        elif timeframe == '30d':
            since = datetime.utcnow() - timedelta(days=30)
        else:
            since = datetime.utcnow() - timedelta(hours=24)
        
        # Get session statistics
        total_sessions = EvaluationSession.query.filter(
            EvaluationSession.created_at >= since
        ).count()
        
        completed_sessions = EvaluationSession.query.filter(
            EvaluationSession.created_at >= since,
            EvaluationSession.status.in_([EvaluationStatus.COMPLETED, EvaluationStatus.CORRECTED])
        ).count()
        
        failed_sessions = EvaluationSession.query.filter(
            EvaluationSession.created_at >= since,
            EvaluationSession.status.in_([EvaluationStatus.FAILED, EvaluationStatus.RETRY_LIMIT_REACHED])
        ).count()
        
        # Get average scores
        avg_scores = db.session.query(
            db.func.avg(Evaluation.score).label('avg_score')
        ).join(EvaluationSession).filter(
            EvaluationSession.created_at >= since
        ).first()
        
        # Get retry statistics
        retry_stats = db.session.query(
            db.func.avg(EvaluationSession.retry_count).label('avg_retries'),
            db.func.max(EvaluationSession.retry_count).label('max_retries')
        ).filter(
            EvaluationSession.created_at >= since
        ).first()
        
        # Get top agents by session count
        top_agents = db.session.query(
            Agent.name,
            db.func.count(EvaluationSession.id).label('session_count')
        ).join(EvaluationSession).filter(
            EvaluationSession.created_at >= since
        ).group_by(Agent.id).order_by(
            db.func.count(EvaluationSession.id).desc()
        ).limit(5).all()
        
        metrics = {
            'timeframe': timeframe,
            'total_sessions': total_sessions,
            'completed_sessions': completed_sessions,
            'failed_sessions': failed_sessions,
            'success_rate': (completed_sessions / total_sessions * 100) if total_sessions > 0 else 0,
            'average_score': float(avg_scores.avg_score) if avg_scores.avg_score else 0,
            'average_retries': float(retry_stats.avg_retries) if retry_stats.avg_retries else 0,
            'max_retries': retry_stats.max_retries if retry_stats.max_retries else 0,
            'top_agents': [{'name': agent.name, 'sessions': agent.session_count} for agent in top_agents]
        }
        
        return jsonify(metrics)
        
    except Exception as e:
        logger.error(f"Error getting metrics: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<int:session_id>/cancel', methods=['POST'])
def api_cancel_session(session_id):
    """Cancel a session and its scheduled retries"""
    try:
        session = EvaluationSession.query.get(session_id)
        if not session:
            return jsonify({'error': 'Session not found'}), 404
        
        # Cancel scheduled retries
        cancel_result = retry_controller.cancel_scheduled_retries(session_id)
        
        # Update session status
        session.status = EvaluationStatus.FAILED
        session.completed_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'session_id': session_id,
            'cancel_result': cancel_result
        })
        
    except Exception as e:
        logger.error(f"Error cancelling session: {str(e)}")
        return jsonify({'error': str(e)}), 500

# API Key Management Endpoints
@app.route('/api/keys', methods=['GET', 'POST'])
def api_keys_manage():
    """Manage API keys"""
    api_key_manager = APIKeyManager()
    
    if request.method == 'GET':
        # List all API keys
        result = api_key_manager.list_api_keys()
        return jsonify(result), 200 if result['success'] else 500
    
    elif request.method == 'POST':
        # Create new API key
        data = request.get_json()
        
        if not data or 'name' not in data:
            return jsonify({'error': 'Name is required'}), 400
        
        result = api_key_manager.generate_api_key(
            name=data['name'],
            description=data.get('description', ''),
            expires_in_days=data.get('expires_in_days', 365)
        )
        
        return jsonify(result), 201 if result['success'] else 500

@app.route('/api/keys/<int:key_id>', methods=['DELETE'])
def api_key_delete(key_id):
    """Revoke an API key"""
    api_key_manager = APIKeyManager()
    result = api_key_manager.revoke_api_key(key_id)
    
    return jsonify(result), 200 if result['success'] else 500

# Error handlers
@app.errorhandler(404)
def api_not_found(error):
    if request.path.startswith('/api/'):
        return jsonify({'error': 'API endpoint not found'}), 404
    return error

@app.errorhandler(500)
def api_internal_error(error):
    if request.path.startswith('/api/'):
        return jsonify({'error': 'Internal server error'}), 500
    return error
