from app import db
from datetime import datetime
from sqlalchemy import Enum
import enum

class EvaluationStatus(enum.Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    CORRECTED = "corrected"
    RETRY_LIMIT_REACHED = "retry_limit_reached"

class CorrectionStatus(enum.Enum):
    PENDING = "pending"
    APPLIED = "applied"
    FAILED = "failed"
    REJECTED = "rejected"

class EvaluationCriteria(enum.Enum):
    RELEVANCE = "relevance"
    COMPLETENESS = "completeness"
    ACCURACY = "accuracy"
    COHERENCE = "coherence"
    SAFETY = "safety"

class Agent(db.Model):
    """AI Agent that submits actions for evaluation"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    api_endpoint = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    evaluation_sessions = db.relationship('EvaluationSession', backref='agent', lazy=True)

class EvaluationSession(db.Model):
    """A session containing multiple evaluations for an agent's action"""
    id = db.Column(db.Integer, primary_key=True)
    agent_id = db.Column(db.Integer, db.ForeignKey('agent.id'), nullable=False)
    original_input = db.Column(db.Text, nullable=False)
    original_output = db.Column(db.Text, nullable=False)
    status = db.Column(Enum(EvaluationStatus), default=EvaluationStatus.PENDING)
    retry_count = db.Column(db.Integer, default=0)
    max_retries = db.Column(db.Integer, default=3)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    
    # Relationships
    evaluations = db.relationship('Evaluation', backref='session', lazy=True)
    corrections = db.relationship('Correction', backref='session', lazy=True)

class Evaluation(db.Model):
    """Individual evaluation of an agent's output based on specific criteria"""
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('evaluation_session.id'), nullable=False)
    criteria = db.Column(Enum(EvaluationCriteria), nullable=False)
    score = db.Column(db.Float, nullable=False)  # 0.0 to 1.0
    confidence = db.Column(db.Float, nullable=False)  # 0.0 to 1.0
    feedback = db.Column(db.Text)
    evaluator_name = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Evaluation details
    details = db.Column(db.JSON)  # Store structured evaluation data

class Correction(db.Model):
    """Correction suggestions generated based on evaluation results"""
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('evaluation_session.id'), nullable=False)
    correction_type = db.Column(db.String(50), nullable=False)  # 'prompt', 'parameter', 'action'
    original_value = db.Column(db.Text)
    suggested_value = db.Column(db.Text, nullable=False)
    reasoning = db.Column(db.Text)
    priority = db.Column(db.Integer, default=1)  # 1=low, 2=medium, 3=high
    status = db.Column(Enum(CorrectionStatus), default=CorrectionStatus.PENDING)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    applied_at = db.Column(db.DateTime)
    
    # Correction metadata
    correction_metadata = db.Column(db.JSON)

class RetryAttempt(db.Model):
    """Track retry attempts for each evaluation session"""
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('evaluation_session.id'), nullable=False)
    attempt_number = db.Column(db.Integer, nullable=False)
    input_used = db.Column(db.Text, nullable=False)
    output_received = db.Column(db.Text, nullable=False)
    corrections_applied = db.Column(db.JSON)  # List of correction IDs applied
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    session = db.relationship('EvaluationSession', backref='retry_attempts')

class APIKey(db.Model):
    """API keys for external access to the evaluation system"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    key_hash = db.Column(db.String(64), unique=True, nullable=False)  # SHA256 hash
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
    last_used_at = db.Column(db.DateTime)
    usage_count = db.Column(db.Integer, default=0)
    revoked_at = db.Column(db.DateTime)


