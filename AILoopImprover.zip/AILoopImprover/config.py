import os

class Config:
    """Configuration settings for the evaluation system"""
    
    # OpenRouter Configuration for Open Source Models
    OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY", "")
    OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
    # Using Llama 2 70B as the primary model for evaluations
    EVALUATION_MODEL = "meta-llama/llama-2-70b-chat"
    # Alternative models available: "microsoft/DialoGPT-medium", "huggingface/CodeBERTa-small-v1", "togethercomputer/falcon-7b-instruct"
    FALLBACK_MODELS = [
        "microsoft/DialoGPT-medium",
        "togethercomputer/falcon-7b-instruct",
        "huggingface/CodeBERTa-small-v1"
    ]
    
    # Evaluation Settings
    DEFAULT_MAX_RETRIES = 3
    EVALUATION_TIMEOUT = 60  # seconds
    CORRECTION_TIMEOUT = 30  # seconds
    
    # Scoring Thresholds
    SCORE_THRESHOLDS = {
        "excellent": 0.9,
        "good": 0.7,
        "acceptable": 0.5,
        "poor": 0.3
    }
    
    # Evaluation Criteria Weights
    CRITERIA_WEIGHTS = {
        "relevance": 0.3,
        "completeness": 0.25,
        "accuracy": 0.25,
        "coherence": 0.15,
        "safety": 0.05
    }
    
    # Retry Configuration
    RETRY_DELAYS = [1, 2, 4, 8, 16]  # Exponential backoff in seconds
    MAX_CONCURRENT_EVALUATIONS = 10
    
    # Dashboard Configuration
    DASHBOARD_REFRESH_INTERVAL = 30  # seconds
    METRICS_RETENTION_DAYS = 30
    
    # API Configuration
    API_RATE_LIMIT = "100 per minute"
    API_TIMEOUT = 30  # seconds
    
    @staticmethod
    def get_evaluation_prompt_template():
        return """
        You are an expert AI evaluator. Please evaluate the following AI agent output based on the specified criteria.
        
        Criteria: {criteria}
        Original Input: {input}
        Agent Output: {output}
        
        Please provide your evaluation in the following JSON format:
        {{
            "score": <float between 0.0 and 1.0>,
            "confidence": <float between 0.0 and 1.0>,
            "feedback": "<detailed feedback explaining the score>",
            "specific_issues": ["<list of specific issues found>"],
            "suggestions": ["<list of improvement suggestions>"]
        }}
        
        Evaluation Guidelines:
        - Score 1.0 = Perfect, no issues
        - Score 0.8-0.9 = Very good, minor issues
        - Score 0.6-0.7 = Good, some issues
        - Score 0.4-0.5 = Acceptable, several issues
        - Score 0.2-0.3 = Poor, major issues
        - Score 0.0-0.1 = Very poor, critical issues
        
        Focus on {criteria} specifically but consider overall quality.
        """
    
    @staticmethod
    def get_correction_prompt_template():
        return """
        You are an expert AI correction specialist. Based on the evaluation results, generate specific corrections to improve the AI agent's performance.
        
        Original Input: {input}
        Agent Output: {output}
        Evaluation Results: {evaluation_results}
        
        Please provide corrections in the following JSON format:
        {{
            "corrections": [
                {{
                    "type": "<prompt|parameter|action>",
                    "original_value": "<current value>",
                    "suggested_value": "<improved value>",
                    "reasoning": "<explanation for the correction>",
                    "priority": <1-3, where 3 is highest priority>
                }}
            ],
            "overall_strategy": "<general improvement strategy>",
            "expected_improvement": "<expected outcome after applying corrections>"
        }}
        
        Correction Types:
        - prompt: Modifications to the input prompt
        - parameter: Changes to model parameters or settings
        - action: Structural changes to the agent's action
        
        Prioritize corrections that address the most critical issues first.
        """
