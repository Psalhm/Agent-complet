import json
import logging
from typing import Dict, List, Optional
from datetime import datetime
import os
import requests
from models import Correction, CorrectionStatus, EvaluationSession, Evaluation, db
from config import Config

class CorrectionEngine:
    """Engine for generating and applying corrections based on evaluation results"""
    
    def __init__(self):
        self.api_key = os.environ.get("OPENROUTER_API_KEY")
        self.config = Config()
        self.logger = logging.getLogger(__name__)
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        })
    
    def generate_corrections(self, session_id: int) -> Dict:
        """
        Generate corrections for a session based on evaluation results
        
        Args:
            session_id: ID of the evaluation session
            
        Returns:
            Dictionary containing generated corrections
        """
        try:
            session = EvaluationSession.query.get(session_id)
            if not session:
                raise ValueError(f"Session {session_id} not found")
            
            evaluations = Evaluation.query.filter_by(session_id=session_id).all()
            if not evaluations:
                raise ValueError(f"No evaluations found for session {session_id}")
            
            # Compile evaluation results
            evaluation_results = self._compile_evaluation_results(evaluations)
            
            # Generate corrections using OpenAI
            corrections_data = self._generate_corrections_with_ai(
                session.original_input,
                session.original_output,
                evaluation_results
            )
            
            # Store corrections in database
            stored_corrections = []
            for correction_data in corrections_data.get('corrections', []):
                correction = Correction(
                    session_id=session_id,
                    correction_type=correction_data['type'],
                    original_value=correction_data.get('original_value', ''),
                    suggested_value=correction_data['suggested_value'],
                    reasoning=correction_data['reasoning'],
                    priority=correction_data.get('priority', 1),
                    status=CorrectionStatus.PENDING,
                    correction_metadata={
                        'overall_strategy': corrections_data.get('overall_strategy', ''),
                        'expected_improvement': corrections_data.get('expected_improvement', '')
                    }
                )
                db.session.add(correction)
                stored_corrections.append(correction)
            
            db.session.commit()
            
            return {
                'corrections_generated': len(stored_corrections),
                'corrections': corrections_data,
                'correction_ids': [c.id for c in stored_corrections]
            }
            
        except Exception as e:
            self.logger.error(f"Error generating corrections: {str(e)}")
            db.session.rollback()
            raise
    
    def _compile_evaluation_results(self, evaluations: List[Evaluation]) -> Dict:
        """Compile evaluation results into a structured format"""
        results = {
            'scores': {},
            'feedback': {},
            'critical_issues': [],
            'suggestions': [],
            'overall_score': 0.0
        }
        
        total_weighted_score = 0.0
        
        for evaluation in evaluations:
            criteria_name = evaluation.criteria.value
            results['scores'][criteria_name] = evaluation.score
            results['feedback'][criteria_name] = evaluation.feedback
            
            # Calculate weighted score
            weight = self.config.CRITERIA_WEIGHTS.get(criteria_name, 0.2)
            total_weighted_score += evaluation.score * weight
            
            # Extract issues and suggestions from details
            if evaluation.details:
                details = evaluation.details if isinstance(evaluation.details, dict) else {}
                
                if evaluation.score < 0.5:  # Critical threshold
                    issues = details.get('specific_issues', [])
                    results['critical_issues'].extend(issues)
                
                suggestions = details.get('suggestions', [])
                results['suggestions'].extend(suggestions)
        
        results['overall_score'] = total_weighted_score
        
        return results
    
    def _generate_corrections_with_ai(self, original_input: str, 
                                    agent_output: str, 
                                    evaluation_results: Dict) -> Dict:
        """
        Generate corrections using OpenAI based on evaluation results
        
        Args:
            original_input: Original input to the agent
            agent_output: Agent's output
            evaluation_results: Compiled evaluation results
            
        Returns:
            Dictionary containing generated corrections
        """
        try:
            if not self.api_key:
                raise Exception("OpenRouter API key not configured")
                
            prompt = self.config.get_correction_prompt_template().format(
                input=original_input,
                output=agent_output,
                evaluation_results=json.dumps(evaluation_results, indent=2)
            )
            
            # Try primary model first, then fallback models
            models_to_try = [self.config.EVALUATION_MODEL] + self.config.FALLBACK_MODELS
            
            for model in models_to_try:
                try:
                    payload = {
                        "model": model,
                        "messages": [
                            {"role": "system", "content": "You are an expert AI correction specialist. Respond with valid JSON only."},
                            {"role": "user", "content": prompt}
                        ],
                        "temperature": 0.3,
                        "max_tokens": 1500
                    }
                    
                    response = self.session.post(
                        f"{self.config.OPENROUTER_BASE_URL}/chat/completions",
                        json=payload,
                        timeout=self.config.CORRECTION_TIMEOUT
                    )
                    
                    if response.status_code == 200:
                        data = response.json()
                        result = json.loads(data["choices"][0]["message"]["content"])
                        
                        # Validate and clean corrections
                        cleaned_corrections = []
                        for correction in result.get('corrections', []):
                            cleaned_correction = {
                                'type': correction.get('type', 'prompt'),
                                'original_value': correction.get('original_value', ''),
                                'suggested_value': correction.get('suggested_value', ''),
                                'reasoning': correction.get('reasoning', ''),
                                'priority': max(1, min(3, int(correction.get('priority', 1)))),
                                'model_used': model
                            }
                            cleaned_corrections.append(cleaned_correction)
                        
                        return {
                            'corrections': cleaned_corrections,
                            'overall_strategy': result.get('overall_strategy', ''),
                            'expected_improvement': result.get('expected_improvement', ''),
                            'model_used': model
                        }
                    else:
                        self.logger.warning(f"Model {model} returned status {response.status_code}")
                        continue
                        
                except Exception as e:
                    self.logger.warning(f"Failed to use model {model}: {str(e)}")
                    continue
            
            # If all models failed, return default response
            return {
                'corrections': [],
                'overall_strategy': 'All correction models failed to respond',
                'expected_improvement': 'Unknown due to model failure'
            }
            
        except Exception as e:
            self.logger.error(f"Error in _generate_corrections_with_ai: {str(e)}")
            return {
                'corrections': [],
                'overall_strategy': f"Error generating corrections: {str(e)}",
                'expected_improvement': 'Unknown due to error'
            }
    
    def apply_corrections(self, session_id: int, correction_ids: List[int]) -> Dict:
        """
        Apply selected corrections to prepare for retry
        
        Args:
            session_id: ID of the evaluation session
            correction_ids: List of correction IDs to apply
            
        Returns:
            Dictionary containing application results
        """
        try:
            session = EvaluationSession.query.get(session_id)
            if not session:
                raise ValueError(f"Session {session_id} not found")
            
            corrections = Correction.query.filter(
                Correction.id.in_(correction_ids),
                Correction.session_id == session_id
            ).all()
            
            if not corrections:
                raise ValueError("No valid corrections found")
            
            # Sort corrections by priority (high to low)
            corrections.sort(key=lambda c: c.priority, reverse=True)
            
            # Apply corrections to create modified input
            modified_input = session.original_input
            applied_corrections = []
            
            for correction in corrections:
                try:
                    if correction.correction_type == 'prompt':
                        modified_input = self._apply_prompt_correction(
                            modified_input, correction
                        )
                    elif correction.correction_type == 'parameter':
                        # For parameters, we'll store them for the retry attempt
                        pass
                    elif correction.correction_type == 'action':
                        # For actions, we'll modify the structure
                        modified_input = self._apply_action_correction(
                            modified_input, correction
                        )
                    
                    # Mark correction as applied
                    correction.status = CorrectionStatus.APPLIED
                    correction.applied_at = datetime.utcnow()
                    applied_corrections.append(correction.id)
                    
                except Exception as e:
                    self.logger.error(f"Error applying correction {correction.id}: {str(e)}")
                    correction.status = CorrectionStatus.FAILED
            
            db.session.commit()
            
            return {
                'modified_input': modified_input,
                'applied_corrections': applied_corrections,
                'total_corrections': len(corrections),
                'successful_applications': len(applied_corrections)
            }
            
        except Exception as e:
            self.logger.error(f"Error applying corrections: {str(e)}")
            db.session.rollback()
            raise
    
    def _apply_prompt_correction(self, original_input: str, correction: Correction) -> str:
        """Apply a prompt-based correction"""
        try:
            if correction.original_value and correction.original_value in original_input:
                # Replace specific text
                return original_input.replace(
                    correction.original_value, 
                    correction.suggested_value
                )
            else:
                # Append or prepend correction
                if correction.reasoning and 'append' in correction.reasoning.lower():
                    return original_input + "\n\n" + correction.suggested_value
                else:
                    return correction.suggested_value + "\n\n" + original_input
                    
        except Exception as e:
            self.logger.error(f"Error in _apply_prompt_correction: {str(e)}")
            return original_input
    
    def _apply_action_correction(self, original_input: str, correction: Correction) -> str:
        """Apply an action-based correction"""
        try:
            # For action corrections, we'll modify the structure or add instructions
            correction_instruction = f"\n\nIMPORTANT CORRECTION: {correction.suggested_value}\nReasoning: {correction.reasoning}"
            return original_input + correction_instruction
            
        except Exception as e:
            self.logger.error(f"Error in _apply_action_correction: {str(e)}")
            return original_input
    
    def get_correction_suggestions(self, session_id: int) -> List[Dict]:
        """
        Get correction suggestions for a session
        
        Args:
            session_id: ID of the evaluation session
            
        Returns:
            List of correction suggestions
        """
        try:
            corrections = Correction.query.filter_by(session_id=session_id).order_by(
                Correction.priority.desc(), Correction.created_at.desc()
            ).all()
            
            suggestions = []
            for correction in corrections:
                suggestion = {
                    'id': correction.id,
                    'type': correction.correction_type,
                    'suggested_value': correction.suggested_value,
                    'reasoning': correction.reasoning,
                    'priority': correction.priority,
                    'status': correction.status.value,
                    'created_at': correction.created_at.isoformat(),
                    'metadata': correction.correction_metadata
                }
                suggestions.append(suggestion)
            
            return suggestions
            
        except Exception as e:
            self.logger.error(f"Error getting correction suggestions: {str(e)}")
            return []
