#!/usr/bin/env python3
"""
Examples of how to use the AI Agent Evaluation System API
"""

import requests
import json
import time

# Configuration
API_BASE_URL = "http://localhost:5000"
API_KEY = "your_api_key_here"  # Replace with your generated API key

def make_request(method, endpoint, data=None, headers=None):
    """Make an API request with proper headers"""
    url = f"{API_BASE_URL}{endpoint}"
    
    default_headers = {
        "X-API-Key": API_KEY,
        "Content-Type": "application/json"
    }
    
    if headers:
        default_headers.update(headers)
    
    response = requests.request(
        method=method,
        url=url,
        headers=default_headers,
        json=data if data else None
    )
    
    return response

def example_create_agent():
    """Example: Create a new agent"""
    print("Creating a new agent...")
    
    agent_data = {
        "name": "Test Agent",
        "description": "A test agent for demonstration purposes",
        "api_endpoint": "https://api.example.com/agent"
    }
    
    response = make_request("POST", "/api/agents", agent_data)
    
    if response.status_code == 201:
        agent = response.json()
        print(f"Agent created successfully: {agent['name']} (ID: {agent['id']})")
        return agent['id']
    else:
        print(f"Error creating agent: {response.text}")
        return None

def example_evaluate_agent_output(agent_id):
    """Example: Evaluate an agent's output"""
    print(f"Evaluating agent {agent_id} output...")
    
    evaluation_data = {
        "agent_id": agent_id,
        "original_input": "What is the capital of France?",
        "agent_output": "The capital of France is Paris. It is located in the north-central part of the country and is home to approximately 2.2 million people."
    }
    
    response = make_request("POST", "/api/evaluate", evaluation_data)
    
    if response.status_code == 200:
        result = response.json()
        print(f"Evaluation completed! Session ID: {result['session_id']}")
        print(f"Overall Score: {result['results']['overall_score']:.2f}")
        print(f"Recommendation: {result['results']['recommendation']}")
        return result['session_id']
    else:
        print(f"Error evaluating: {response.text}")
        return None

def example_get_session_status(session_id):
    """Example: Get session status"""
    print(f"Getting session {session_id} status...")
    
    response = make_request("GET", f"/api/sessions/{session_id}/status")
    
    if response.status_code == 200:
        status = response.json()
        print(f"Session Status: {status['status']}")
        print(f"Overall Score: {status['overall_score']:.2f}")
        
        for criteria, evaluation in status['evaluations'].items():
            print(f"  {criteria}: {evaluation['score']:.2f} (confidence: {evaluation['confidence']:.2f})")
        
        return status
    else:
        print(f"Error getting session status: {response.text}")
        return None

def example_generate_corrections(session_id):
    """Example: Generate corrections for a session"""
    print(f"Generating corrections for session {session_id}...")
    
    response = make_request("POST", f"/api/sessions/{session_id}/corrections")
    
    if response.status_code == 200:
        corrections = response.json()
        print(f"Generated {len(corrections['corrections'])} corrections")
        
        for i, correction in enumerate(corrections['corrections'], 1):
            print(f"  Correction {i}:")
            print(f"    Type: {correction['type']}")
            print(f"    Priority: {correction['priority']}")
            print(f"    Reasoning: {correction['reasoning']}")
            print(f"    Suggested Value: {correction['suggested_value'][:100]}...")
        
        return corrections
    else:
        print(f"Error generating corrections: {response.text}")
        return None

def example_retry_session(session_id):
    """Example: Retry a session with corrections"""
    print(f"Retrying session {session_id}...")
    
    response = make_request("POST", f"/api/sessions/{session_id}/retry")
    
    if response.status_code == 200:
        result = response.json()
        print(f"Retry initiated: {result['message']}")
        return result
    else:
        print(f"Error retrying session: {response.text}")
        return None

def example_list_sessions():
    """Example: List all sessions"""
    print("Listing all sessions...")
    
    response = make_request("GET", "/api/sessions")
    
    if response.status_code == 200:
        sessions = response.json()
        print(f"Found {len(sessions)} sessions")
        
        for session in sessions[:5]:  # Show first 5 sessions
            print(f"  Session {session['id']}: {session['status']} (Agent: {session['agent_name']})")
        
        return sessions
    else:
        print(f"Error listing sessions: {response.text}")
        return None

def example_get_metrics():
    """Example: Get system metrics"""
    print("Getting system metrics...")
    
    response = make_request("GET", "/api/metrics")
    
    if response.status_code == 200:
        metrics = response.json()
        print(f"Total Sessions: {metrics['total_sessions']}")
        print(f"Active Sessions: {metrics['active_sessions']}")
        print(f"Average Score: {metrics['average_score']:.2f}")
        print(f"Success Rate: {metrics['success_rate']:.1f}%")
        
        return metrics
    else:
        print(f"Error getting metrics: {response.text}")
        return None

def main():
    """Run all examples"""
    print("AI Agent Evaluation System API Examples")
    print("=" * 50)
    
    if API_KEY == "your_api_key_here":
        print("Please set your API key in the API_KEY variable before running examples")
        return
    
    # Example workflow
    try:
        # 1. Create an agent
        agent_id = example_create_agent()
        if not agent_id:
            return
        
        print("\n" + "-" * 50)
        
        # 2. Evaluate agent output
        session_id = example_evaluate_agent_output(agent_id)
        if not session_id:
            return
        
        print("\n" + "-" * 50)
        
        # 3. Get session status
        status = example_get_session_status(session_id)
        if not status:
            return
        
        print("\n" + "-" * 50)
        
        # 4. Generate corrections if needed
        if status['overall_score'] < 0.7:
            corrections = example_generate_corrections(session_id)
            if corrections:
                print("\n" + "-" * 50)
                
                # 5. Retry with corrections
                example_retry_session(session_id)
        
        print("\n" + "-" * 50)
        
        # 6. List sessions
        example_list_sessions()
        
        print("\n" + "-" * 50)
        
        # 7. Get metrics
        example_get_metrics()
        
    except Exception as e:
        print(f"Error during example execution: {e}")

if __name__ == "__main__":
    main()