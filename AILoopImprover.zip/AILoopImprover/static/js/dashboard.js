/**
 * Dashboard JavaScript for AI Agent Evaluation System
 * Handles chart initialization, real-time updates, and interactive features
 */

class DashboardManager {
    constructor() {
        this.charts = {};
        this.refreshInterval = null;
        this.autoRefreshEnabled = false;
        this.lastUpdateTime = null;
        
        this.init();
    }
    
    init() {
        // Initialize dashboard when DOM is ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.initializeDashboard());
        } else {
            this.initializeDashboard();
        }
    }
    
    initializeDashboard() {
        console.log('Initializing dashboard...');
        
        // Initialize charts
        this.initializeCharts();
        
        // Setup event listeners
        this.setupEventListeners();
        
        // Start auto-refresh if enabled
        this.setupAutoRefresh();
        
        // Initial metrics load
        this.loadMetrics();
        
        console.log('Dashboard initialized successfully');
    }
    
    initializeCharts() {
        try {
            // Performance Chart
            const performanceCanvas = document.getElementById('performanceChart');
            if (performanceCanvas) {
                this.charts.performance = this.createPerformanceChart(performanceCanvas);
            }
            
            // Status Chart
            const statusCanvas = document.getElementById('statusChart');
            if (statusCanvas) {
                this.charts.status = this.createStatusChart(statusCanvas);
            }
            
            console.log('Charts initialized successfully');
        } catch (error) {
            console.error('Error initializing charts:', error);
            // Fallback if showError method doesn't exist
            if (typeof this.showError === 'function') {
                this.showError('Failed to initialize charts');
            }
        }
    }
    
    createPerformanceChart(canvas) {
        const ctx = canvas.getContext('2d');
        
        return new Chart(ctx, {
            type: 'line',
            data: {
                labels: this.generateTimeLabels(),
                datasets: [{
                    label: 'Sessions',
                    data: [],
                    borderColor: 'rgb(75, 192, 192)',
                    backgroundColor: 'rgba(75, 192, 192, 0.1)',
                    tension: 0.1,
                    fill: true
                }, {
                    label: 'Completed',
                    data: [],
                    borderColor: 'rgb(40, 167, 69)',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    tension: 0.1,
                    fill: true
                }, {
                    label: 'Failed',
                    data: [],
                    borderColor: 'rgb(220, 53, 69)',
                    backgroundColor: 'rgba(220, 53, 69, 0.1)',
                    tension: 0.1,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Session Performance Over Time'
                    },
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Time'
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    }
    
    createStatusChart(canvas) {
        const ctx = canvas.getContext('2d');
        
        return new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Completed', 'Corrected', 'Pending', 'Failed', 'Retry Limit Reached'],
                datasets: [{
                    data: [0, 0, 0, 0, 0],
                    backgroundColor: [
                        'rgb(40, 167, 69)',      // Completed - green
                        'rgb(23, 162, 184)',     // Corrected - teal
                        'rgb(255, 193, 7)',      // Pending - yellow
                        'rgb(220, 53, 69)',      // Failed - red
                        'rgb(108, 117, 125)'     // Retry Limit - gray
                    ],
                    borderWidth: 2,
                    borderColor: 'rgba(255, 255, 255, 0.1)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Session Status Distribution'
                    },
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 15
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    }
    
    generateTimeLabels() {
        const labels = [];
        const now = new Date();
        
        for (let i = 23; i >= 0; i--) {
            const time = new Date(now.getTime() - (i * 60 * 60 * 1000));
            labels.push(time.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }));
        }
        
        return labels;
    }
    
    setupEventListeners() {
        // Refresh button
        const refreshBtn = document.querySelector('[onclick="refreshMetrics()"]');
        if (refreshBtn) {
            refreshBtn.removeAttribute('onclick');
            refreshBtn.addEventListener('click', () => this.refreshMetrics());
        }
        
        // Auto-refresh toggle
        const autoRefreshToggle = document.getElementById('autoRefreshToggle');
        if (autoRefreshToggle) {
            autoRefreshToggle.addEventListener('change', (e) => {
                this.toggleAutoRefresh(e.target.checked);
            });
        }
        
        // Timeframe selector
        const timeframeSelect = document.getElementById('timeframeSelect');
        if (timeframeSelect) {
            timeframeSelect.addEventListener('change', (e) => {
                this.changeTimeframe(e.target.value);
            });
        }
        
        // Session status filters
        document.querySelectorAll('.status-filter').forEach(filter => {
            filter.addEventListener('click', (e) => {
                e.preventDefault();
                this.filterByStatus(e.target.dataset.status);
            });
        });
        
        // Retry buttons
        document.querySelectorAll('.retry-session-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                this.retrySession(e.target.dataset.sessionId);
            });
        });
    }
    
    setupAutoRefresh() {
        // Check if auto-refresh is enabled in localStorage
        const autoRefreshSetting = localStorage.getItem('dashboardAutoRefresh');
        if (autoRefreshSetting === 'true') {
            this.toggleAutoRefresh(true);
        }
    }
    
    toggleAutoRefresh(enabled) {
        this.autoRefreshEnabled = enabled;
        localStorage.setItem('dashboardAutoRefresh', enabled.toString());
        
        if (enabled) {
            this.refreshInterval = setInterval(() => {
                this.loadMetrics();
            }, 30000); // 30 seconds
            
            this.showNotification('Auto-refresh enabled', 'success');
        } else {
            if (this.refreshInterval) {
                clearInterval(this.refreshInterval);
                this.refreshInterval = null;
            }
            this.showNotification('Auto-refresh disabled', 'info');
        }
        
        // Update toggle state
        const toggle = document.getElementById('autoRefreshToggle');
        if (toggle) {
            toggle.checked = enabled;
        }
    }
    
    async loadMetrics(timeframe = '24h') {
        try {
            this.showLoading(true);
            
            const response = await fetch(`/api/metrics?timeframe=${timeframe}`);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const metrics = await response.json();
            
            if (metrics.error) {
                throw new Error(metrics.error);
            }
            
            this.updateMetrics(metrics);
            this.updateCharts(metrics);
            
            this.lastUpdateTime = new Date();
            this.updateLastUpdateTime();
            
        } catch (error) {
            console.error('Error loading metrics:', error);
            this.showError(`Failed to load metrics: ${error.message}`);
        } finally {
            this.showLoading(false);
        }
    }
    
    updateMetrics(metrics) {
        // Update metric cards
        this.updateMetricCard('total-sessions', metrics.total_sessions);
        this.updateMetricCard('completed-sessions', metrics.completed_sessions);
        this.updateMetricCard('success-rate', `${metrics.success_rate.toFixed(1)}%`);
        this.updateMetricCard('average-score', `${(metrics.average_score * 100).toFixed(1)}%`);
        this.updateMetricCard('average-retries', metrics.average_retries.toFixed(1));
        
        // Update additional metrics if elements exist
        const failedSessionsEl = document.getElementById('failed-sessions');
        if (failedSessionsEl) {
            failedSessionsEl.textContent = metrics.failed_sessions;
        }
        
        const maxRetriesEl = document.getElementById('max-retries');
        if (maxRetriesEl) {
            maxRetriesEl.textContent = metrics.max_retries;
        }
    }
    
    updateMetricCard(id, value) {
        const element = document.getElementById(id);
        if (element) {
            // Add animation class
            element.classList.add('fade-in');
            element.textContent = value;
            
            // Remove animation class after animation completes
            setTimeout(() => {
                element.classList.remove('fade-in');
            }, 500);
        }
    }
    
    updateCharts(metrics) {
        // Update performance chart with mock hourly data
        if (this.charts.performance) {
            this.updatePerformanceChart(metrics);
        }
        
        // Update status chart
        if (this.charts.status) {
            this.updateStatusChart(metrics);
        }
    }
    
    updatePerformanceChart(metrics) {
        const chart = this.charts.performance;
        
        // Generate sample hourly data based on total metrics
        const hoursData = this.generateHourlyData(metrics);
        
        chart.data.datasets[0].data = hoursData.total;
        chart.data.datasets[1].data = hoursData.completed;
        chart.data.datasets[2].data = hoursData.failed;
        
        chart.update('none'); // Update without animation for real-time feel
    }
    
    updateStatusChart(metrics) {
        const chart = this.charts.status;
        
        // Calculate corrected sessions (assuming 10% of completed are corrected)
        const correctedSessions = Math.floor(metrics.completed_sessions * 0.1);
        const completedSessions = metrics.completed_sessions - correctedSessions;
        
        chart.data.datasets[0].data = [
            completedSessions,
            correctedSessions,
            metrics.total_sessions - metrics.completed_sessions - metrics.failed_sessions,
            metrics.failed_sessions,
            0 // Retry limit reached (would need to be tracked separately)
        ];
        
        chart.update('none');
    }
    
    generateHourlyData(metrics) {
        const hours = 24;
        const data = {
            total: [],
            completed: [],
            failed: []
        };
        
        // Generate realistic distribution of sessions throughout the day
        for (let i = 0; i < hours; i++) {
            const hour = (new Date().getHours() - (hours - 1 - i) + 24) % 24;
            
            // Simulate business hours pattern (more activity 9-17)
            let multiplier = 0.3; // Base activity
            if (hour >= 9 && hour <= 17) {
                multiplier = 1.0; // Peak activity
            } else if (hour >= 8 && hour <= 19) {
                multiplier = 0.7; // Moderate activity
            }
            
            const totalForHour = Math.floor(metrics.total_sessions * multiplier / 8);
            const completedForHour = Math.floor(totalForHour * (metrics.success_rate / 100));
            const failedForHour = Math.floor(totalForHour * 0.1); // Assume 10% failure rate
            
            data.total.push(totalForHour);
            data.completed.push(completedForHour);
            data.failed.push(failedForHour);
        }
        
        return data;
    }
    
    async refreshMetrics() {
        const timeframe = document.getElementById('timeframeSelect')?.value || '24h';
        await this.loadMetrics(timeframe);
        this.showNotification('Metrics refreshed successfully', 'success');
    }
    
    async changeTimeframe(timeframe) {
        await this.loadMetrics(timeframe);
        this.showNotification(`Timeframe changed to ${timeframe}`, 'info');
    }
    
    async retrySession(sessionId) {
        try {
            const response = await fetch(`/api/sessions/${sessionId}/retry`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const result = await response.json();
            
            if (result.error) {
                throw new Error(result.error);
            }
            
            if (result.success) {
                this.showNotification('Session retry initiated successfully', 'success');
                // Refresh the page to show updated status
                setTimeout(() => window.location.reload(), 1000);
            } else {
                this.showNotification(`Retry failed: ${result.reason}`, 'warning');
            }
            
        } catch (error) {
            console.error('Error retrying session:', error);
            this.showError(`Failed to retry session: ${error.message}`);
        }
    }
    
    filterByStatus(status) {
        const url = new URL(window.location);
        url.searchParams.set('status', status);
        window.location.href = url.toString();
    }
    
    showLoading(show) {
        const loadingElements = document.querySelectorAll('.loading-indicator');
        const refreshBtn = document.querySelector('[onclick="refreshMetrics()"]');
        
        if (show) {
            loadingElements.forEach(el => el.classList.remove('d-none'));
            if (refreshBtn) {
                refreshBtn.disabled = true;
                refreshBtn.innerHTML = '<i data-feather="loader" class="me-2"></i>Loading...';
            }
        } else {
            loadingElements.forEach(el => el.classList.add('d-none'));
            if (refreshBtn) {
                refreshBtn.disabled = false;
                refreshBtn.innerHTML = '<i data-feather="refresh-cw" class="me-2"></i>Refresh';
            }
        }
        
        // Re-initialize feather icons
        if (typeof feather !== 'undefined') {
            feather.replace();
        }
    }
    
    showNotification(message, type = 'info') {
        const alertClass = type === 'error' ? 'danger' : type;
        const iconName = type === 'error' ? 'alert-circle' : 
                        type === 'success' ? 'check-circle' : 
                        type === 'warning' ? 'alert-triangle' : 'info';
        
        const alert = document.createElement('div');
        alert.className = `alert alert-${alertClass} alert-dismissible fade show`;
        alert.innerHTML = `
            <i data-feather="${iconName}" class="me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        // Find container or create one
        let container = document.querySelector('.notification-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'notification-container position-fixed top-0 end-0 p-3';
            container.style.zIndex = '9999';
            document.body.appendChild(container);
        }
        
        container.appendChild(alert);
        
        // Re-initialize feather icons
        if (typeof feather !== 'undefined') {
            feather.replace();
        }
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            if (alert.parentNode) {
                alert.remove();
            }
        }, 5000);
    }
    
    showError(message) {
        this.showNotification(message, 'error');
    }
    
    updateLastUpdateTime() {
        const timeElement = document.getElementById('lastUpdateTime');
        if (timeElement && this.lastUpdateTime) {
            timeElement.textContent = `Last updated: ${this.lastUpdateTime.toLocaleTimeString()}`;
        }
    }
    
    // Utility method to format numbers
    formatNumber(num) {
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        } else if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    }
    
    // Cleanup method
    destroy() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }
        
        // Destroy charts
        Object.values(this.charts).forEach(chart => {
            if (chart && typeof chart.destroy === 'function') {
                chart.destroy();
            }
        });
        
        console.log('Dashboard manager destroyed');
    }
}

// Global functions for backward compatibility
window.refreshMetrics = function() {
    if (window.dashboardManager) {
        window.dashboardManager.refreshMetrics();
    }
};

window.showAttemptDetails = function(attemptNumber, input, output) {
    const modal = document.getElementById('attemptDetailsModal');
    if (modal) {
        const title = modal.querySelector('.modal-title');
        const inputCode = modal.querySelector('#attemptInput code');
        const outputCode = modal.querySelector('#attemptOutput code');
        
        if (title) title.textContent = `Attempt #${attemptNumber} Details`;
        if (inputCode) inputCode.textContent = input;
        if (outputCode) outputCode.textContent = output;
        
        const bootstrapModal = new bootstrap.Modal(modal);
        bootstrapModal.show();
    }
};

// Initialize dashboard manager when script loads
document.addEventListener('DOMContentLoaded', function() {
    window.dashboardManager = new DashboardManager();
});

// Cleanup on page unload
window.addEventListener('beforeunload', function() {
    if (window.dashboardManager) {
        window.dashboardManager.destroy();
    }
});
