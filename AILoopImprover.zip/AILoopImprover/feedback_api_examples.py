"""
Examples of how to use the Feedback Loop API
"""

import requests
import json
from datetime import datetime

# API base URL
BASE_URL = "http://localhost:8000"

def example_evaluate_agent():
    """Example: Evaluate an agent's response"""
    print("=== Evaluating Agent Response ===")
    
    payload = {
        "agent_id": "chatbot_001",
        "input": "What are the benefits of renewable energy?",
        "output": "Renewable energy helps reduce carbon emissions and is sustainable.",
        "expected": "Renewable energy sources like solar and wind reduce greenhouse gas emissions, decrease dependence on fossil fuels, and provide sustainable long-term energy solutions.",
        "method": "autoeval",
        "metrics": ["accuracy", "relevance", "completeness", "fluency"]
    }
    
    try:
        response = requests.post(f"{BASE_URL}/feedback/evaluate", json=payload)
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Evaluation completed!")
            print(f"   Overall Score: {result['overall_score']:.2f}")
            print(f"   Detailed Scores: {result['detailed_scores']}")
            print(f"   Needs Retry: {result['needs_retry']}")
            print(f"   Recommendations: {result['recommendations']}")
            return result['feedback_id'], result['task_id']
        else:
            print(f"❌ Error: {response.status_code} - {response.text}")
            return None, None
    except Exception as e:
        print(f"❌ Exception: {e}")
        return None, None

def example_retry_task(task_id):
    """Example: Retry a task with corrections"""
    print(f"\n=== Retrying Task {task_id} ===")
    
    payload = {
        "agent_id": "chatbot_001",
        "task_id": task_id,
        "strategy": "modify_prompt",
        "last_attempt": {
            "prompt": "What are the benefits of renewable energy?",
            "response": "Renewable energy helps reduce carbon emissions and is sustainable.",
            "error": "Response lacks detail and completeness"
        }
    }
    
    try:
        response = requests.post(f"{BASE_URL}/feedback/retry", json=payload)
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Retry initiated!")
            print(f"   Attempt Number: {result['attempt_number']}")
            print(f"   Strategy Applied: {result['strategy_applied']}")
            print(f"   Corrected Prompt: {result['corrected_prompt']}")
            print(f"   Success: {result['success']}")
            return result['retry_id']
        else:
            print(f"❌ Error: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        print(f"❌ Exception: {e}")
        return None

def example_train_agent():
    """Example: Add training data for agent improvement"""
    print("\n=== Training Agent ===")
    
    payload = {
        "agent_id": "chatbot_001",
        "prompt": "What is machine learning?",
        "bad_response": "ML is about computers learning things.",
        "expected_correction": "Machine learning is a subset of artificial intelligence that enables computers to learn and improve from experience without being explicitly programmed, using algorithms to find patterns in data.",
        "feedback_type": "user_correction"
    }
    
    try:
        response = requests.post(f"{BASE_URL}/feedback/train", json=payload)
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Training data added!")
            print(f"   Training ID: {result['training_id']}")
            print(f"   Status: {result['status']}")
            print(f"   Message: {result['message']}")
            return result['training_id']
        else:
            print(f"❌ Error: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        print(f"❌ Exception: {e}")
        return None

def example_get_feedback_history(agent_id):
    """Example: Get feedback history for an agent"""
    print(f"\n=== Getting Feedback History for {agent_id} ===")
    
    try:
        response = requests.get(f"{BASE_URL}/feedback/history/{agent_id}")
        if response.status_code == 200:
            result = response.json()
            print(f"✅ History retrieved!")
            print(f"   Total Feedbacks: {result['total_feedbacks']}")
            print(f"   Average Score: {result['average_score']:.2f}")
            print(f"   Recent Feedbacks:")
            
            for i, feedback in enumerate(result['feedbacks'][:3]):  # Show first 3
                print(f"     {i+1}. Score: {feedback['overall_score']:.2f} | Status: {feedback['status']}")
                print(f"        Input: {feedback['input'][:50]}...")
                print(f"        Output: {feedback['output'][:50]}...")
                print(f"        Created: {feedback['created_at']}")
                print()
            
            return result
        else:
            print(f"❌ Error: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        print(f"❌ Exception: {e}")
        return None

def example_get_task_status(task_id):
    """Example: Get task status"""
    print(f"\n=== Getting Task Status for {task_id} ===")
    
    try:
        response = requests.get(f"{BASE_URL}/feedback/status/{task_id}")
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Task status retrieved!")
            print(f"   Task ID: {result['task_id']}")
            print(f"   Agent ID: {result['agent_id']}")
            print(f"   Status: {result['status']}")
            print(f"   Current Attempt: {result['current_attempt']}")
            print(f"   Max Attempts: {result['max_attempts']}")
            print(f"   History Entries: {len(result['history'])}")
            
            if result['history']:
                print(f"   Recent Attempts:")
                for attempt in result['history'][:3]:  # Show first 3
                    print(f"     - Attempt {attempt['attempt_number']}: {attempt['strategy']} | Success: {attempt['success']}")
            
            return result
        else:
            print(f"❌ Error: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        print(f"❌ Exception: {e}")
        return None

def example_full_feedback_loop():
    """Example: Complete feedback loop workflow"""
    print("🚀 Starting Complete Feedback Loop Workflow")
    print("=" * 50)
    
    # Step 1: Evaluate agent response
    feedback_id, task_id = example_evaluate_agent()
    if not feedback_id:
        print("❌ Failed to evaluate agent. Stopping workflow.")
        return
    
    # Step 2: Check task status
    task_status = example_get_task_status(task_id)
    if not task_status:
        print("❌ Failed to get task status. Stopping workflow.")
        return
    
    # Step 3: If task needs retry, retry it
    if task_status['status'] == 'retrying':
        retry_id = example_retry_task(task_id)
        if retry_id:
            print(f"✅ Task retried successfully: {retry_id}")
        else:
            print("❌ Failed to retry task.")
    
    # Step 4: Add training data
    training_id = example_train_agent()
    if training_id:
        print(f"✅ Training data added: {training_id}")
    else:
        print("❌ Failed to add training data.")
    
    # Step 5: Get feedback history
    history = example_get_feedback_history("chatbot_001")
    if history:
        print(f"✅ Retrieved {history['total_feedbacks']} feedback entries")
    else:
        print("❌ Failed to get feedback history.")
    
    print("\n🎉 Feedback loop workflow completed!")

def example_batch_evaluation():
    """Example: Batch evaluation of multiple responses"""
    print("\n=== Batch Evaluation Example ===")
    
    test_cases = [
        {
            "input": "What is Python?",
            "output": "Python is a programming language.",
            "expected": "Python is a high-level, interpreted programming language known for its simplicity and readability."
        },
        {
            "input": "How does photosynthesis work?",
            "output": "Plants use sunlight to make food.",
            "expected": "Photosynthesis is the process by which plants convert light energy into chemical energy, using chlorophyll to absorb sunlight and convert CO2 and water into glucose and oxygen."
        },
        {
            "input": "What are the benefits of exercise?",
            "output": "Exercise is good for health and helps you stay fit.",
            "expected": "Regular exercise improves cardiovascular health, strengthens muscles and bones, boosts mental health, helps with weight management, and reduces the risk of chronic diseases."
        }
    ]
    
    results = []
    
    for i, test_case in enumerate(test_cases):
        print(f"\n--- Evaluating Test Case {i+1} ---")
        
        payload = {
            "agent_id": f"batch_agent_{i+1}",
            "input": test_case["input"],
            "output": test_case["output"],
            "expected": test_case["expected"],
            "method": "autoeval",
            "metrics": ["accuracy", "relevance", "completeness"]
        }
        
        try:
            response = requests.post(f"{BASE_URL}/feedback/evaluate", json=payload)
            if response.status_code == 200:
                result = response.json()
                results.append(result)
                print(f"✅ Score: {result['overall_score']:.2f}")
                print(f"   Needs Retry: {result['needs_retry']}")
            else:
                print(f"❌ Error: {response.status_code}")
        except Exception as e:
            print(f"❌ Exception: {e}")
    
    # Summary
    if results:
        avg_score = sum(r['overall_score'] for r in results) / len(results)
        retry_needed = sum(1 for r in results if r['needs_retry'])
        
        print(f"\n📊 Batch Evaluation Summary:")
        print(f"   Total Evaluations: {len(results)}")
        print(f"   Average Score: {avg_score:.2f}")
        print(f"   Retries Needed: {retry_needed}")
        print(f"   Success Rate: {((len(results) - retry_needed) / len(results)) * 100:.1f}%")

def example_health_check():
    """Example: API health check"""
    print("\n=== API Health Check ===")
    
    try:
        response = requests.get(f"{BASE_URL}/health")
        if response.status_code == 200:
            result = response.json()
            print(f"✅ API is healthy!")
            print(f"   Status: {result['status']}")
            print(f"   Timestamp: {result['timestamp']}")
            return True
        else:
            print(f"❌ API is not healthy: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Cannot connect to API: {e}")
        return False

def main():
    """Run all examples"""
    print("🎯 Feedback Loop API Examples")
    print("=" * 50)
    
    # Check if API is running
    if not example_health_check():
        print("❌ API is not running. Please start the FastAPI server first:")
        print("   python -m uvicorn feedback_api:app --host 0.0.0.0 --port 8000")
        return
    
    # Run examples
    try:
        # Individual examples
        example_evaluate_agent()
        example_train_agent()
        example_get_feedback_history("chatbot_001")
        
        # Batch evaluation
        example_batch_evaluation()
        
        # Complete workflow
        example_full_feedback_loop()
        
    except KeyboardInterrupt:
        print("\n\n⚠️  Examples interrupted by user")
    except Exception as e:
        print(f"\n❌ Error running examples: {e}")

if __name__ == "__main__":
    main()