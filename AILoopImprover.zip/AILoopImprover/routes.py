from flask import render_template, request, redirect, url_for, flash, jsonify
from app import app, db
from models import (
    Agent, EvaluationSession, EvaluationStatus, 
    Evaluation, Correction, RetryAttempt, APIKey
)
from evaluation_engine import EvaluationEngine
from correction_engine import CorrectionEngine
from retry_controller import RetryController
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

@app.route('/')
def dashboard():
    """Main dashboard showing system overview"""
    try:
        # Get recent sessions
        recent_sessions = EvaluationSession.query.order_by(
            EvaluationSession.created_at.desc()
        ).limit(10).all()
        
        # Get basic statistics
        total_sessions = EvaluationSession.query.count()
        completed_sessions = EvaluationSession.query.filter(
            EvaluationSession.status.in_([EvaluationStatus.COMPLETED, EvaluationStatus.CORRECTED])
        ).count()
        
        # Get active agents
        active_agents = Agent.query.all()
        
        # Calculate success rate
        success_rate = (completed_sessions / total_sessions * 100) if total_sessions > 0 else 0
        
        return render_template('dashboard.html',
            recent_sessions=recent_sessions,
            total_sessions=total_sessions,
            completed_sessions=completed_sessions,
            success_rate=success_rate,
            active_agents=active_agents
        )
        
    except Exception as e:
        logger.error(f"Error loading dashboard: {str(e)}")
        flash(f'Error loading dashboard: {str(e)}', 'error')
        return render_template('dashboard.html',
            recent_sessions=[],
            total_sessions=0,
            completed_sessions=0,
            success_rate=0,
            active_agents=[]
        )

@app.route('/sessions')
def sessions():
    """List all evaluation sessions"""
    try:
        page = request.args.get('page', 1, type=int)
        status_filter = request.args.get('status')
        agent_filter = request.args.get('agent_id', type=int)
        
        query = EvaluationSession.query
        
        if status_filter:
            try:
                query = query.filter_by(status=EvaluationStatus(status_filter))
            except ValueError:
                flash(f'Invalid status filter: {status_filter}', 'warning')
        
        if agent_filter:
            query = query.filter_by(agent_id=agent_filter)
        
        sessions = query.order_by(EvaluationSession.created_at.desc()).paginate(
            page=page, per_page=20, error_out=False
        )
        
        # Get agents for filter dropdown
        agents = Agent.query.all()
        
        return render_template('sessions.html',
            sessions=sessions,
            agents=agents,
            current_status=status_filter,
            current_agent=agent_filter,
            evaluation_statuses=EvaluationStatus
        )
        
    except Exception as e:
        logger.error(f"Error loading sessions: {str(e)}")
        flash(f'Error loading sessions: {str(e)}', 'error')
        return redirect(url_for('dashboard'))

@app.route('/sessions/<int:session_id>')
def session_detail(session_id):
    """Show detailed view of an evaluation session"""
    try:
        session = EvaluationSession.query.get_or_404(session_id)
        
        # Get evaluations
        evaluations = Evaluation.query.filter_by(session_id=session_id).all()
        
        # Get corrections
        corrections = Correction.query.filter_by(session_id=session_id).order_by(
            Correction.priority.desc(), Correction.created_at.desc()
        ).all()
        
        # Get retry attempts
        retry_attempts = RetryAttempt.query.filter_by(session_id=session_id).order_by(
            RetryAttempt.attempt_number.desc()
        ).all()
        
        return render_template('evaluation_detail.html',
            session=session,
            evaluations=evaluations,
            corrections=corrections,
            retry_attempts=retry_attempts
        )
        
    except Exception as e:
        logger.error(f"Error loading session detail: {str(e)}")
        flash(f'Error loading session detail: {str(e)}', 'error')
        return redirect(url_for('sessions'))

@app.route('/agents')
def agents():
    """List all agents"""
    try:
        agents = Agent.query.order_by(Agent.created_at.desc()).all()
        return render_template('agents.html', agents=agents)
    except Exception as e:
        logger.error(f"Error loading agents: {str(e)}")
        flash(f'Error loading agents: {str(e)}', 'error')
        return redirect(url_for('dashboard'))

@app.route('/agents/new', methods=['GET', 'POST'])
def new_agent():
    """Create a new agent"""
    if request.method == 'POST':
        try:
            name = request.form.get('name')
            description = request.form.get('description', '')
            api_endpoint = request.form.get('api_endpoint', '')
            
            if not name:
                flash('Agent name is required', 'error')
                return render_template('agent_form.html')
            
            agent = Agent(
                name=name,
                description=description,
                api_endpoint=api_endpoint
            )
            
            db.session.add(agent)
            db.session.commit()
            
            flash(f'Agent "{name}" created successfully', 'success')
            return redirect(url_for('agents'))
            
        except Exception as e:
            logger.error(f"Error creating agent: {str(e)}")
            db.session.rollback()
            flash(f'Error creating agent: {str(e)}', 'error')
    
    return render_template('agent_form.html')

@app.route('/evaluate', methods=['GET', 'POST'])
def evaluate():
    """Manual evaluation form"""
    if request.method == 'POST':
        try:
            agent_id = request.form.get('agent_id', type=int)
            input_text = request.form.get('input_text')
            output_text = request.form.get('output_text')
            max_retries = request.form.get('max_retries', 3, type=int)
            
            if not all([agent_id, input_text, output_text]):
                flash('All fields are required', 'error')
                return render_template('evaluate_form.html', agents=Agent.query.all())
            
            agent = Agent.query.get(agent_id)
            if not agent:
                flash('Selected agent not found', 'error')
                return render_template('evaluate_form.html', agents=Agent.query.all())
            
            # Create evaluation session
            session = EvaluationSession(
                agent_id=agent_id,
                original_input=input_text,
                original_output=output_text,
                max_retries=max_retries
            )
            
            db.session.add(session)
            db.session.commit()
            
            flash(f'Evaluation started for session {session.id}', 'success')
            return redirect(url_for('session_detail', session_id=session.id))
            
        except Exception as e:
            logger.error(f"Error starting evaluation: {str(e)}")
            db.session.rollback()
            flash(f'Error starting evaluation: {str(e)}', 'error')
    
    agents = Agent.query.all()
    return render_template('evaluate_form.html', agents=agents)

@app.route('/sessions/<int:session_id>/retry', methods=['POST'])
def retry_session(session_id):
    """Manually trigger retry for a session"""
    try:
        retry_controller = RetryController()
        result = retry_controller.initiate_retry_cycle(session_id)
        
        if result['success']:
            flash('Retry initiated successfully', 'success')
        else:
            flash(f'Retry failed: {result.get("reason", "Unknown error")}', 'error')
        
        return redirect(url_for('session_detail', session_id=session_id))
        
    except Exception as e:
        logger.error(f"Error retrying session: {str(e)}")
        flash(f'Error retrying session: {str(e)}', 'error')
        return redirect(url_for('session_detail', session_id=session_id))

@app.route('/sessions/<int:session_id>/cancel', methods=['POST'])
def cancel_session(session_id):
    """Cancel a session and its scheduled retries"""
    try:
        session = EvaluationSession.query.get_or_404(session_id)
        
        # Cancel scheduled retries
        retry_controller = RetryController()
        retry_controller.cancel_scheduled_retries(session_id)
        
        # Update session status
        session.status = EvaluationStatus.FAILED
        session.completed_at = datetime.utcnow()
        db.session.commit()
        
        flash('Session cancelled successfully', 'success')
        return redirect(url_for('session_detail', session_id=session_id))
        
    except Exception as e:
        logger.error(f"Error cancelling session: {str(e)}")
        flash(f'Error cancelling session: {str(e)}', 'error')
        return redirect(url_for('session_detail', session_id=session_id))

@app.route('/sessions/<int:session_id>/corrections/generate', methods=['POST'])
def generate_corrections(session_id):
    """Generate corrections for a session"""
    try:
        correction_engine = CorrectionEngine()
        result = correction_engine.generate_corrections(session_id)
        
        flash(f'Generated {result["corrections_generated"]} corrections', 'success')
        return redirect(url_for('session_detail', session_id=session_id))
        
    except Exception as e:
        logger.error(f"Error generating corrections: {str(e)}")
        flash(f'Error generating corrections: {str(e)}', 'error')
        return redirect(url_for('session_detail', session_id=session_id))

@app.route('/metrics')
def metrics():
    """Show system metrics and analytics"""
    try:
        # Get timeframe from query parameter
        timeframe = request.args.get('timeframe', '24h')
        
        # This would typically fetch from the metrics API
        # For now, redirect to dashboard
        return redirect(url_for('dashboard'))
        
    except Exception as e:
        logger.error(f"Error loading metrics: {str(e)}")
        flash(f'Error loading metrics: {str(e)}', 'error')
        return redirect(url_for('dashboard'))

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500

@app.route('/api-keys')
def api_keys():
    """API Keys management page"""
    return render_template('api_keys.html')
