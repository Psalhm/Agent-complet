"""
FastAPI Main Entry Point for Feedback Loop API
"""

import uvicorn
from feedback_api import app

if __name__ == "__main__":
    # Run the FastAPI application
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=8000, 
        reload=True,
        log_level="info"
    )