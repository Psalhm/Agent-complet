"""
FastAPI API for Multi-Agent System Intelligent Logging
Provides REST endpoints for accessing logs and metrics data.
"""

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import json
import os
from datetime import datetime
from pathlib import Path
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Multi-Agent System Logs API",
    description="API for accessing intelligent logging data from multi-agent systems",
    version="1.0.0"
)

# Configuration
LOGS_DIR = Path("logs")
AGENT_LOG_FILE = LOGS_DIR / "agent.log"
AGENT_EVENTS_FILE = LOGS_DIR / "agent_events.jsonl"
METRICS_FILE = LOGS_DIR / "metrics.json"

# Pydantic models
class AnnotationRequest(BaseModel):
    log_id: str
    annotation: str
    tags: Optional[List[str]] = None

class LogsAPIService:
    """Service class for handling logs and metrics operations."""
    
    def __init__(self, logs_dir: str = "logs"):
        self.logs_dir = Path(logs_dir)
        self.agent_log_file = self.logs_dir / "agent.log"
        self.agent_events_file = self.logs_dir / "agent_events.jsonl"
        self.metrics_file = self.logs_dir / "metrics.json"
        
    def read_raw_logs(self, agent_filter: Optional[str] = None, 
                     level_filter: Optional[str] = None,
                     limit: int = 1000) -> List[Dict[str, Any]]:
        """Read and filter raw logs from agent.log file."""
        logs = []
        
        if not self.agent_log_file.exists():
            return logs
            
        try:
            with open(self.agent_log_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                
            for line in lines[-limit:]:  # Get last N lines
                line = line.strip()
                if not line:
                    continue
                    
                parsed_log = self._parse_log_line(line)
                if parsed_log:
                    # Apply filters
                    if agent_filter and agent_filter.lower() not in parsed_log.get('message', '').lower():
                        continue
                    if level_filter and parsed_log.get('level', '').upper() != level_filter.upper():
                        continue
                        
                    logs.append(parsed_log)
                    
        except Exception as e:
            logger.error(f"Error reading logs: {e}")
            
        return logs
    
    def read_jsonl_events(self, agent_filter: Optional[str] = None,
                         limit: int = 1000) -> List[Dict[str, Any]]:
        """Read structured events from agent_events.jsonl file."""
        events = []
        
        if not self.agent_events_file.exists():
            return events
            
        try:
            with open(self.agent_events_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                
            for line in lines[-limit:]:  # Get last N lines
                line = line.strip()
                if not line:
                    continue
                    
                try:
                    event = json.loads(line)
                    
                    # Apply agent filter
                    if agent_filter:
                        sender = event.get('sender', '').lower()
                        recipient = event.get('recipient', '').lower()
                        if (agent_filter.lower() not in sender and 
                            agent_filter.lower() not in recipient):
                            continue
                            
                    events.append(event)
                except json.JSONDecodeError:
                    continue
                    
        except Exception as e:
            logger.error(f"Error reading events: {e}")
            
        return events
    
    def read_metrics(self) -> Dict[str, Any]:
        """Read metrics from metrics.json file."""
        if not self.metrics_file.exists():
            return {}
            
        try:
            with open(self.metrics_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error reading metrics: {e}")
            return {}
    
    def get_agent_metrics(self, agent_id: str) -> Dict[str, Any]:
        """Get metrics for a specific agent."""
        all_metrics = self.read_metrics()
        agents_data = all_metrics.get('agent_metrics', {})
        
        if agent_id not in agents_data:
            return {}
            
        agent_data = agents_data[agent_id]
        
        # Return formatted agent metrics
        return {
            'agent_id': agent_id,
            'messages_sent': agent_data.get('messages_sent', 0),
            'messages_received': agent_data.get('messages_received', 0),
            'successful_actions': agent_data.get('successful_actions', 0),
            'failed_actions': agent_data.get('failed_actions', 0),
            'total_actions': agent_data.get('total_actions', 0),
            'reliability_score': agent_data.get('reliability_score', 0.0),
            'first_activity': agent_data.get('first_activity'),
            'last_activity': agent_data.get('last_activity')
        }
    
    def add_log_annotation(self, log_id: str, annotation: str, 
                          tags: Optional[List[str]] = None) -> Dict[str, Any]:
        """Add annotation to a log entry."""
        # Create annotations file if it doesn't exist
        annotations_file = self.logs_dir / "annotations.json"
        
        # Read existing annotations
        annotations = {}
        if annotations_file.exists():
            try:
                with open(annotations_file, 'r', encoding='utf-8') as f:
                    annotations = json.load(f)
            except Exception as e:
                logger.error(f"Error reading annotations: {e}")
        
        # Add new annotation
        annotation_entry = {
            'annotation': annotation,
            'tags': tags or [],
            'timestamp': datetime.now().isoformat(),
            'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        annotations[log_id] = annotation_entry
        
        # Save annotations
        try:
            with open(annotations_file, 'w', encoding='utf-8') as f:
                json.dump(annotations, f, indent=2)
            return annotation_entry
        except Exception as e:
            logger.error(f"Error saving annotation: {e}")
            raise HTTPException(status_code=500, detail="Failed to save annotation")
    
    def check_health(self) -> Dict[str, Any]:
        """Check the health of the logging system."""
        health_status = {
            'logging_ok': True,
            'timestamp': datetime.now().isoformat(),
            'checks': {
                'logs_directory_exists': self.logs_dir.exists(),
                'agent_log_exists': self.agent_log_file.exists(),
                'agent_events_exists': self.agent_events_file.exists(),
                'metrics_exists': self.metrics_file.exists()
            }
        }
        
        # Check if we can read files
        try:
            if self.metrics_file.exists():
                self.read_metrics()
            if self.agent_log_file.exists():
                self.read_raw_logs(limit=1)
            if self.agent_events_file.exists():
                self.read_jsonl_events(limit=1)
        except Exception as e:
            health_status['logging_ok'] = False
            health_status['error'] = str(e)
            
        return health_status
    
    def _parse_log_line(self, line: str) -> Optional[Dict[str, Any]]:
        """Parse a single log line into structured data."""
        try:
            # Expected format: "2025-07-09 13:32:16 - INFO - [SUCCESS] agent -> recipient | Action: ACTION | Payload: data"
            parts = line.split(' - ', 2)
            if len(parts) < 3:
                return None
                
            timestamp = parts[0]
            level = parts[1]
            message = parts[2]
            
            return {
                'timestamp': timestamp,
                'level': level,
                'message': message,
                'raw': line
            }
        except Exception:
            return None

# Initialize service
logs_service = LogsAPIService()

@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "name": "Multi-Agent System Logs API",
        "version": "1.0.0",
        "description": "API for accessing intelligent logging data",
        "endpoints": {
            "logs": "/logs/raw",
            "metrics": "/metrics",
            "agent_metrics": "/metrics/{agent_id}",
            "annotate": "/logs/annotate",
            "health": "/health"
        }
    }

@app.get("/logs/raw")
async def get_raw_logs(
    agent: Optional[str] = Query(None, description="Filter by agent name"),
    level: Optional[str] = Query(None, description="Filter by log level (INFO, ERROR, etc.)"),
    limit: int = Query(1000, description="Maximum number of logs to return"),
    format: str = Query("log", description="Format: 'log' for .log file, 'jsonl' for structured events")
):
    """Get raw logs with optional filtering."""
    try:
        if format.lower() == "jsonl":
            logs = logs_service.read_jsonl_events(agent_filter=agent, limit=limit)
        else:
            logs = logs_service.read_raw_logs(agent_filter=agent, level_filter=level, limit=limit)
        
        return {
            "success": True,
            "count": len(logs),
            "data": logs,
            "filters": {
                "agent": agent,
                "level": level,
                "format": format
            },
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting raw logs: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/metrics")
async def get_metrics():
    """Get complete metrics from metrics.json file."""
    try:
        metrics = logs_service.read_metrics()
        
        if not metrics:
            return {
                "success": False,
                "message": "No metrics data available",
                "timestamp": datetime.now().isoformat()
            }
        
        return {
            "success": True,
            "data": metrics,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/metrics/{agent_id}")
async def get_agent_metrics(agent_id: str):
    """Get metrics for a specific agent."""
    try:
        agent_metrics = logs_service.get_agent_metrics(agent_id)
        
        if not agent_metrics:
            raise HTTPException(
                status_code=404, 
                detail=f"Agent '{agent_id}' not found or no metrics available"
            )
        
        return {
            "success": True,
            "data": agent_metrics,
            "timestamp": datetime.now().isoformat()
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting agent metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/logs/annotate")
async def annotate_log(request: AnnotationRequest):
    """Add annotation to a log entry."""
    try:
        result = logs_service.add_log_annotation(request.log_id, request.annotation, request.tags)
        
        return {
            "success": True,
            "message": "Annotation added successfully",
            "data": result,
            "timestamp": datetime.now().isoformat()
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error adding annotation: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    """Check the health of the logging system."""
    try:
        health_status = logs_service.check_health()
        
        if not health_status['logging_ok']:
            return JSONResponse(
                status_code=503,
                content=health_status
            )
        
        return health_status
    except Exception as e:
        logger.error(f"Error checking health: {e}")
        return JSONResponse(
            status_code=503,
            content={
                "logging_ok": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)