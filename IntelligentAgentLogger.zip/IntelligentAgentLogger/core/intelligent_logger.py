"""
Intelligent Logger for Multi-Agent Systems
Provides comprehensive logging and metrics tracking for agent interactions.
"""

import json
import logging
import os
import datetime
from collections import defaultdict, Counter
from pathlib import Path
from typing import Dict, Any, Optional, List


class IntelligentLogger:
    """
    Intelligent logging system for multi-agent communications.
    Tracks all interactions, generates metrics, and provides dual-format logging.
    """
    
    def __init__(self, log_dir: str = "logs"):
        """
        Initialize the intelligent logger.
        
        Args:
            log_dir: Directory where log files will be stored
        """
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)
        
        # Initialize metrics tracking
        self.agent_metrics = defaultdict(lambda: {
            'messages_sent': 0,
            'messages_received': 0,
            'successful_actions': 0,
            'failed_actions': 0,
            'total_actions': 0,
            'reliability_score': 0.0,
            'first_activity': None,
            'last_activity': None
        })
        
        # Message counters
        self.message_counter = Counter()
        self.action_counter = Counter()
        
        # Setup logging handlers
        self._setup_logging()
    
    def _setup_logging(self):
        """Setup dual-format logging (human-readable and JSON)."""
        # Create formatters
        human_formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # Setup human-readable log file
        self.human_logger = logging.getLogger('agent_human')
        self.human_logger.setLevel(logging.INFO)
        
        human_handler = logging.FileHandler(self.log_dir / 'agent.log')
        human_handler.setFormatter(human_formatter)
        self.human_logger.addHandler(human_handler)
        
        # Setup console handler
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(human_formatter)
        self.human_logger.addHandler(console_handler)
        
        # JSON log file handler (we'll write directly to this)
        self.json_log_path = self.log_dir / 'agent_events.jsonl'
        
        # Clear existing logs on startup
        if self.json_log_path.exists():
            self.json_log_path.unlink()
    
    def log_message(self, 
                   sender: str, 
                   recipient: str, 
                   action_type: str, 
                   payload: Any, 
                   status: str = "SENT",
                   error_details: Optional[str] = None):
        """
        Log a message between agents.
        
        Args:
            sender: Agent sending the message
            recipient: Agent receiving the message
            action_type: Type of action being performed
            payload: Message payload/data
            status: Message status (SENT, SUCCESS, ERROR)
            error_details: Error details if status is ERROR
        """
        timestamp = datetime.datetime.now().isoformat()
        
        # Update metrics
        self._update_metrics(sender, recipient, action_type, status, timestamp)
        
        # Create log entry
        log_entry = {
            'timestamp': timestamp,
            'sender': sender,
            'recipient': recipient,
            'action_type': action_type,
            'payload': self._serialize_payload(payload),
            'status': status,
            'message_id': self._generate_message_id(sender, recipient, timestamp)
        }
        
        if error_details:
            log_entry['error_details'] = error_details
        
        # Write to JSON log
        self._write_json_log(log_entry)
        
        # Write to human-readable log
        self._write_human_log(log_entry, error_details)
    
    def _update_metrics(self, sender: str, recipient: str, action_type: str, 
                       status: str, timestamp: str):
        """Update agent metrics based on logged action."""
        # Update sender metrics
        sender_metrics = self.agent_metrics[sender]
        sender_metrics['messages_sent'] += 1
        sender_metrics['total_actions'] += 1
        
        if status == "SUCCESS":
            sender_metrics['successful_actions'] += 1
        elif status == "ERROR":
            sender_metrics['failed_actions'] += 1
        
        # Update recipient metrics
        recipient_metrics = self.agent_metrics[recipient]
        recipient_metrics['messages_received'] += 1
        
        # Update timestamps
        for agent in [sender, recipient]:
            metrics = self.agent_metrics[agent]
            if metrics['first_activity'] is None:
                metrics['first_activity'] = timestamp
            metrics['last_activity'] = timestamp
        
        # Update counters
        self.message_counter[f"{sender}->{recipient}"] += 1
        self.action_counter[action_type] += 1
        
        # Calculate reliability scores
        self._calculate_reliability_scores()
    
    def _calculate_reliability_scores(self):
        """Calculate reliability scores for all agents."""
        for agent, metrics in self.agent_metrics.items():
            if metrics['total_actions'] > 0:
                metrics['reliability_score'] = (
                    metrics['successful_actions'] / metrics['total_actions']
                ) * 100
            else:
                metrics['reliability_score'] = 0.0
    
    def _serialize_payload(self, payload: Any) -> Any:
        """Serialize payload for JSON logging."""
        try:
            json.dumps(payload)
            return payload
        except (TypeError, ValueError):
            return str(payload)
    
    def _generate_message_id(self, sender: str, recipient: str, timestamp: str) -> str:
        """Generate unique message ID."""
        return f"{sender}_{recipient}_{timestamp.replace(':', '').replace('-', '').replace('.', '')}"
    
    def _write_json_log(self, log_entry: Dict[str, Any]):
        """Write log entry to JSON lines file."""
        with open(self.json_log_path, 'a') as f:
            f.write(json.dumps(log_entry) + '\n')
    
    def _write_human_log(self, log_entry: Dict[str, Any], error_details: Optional[str]):
        """Write log entry to human-readable log."""
        message = (
            f"[{log_entry['status']}] {log_entry['sender']} -> {log_entry['recipient']} "
            f"| Action: {log_entry['action_type']} | Payload: {log_entry['payload']}"
        )
        
        if error_details:
            message += f" | Error: {error_details}"
        
        if log_entry['status'] == "ERROR":
            self.human_logger.error(message)
        else:
            self.human_logger.info(message)
    
    def log_agent_action(self, agent_name: str, action: str, details: Any, 
                        success: bool = True, error: Optional[str] = None):
        """
        Log an internal agent action.
        
        Args:
            agent_name: Name of the agent
            action: Action being performed
            details: Action details
            success: Whether the action was successful
            error: Error details if action failed
        """
        status = "SUCCESS" if success else "ERROR"
        self.log_message(
            sender=agent_name,
            recipient="INTERNAL",
            action_type=action,
            payload=details,
            status=status,
            error_details=error
        )
    
    def get_agent_metrics(self, agent_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Get metrics for a specific agent or all agents.
        
        Args:
            agent_name: Name of specific agent, or None for all agents
            
        Returns:
            Dictionary containing agent metrics
        """
        if agent_name:
            return dict(self.agent_metrics.get(agent_name, {}))
        else:
            return {agent: dict(metrics) for agent, metrics in self.agent_metrics.items()}
    
    def get_system_metrics(self) -> Dict[str, Any]:
        """Get overall system metrics."""
        total_messages = sum(self.message_counter.values())
        total_actions = sum(count for metrics in self.agent_metrics.values() 
                           for count in [metrics['total_actions']])
        total_successful = sum(metrics['successful_actions'] 
                             for metrics in self.agent_metrics.values())
        total_failed = sum(metrics['failed_actions'] 
                          for metrics in self.agent_metrics.values())
        
        return {
            'total_messages': total_messages,
            'total_actions': total_actions,
            'total_successful_actions': total_successful,
            'total_failed_actions': total_failed,
            'overall_reliability': (total_successful / total_actions * 100) if total_actions > 0 else 0.0,
            'active_agents': len(self.agent_metrics),
            'message_distribution': dict(self.message_counter),
            'action_distribution': dict(self.action_counter),
            'agent_metrics': self.get_agent_metrics()
        }
    
    def generate_metrics_report(self) -> str:
        """Generate a comprehensive metrics report."""
        metrics = self.get_system_metrics()
        
        report = []
        report.append("=" * 60)
        report.append("MULTI-AGENT SYSTEM METRICS REPORT")
        report.append("=" * 60)
        report.append(f"Generated at: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append("")
        
        # System overview
        report.append("SYSTEM OVERVIEW:")
        report.append(f"  Total Messages: {metrics['total_messages']}")
        report.append(f"  Total Actions: {metrics['total_actions']}")
        report.append(f"  Successful Actions: {metrics['total_successful_actions']}")
        report.append(f"  Failed Actions: {metrics['total_failed_actions']}")
        report.append(f"  Overall Reliability: {metrics['overall_reliability']:.2f}%")
        report.append(f"  Active Agents: {metrics['active_agents']}")
        report.append("")
        
        # Agent details
        report.append("AGENT DETAILS:")
        for agent, agent_metrics in metrics['agent_metrics'].items():
            report.append(f"  {agent}:")
            report.append(f"    Messages Sent: {agent_metrics['messages_sent']}")
            report.append(f"    Messages Received: {agent_metrics['messages_received']}")
            report.append(f"    Successful Actions: {agent_metrics['successful_actions']}")
            report.append(f"    Failed Actions: {agent_metrics['failed_actions']}")
            report.append(f"    Reliability Score: {agent_metrics['reliability_score']:.2f}%")
            report.append(f"    First Activity: {agent_metrics['first_activity']}")
            report.append(f"    Last Activity: {agent_metrics['last_activity']}")
            report.append("")
        
        # Message distribution
        if metrics['message_distribution']:
            report.append("MESSAGE DISTRIBUTION:")
            for route, count in metrics['message_distribution'].items():
                report.append(f"  {route}: {count} messages")
            report.append("")
        
        # Action distribution
        if metrics['action_distribution']:
            report.append("ACTION DISTRIBUTION:")
            for action, count in metrics['action_distribution'].items():
                report.append(f"  {action}: {count} times")
            report.append("")
        
        report.append("=" * 60)
        return "\n".join(report)
    
    def save_metrics_json(self):
        """Save metrics to JSON file."""
        metrics = self.get_system_metrics()
        metrics_file = self.log_dir / 'metrics.json'
        
        with open(metrics_file, 'w') as f:
            json.dump(metrics, f, indent=2, default=str)
        
        self.human_logger.info(f"Metrics saved to {metrics_file}")
    
    def print_summary(self):
        """Print a summary of the logging session."""
        print(self.generate_metrics_report())
        self.save_metrics_json()
