"""
Base Agent Class for Multi-Agent System
"""

from typing import Any, Dict, Optional
from .message_bus import MessageBus


class BaseAgent:
    """
    Base class for all agents in the multi-agent system.
    Provides common functionality and message handling.
    """
    
    def __init__(self, name: str, message_bus: Optional[MessageBus] = None):
        """
        Initialize the base agent.
        
        Args:
            name: Unique name for the agent
            message_bus: Message bus for communication
        """
        self.name = name
        self.message_bus = message_bus
        self.state = "IDLE"
        self.message_history = []
        
        # Register with message bus if provided
        if self.message_bus:
            self.message_bus.register_agent(self.name, self)
    
    def receive_message(self, sender: str, message_type: str, payload: Any) -> bool:
        """
        Receive and process a message from another agent.
        
        Args:
            sender: Name of sending agent
            message_type: Type of message
            payload: Message payload
            
        Returns:
            True if message was processed successfully
        """
        try:
            # Store message in history
            self.message_history.append({
                'sender': sender,
                'message_type': message_type,
                'payload': payload,
                'timestamp': self._get_timestamp()
            })
            
            # Process message based on type
            return self._process_message(sender, message_type, payload)
            
        except Exception as e:
            if self.message_bus:
                self.message_bus.get_logger().log_agent_action(
                    agent_name=self.name,
                    action="RECEIVE_MESSAGE_ERROR",
                    details={"sender": sender, "message_type": message_type, "error": str(e)},
                    success=False,
                    error=str(e)
                )
            return False
    
    def send_message(self, recipient: str, message_type: str, payload: Any) -> bool:
        """
        Send a message to another agent.
        
        Args:
            recipient: Name of receiving agent
            message_type: Type of message
            payload: Message payload
            
        Returns:
            True if message was sent successfully
        """
        if not self.message_bus:
            return False
            
        return self.message_bus.send_message(
            sender=self.name,
            recipient=recipient,
            message_type=message_type,
            payload=payload
        )
    
    def broadcast_message(self, message_type: str, payload: Any) -> int:
        """
        Broadcast a message to all other agents.
        
        Args:
            message_type: Type of message
            payload: Message payload
            
        Returns:
            Number of agents that received the message
        """
        if not self.message_bus:
            return 0
            
        return self.message_bus.broadcast_message(
            sender=self.name,
            message_type=message_type,
            payload=payload
        )
    
    def _process_message(self, sender: str, message_type: str, payload: Any) -> bool:
        """
        Process a received message. Override in subclasses.
        
        Args:
            sender: Name of sending agent
            message_type: Type of message
            payload: Message payload
            
        Returns:
            True if message was processed successfully
        """
        # Default implementation - just log the message
        if self.message_bus:
            self.message_bus.get_logger().log_agent_action(
                agent_name=self.name,
                action="PROCESS_MESSAGE",
                details={
                    "sender": sender,
                    "message_type": message_type,
                    "payload": payload
                },
                success=True
            )
        return True
    
    def _get_timestamp(self) -> str:
        """Get current timestamp."""
        import datetime
        return datetime.datetime.now().isoformat()
    
    def get_state(self) -> str:
        """Get current agent state."""
        return self.state
    
    def set_state(self, new_state: str):
        """Set agent state."""
        old_state = self.state
        self.state = new_state
        
        if self.message_bus:
            self.message_bus.get_logger().log_agent_action(
                agent_name=self.name,
                action="STATE_CHANGE",
                details={"old_state": old_state, "new_state": new_state},
                success=True
            )
    
    def get_message_history(self) -> list:
        """Get message history."""
        return self.message_history.copy()


class CoordinatorAgent(BaseAgent):
    """
    Coordinator agent that manages other agents and workflows.
    """
    
    def __init__(self, name: str, message_bus: Optional[MessageBus] = None):
        super().__init__(name, message_bus)
        self.managed_agents = []
        self.tasks = []
    
    def _process_message(self, sender: str, message_type: str, payload: Any) -> bool:
        """Process coordinator-specific messages."""
        if message_type == "TASK_REQUEST":
            return self._handle_task_request(sender, payload)
        elif message_type == "TASK_COMPLETE":
            return self._handle_task_complete(sender, payload)
        elif message_type == "AGENT_REGISTER":
            return self._handle_agent_register(sender, payload)
        else:
            return super()._process_message(sender, message_type, payload)
    
    def _handle_task_request(self, sender: str, task_data: Any) -> bool:
        """Handle task request from an agent."""
        self.tasks.append({
            'requester': sender,
            'task_data': task_data,
            'status': 'PENDING',
            'timestamp': self._get_timestamp()
        })
        
        # Acknowledge task
        self.send_message(sender, "TASK_ACKNOWLEDGED", {
            'task_id': len(self.tasks) - 1,
            'status': 'PENDING'
        })
        
        return True
    
    def _handle_task_complete(self, sender: str, task_result: Any) -> bool:
        """Handle task completion notification."""
        # Log task completion
        if self.message_bus:
            self.message_bus.get_logger().log_agent_action(
                agent_name=self.name,
                action="TASK_COMPLETED",
                details={
                    "completed_by": sender,
                    "result": task_result
                },
                success=True
            )
        return True
    
    def _handle_agent_register(self, sender: str, agent_info: Any) -> bool:
        """Handle agent registration."""
        if sender not in self.managed_agents:
            self.managed_agents.append(sender)
            
        self.send_message(sender, "REGISTRATION_CONFIRMED", {
            'agent_name': sender,
            'coordinator': self.name
        })
        
        return True


class ComputeAgent(BaseAgent):
    """
    Compute agent that performs calculations and data processing.
    """
    
    def __init__(self, name: str, message_bus: Optional[MessageBus] = None):
        super().__init__(name, message_bus)
        self.computation_history = []
    
    def _process_message(self, sender: str, message_type: str, payload: Any) -> bool:
        """Process compute-specific messages."""
        if message_type == "COMPUTE_REQUEST":
            return self._handle_compute_request(sender, payload)
        elif message_type == "DATA_PROCESS":
            return self._handle_data_process(sender, payload)
        else:
            return super()._process_message(sender, message_type, payload)
    
    def _handle_compute_request(self, sender: str, compute_data: Any) -> bool:
        """Handle computation request."""
        try:
            # Simulate computation
            if isinstance(compute_data, dict) and 'operation' in compute_data:
                operation = compute_data['operation']
                if operation == 'add':
                    result = compute_data.get('a', 0) + compute_data.get('b', 0)
                elif operation == 'multiply':
                    result = compute_data.get('a', 1) * compute_data.get('b', 1)
                else:
                    result = f"Unknown operation: {operation}"
                
                # Store computation
                self.computation_history.append({
                    'requester': sender,
                    'operation': operation,
                    'input': compute_data,
                    'result': result,
                    'timestamp': self._get_timestamp()
                })
                
                # Send result back
                self.send_message(sender, "COMPUTE_RESULT", {
                    'operation': operation,
                    'result': result,
                    'input': compute_data
                })
                
                return True
            else:
                raise ValueError("Invalid compute request format")
                
        except Exception as e:
            # Send error back
            self.send_message(sender, "COMPUTE_ERROR", {
                'error': str(e),
                'input': compute_data
            })
            return False
    
    def _handle_data_process(self, sender: str, data: Any) -> bool:
        """Handle data processing request."""
        try:
            # Simulate data processing
            processed_data = {
                'original': data,
                'processed': f"Processed: {data}",
                'processor': self.name,
                'timestamp': self._get_timestamp()
            }
            
            self.send_message(sender, "DATA_PROCESSED", processed_data)
            return True
            
        except Exception as e:
            self.send_message(sender, "DATA_ERROR", {
                'error': str(e),
                'input': data
            })
            return False
