"""
Message Bus for Multi-Agent System with Intelligent Logging Integration
"""

from typing import Dict, Any, Callable, Optional
from .intelligent_logger import IntelligentLogger


class MessageBus:
    """
    Message bus for coordinating communication between agents.
    Integrates with IntelligentLogger for comprehensive tracking.
    """
    
    def __init__(self, logger: Optional[IntelligentLogger] = None):
        """
        Initialize the message bus.
        
        Args:
            logger: IntelligentLogger instance for tracking communications
        """
        self.agents: Dict[str, Any] = {}
        self.message_handlers: Dict[str, Callable] = {}
        self.logger = logger or IntelligentLogger()
    
    def register_agent(self, agent_name: str, agent_instance: Any):
        """
        Register an agent with the message bus.
        
        Args:
            agent_name: Unique name for the agent
            agent_instance: Agent instance
        """
        self.agents[agent_name] = agent_instance
        self.logger.log_agent_action(
            agent_name=agent_name,
            action="REGISTER",
            details={"agent_type": type(agent_instance).__name__},
            success=True
        )
    
    def register_handler(self, message_type: str, handler: Callable):
        """
        Register a message handler for a specific message type.
        
        Args:
            message_type: Type of message to handle
            handler: Handler function
        """
        self.message_handlers[message_type] = handler
    
    def send_message(self, sender: str, recipient: str, message_type: str, 
                    payload: Any) -> bool:
        """
        Send a message from one agent to another.
        
        Args:
            sender: Name of sending agent
            recipient: Name of receiving agent
            message_type: Type of message
            payload: Message payload
            
        Returns:
            True if message was sent successfully, False otherwise
        """
        try:
            # Log message as SENT
            self.logger.log_message(
                sender=sender,
                recipient=recipient,
                action_type=message_type,
                payload=payload,
                status="SENT"
            )
            
            # Check if recipient exists
            if recipient not in self.agents:
                error_msg = f"Recipient agent '{recipient}' not found"
                self.logger.log_message(
                    sender=sender,
                    recipient=recipient,
                    action_type=message_type,
                    payload=payload,
                    status="ERROR",
                    error_details=error_msg
                )
                return False
            
            # Get recipient agent
            recipient_agent = self.agents[recipient]
            
            # Try to deliver message
            if hasattr(recipient_agent, 'receive_message'):
                result = recipient_agent.receive_message(sender, message_type, payload)
                
                # Log success
                self.logger.log_message(
                    sender=sender,
                    recipient=recipient,
                    action_type=message_type,
                    payload=payload,
                    status="SUCCESS"
                )
                return True
            else:
                error_msg = f"Recipient agent '{recipient}' does not have receive_message method"
                self.logger.log_message(
                    sender=sender,
                    recipient=recipient,
                    action_type=message_type,
                    payload=payload,
                    status="ERROR",
                    error_details=error_msg
                )
                return False
                
        except Exception as e:
            # Log error
            self.logger.log_message(
                sender=sender,
                recipient=recipient,
                action_type=message_type,
                payload=payload,
                status="ERROR",
                error_details=str(e)
            )
            return False
    
    def broadcast_message(self, sender: str, message_type: str, payload: Any, 
                         exclude_sender: bool = True) -> int:
        """
        Broadcast a message to all registered agents.
        
        Args:
            sender: Name of sending agent
            message_type: Type of message
            payload: Message payload
            exclude_sender: Whether to exclude sender from broadcast
            
        Returns:
            Number of agents that received the message successfully
        """
        successful_sends = 0
        
        for agent_name in self.agents:
            if exclude_sender and agent_name == sender:
                continue
                
            if self.send_message(sender, agent_name, message_type, payload):
                successful_sends += 1
        
        return successful_sends
    
    def get_logger(self) -> IntelligentLogger:
        """Get the intelligent logger instance."""
        return self.logger
    
    def get_registered_agents(self) -> Dict[str, Any]:
        """Get all registered agents."""
        return self.agents.copy()
