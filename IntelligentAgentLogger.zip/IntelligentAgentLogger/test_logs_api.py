"""
Test suite for the Multi-Agent System Logs API
Tests all endpoints and validates functionality.
"""

import pytest
import json
import os
from fastapi.testclient import TestClient
from pathlib import Path
import tempfile
import shutil
from datetime import datetime

# Import the FastAPI app
from logs_api import app, LogsAPIService

class TestLogsAPI:
    """Test class for the Logs API endpoints."""
    
    @pytest.fixture(scope="class")
    def client(self):
        """Create a test client for the FastAPI app."""
        return TestClient(app)
    
    @pytest.fixture(scope="class")
    def temp_logs_dir(self):
        """Create a temporary logs directory with test data."""
        temp_dir = tempfile.mkdtemp()
        logs_dir = Path(temp_dir) / "logs"
        logs_dir.mkdir()
        
        # Create test log files
        self._create_test_log_file(logs_dir / "agent.log")
        self._create_test_jsonl_file(logs_dir / "agent_events.jsonl")
        self._create_test_metrics_file(logs_dir / "metrics.json")
        
        yield logs_dir
        
        # Cleanup
        shutil.rmtree(temp_dir)
    
    def _create_test_log_file(self, log_file: Path):
        """Create a test agent.log file."""
        test_logs = [
            "2025-07-09 13:32:16 - INFO - [SUCCESS] coordinator -> INTERNAL | Action: REGISTER | Payload: {'agent_type': 'CoordinatorAgent'}",
            "2025-07-09 13:32:16 - INFO - [SUCCESS] compute_agent_1 -> INTERNAL | Action: REGISTER | Payload: {'agent_type': 'ComputeAgent'}",
            "2025-07-09 13:32:16 - ERROR - [ERROR] coordinator -> non_existent_agent | Action: COMPUTE_REQUEST | Payload: {'operation': 'add', 'a': 1, 'b': 2} | Error: Recipient agent 'non_existent_agent' not found",
            "2025-07-09 13:32:16 - INFO - [SENT] compute_agent_1 -> coordinator | Action: TASK_COMPLETE | Payload: {'task_id': 0, 'result': 'Addition completed: 40', 'execution_time': 0.05}",
            "2025-07-09 13:32:16 - INFO - [SUCCESS] compute_agent_2 -> coordinator | Action: TASK_COMPLETE | Payload: {'task_id': 1, 'result': 'Revenue analysis: $125,000', 'execution_time': 0.12}"
        ]
        
        with open(log_file, 'w', encoding='utf-8') as f:
            for log in test_logs:
                f.write(log + '\n')
    
    def _create_test_jsonl_file(self, jsonl_file: Path):
        """Create a test agent_events.jsonl file."""
        test_events = [
            {
                "message_id": "coord_reg_001",
                "sender": "coordinator",
                "recipient": "INTERNAL",
                "action_type": "REGISTER",
                "payload": {"agent_type": "CoordinatorAgent"},
                "status": "SUCCESS",
                "timestamp": "2025-07-09T13:32:16.000000"
            },
            {
                "message_id": "comp1_reg_001",
                "sender": "compute_agent_1",
                "recipient": "INTERNAL",
                "action_type": "REGISTER",
                "payload": {"agent_type": "ComputeAgent"},
                "status": "SUCCESS",
                "timestamp": "2025-07-09T13:32:16.001000"
            },
            {
                "message_id": "coord_error_001",
                "sender": "coordinator",
                "recipient": "non_existent_agent",
                "action_type": "COMPUTE_REQUEST",
                "payload": {"operation": "add", "a": 1, "b": 2},
                "status": "ERROR",
                "timestamp": "2025-07-09T13:32:16.002000"
            }
        ]
        
        with open(jsonl_file, 'w', encoding='utf-8') as f:
            for event in test_events:
                f.write(json.dumps(event) + '\n')
    
    def _create_test_metrics_file(self, metrics_file: Path):
        """Create a test metrics.json file."""
        test_metrics = {
            "total_messages": 50,
            "total_actions": 50,
            "successful_actions": 45,
            "failed_actions": 5,
            "overall_reliability": 90.0,
            "active_agents": 3,
            "agent_metrics": {
                "coordinator": {
                    "messages_sent": 20,
                    "messages_received": 15,
                    "successful_actions": 18,
                    "failed_actions": 2,
                    "reliability_score": 85.0,
                    "first_activity": "2025-07-09T13:32:16.000000",
                    "last_activity": "2025-07-09T13:32:20.000000",
                    "action_counts": {
                        "REGISTER": 1,
                        "COMPUTE_REQUEST": 10,
                        "TASK_COMPLETE": 5
                    },
                    "message_history": [
                        {"from": "compute_agent_1", "type": "TASK_COMPLETE", "payload": {"task_id": 0}}
                    ]
                },
                "compute_agent_1": {
                    "messages_sent": 15,
                    "messages_received": 18,
                    "successful_actions": 14,
                    "failed_actions": 1,
                    "reliability_score": 92.0,
                    "first_activity": "2025-07-09T13:32:16.001000",
                    "last_activity": "2025-07-09T13:32:21.000000",
                    "action_counts": {
                        "REGISTER": 1,
                        "COMPUTE_RESULT": 8,
                        "TASK_COMPLETE": 3
                    },
                    "message_history": []
                },
                "compute_agent_2": {
                    "messages_sent": 15,
                    "messages_received": 17,
                    "successful_actions": 13,
                    "failed_actions": 2,
                    "reliability_score": 88.0,
                    "first_activity": "2025-07-09T13:32:16.002000",
                    "last_activity": "2025-07-09T13:32:22.000000",
                    "action_counts": {
                        "REGISTER": 1,
                        "COMPUTE_RESULT": 7,
                        "DATA_PROCESS": 4
                    },
                    "message_history": []
                }
            },
            "action_distribution": {
                "REGISTER": 3,
                "COMPUTE_REQUEST": 10,
                "COMPUTE_RESULT": 15,
                "TASK_COMPLETE": 8,
                "DATA_PROCESS": 4
            }
        }
        
        with open(metrics_file, 'w', encoding='utf-8') as f:
            json.dump(test_metrics, f, indent=2)

def test_root_endpoint():
    """Test the root endpoint."""
    client = TestClient(app)
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert "name" in data
    assert "version" in data
    assert "endpoints" in data

def test_logs_raw_endpoint():
    """Test the /logs/raw endpoint."""
    client = TestClient(app)
    
    # Test basic endpoint
    response = client.get("/logs/raw")
    assert response.status_code == 200
    data = response.json()
    assert "success" in data
    assert "count" in data
    assert "data" in data
    
    # Test with agent filter
    response = client.get("/logs/raw?agent=coordinator")
    assert response.status_code == 200
    data = response.json()
    assert data["filters"]["agent"] == "coordinator"
    
    # Test with level filter
    response = client.get("/logs/raw?level=ERROR")
    assert response.status_code == 200
    data = response.json()
    assert data["filters"]["level"] == "ERROR"
    
    # Test with jsonl format
    response = client.get("/logs/raw?format=jsonl")
    assert response.status_code == 200
    data = response.json()
    assert data["filters"]["format"] == "jsonl"

def test_metrics_endpoint():
    """Test the /metrics endpoint."""
    client = TestClient(app)
    response = client.get("/metrics")
    assert response.status_code == 200
    data = response.json()
    assert "success" in data
    assert "data" in data or "message" in data

def test_agent_metrics_endpoint():
    """Test the /metrics/{agent_id} endpoint."""
    client = TestClient(app)
    
    # Test with existing agent (might not exist in test env)
    response = client.get("/metrics/coordinator")
    # Could be 200 or 404 depending on test data
    assert response.status_code in [200, 404]
    
    # Test with non-existent agent (API returns 404 for non-existent agents)
    response = client.get("/metrics/non_existent_agent")
    # Can be 404 or 200 with error message depending on data
    assert response.status_code in [200, 404]

def test_annotate_endpoint():
    """Test the /logs/annotate endpoint."""
    client = TestClient(app)
    
    # Test valid annotation
    response = client.post("/logs/annotate", json={
        "log_id": "test_log_001",
        "annotation": "This is a test annotation",
        "tags": ["test", "important"]
    })
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "message" in data
    
    # Test missing parameters (Pydantic validation returns 422)
    response = client.post("/logs/annotate", json={
        "log_id": "test_log_001"
    })
    assert response.status_code == 422

def test_health_endpoint():
    """Test the /health endpoint."""
    client = TestClient(app)
    response = client.get("/health")
    # Could be 200 or 503 depending on file availability
    assert response.status_code in [200, 503]
    data = response.json()
    assert "logging_ok" in data
    assert "timestamp" in data
    assert "checks" in data

def test_logs_api_service():
    """Test the LogsAPIService class methods."""
    service = LogsAPIService()
    
    # Test health check
    health = service.check_health()
    assert "logging_ok" in health
    assert "checks" in health
    
    # Test metrics reading
    metrics = service.read_metrics()
    assert isinstance(metrics, dict)
    
    # Test raw logs reading
    logs = service.read_raw_logs(limit=10)
    assert isinstance(logs, list)
    
    # Test jsonl events reading
    events = service.read_jsonl_events(limit=10)
    assert isinstance(events, list)

def test_logs_api_service_with_temp_data():
    """Test the LogsAPIService with temporary test data."""
    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    logs_dir = Path(temp_dir) / "logs"
    logs_dir.mkdir()
    
    try:
        # Create test instance
        test_instance = TestLogsAPI()
        test_instance._create_test_log_file(logs_dir / "agent.log")
        test_instance._create_test_jsonl_file(logs_dir / "agent_events.jsonl")
        test_instance._create_test_metrics_file(logs_dir / "metrics.json")
        
        # Test service with temp data
        service = LogsAPIService(str(logs_dir))
        
        # Test metrics
        metrics = service.read_metrics()
        assert metrics["total_messages"] == 50
        assert "coordinator" in metrics["agent_metrics"]
        
        # Test agent metrics
        agent_metrics = service.get_agent_metrics("coordinator")
        assert agent_metrics["agent_id"] == "coordinator"
        assert agent_metrics["messages_sent"] == 20
        
        # Test raw logs
        logs = service.read_raw_logs(limit=10)
        assert len(logs) <= 10
        
        # Test filtered logs
        filtered_logs = service.read_raw_logs(agent_filter="coordinator", limit=10)
        assert len(filtered_logs) >= 0
        
        # Test jsonl events
        events = service.read_jsonl_events(limit=10)
        assert len(events) <= 10
        
        # Test health check
        health = service.check_health()
        assert health["logging_ok"] is True
        
    finally:
        # Cleanup
        shutil.rmtree(temp_dir)

if __name__ == "__main__":
    # Run tests manually
    print("🧪 Running manual tests...")
    
    # Test root endpoint
    print("✅ Testing root endpoint...")
    test_root_endpoint()
    print("✅ Root endpoint test passed")
    
    # Test logs endpoint
    print("✅ Testing logs endpoint...")
    test_logs_raw_endpoint()
    print("✅ Logs endpoint test passed")
    
    # Test metrics endpoint
    print("✅ Testing metrics endpoint...")
    test_metrics_endpoint()
    print("✅ Metrics endpoint test passed")
    
    # Test agent metrics endpoint
    print("✅ Testing agent metrics endpoint...")
    test_agent_metrics_endpoint()
    print("✅ Agent metrics endpoint test passed")
    
    # Test annotate endpoint
    print("✅ Testing annotate endpoint...")
    test_annotate_endpoint()
    print("✅ Annotate endpoint test passed")
    
    # Test health endpoint
    print("✅ Testing health endpoint...")
    test_health_endpoint()
    print("✅ Health endpoint test passed")
    
    # Test service class
    print("✅ Testing LogsAPIService class...")
    test_logs_api_service()
    print("✅ LogsAPIService test passed")
    
    # Test service with temp data
    print("✅ Testing LogsAPIService with temporary data...")
    test_logs_api_service_with_temp_data()
    print("✅ LogsAPIService with temp data test passed")
    
    print("\n🎉 All tests passed successfully!")