/**
 * Multi-Agent System Log Viewer - Frontend JavaScript
 * Handles real-time data fetching, filtering, and display updates
 */

class LogViewer {
    constructor() {
        this.refreshInterval = 5000; // 5 seconds
        this.intervalId = null;
        this.isLoading = false;
        
        // DOM elements
        this.elements = {
            systemStatus: document.getElementById('systemStatus'),
            statusIndicator: document.getElementById('statusIndicator'),
            lastUpdate: document.getElementById('lastUpdate'),
            totalMessages: document.getElementById('totalMessages'),
            successRate: document.getElementById('successRate'),
            activeAgents: document.getElementById('activeAgents'),
            failedActions: document.getElementById('failedActions'),
            agentsTableBody: document.getElementById('agentsTableBody'),
            logsContainer: document.getElementById('logsContainer'),
            agentFilter: document.getElementById('agentFilter'),
            levelFilter: document.getElementById('levelFilter'),
            linesLimit: document.getElementById('linesLimit'),
            loadingSpinner: document.getElementById('loadingSpinner')
        };
        
        this.init();
    }
    
    init() {
        console.log('🚀 Initializing Multi-Agent Log Viewer');
        
        // Set up event listeners
        this.setupEventListeners();
        
        // Initial data load
        this.loadAllData();
        
        // Start auto-refresh
        this.startAutoRefresh();
    }
    
    setupEventListeners() {
        // Filter change events
        this.elements.agentFilter.addEventListener('change', () => {
            this.loadLogs();
        });
        
        this.elements.levelFilter.addEventListener('change', () => {
            this.loadLogs();
        });
        
        this.elements.linesLimit.addEventListener('change', () => {
            this.loadLogs();
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.key === 'F5' || (e.ctrlKey && e.key === 'r')) {
                e.preventDefault();
                this.loadAllData();
            }
        });
    }
    
    startAutoRefresh() {
        this.intervalId = setInterval(() => {
            if (!this.isLoading) {
                this.loadAllData();
            }
        }, this.refreshInterval);
    }
    
    stopAutoRefresh() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
        }
    }
    
    async loadAllData() {
        try {
            await Promise.all([
                this.loadMetrics(),
                this.loadLogs(),
                this.loadAgents()
            ]);
            
            this.updateSystemStatus('Connecté', true);
            this.updateLastUpdate();
        } catch (error) {
            console.error('Error loading data:', error);
            this.updateSystemStatus('Erreur de connexion', false);
            this.showError('Erreur lors du chargement des données');
        }
    }
    
    async loadMetrics() {
        try {
            const response = await fetch('/api/metrics');
            const result = await response.json();
            
            if (result.success) {
                this.updateMetrics(result.data);
            } else {
                throw new Error(result.error || 'Erreur lors du chargement des métriques');
            }
        } catch (error) {
            console.error('Error loading metrics:', error);
            throw error;
        }
    }
    
    async loadLogs() {
        try {
            this.showLoading(true);
            
            const agentFilter = this.elements.agentFilter.value;
            const levelFilter = this.elements.levelFilter.value;
            const linesLimit = this.elements.linesLimit.value;
            
            const params = new URLSearchParams({
                lines: linesLimit,
                ...(agentFilter !== 'all' && { agent: agentFilter }),
                ...(levelFilter !== 'all' && { level: levelFilter })
            });
            
            const response = await fetch(`/api/logs?${params}`);
            const result = await response.json();
            
            if (result.success) {
                this.updateLogs(result.data);
            } else {
                throw new Error(result.error || 'Erreur lors du chargement des logs');
            }
        } catch (error) {
            console.error('Error loading logs:', error);
            this.showError('Erreur lors du chargement des logs');
        } finally {
            this.showLoading(false);
        }
    }
    
    async loadAgents() {
        try {
            const response = await fetch('/api/agents');
            const result = await response.json();
            
            if (result.success) {
                this.updateAgentFilter(result.data);
            }
        } catch (error) {
            console.error('Error loading agents:', error);
            // Don't throw here as it's not critical
        }
    }
    
    updateMetrics(metrics) {
        this.elements.totalMessages.textContent = metrics.total_messages || 0;
        this.elements.successRate.textContent = `${(metrics.overall_reliability || 0).toFixed(1)}%`;
        this.elements.activeAgents.textContent = metrics.active_agents || 0;
        this.elements.failedActions.textContent = metrics.total_failed_actions || 0;
        
        // Update agents table
        this.updateAgentsTable(metrics.agent_metrics || {});
    }
    
    updateAgentsTable(agentMetrics) {
        const tbody = this.elements.agentsTableBody;
        tbody.innerHTML = '';
        
        if (Object.keys(agentMetrics).length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #7f8c8d;">Aucun agent trouvé</td></tr>';
            return;
        }
        
        Object.entries(agentMetrics).forEach(([agentName, metrics]) => {
            // Skip INTERNAL agent
            if (agentName === 'INTERNAL') return;
            
            const row = document.createElement('tr');
            const reliability = metrics.reliability_score || 0;
            const reliabilityClass = reliability >= 80 ? 'high' : reliability >= 60 ? 'medium' : 'low';
            
            row.innerHTML = `
                <td><strong>${agentName}</strong></td>
                <td>${metrics.messages_sent || 0}</td>
                <td>${metrics.messages_received || 0}</td>
                <td><span class="reliability-score ${reliabilityClass}">${reliability.toFixed(1)}%</span></td>
            `;
            
            tbody.appendChild(row);
        });
    }
    
    updateLogs(logs) {
        const container = this.elements.logsContainer;
        
        if (logs.length === 0) {
            container.innerHTML = '<div style="text-align: center; color: #7f8c8d;">Aucun log trouvé avec les filtres appliqués</div>';
            return;
        }
        
        container.innerHTML = logs.map(log => this.formatLogEntry(log)).join('');
        
        // Auto-scroll to bottom
        container.scrollTop = container.scrollHeight;
    }
    
    formatLogEntry(log) {
        const timestamp = this.formatTimestamp(log.timestamp);
        const level = log.level || 'INFO';
        const message = this.highlightLogMessage(log.message || '');
        
        return `
            <div class="log-entry">
                <span class="log-timestamp">${timestamp}</span>
                <span class="log-level ${level}">${level}</span>
                <span class="log-message">${message}</span>
            </div>
        `;
    }
    
    highlightLogMessage(message) {
        return message
            .replace(/\[SUCCESS\]/g, '<span class="success">[SUCCESS]</span>')
            .replace(/\[ERROR\]/g, '<span class="error">[ERROR]</span>')
            .replace(/\[SENT\]/g, '<span class="success">[SENT]</span>')
            .replace(/(coordinator|compute_agent_\d+|[a-zA-Z_]+_agent[a-zA-Z_\d]*)/g, '<span class="agent">$1</span>')
            .replace(/Action: ([A-Z_]+)/g, 'Action: <span class="action">$1</span>');
    }
    
    formatTimestamp(timestamp) {
        try {
            const date = new Date(timestamp);
            return date.toLocaleTimeString('fr-FR', { 
                hour: '2-digit', 
                minute: '2-digit', 
                second: '2-digit' 
            });
        } catch (error) {
            return timestamp;
        }
    }
    
    updateAgentFilter(agents) {
        const select = this.elements.agentFilter;
        const currentValue = select.value;
        
        // Keep "all" option and add agents
        select.innerHTML = '<option value="all">Tous les agents</option>';
        
        agents.forEach(agent => {
            const option = document.createElement('option');
            option.value = agent;
            option.textContent = agent;
            select.appendChild(option);
        });
        
        // Restore previous selection if it still exists
        if (currentValue && [...select.options].some(opt => opt.value === currentValue)) {
            select.value = currentValue;
        }
    }
    
    updateSystemStatus(status, isOnline) {
        this.elements.systemStatus.textContent = status;
        this.elements.statusIndicator.className = `status-indicator ${isOnline ? '' : 'offline'}`;
    }
    
    updateLastUpdate() {
        const now = new Date();
        this.elements.lastUpdate.textContent = now.toLocaleTimeString('fr-FR');
    }
    
    showLoading(show) {
        this.isLoading = show;
        this.elements.loadingSpinner.style.display = show ? 'inline-block' : 'none';
    }
    
    showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        
        // Find a good place to show the error
        const container = document.querySelector('.container');
        const existingError = container.querySelector('.error-message');
        
        if (existingError) {
            existingError.remove();
        }
        
        container.insertBefore(errorDiv, container.firstChild.nextSibling);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (errorDiv.parentNode) {
                errorDiv.remove();
            }
        }, 5000);
    }
    
    // Public methods for external control
    refresh() {
        this.loadAllData();
    }
    
    destroy() {
        this.stopAutoRefresh();
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.logViewer = new LogViewer();
});

// Handle page visibility changes to pause/resume auto-refresh
document.addEventListener('visibilitychange', () => {
    if (window.logViewer) {
        if (document.hidden) {
            window.logViewer.stopAutoRefresh();
        } else {
            window.logViewer.startAutoRefresh();
        }
    }
});

// Handle beforeunload to cleanup
window.addEventListener('beforeunload', () => {
    if (window.logViewer) {
        window.logViewer.destroy();
    }
});