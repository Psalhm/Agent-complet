"""
Flask Web Interface for Multi-Agent System Intelligent Logging
Simple web dashboard to visualize agent metrics and logs in real-time.
"""

from flask import Flask, render_template, jsonify, request
import json
import os
from pathlib import Path
from datetime import datetime
import logging
from typing import Dict, List, Any, Optional

app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class LogViewer:
    """Handles reading and processing log files for the web interface."""
    
    def __init__(self, log_dir: str = "logs"):
        self.log_dir = Path(log_dir)
        self.human_log_path = self.log_dir / "agent.log"
        self.json_log_path = self.log_dir / "agent_events.jsonl"
        self.metrics_path = self.log_dir / "metrics.json"
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current agent metrics from metrics.json file."""
        try:
            if self.metrics_path.exists():
                with open(self.metrics_path, 'r') as f:
                    return json.load(f)
            else:
                return self._generate_sample_metrics()
        except Exception as e:
            logger.error(f"Error reading metrics: {e}")
            return self._generate_sample_metrics()
    
    def get_logs(self, lines: int = 100, agent_filter: Optional[str] = None, 
                 level_filter: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get recent logs with optional filtering."""
        try:
            if self.human_log_path.exists():
                with open(self.human_log_path, 'r') as f:
                    log_lines = f.readlines()
                
                # Get last N lines
                recent_lines = log_lines[-lines:] if len(log_lines) > lines else log_lines
                
                parsed_logs = []
                for line in recent_lines:
                    if line.strip():
                        parsed_log = self._parse_log_line(line.strip())
                        if parsed_log:
                            # Apply filters
                            if agent_filter and agent_filter != "all":
                                if agent_filter not in parsed_log.get('message', ''):
                                    continue
                            
                            if level_filter and level_filter != "all":
                                if parsed_log.get('level') != level_filter:
                                    continue
                            
                            parsed_logs.append(parsed_log)
                
                return parsed_logs
            else:
                return self._generate_sample_logs()
        except Exception as e:
            logger.error(f"Error reading logs: {e}")
            return self._generate_sample_logs()
    
    def _parse_log_line(self, line: str) -> Optional[Dict[str, Any]]:
        """Parse a single log line into structured data."""
        try:
            # Format: 2025-07-09 13:32:16 - INFO - [SUCCESS] coordinator -> compute_agent_1 | Action: REGISTER | Payload: {...}
            parts = line.split(' - ', 2)
            if len(parts) >= 3:
                timestamp = parts[0]
                level = parts[1]
                message = parts[2]
                
                return {
                    'timestamp': timestamp,
                    'level': level,
                    'message': message,
                    'raw': line
                }
        except Exception as e:
            logger.error(f"Error parsing log line: {e}")
        return None
    
    def get_agent_names(self) -> List[str]:
        """Get list of all agent names from metrics."""
        try:
            metrics = self.get_metrics()
            agent_names = []
            if 'agent_metrics' in metrics:
                for agent_name in metrics['agent_metrics'].keys():
                    if agent_name != 'INTERNAL':  # Skip internal tracking
                        agent_names.append(agent_name)
            return sorted(agent_names)
        except Exception as e:
            logger.error(f"Error getting agent names: {e}")
            return ['coordinator', 'compute_agent_1', 'compute_agent_2']
    
    def _generate_sample_metrics(self) -> Dict[str, Any]:
        """Generate sample metrics when real data is not available."""
        return {
            "total_messages": 80,
            "total_actions": 80,
            "total_successful_actions": 70,
            "total_failed_actions": 10,
            "overall_reliability": 87.5,
            "active_agents": 3,
            "message_distribution": {
                "coordinator->compute_agent_1": 25,
                "coordinator->compute_agent_2": 25,
                "compute_agent_1->coordinator": 15,
                "compute_agent_2->coordinator": 15
            },
            "agent_metrics": {
                "coordinator": {
                    "messages_sent": 50,
                    "messages_received": 30,
                    "successful_actions": 45,
                    "failed_actions": 5,
                    "reliability_score": 90.0,
                    "first_activity": "2025-07-09T13:32:16.000000",
                    "last_activity": "2025-07-09T13:32:17.000000"
                },
                "compute_agent_1": {
                    "messages_sent": 20,
                    "messages_received": 25,
                    "successful_actions": 18,
                    "failed_actions": 2,
                    "reliability_score": 90.0,
                    "first_activity": "2025-07-09T13:32:16.000000",
                    "last_activity": "2025-07-09T13:32:17.000000"
                },
                "compute_agent_2": {
                    "messages_sent": 10,
                    "messages_received": 25,
                    "successful_actions": 7,
                    "failed_actions": 3,
                    "reliability_score": 70.0,
                    "first_activity": "2025-07-09T13:32:16.000000",
                    "last_activity": "2025-07-09T13:32:17.000000"
                }
            }
        }
    
    def _generate_sample_logs(self) -> List[Dict[str, Any]]:
        """Generate sample log entries when real data is not available."""
        sample_logs = [
            {
                "timestamp": "2025-07-09 13:32:16",
                "level": "INFO",
                "message": "[SUCCESS] coordinator -> compute_agent_1 | Action: REGISTER | Payload: {'agent_type': 'ComputeAgent'}",
                "raw": "2025-07-09 13:32:16 - INFO - [SUCCESS] coordinator -> compute_agent_1 | Action: REGISTER | Payload: {'agent_type': 'ComputeAgent'}"
            },
            {
                "timestamp": "2025-07-09 13:32:17",
                "level": "INFO",
                "message": "[SUCCESS] compute_agent_1 -> coordinator | Action: TASK_REQUEST | Payload: {'task_type': 'computation'}",
                "raw": "2025-07-09 13:32:17 - INFO - [SUCCESS] compute_agent_1 -> coordinator | Action: TASK_REQUEST | Payload: {'task_type': 'computation'}"
            },
            {
                "timestamp": "2025-07-09 13:32:18",
                "level": "ERROR",
                "message": "[ERROR] coordinator -> non_existent_agent | Action: COMPUTE_REQUEST | Payload: {'operation': 'add'} | Error: Agent not found",
                "raw": "2025-07-09 13:32:18 - ERROR - [ERROR] coordinator -> non_existent_agent | Action: COMPUTE_REQUEST | Payload: {'operation': 'add'} | Error: Agent not found"
            }
        ]
        return sample_logs

# Initialize log viewer
log_viewer = LogViewer()

@app.route('/')
def index():
    """Main dashboard page."""
    return render_template('index.html')

@app.route('/api/metrics')
def get_metrics():
    """API endpoint to get agent metrics."""
    try:
        metrics = log_viewer.get_metrics()
        return jsonify({
            'success': True,
            'data': metrics,
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        logger.error(f"Error in /api/metrics: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/logs')
def get_logs():
    """API endpoint to get recent logs with filtering."""
    try:
        lines = int(request.args.get('lines', 100))
        agent_filter = request.args.get('agent', None)
        level_filter = request.args.get('level', None)
        
        logs = log_viewer.get_logs(lines, agent_filter, level_filter)
        
        return jsonify({
            'success': True,
            'data': logs,
            'count': len(logs),
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        logger.error(f"Error in /api/logs: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/agents')
def get_agents():
    """API endpoint to get list of available agents."""
    try:
        agents = log_viewer.get_agent_names()
        return jsonify({
            'success': True,
            'data': agents,
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        logger.error(f"Error in /api/agents: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/system/status')
def get_system_status():
    """API endpoint to get system status."""
    try:
        log_dir_exists = log_viewer.log_dir.exists()
        metrics_exists = log_viewer.metrics_path.exists()
        logs_exists = log_viewer.human_log_path.exists()
        
        return jsonify({
            'success': True,
            'data': {
                'log_directory_exists': log_dir_exists,
                'metrics_file_exists': metrics_exists,
                'log_file_exists': logs_exists,
                'system_time': datetime.now().isoformat(),
                'log_dir_path': str(log_viewer.log_dir)
            }
        })
    except Exception as e:
        logger.error(f"Error in /api/system/status: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

if __name__ == '__main__':
    print("🚀 Starting Multi-Agent Log Viewer")
    print("📊 Dashboard will be available at: http://localhost:5000")
    print("🔧 Log directory:", log_viewer.log_dir)
    print("=" * 50)
    
    app.run(host='0.0.0.0', port=5000, debug=True)