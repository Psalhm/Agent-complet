# Multi-Agent System Log Viewer

Une interface web moderne pour visualiser les logs intelligents d'un système multi-agents Python en temps réel.

## 🚀 Fonctionnalités

- **Dashboard en temps réel** : Métriques système et performance des agents
- **Visualisation des logs** : Interface moderne avec coloration syntaxique
- **Filtrage avancé** : Par agent, niveau de log, et nombre de lignes
- **Rafraîchissement automatique** : Données mises à jour toutes les 5 secondes
- **Interface responsive** : Optimisée pour desktop et mobile
- **Thème sombre** : Support des logs en mode terminal

## 📋 Prérequis

- Python 3.7+
- Flask
- Système multi-agents avec logging intelligent (voir `core/` dans le projet)

## 🔧 Installation

1. **Cloner le projet** :
   ```bash
   git clone <votre-repo>
   cd multi-agent-log-viewer
   ```

2. **Installer les dépendances** :
   ```bash
   pip install flask
   ```

3. **Vérifier la structure** :
   ```
   ├── main.py                 # Serveur Flask
   ├── templates/
   │   └── index.html         # Interface web
   ├── static/
   │   ├── js/
   │   │   └── script.js      # Code JavaScript
   │   └── css/
   │       └── style.css      # Styles additionnels
   ├── core/                  # Système multi-agents
   │   ├── intelligent_logger.py
   │   ├── message_bus.py
   │   └── agent_base.py
   ├── logs/                  # Dossier des logs (généré automatiquement)
   │   ├── agent.log          # Logs lisibles
   │   ├── agent_events.jsonl # Logs machine
   │   └── metrics.json       # Métriques système
   └── README.md
   ```

## 🎯 Utilisation

### Démarrer le serveur

```bash
python main.py
```

Le serveur démarre sur : **http://localhost:5000**

### Accéder à l'interface

1. Ouvrez votre navigateur
2. Allez à `http://localhost:5000`
3. Le dashboard se charge automatiquement

### Générer des logs de test

Pour tester l'interface avec des données réelles :

```bash
python demo_logger.py
```

Cela génère des logs et métriques dans le dossier `logs/`.

## 🎨 Interface

### Dashboard Principal

- **Métriques système** : Messages totaux, taux de réussite, agents actifs
- **Tableau des agents** : Performance individuelle avec scores de fiabilité
- **Logs en temps réel** : Affichage avec coloration syntaxique

### Filtres Disponibles

- **Agent** : Filtrer par agent spécifique
- **Niveau** : INFO, ERROR, WARNING
- **Lignes** : Nombre de lignes à afficher (10-1000)

### Raccourcis Clavier

- **F5** ou **Ctrl+R** : Actualiser manuellement
- **Échap** : Réinitialiser les filtres

## 🔌 API Endpoints

### GET `/api/metrics`
Retourne les métriques système et des agents.

**Réponse** :
```json
{
  "success": true,
  "data": {
    "total_messages": 80,
    "overall_reliability": 87.5,
    "active_agents": 3,
    "agent_metrics": {
      "coordinator": {
        "messages_sent": 50,
        "reliability_score": 90.0
      }
    }
  }
}
```

### GET `/api/logs`
Retourne les logs récents avec filtrage.

**Paramètres** :
- `lines` : Nombre de lignes (défaut: 100)
- `agent` : Filtrer par agent
- `level` : Filtrer par niveau (INFO, ERROR, WARNING)

**Réponse** :
```json
{
  "success": true,
  "data": [
    {
      "timestamp": "2025-07-09 13:32:16",
      "level": "INFO",
      "message": "[SUCCESS] coordinator -> compute_agent_1 | Action: REGISTER"
    }
  ]
}
```

### GET `/api/agents`
Liste des agents disponibles.

### GET `/api/system/status`
Statut du système et des fichiers de logs.

## 🔧 Configuration

### Personnaliser les paramètres

Modifiez `main.py` pour ajuster :

```python
# Dossier des logs
log_viewer = LogViewer(log_dir="logs")

# Port du serveur
app.run(host='0.0.0.0', port=5000, debug=True)
```

### Modifier l'interface

- **Styles** : Éditez `templates/index.html` (CSS intégré)
- **Logique** : Modifiez `static/js/script.js`
- **Fréquence de rafraîchissement** : Changez `refreshInterval` dans `script.js`

## 🐛 Dépannage

### Problèmes courants

1. **Erreur "logs/ not found"** :
   - Exécutez `python demo_logger.py` pour générer des logs
   - Vérifiez que le dossier `logs/` existe

2. **Données vides** :
   - Le système utilise des données d'exemple si aucun log réel n'est trouvé
   - Vérifiez que `metrics.json` et `agent.log` existent

3. **Problèmes de performance** :
   - Réduisez le nombre de lignes affichées
   - Augmentez l'intervalle de rafraîchissement

### Logs de débogage

Le serveur Flask affiche des logs détaillés en mode debug :

```bash
python main.py
# Sortie :
# 🚀 Starting Multi-Agent Log Viewer
# 📊 Dashboard will be available at: http://localhost:5000
# 🔧 Log directory: logs
```

## 📈 Fonctionnalités Avancées

### Données temps réel

L'interface peut être étendue pour supporter WebSocket :

```python
# Ajoutez dans main.py
from flask_socketio import SocketIO

socketio = SocketIO(app)

@socketio.on('connect')
def handle_connect():
    emit('status', {'msg': 'Connected to log viewer'})
```

### Filtres personnalisés

Ajoutez de nouveaux filtres en modifiant `get_logs()` dans `main.py` :

```python
def get_logs(self, action_filter=None, ...):
    # Filtrer par type d'action
    if action_filter:
        # Logique de filtrage
        pass
```

### Export des données

Ajoutez un endpoint pour exporter :

```python
@app.route('/api/export/<format>')
def export_data(format):
    if format == 'csv':
        # Exporter en CSV
        pass
    elif format == 'json':
        # Exporter en JSON
        pass
```

## 🤝 Contribution

1. Fork le projet
2. Créez une branche feature (`git checkout -b feature/nouvelle-fonctionnalité`)
3. Commitez vos changements (`git commit -m 'Ajout nouvelle fonctionnalité'`)
4. Push vers la branche (`git push origin feature/nouvelle-fonctionnalité`)
5. Ouvrez une Pull Request

## 📄 Licence

Ce projet est sous licence MIT. Voir le fichier `LICENSE` pour plus de détails.

## 🆘 Support

- **Issues** : Utilisez GitHub Issues pour signaler des bugs
- **Documentation** : Consultez les commentaires dans le code
- **Communauté** : Rejoignez les discussions sur GitHub

---

**Note** : Cette interface fonctionne avec le système de logging intelligent des agents Python. Assurez-vous d'avoir configuré le système multi-agents avant d'utiliser cette interface.