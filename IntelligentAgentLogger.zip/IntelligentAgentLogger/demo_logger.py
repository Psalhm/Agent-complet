"""
Demo script for the Intelligent Logger Multi-Agent System
Demonstrates comprehensive logging and metrics tracking.
"""

import time
import random
from core.intelligent_logger import IntelligentLogger
from core.message_bus import MessageBus
from core.agent_base import CoordinatorAgent, ComputeAgent


def main():
    """Main demonstration function."""
    print("🚀 Starting Multi-Agent System Demo with Intelligent Logging")
    print("=" * 60)
    
    # Initialize the intelligent logger
    logger = IntelligentLogger()
    
    # Create message bus with logger
    message_bus = MessageBus(logger)
    
    # Create agents
    coordinator = CoordinatorAgent("coordinator", message_bus)
    compute_agent_1 = ComputeAgent("compute_agent_1", message_bus)
    compute_agent_2 = ComputeAgent("compute_agent_2", message_bus)
    
    print("✅ Agents created and registered:")
    print(f"  - {coordinator.name}")
    print(f"  - {compute_agent_1.name}")
    print(f"  - {compute_agent_2.name}")
    print()
    
    # Simulate agent registration with coordinator
    print("📝 Registering agents with coordinator...")
    compute_agent_1.send_message("coordinator", "AGENT_REGISTER", {
        "agent_type": "compute",
        "capabilities": ["math", "data_processing"]
    })
    
    compute_agent_2.send_message("coordinator", "AGENT_REGISTER", {
        "agent_type": "compute",
        "capabilities": ["math", "analytics"]
    })
    
    time.sleep(0.1)  # Small delay for realistic timing
    
    # Simulate task requests
    print("🎯 Sending task requests...")
    compute_agent_1.send_message("coordinator", "TASK_REQUEST", {
        "task_type": "computation",
        "priority": "high",
        "data": {"operation": "add", "a": 10, "b": 20}
    })
    
    compute_agent_2.send_message("coordinator", "TASK_REQUEST", {
        "task_type": "analysis",
        "priority": "medium",
        "data": {"dataset": "sales_data", "metric": "revenue"}
    })
    
    time.sleep(0.1)
    
    # Simulate computation requests
    print("🔢 Performing computations...")
    
    # Successful computation
    coordinator.send_message("compute_agent_1", "COMPUTE_REQUEST", {
        "operation": "add",
        "a": 15,
        "b": 25
    })
    
    # Another successful computation
    coordinator.send_message("compute_agent_2", "COMPUTE_REQUEST", {
        "operation": "multiply",
        "a": 7,
        "b": 8
    })
    
    time.sleep(0.1)
    
    # Data processing requests
    print("📊 Processing data...")
    compute_agent_1.send_message("compute_agent_2", "DATA_PROCESS", {
        "data_type": "sensor_readings",
        "values": [1.2, 2.3, 3.4, 4.5, 5.6]
    })
    
    compute_agent_2.send_message("compute_agent_1", "DATA_PROCESS", {
        "data_type": "user_activity",
        "events": ["login", "search", "purchase", "logout"]
    })
    
    time.sleep(0.1)
    
    # Simulate some errors
    print("❌ Simulating error scenarios...")
    
    # Send message to non-existent agent
    coordinator.send_message("non_existent_agent", "COMPUTE_REQUEST", {
        "operation": "add",
        "a": 1,
        "b": 2
    })
    
    # Send invalid computation request
    coordinator.send_message("compute_agent_1", "COMPUTE_REQUEST", {
        "invalid_field": "this will cause an error"
    })
    
    time.sleep(0.1)
    
    # Broadcast message
    print("📢 Broadcasting system status...")
    coordinator.broadcast_message("SYSTEM_STATUS", {
        "status": "operational",
        "timestamp": time.time(),
        "active_agents": len(message_bus.get_registered_agents())
    })
    
    time.sleep(0.1)
    
    # Task completion notifications
    print("✅ Completing tasks...")
    compute_agent_1.send_message("coordinator", "TASK_COMPLETE", {
        "task_id": 0,
        "result": "Addition completed: 40",
        "execution_time": 0.05
    })
    
    compute_agent_2.send_message("coordinator", "TASK_COMPLETE", {
        "task_id": 1,
        "result": "Revenue analysis: $125,000",
        "execution_time": 0.12
    })
    
    time.sleep(0.1)
    
    # Additional agent actions
    print("🔄 Performing additional agent actions...")
    
    # State changes
    coordinator.set_state("COORDINATING")
    compute_agent_1.set_state("COMPUTING")
    compute_agent_2.set_state("PROCESSING")
    
    # More complex interactions
    for i in range(3):
        agent = random.choice([compute_agent_1, compute_agent_2])
        target = compute_agent_2 if agent == compute_agent_1 else compute_agent_1
        
        agent.send_message(target.name, "COMPUTE_REQUEST", {
            "operation": "add",
            "a": random.randint(1, 100),
            "b": random.randint(1, 100)
        })
        
        time.sleep(0.05)
    
    print()
    print("🎉 Demo completed! Generating comprehensive metrics report...")
    print()
    
    # Generate and display metrics
    logger.print_summary()
    
    # Show some specific metrics
    print("\n" + "=" * 60)
    print("ADDITIONAL INSIGHTS:")
    print("=" * 60)
    
    # Show message history for one agent
    coord_history = coordinator.get_message_history()
    print(f"📜 {coordinator.name} message history ({len(coord_history)} messages):")
    for msg in coord_history[-3:]:  # Show last 3 messages
        print(f"  From {msg['sender']}: {msg['message_type']} - {msg['payload']}")
    
    # Show computation history
    comp_history = compute_agent_1.computation_history
    print(f"\n🔢 {compute_agent_1.name} computation history ({len(comp_history)} computations):")
    for comp in comp_history:
        print(f"  {comp['operation']}: {comp['input']} = {comp['result']}")
    
    # Show system status
    system_metrics = logger.get_system_metrics()
    print(f"\n📊 System Status:")
    print(f"  Total Messages: {system_metrics['total_messages']}")
    print(f"  Success Rate: {system_metrics['overall_reliability']:.1f}%")
    print(f"  Active Agents: {system_metrics['active_agents']}")
    
    print("\n✨ Log files generated:")
    print("  - logs/agent.log (human-readable)")
    print("  - logs/agent_events.jsonl (machine-readable)")
    print("  - logs/metrics.json (system metrics)")
    
    print("\n🎯 Demo completed successfully!")


if __name__ == "__main__":
    main()
