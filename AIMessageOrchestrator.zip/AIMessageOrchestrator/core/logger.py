"""
Message logger for recording all inter-agent communications.
"""
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List
import os

from .message_schema import Message


class MessageLogger:
    """
    Logger for recording all messages exchanged between agents.
    
    Provides both JSON and human-readable logging formats.
    """
    
    def __init__(self, log_dir: str = "logs", 
                 json_log_file: str = "messages.json",
                 human_log_file: str = "messages.log"):
        """
        Initialize the message logger.
        
        Args:
            log_dir: Directory for log files
            json_log_file: Name of JSON log file
            human_log_file: Name of human-readable log file
        """
        self.log_dir = Path(log_dir)
        self.json_log_file = self.log_dir / json_log_file
        self.human_log_file = self.log_dir / human_log_file
        
        # Create log directory if it doesn't exist
        self.log_dir.mkdir(exist_ok=True)
        
        # Setup logging
        self.logger = logging.getLogger('message_logger')
        self.logger.setLevel(logging.INFO)
        
        # Create file handlers
        self._setup_file_handlers()
        
        # Message statistics
        self.stats = {
            'total_messages': 0,
            'messages_by_type': {},
            'messages_by_agent': {},
            'start_time': datetime.now().isoformat()
        }
        
        self.logger.info("MessageLogger initialized")
        self._log_initialization()
    
    def _setup_file_handlers(self):
        """Setup file handlers for logging."""
        # Remove existing handlers
        for handler in self.logger.handlers[:]:
            self.logger.removeHandler(handler)
        
        # JSON file handler
        json_handler = logging.FileHandler(self.json_log_file)
        json_handler.setLevel(logging.INFO)
        json_formatter = logging.Formatter('%(message)s')
        json_handler.setFormatter(json_formatter)
        
        # Human-readable file handler
        human_handler = logging.FileHandler(self.human_log_file)
        human_handler.setLevel(logging.INFO)
        human_formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s'
        )
        human_handler.setFormatter(human_formatter)
        
        self.logger.addHandler(json_handler)
        self.logger.addHandler(human_handler)
    
    def _log_initialization(self):
        """Log initialization message."""
        init_message = {
            "event": "logger_initialized",
            "timestamp": datetime.now().isoformat(),
            "log_dir": str(self.log_dir),
            "json_log_file": str(self.json_log_file),
            "human_log_file": str(self.human_log_file)
        }
        
        # Write to JSON log
        with open(self.json_log_file, 'a') as f:
            f.write(json.dumps(init_message) + '\n')
    
    def log_message(self, message: Message):
        """
        Log a message in both JSON and human-readable formats.
        
        Args:
            message: Message to log
        """
        # Update statistics
        self.stats['total_messages'] += 1
        
        # Count by type
        msg_type = message.type.value
        self.stats['messages_by_type'][msg_type] = self.stats['messages_by_type'].get(msg_type, 0) + 1
        
        # Count by agent
        sender = message.sender
        self.stats['messages_by_agent'][sender] = self.stats['messages_by_agent'].get(sender, 0) + 1
        
        # Log to JSON file
        self._log_json(message)
        
        # Log to human-readable file
        self._log_human_readable(message)
    
    def _log_json(self, message: Message):
        """
        Log message in JSON format.
        
        Args:
            message: Message to log
        """
        try:
            json_entry = {
                "event": "message",
                "message": message.to_dict(),
                "logged_at": datetime.now().isoformat()
            }
            
            with open(self.json_log_file, 'a') as f:
                f.write(json.dumps(json_entry) + '\n')
                
        except Exception as e:
            self.logger.error(f"Failed to log JSON message: {e}")
    
    def _log_human_readable(self, message: Message):
        """
        Log message in human-readable format.
        
        Args:
            message: Message to log
        """
        try:
            # Create human-readable log entry
            human_entry = (
                f"[{message.timestamp.strftime('%Y-%m-%d %H:%M:%S')}] "
                f"{message.type.value.upper()}: "
                f"{message.sender} -> {message.recipient} | "
                f"Task: {message.task} | "
                f"Payload: {self._format_payload(message.payload)}"
            )
            
            # Use appropriate log level based on message type
            if message.type.value == "error":
                self.logger.error(human_entry)
            elif message.type.value == "coordination":
                self.logger.info(human_entry)
            else:
                self.logger.info(human_entry)
                
        except Exception as e:
            self.logger.error(f"Failed to log human-readable message: {e}")
    
    def _format_payload(self, payload: Dict[str, Any], max_length: int = 200) -> str:
        """
        Format payload for human-readable logging.
        
        Args:
            payload: Message payload
            max_length: Maximum length of formatted payload
            
        Returns:
            Formatted payload string
        """
        if not payload:
            return "{}"
        
        try:
            payload_str = json.dumps(payload, default=str)
            if len(payload_str) > max_length:
                return payload_str[:max_length] + "..."
            return payload_str
        except:
            return str(payload)[:max_length]
    
    def get_message_history(self, limit: int = 100, 
                          filter_by: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Get message history from JSON log file.
        
        Args:
            limit: Maximum number of messages to return
            filter_by: Optional filter criteria
            
        Returns:
            List of message dictionaries
        """
        messages = []
        
        try:
            if not self.json_log_file.exists():
                return messages
            
            with open(self.json_log_file, 'r') as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())
                        if entry.get("event") == "message":
                            message = entry["message"]
                            
                            # Apply filters if provided
                            if filter_by:
                                if not self._matches_filter(message, filter_by):
                                    continue
                            
                            messages.append(message)
                            
                            # Stop if we've reached the limit
                            if len(messages) >= limit:
                                break
                                
                    except json.JSONDecodeError:
                        continue
                        
        except Exception as e:
            self.logger.error(f"Failed to read message history: {e}")
        
        # Return most recent messages first
        return messages[-limit:]
    
    def _matches_filter(self, message: Dict[str, Any], filter_by: Dict[str, Any]) -> bool:
        """
        Check if a message matches the filter criteria.
        
        Args:
            message: Message to check
            filter_by: Filter criteria
            
        Returns:
            True if message matches filter
        """
        for key, value in filter_by.items():
            if key in message and message[key] != value:
                return False
        return True
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get logging statistics.
        
        Returns:
            Dictionary of statistics
        """
        return {
            **self.stats,
            'log_files': {
                'json_log': str(self.json_log_file),
                'human_log': str(self.human_log_file),
                'json_size': self._get_file_size(self.json_log_file),
                'human_size': self._get_file_size(self.human_log_file)
            }
        }
    
    def _get_file_size(self, file_path: Path) -> str:
        """
        Get human-readable file size.
        
        Args:
            file_path: Path to file
            
        Returns:
            Human-readable file size
        """
        try:
            if file_path.exists():
                size = file_path.stat().st_size
                for unit in ['B', 'KB', 'MB', 'GB']:
                    if size < 1024.0:
                        return f"{size:.1f} {unit}"
                    size /= 1024.0
                return f"{size:.1f} TB"
            return "0 B"
        except:
            return "Unknown"
    
    def search_messages(self, query: str, limit: int = 50) -> List[Dict[str, Any]]:
        """
        Search messages by content.
        
        Args:
            query: Search query
            limit: Maximum number of results
            
        Returns:
            List of matching messages
        """
        results = []
        query_lower = query.lower()
        
        try:
            if not self.json_log_file.exists():
                return results
            
            with open(self.json_log_file, 'r') as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())
                        if entry.get("event") == "message":
                            message = entry["message"]
                            
                            # Search in various fields
                            search_text = f"{message.get('sender', '')} {message.get('recipient', '')} {message.get('task', '')} {json.dumps(message.get('payload', {}))}"
                            
                            if query_lower in search_text.lower():
                                results.append(message)
                                
                                if len(results) >= limit:
                                    break
                                    
                    except json.JSONDecodeError:
                        continue
                        
        except Exception as e:
            self.logger.error(f"Failed to search messages: {e}")
        
        return results
    
    def clear_logs(self):
        """
        Clear all log files.
        """
        try:
            if self.json_log_file.exists():
                self.json_log_file.unlink()
            if self.human_log_file.exists():
                self.human_log_file.unlink()
            
            # Reset statistics
            self.stats = {
                'total_messages': 0,
                'messages_by_type': {},
                'messages_by_agent': {},
                'start_time': datetime.now().isoformat()
            }
            
            # Recreate file handlers
            self._setup_file_handlers()
            self._log_initialization()
            
            self.logger.info("Log files cleared")
            
        except Exception as e:
            self.logger.error(f"Failed to clear logs: {e}")
    
    def export_messages(self, output_file: str, format_type: str = "json") -> bool:
        """
        Export messages to a file.
        
        Args:
            output_file: Output file path
            format_type: Export format ("json" or "csv")
            
        Returns:
            True if export successful
        """
        try:
            messages = self.get_message_history(limit=10000)  # Get all messages
            
            if format_type == "json":
                with open(output_file, 'w') as f:
                    json.dump(messages, f, indent=2, default=str)
                    
            elif format_type == "csv":
                import csv
                with open(output_file, 'w', newline='') as f:
                    if messages:
                        writer = csv.DictWriter(f, fieldnames=messages[0].keys())
                        writer.writeheader()
                        writer.writerows(messages)
            
            self.logger.info(f"Messages exported to {output_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to export messages: {e}")
            return False
    
    def __str__(self) -> str:
        return f"MessageLogger(total_messages={self.stats['total_messages']})"
    
    def __repr__(self) -> str:
        return f"MessageLogger(log_dir='{self.log_dir}', total_messages={self.stats['total_messages']})"
