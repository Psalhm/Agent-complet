"""
Core package for the multi-agent communication system.
"""
from .message_schema import Message, MessageType
from .bus import MessageBus
from .logger import MessageLogger

__all__ = ['Message', 'MessageType', 'MessageBus', 'MessageLogger']
