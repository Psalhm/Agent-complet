"""
Message schema definitions using Pydantic for validation.
"""
from pydantic import BaseModel, Field
from typing import Dict, Any, Optional
from datetime import datetime
from enum import Enum


class MessageType(str, Enum):
    """
    Enumeration of supported message types.
    """
    REQUEST = "request"
    RESPONSE = "response"
    ERROR = "error"
    COORDINATION = "coordination"


class Message(BaseModel):
    """
    Structured message format for inter-agent communication.
    
    This model defines the standard format for all messages exchanged
    between agents in the system.
    """
    
    sender: str = Field(
        ...,
        description="Name of the agent sending the message",
        min_length=1,
        max_length=100
    )
    
    recipient: str = Field(
        ...,
        description="Name of the agent receiving the message or '*' for broadcast",
        min_length=1,
        max_length=100
    )
    
    type: MessageType = Field(
        ...,
        description="Type of message: request, response, error, or coordination"
    )
    
    task: str = Field(
        ...,
        description="Short description of the task or operation",
        min_length=1,
        max_length=200
    )
    
    payload: Dict[str, Any] = Field(
        default_factory=dict,
        description="Dictionary containing the actual message data"
    )
    
    timestamp: datetime = Field(
        default_factory=datetime.now,
        description="ISO timestamp when the message was created"
    )
    
    message_id: Optional[str] = Field(
        default=None,
        description="Unique identifier for the message"
    )
    
    correlation_id: Optional[str] = Field(
        default=None,
        description="ID to correlate request/response pairs"
    )
    
    priority: int = Field(
        default=1,
        description="Message priority (1=low, 5=high)",
        ge=1,
        le=5
    )
    
    def __init__(self, **data):
        """
        Initialize a message with automatic message ID generation.
        """
        if 'message_id' not in data:
            data['message_id'] = f"msg_{data.get('sender', 'unknown')}_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
        super().__init__(**data)
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the message to a dictionary for serialization.
        
        Returns:
            Dictionary representation of the message
        """
        return {
            "sender": self.sender,
            "recipient": self.recipient,
            "type": self.type.value,
            "task": self.task,
            "payload": self.payload,
            "timestamp": self.timestamp.isoformat(),
            "message_id": self.message_id,
            "correlation_id": self.correlation_id,
            "priority": self.priority
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Message':
        """
        Create a message from a dictionary.
        
        Args:
            data: Dictionary containing message data
            
        Returns:
            Message instance
        """
        # Convert timestamp string back to datetime if needed
        if isinstance(data.get('timestamp'), str):
            data['timestamp'] = datetime.fromisoformat(data['timestamp'].replace('Z', '+00:00'))
        
        return cls(**data)
    
    def create_response(self, response_payload: Dict[str, Any], 
                       sender: str) -> 'Message':
        """
        Create a response message to this message.
        
        Args:
            response_payload: Response data
            sender: Name of the agent sending the response
            
        Returns:
            Response message
        """
        return Message(
            sender=sender,
            recipient=self.sender,
            type=MessageType.RESPONSE,
            task=f"{self.task}_response",
            payload=response_payload,
            correlation_id=self.message_id,
            priority=self.priority
        )
    
    def create_error(self, error_message: str, sender: str) -> 'Message':
        """
        Create an error message in response to this message.
        
        Args:
            error_message: Error description
            sender: Name of the agent sending the error
            
        Returns:
            Error message
        """
        return Message(
            sender=sender,
            recipient=self.sender,
            type=MessageType.ERROR,
            task=f"{self.task}_error",
            payload={
                "error": error_message,
                "original_task": self.task,
                "original_message_id": self.message_id
            },
            correlation_id=self.message_id,
            priority=min(self.priority + 1, 5)  # Increase priority for errors
        )
    
    def is_broadcast(self) -> bool:
        """
        Check if this message is a broadcast message.
        
        Returns:
            True if message is broadcast
        """
        return self.recipient == "*"
    
    def is_response_to(self, original_message: 'Message') -> bool:
        """
        Check if this message is a response to another message.
        
        Args:
            original_message: Original message to check against
            
        Returns:
            True if this is a response to the original message
        """
        return (self.correlation_id == original_message.message_id and
                self.type == MessageType.RESPONSE)
    
    def __str__(self) -> str:
        """
        String representation of the message.
        
        Returns:
            Human-readable string representation
        """
        return f"Message({self.sender} -> {self.recipient}: {self.task})"
    
    def __repr__(self) -> str:
        """
        Detailed string representation of the message.
        
        Returns:
            Detailed string representation
        """
        return (f"Message(sender='{self.sender}', recipient='{self.recipient}', "
                f"type='{self.type.value}', task='{self.task}', "
                f"timestamp='{self.timestamp.isoformat()}')")


class MessageValidationError(ValueError):
    """
    Custom exception for message validation errors.
    """
    pass


def validate_message(message_data: Dict[str, Any]) -> Message:
    """
    Validate and create a message from dictionary data.
    
    Args:
        message_data: Dictionary containing message data
        
    Returns:
        Validated Message instance
        
    Raises:
        MessageValidationError: If validation fails
    """
    try:
        return Message.from_dict(message_data)
    except Exception as e:
        raise MessageValidationError(f"Invalid message format: {e}")
