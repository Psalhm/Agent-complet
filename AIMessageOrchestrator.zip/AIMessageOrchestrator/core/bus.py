"""
Message bus for routing messages between agents.
"""
import logging
from typing import Dict, List, Optional, Callable, Any
from datetime import datetime
import json
from threading import Lock

from .message_schema import Message, MessageType
from .logger import MessageLogger


class MessageBus:
    """
    Central message bus for routing messages between agents.
    
    The message bus handles:
    - Agent registration and discovery
    - Message routing and delivery
    - Broadcast messaging
    - Error handling and logging
    - Message queuing and buffering
    """
    
    def __init__(self, logger: Optional[MessageLogger] = None):
        """
        Initialize the message bus.
        
        Args:
            logger: Optional message logger instance
        """
        self.agents: Dict[str, Any] = {}  # Registered agents
        self.message_handlers: Dict[str, Callable] = {}  # Message handlers
        self.message_queue: List[Message] = []  # Message queue
        self.message_history: List[Message] = []  # Message history
        self.logger = logger or MessageLogger()
        self.system_logger = logging.getLogger('message_bus')
        self._lock = Lock()  # Thread safety
        
        # Bus statistics
        self.stats = {
            'messages_routed': 0,
            'messages_delivered': 0,
            'messages_failed': 0,
            'broadcast_count': 0,
            'registered_agents': 0
        }
        
        self.system_logger.info("MessageBus initialized")
    
    def register_agent(self, agent) -> bool:
        """
        Register an agent with the message bus.
        
        Args:
            agent: Agent instance to register
            
        Returns:
            True if registration successful
        """
        with self._lock:
            if agent.name in self.agents:
                self.system_logger.warning(f"Agent {agent.name} already registered")
                return False
            
            self.agents[agent.name] = agent
            self.message_handlers[agent.name] = agent.handle_message
            self.stats['registered_agents'] += 1
            
            self.system_logger.info(f"Agent {agent.name} registered successfully")
            
            # Log registration
            self.logger.log_message(Message(
                sender="message_bus",
                recipient=agent.name,
                type=MessageType.COORDINATION,
                task="agent_registration",
                payload={"agent_name": agent.name, "capabilities": agent.get_capabilities()}
            ))
            
            return True
    
    def unregister_agent(self, agent_name: str) -> bool:
        """
        Unregister an agent from the message bus.
        
        Args:
            agent_name: Name of the agent to unregister
            
        Returns:
            True if unregistration successful
        """
        with self._lock:
            if agent_name not in self.agents:
                self.system_logger.warning(f"Agent {agent_name} not found for unregistration")
                return False
            
            del self.agents[agent_name]
            del self.message_handlers[agent_name]
            self.stats['registered_agents'] -= 1
            
            self.system_logger.info(f"Agent {agent_name} unregistered successfully")
            
            # Log unregistration
            self.logger.log_message(Message(
                sender="message_bus",
                recipient=agent_name,
                type=MessageType.COORDINATION,
                task="agent_unregistration",
                payload={"agent_name": agent_name}
            ))
            
            return True
    
    def route_message(self, message: Message) -> bool:
        """
        Route a message to its destination.
        
        Args:
            message: Message to route
            
        Returns:
            True if routing successful
        """
        with self._lock:
            self.stats['messages_routed'] += 1
            
            # Log the message
            self.logger.log_message(message)
            
            # Add to message history
            self.message_history.append(message)
            
            # Keep only last 1000 messages in history
            if len(self.message_history) > 1000:
                self.message_history = self.message_history[-1000:]
            
            # Handle broadcast messages
            if message.is_broadcast():
                return self._handle_broadcast(message)
            
            # Route to specific recipient
            return self._route_to_recipient(message)
    
    def _route_to_recipient(self, message: Message) -> bool:
        """
        Route message to a specific recipient.
        
        Args:
            message: Message to route
            
        Returns:
            True if delivery successful
        """
        recipient = message.recipient
        
        if recipient not in self.agents:
            # Recipient not found, send error back to sender
            error_message = Message(
                sender="message_bus",
                recipient=message.sender,
                type=MessageType.ERROR,
                task="routing_error",
                payload={
                    "error": f"Recipient not found: {recipient}",
                    "original_message": message.to_dict(),
                    "available_agents": list(self.agents.keys())
                }
            )
            
            self.logger.log_message(error_message)
            self.stats['messages_failed'] += 1
            
            # Try to deliver error message to sender
            if message.sender in self.agents:
                try:
                    self.message_handlers[message.sender](error_message)
                    self.system_logger.error(f"Routing failed: {recipient} not found, error sent to {message.sender}")
                except Exception as e:
                    self.system_logger.error(f"Failed to deliver error message to {message.sender}: {e}")
            
            return False
        
        # Deliver message to recipient
        try:
            handler = self.message_handlers[recipient]
            handler(message)
            self.stats['messages_delivered'] += 1
            self.system_logger.debug(f"Message delivered: {message.sender} -> {recipient}")
            return True
            
        except Exception as e:
            # Delivery failed, send error back to sender
            error_message = Message(
                sender="message_bus",
                recipient=message.sender,
                type=MessageType.ERROR,
                task="delivery_error",
                payload={
                    "error": f"Message delivery failed: {str(e)}",
                    "original_message": message.to_dict(),
                    "target_agent": recipient
                }
            )
            
            self.logger.log_message(error_message)
            self.stats['messages_failed'] += 1
            
            # Try to deliver error message to sender
            if message.sender in self.agents and message.sender != recipient:
                try:
                    self.message_handlers[message.sender](error_message)
                    self.system_logger.error(f"Delivery failed to {recipient}, error sent to {message.sender}")
                except Exception as delivery_error:
                    self.system_logger.error(f"Failed to deliver error message to {message.sender}: {delivery_error}")
            
            return False
    
    def _handle_broadcast(self, message: Message) -> bool:
        """
        Handle broadcast messages.
        
        Args:
            message: Broadcast message
            
        Returns:
            True if broadcast successful
        """
        self.stats['broadcast_count'] += 1
        delivered_count = 0
        failed_count = 0
        
        # Send to all registered agents except sender
        for agent_name in self.agents:
            if agent_name == message.sender:
                continue
                
            try:
                # Create individual message for each recipient
                individual_message = Message(
                    sender=message.sender,
                    recipient=agent_name,
                    type=message.type,
                    task=message.task,
                    payload=message.payload,
                    timestamp=message.timestamp,
                    correlation_id=message.correlation_id,
                    priority=message.priority
                )
                
                handler = self.message_handlers[agent_name]
                handler(individual_message)
                delivered_count += 1
                
            except Exception as e:
                failed_count += 1
                self.system_logger.error(f"Broadcast delivery failed to {agent_name}: {e}")
        
        self.stats['messages_delivered'] += delivered_count
        self.stats['messages_failed'] += failed_count
        
        self.system_logger.info(f"Broadcast from {message.sender}: {delivered_count} delivered, {failed_count} failed")
        
        return delivered_count > 0
    
    def broadcast_message(self, message: Message) -> bool:
        """
        Broadcast a message to all registered agents.
        
        Args:
            message: Message to broadcast
            
        Returns:
            True if broadcast successful
        """
        # Ensure message is marked as broadcast
        message.recipient = "*"
        return self.route_message(message)
    
    def get_registered_agents(self) -> List[str]:
        """
        Get list of registered agent names.
        
        Returns:
            List of registered agent names
        """
        with self._lock:
            return list(self.agents.keys())
    
    def get_agent_capabilities(self, agent_name: str) -> Optional[List[str]]:
        """
        Get capabilities of a specific agent.
        
        Args:
            agent_name: Name of the agent
            
        Returns:
            List of capabilities or None if agent not found
        """
        with self._lock:
            if agent_name in self.agents:
                return self.agents[agent_name].get_capabilities()
            return None
    
    def get_message_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get recent message history.
        
        Args:
            limit: Maximum number of messages to return
            
        Returns:
            List of message dictionaries
        """
        with self._lock:
            recent_messages = self.message_history[-limit:]
            return [msg.to_dict() for msg in recent_messages]
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get message bus statistics.
        
        Returns:
            Dictionary of statistics
        """
        with self._lock:
            return {
                **self.stats,
                'message_queue_size': len(self.message_queue),
                'message_history_size': len(self.message_history),
                'active_agents': list(self.agents.keys())
            }
    
    def clear_history(self) -> None:
        """
        Clear message history.
        """
        with self._lock:
            self.message_history.clear()
            self.system_logger.info("Message history cleared")
    
    def reset_stats(self) -> None:
        """
        Reset message bus statistics.
        """
        with self._lock:
            self.stats.update({
                'messages_routed': 0,
                'messages_delivered': 0,
                'messages_failed': 0,
                'broadcast_count': 0
            })
            self.system_logger.info("Message bus statistics reset")
    
    def shutdown(self) -> None:
        """
        Shutdown the message bus.
        """
        with self._lock:
            self.system_logger.info("MessageBus shutting down")
            
            # Notify all agents
            shutdown_message = Message(
                sender="message_bus",
                recipient="*",
                type=MessageType.COORDINATION,
                task="system_shutdown",
                payload={"message": "Message bus is shutting down"}
            )
            
            self.broadcast_message(shutdown_message)
            
            # Clear all data
            self.agents.clear()
            self.message_handlers.clear()
            self.message_queue.clear()
            
            self.system_logger.info("MessageBus shutdown complete")
    
    def __str__(self) -> str:
        return f"MessageBus(agents={len(self.agents)}, messages_routed={self.stats['messages_routed']})"
    
    def __repr__(self) -> str:
        return f"MessageBus(registered_agents={list(self.agents.keys())}, stats={self.stats})"
