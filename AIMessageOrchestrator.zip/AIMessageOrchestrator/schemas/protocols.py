"""
Protocol definitions for inter-agent communication.
Defines Pydantic models for different communication protocols.
"""

from pydantic import BaseModel, Field, validator
from typing import Dict, List, Any, Optional, Union
from enum import Enum
from datetime import datetime

class ProtocolType(str, Enum):
    """Available communication protocols."""
    PROMPT = "prompt"
    JSON_RPC = "json-rpc"
    TOOL = "tool"

class PromptProtocol(BaseModel):
    """Natural language prompt-based communication protocol."""
    role: str = Field(..., description="Role of the message sender (user, assistant, system)")
    content: str = Field(..., description="Natural language content of the message")
    context: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Additional context")
    
    @validator('role')
    def validate_role(cls, v):
        allowed_roles = ['user', 'assistant', 'system']
        if v not in allowed_roles:
            raise ValueError(f"Role must be one of: {allowed_roles}")
        return v
    
    @validator('content')
    def validate_content(cls, v):
        if not v.strip():
            raise ValueError("Content cannot be empty")
        return v.strip()

class JsonRpcProtocol(BaseModel):
    """JSON-RPC 2.0 protocol for structured requests."""
    jsonrpc: str = Field("2.0", description="JSON-RPC version")
    method: str = Field(..., description="Method name to call")
    params: Dict[str, Any] = Field(default_factory=dict, description="Method parameters")
    id: Union[str, int] = Field(..., description="Request identifier")
    
    @validator('jsonrpc')
    def validate_jsonrpc(cls, v):
        if v != "2.0":
            raise ValueError("JSON-RPC version must be 2.0")
        return v
    
    @validator('method')
    def validate_method(cls, v):
        if not v.strip():
            raise ValueError("Method name cannot be empty")
        return v.strip()

class ToolProtocol(BaseModel):
    """Tool-based protocol for agent function calls."""
    tool_name: str = Field(..., description="Name of the tool/function to call")
    parameters: Dict[str, Any] = Field(default_factory=dict, description="Tool parameters")
    agent_id: str = Field(..., description="Target agent identifier")
    
    @validator('tool_name')
    def validate_tool_name(cls, v):
        if not v.strip():
            raise ValueError("Tool name cannot be empty")
        return v.strip()
    
    @validator('agent_id')
    def validate_agent_id(cls, v):
        if not v.strip():
            raise ValueError("Agent ID cannot be empty")
        return v.strip()

class ExchangeRequest(BaseModel):
    """Request model for message exchange endpoint."""
    sender: str = Field(..., description="Message sender identifier")
    recipient: str = Field(..., description="Message recipient identifier")
    protocol: ProtocolType = Field(..., description="Communication protocol to use")
    message: Dict[str, Any] = Field(..., description="Protocol-specific message content")
    
    @validator('sender')
    def validate_sender(cls, v):
        if not v.strip():
            raise ValueError("Sender cannot be empty")
        return v.strip()
    
    @validator('recipient')
    def validate_recipient(cls, v):
        if not v.strip():
            raise ValueError("Recipient cannot be empty")
        return v.strip()

class ExchangeResponse(BaseModel):
    """Response model for message exchange endpoint."""
    success: bool = Field(..., description="Whether the exchange was successful")
    message: str = Field(..., description="Response message")
    exchange_id: str = Field(..., description="Unique exchange identifier")
    protocol: ProtocolType = Field(..., description="Protocol used")
    response_data: Dict[str, Any] = Field(default_factory=dict, description="Agent response data")
    timestamp: str = Field(..., description="Response timestamp")

class ValidationRequest(BaseModel):
    """Request model for message validation endpoint."""
    protocol: ProtocolType = Field(..., description="Protocol to validate against")
    message: Dict[str, Any] = Field(..., description="Message to validate")

class ValidationResponse(BaseModel):
    """Response model for message validation endpoint."""
    success: bool = Field(..., description="Whether validation passed")
    message: str = Field(..., description="Validation result message")
    protocol: ProtocolType = Field(..., description="Protocol validated against")
    errors: List[str] = Field(default_factory=list, description="Validation errors if any")
    timestamp: str = Field(..., description="Validation timestamp")

# Protocol examples for documentation
PROTOCOL_EXAMPLES = {
    "prompt": {
        "role": "user",
        "content": "Calculate the sum of 1, 2, and 3",
        "context": {"agent": "compute_agent", "priority": "normal"}
    },
    "json-rpc": {
        "jsonrpc": "2.0",
        "method": "calculate",
        "params": {
            "operation": "add",
            "operands": [1, 2, 3]
        },
        "id": "req_123"
    },
    "tool": {
        "tool_name": "statistics",
        "parameters": {
            "data": [1, 2, 3, 4, 5],
            "operations": ["mean", "median"]
        },
        "agent_id": "compute_agent"
    }
}

# Protocol validation schemas
PROTOCOL_SCHEMAS = {
    "prompt": {
        "type": "object",
        "required": ["role", "content"],
        "properties": {
            "role": {"type": "string", "enum": ["user", "assistant", "system"]},
            "content": {"type": "string", "minLength": 1},
            "context": {"type": "object"}
        }
    },
    "json-rpc": {
        "type": "object",
        "required": ["jsonrpc", "method", "id"],
        "properties": {
            "jsonrpc": {"type": "string", "enum": ["2.0"]},
            "method": {"type": "string", "minLength": 1},
            "params": {"type": "object"},
            "id": {"type": ["string", "integer"]}
        }
    },
    "tool": {
        "type": "object",
        "required": ["tool_name", "agent_id"],
        "properties": {
            "tool_name": {"type": "string", "minLength": 1},
            "parameters": {"type": "object"},
            "agent_id": {"type": "string", "minLength": 1}
        }
    }
}