"""
Schemas package for protocol definitions and validation models.
"""