#!/usr/bin/env python3
"""
Quick test for the specific message format.
"""

import json
import sys
from core.message_schema import Message, MessageType
from core.logger import MessageLogger
from core.bus import MessageBus
from agents.agent_compute import ComputeAgent
from agents.coordinator import CoordinatorAgent

def main():
    """Quick test of the message format."""
    print("🧪 Testing message format...")
    
    # Initialize system
    logger = MessageLogger()
    bus = MessageBus(logger)
    compute_agent = ComputeAgent('compute_agent', bus)
    coordinator_agent = CoordinatorAgent('coordinator', bus)
    
    # Your exact message format
    message_data = {
        "sender": "coordinator",
        "receiver": "compute_agent",
        "action": "statistics",
        "payload": {
            "data": [1, 2, 3, 4, 5],
            "operations": ["mean", "median"]
        },
        "timestamp": "2025-07-09T12:00:00Z"
    }
    
    print("📨 Message format:")
    print(json.dumps(message_data, indent=2))
    
    # Test direct call
    result = compute_agent._compute_statistics(message_data["payload"], "test_user")
    print(f"\n✅ Direct result: {result}")
    
    # Test conversion
    internal_message = Message(
        sender=message_data["sender"],
        recipient=message_data["receiver"],
        type=MessageType.REQUEST,
        task=message_data["action"],
        payload=message_data["payload"]
    )
    
    print(f"\n🔄 Internal format:")
    print(f"  Sender: {internal_message.sender}")
    print(f"  Recipient: {internal_message.recipient}")
    print(f"  Task: {internal_message.task}")
    print(f"  Payload: {internal_message.payload}")
    
    print("\n✅ Format test completed!")

if __name__ == "__main__":
    main()