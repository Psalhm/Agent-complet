#!/usr/bin/env python3
"""
Examples of how to use the orchestration API with different protocols.
"""

import json
import time
from typing import Dict, Any

# Using curl commands instead of requests for demonstration
def demonstrate_api():
    """Demonstrate different API usage patterns."""
    
    print("🚀 Orchestration API Examples")
    print("=" * 50)
    
    # Example 1: Prompt Protocol
    print("\n1. 📝 Using Prompt Protocol")
    print("Command:")
    prompt_cmd = """curl -X POST http://localhost:5000/exchange \\
  -H "Content-Type: application/json" \\
  -d '{
    "sender": "user",
    "recipient": "compute_agent",
    "protocol": "prompt",
    "message": {
      "role": "user",
      "content": "Calculate the average of 10, 20, 30, 40, 50",
      "context": {"operation": "statistics"}
    }
  }'"""
    print(prompt_cmd)
    
    # Example 2: JSON-RPC Protocol
    print("\n2. 🔧 Using JSON-RPC Protocol")
    print("Command:")
    jsonrpc_cmd = """curl -X POST http://localhost:5000/exchange \\
  -H "Content-Type: application/json" \\
  -d '{
    "sender": "api_client",
    "recipient": "compute_agent",
    "protocol": "json-rpc",
    "message": {
      "jsonrpc": "2.0",
      "method": "statistics",
      "params": {
        "data": [1, 2, 3, 4, 5],
        "operations": ["mean", "median"]
      },
      "id": "stat_req_001"
    }
  }'"""
    print(jsonrpc_cmd)
    
    # Example 3: Tool Protocol
    print("\n3. 🛠️ Using Tool Protocol")
    print("Command:")
    tool_cmd = """curl -X POST http://localhost:5000/exchange \\
  -H "Content-Type: application/json" \\
  -d '{
    "sender": "tool_user",
    "recipient": "compute_agent",
    "protocol": "tool",
    "message": {
      "tool_name": "mathematical_operations",
      "parameters": {
        "operation": "fibonacci",
        "value": 10
      },
      "agent_id": "compute_agent"
    }
  }'"""
    print(tool_cmd)
    
    # Example 4: Validation
    print("\n4. ✅ Message Validation")
    print("Command:")
    validation_cmd = """curl -X POST http://localhost:5000/validate-message \\
  -H "Content-Type: application/json" \\
  -d '{
    "protocol": "json-rpc",
    "message": {
      "jsonrpc": "2.0",
      "method": "calculate",
      "params": {"operation": "add", "operands": [1, 2, 3]},
      "id": "validation_test"
    }
  }'"""
    print(validation_cmd)
    
    # Example 5: Get System Information
    print("\n5. 📊 System Information")
    print("Commands:")
    info_cmds = [
        "curl -X GET http://localhost:5000/agents",
        "curl -X GET http://localhost:5000/protocols",
        "curl -X GET http://localhost:5000/stats"
    ]
    
    for cmd in info_cmds:
        print(f"  {cmd}")
    
    print("\n6. 🌐 Swagger Documentation")
    print("Visit: http://localhost:5000/docs")
    print("Or ReDoc: http://localhost:5000/redoc")
    
    print("\n" + "=" * 50)
    print("✨ All examples ready to use!")

def create_test_data():
    """Create test data examples for different protocols."""
    test_data = {
        "prompt_examples": [
            {
                "role": "user",
                "content": "Calculate the sum of 1, 2, 3, 4, 5",
                "context": {"priority": "high"}
            },
            {
                "role": "user", 
                "content": "Get system status",
                "context": {"agent": "coordinator"}
            }
        ],
        "jsonrpc_examples": [
            {
                "jsonrpc": "2.0",
                "method": "calculate",
                "params": {"operation": "multiply", "operands": [2, 3, 4]},
                "id": "calc_001"
            },
            {
                "jsonrpc": "2.0",
                "method": "statistics",
                "params": {"data": [1, 2, 3, 4, 5], "operations": ["mean", "std"]},
                "id": "stat_001"
            }
        ],
        "tool_examples": [
            {
                "tool_name": "mathematical_operations",
                "parameters": {"operation": "factorial", "value": 5},
                "agent_id": "compute_agent"
            },
            {
                "tool_name": "data_analysis",
                "parameters": {"data": [1, 2, 3, 4, 5], "analysis_type": "summary"},
                "agent_id": "compute_agent"
            }
        ]
    }
    
    with open("test_data.json", "w") as f:
        json.dump(test_data, f, indent=2)
    
    print("📄 Test data saved to test_data.json")

if __name__ == "__main__":
    demonstrate_api()
    create_test_data()