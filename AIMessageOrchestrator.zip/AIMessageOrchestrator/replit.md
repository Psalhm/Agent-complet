# Multi-Agent Communication System

## Overview

This is a Python-based multi-agent communication system that enables AI agents to communicate through structured JSON messages. The system implements a message bus architecture with Pydantic validation, specialized agents for different tasks, and comprehensive logging capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

**Latest Update - July 9, 2025:**
✓ Implemented FastAPI orchestration API for inter-agent communication
✓ Added three communication protocols: prompt, json-rpc, and tool
✓ Created comprehensive validation system with Pydantic models
✓ Built Swagger documentation interface at /docs
✓ Added message exchange, validation, and system monitoring endpoints
✓ Fixed infinite loop bugs in agent response handling
✓ System now supports both CLI and REST API interfaces

## System Architecture

### Core Architecture Pattern
The system follows a **message-oriented middleware (MOM)** pattern with a central message bus handling all inter-agent communication. This decouples agents from each other and provides a scalable foundation for multi-agent coordination.

### Key Design Decisions
- **Pydantic for Message Validation**: Ensures all messages follow a strict schema with automatic validation
- **Centralized Message Bus**: Single point of communication routing that handles message delivery, queuing, and error handling
- **Agent Specialization**: Each agent type handles specific capabilities (database operations, computations, coordination)
- **JSON Structured Logging**: Dual logging format (JSON for programmatic access, human-readable for debugging)

## Key Components

### 1. Message Schema (`core/message_schema.py`)
- **Pydantic Models**: Strict validation for message structure
- **MessageType Enum**: Defines supported message types (request, response, error, coordination)
- **Standard Fields**: sender, recipient, type, task, payload, timestamp, message_id, correlation_id, priority

### 2. Message Bus (`core/bus.py`)
- **Agent Registration**: Manages agent discovery and registration
- **Message Routing**: Intelligent routing to appropriate agents
- **Broadcast Support**: Messages can be sent to all agents
- **Queue Management**: Handles message queuing and buffering
- **Statistics Tracking**: Monitors system performance metrics

### 3. Message Logger (`core/logger.py`)
- **Dual Format Logging**: JSON structured and human-readable formats
- **Message History**: Complete audit trail of all communications
- **Search Capabilities**: Content-based message searching
- **Export Functions**: JSON and CSV export capabilities

### 4. Agent System (`agents/`)
- **BaseAgent**: Abstract base class providing common functionality
- **ComputeAgent**: Performs mathematical calculations and statistical operations
- **CoordinatorAgent**: Orchestrates workflows and coordinates between agents

### 5. Orchestration API (`orchestration_api.py`)
- **FastAPI Server**: REST API for inter-agent communication
- **Protocol Support**: Three communication protocols (prompt, json-rpc, tool)
- **Message Validation**: Pydantic-based validation for all protocols
- **Swagger Documentation**: Interactive API documentation at /docs
- **System Monitoring**: Real-time statistics and agent status

### 6. Protocol Schemas (`schemas/`)
- **Protocol Definitions**: Pydantic models for each communication protocol
- **Validation Rules**: Comprehensive validation for message formats
- **Example Data**: Sample messages for testing and documentation

## Data Flow

1. **Agent Registration**: Agents register with the message bus upon initialization
2. **Message Creation**: Agents create Pydantic-validated messages
3. **Message Routing**: Bus routes messages to appropriate recipients
4. **Message Processing**: Receiving agents process messages and optionally respond
5. **Logging**: All messages are logged in both JSON and human-readable formats

## External Dependencies

### Required Libraries
- **Pydantic**: Message validation and schema enforcement
- **Standard Library**: json, logging, datetime, pathlib, threading, enum, abc

### Optional Dependencies
- **asyncio**: For future asynchronous message handling
- **typing**: Enhanced type hints for better code maintainability

## Deployment Strategy

### Development Environment
- **Local File System**: In-memory storage for database agent (demonstration purposes)
- **File-based Logging**: Local log files in `logs/` directory
- **CLI Interface**: Interactive command-line interface for testing and demonstration

### Production Considerations
- **Database Integration**: Replace in-memory storage with actual database connections
- **Message Persistence**: Consider persistent message queues for reliability
- **Distributed Deployment**: Architecture supports multiple instances with proper message bus scaling
- **Monitoring**: Built-in statistics tracking provides foundation for monitoring systems

### File Structure
```
├── core/           # Core system components
│   ├── message_schema.py
│   ├── bus.py
│   └── logger.py
├── agents/         # Agent implementations
│   ├── base.py
│   ├── agent_compute.py
│   └── coordinator.py
├── logs/           # Log files (created at runtime)
├── main.py         # CLI interface
└── demo.py         # Demonstration script
```

### Key Features
- **Thread-Safe**: Uses locks for concurrent access protection
- **Extensible**: Easy to add new agent types and capabilities
- **Testable**: Clear separation of concerns and dependency injection
- **Observable**: Comprehensive logging and statistics for monitoring