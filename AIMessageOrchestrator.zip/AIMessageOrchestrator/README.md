# Multi-Agent Communication System

Un système de communication entre agents IA basé sur des messages JSON structurés avec Pydantic et un bus de communication.

## 🎯 Objectif

Permettre à plusieurs agents Python de communiquer entre eux via des messages normalisés, pour déléguer des tâches, signaler des erreurs ou coordonner des actions.

## 📋 Fonctionnalités

### Modèle de message structuré
- **Validation Pydantic** : Schéma JSON avec validation automatique
- **Champs standardisés** : sender, recipient, type, task, payload, timestamp
- **Types de messages** : request, response, error, coordination
- **Métadonnées** : message_id, correlation_id, priority

### Bus de communication
- **Routage intelligent** : Messages dirigés vers les bons agents
- **Gestion d'erreurs** : Erreurs de routage et de livraison
- **Broadcast** : Messages diffusés à tous les agents
- **Statistiques** : Suivi des performances du système

### Système de logging
- **Double format** : JSON structuré et logs lisibles
- **Historique complet** : Tous les messages enregistrés
- **Recherche** : Recherche par contenu dans les messages
- **Export** : Export en JSON ou CSV

### Agents spécialisés
- **BaseAgent** : Classe de base pour tous les agents
- **DatabaseAgent** : Gestion des données (store, retrieve, query, delete)
- **ComputeAgent** : Calculs mathématiques et statistiques
- **CoordinatorAgent** : Coordination entre agents et workflows

## 🚀 Démarrage rapide

### Installation
```bash
# Cloner le projet
git clone <repository-url>
cd agent_comm_system

# Installer les dépendances
pip install pydantic

# Créer le dossier de logs
mkdir -p logs
```

### Utilisation

#### Mode interactif (CLI)
```bash
python main.py
```

#### Démonstration complète
```bash
python demo.py
```

## 🏗️ Architecture

### Structure des fichiers
```
agent_comm_system/
├── agents/                    # Agents spécialisés
│   ├── __init__.py
│   ├── base.py               # Classe de base pour tous les agents
│   ├── agent_db.py           # Agent base de données
│   ├── agent_compute.py      # Agent de calcul
│   └── coordinator.py        # Agent coordinateur
├── core/                     # Composants système
│   ├── __init__.py
│   ├── message_schema.py     # Schémas Pydantic pour les messages
│   ├── bus.py               # Bus de communication
│   └── logger.py            # Système de logging
├── logs/                    # Logs du système
│   ├── .gitkeep
│   ├── messages.json        # Logs JSON structurés
│   └── messages.log         # Logs lisibles par l'homme
├── demo.py                  # Script de démonstration
├── main.py                  # Interface CLI interactive
└── README.md
```

## 🔧 Utilisation avancée

### Envoyer des messages via CLI
```bash
# Envoyer un message à un agent
(agents) send db_agent store_data {"key": "test", "data": {"value": 123}}

# Diffuser un message à tous les agents
(agents) broadcast system_announcement {"message": "Maintenance programmée"}

# Voir l'historique des messages
(agents) history 10

# Rechercher dans les messages
(agents) search calculate

# Afficher les statistiques
(agents) stats
```

### Exemples d'utilisation programmatique

#### Création d'agents personnalisés
```python
from agents.base import BaseAgent
from core.message_schema import Message, MessageType

class CustomAgent(BaseAgent):
    def __init__(self, name: str, bus):
        super().__init__(name, bus)
        self.add_capability("custom_task")
    
    def handle_message(self, message: Message):
        if message.task == "custom_task":
            # Traiter la tâche personnalisée
            response = {"result": "Task completed"}
            self.send_message(message.sender, MessageType.RESPONSE, 
                            "custom_task_response", response)
```

#### Coordination de workflows
```python
# Orchestrer un workflow complexe
coordinator.send_message("coordinator", MessageType.REQUEST, "orchestrate_workflow", {
    "workflow_id": "data_processing",
    "steps": [
        {"agent": "db_agent", "task": "retrieve_data", "params": {"key": "raw_data"}},
        {"agent": "compute_agent", "task": "statistics", "params": {"data": [1,2,3,4,5]}},
        {"agent": "db_agent", "task": "store_data", "params": {"key": "results", "data": {}}}
    ]
})
```

## 📊 Fonctionnalités avancées

### Gestion des erreurs
- Validation automatique des messages avec Pydantic
- Routage d'erreurs vers les expéditeurs
- Logging détaillé de toutes les erreurs

### Monitoring et observabilité
- Statistiques en temps réel du bus de messages
- Historique complet des communications
- Recherche dans les logs
- Export des données en JSON/CSV

### Sécurité thread-safe
- Verrous pour les opérations concurrentes
- Gestion sécurisée des agents multiples
- Queue de messages thread-safe

## 🔮 Extensions possibles

### Persistance
- Remplacer le stockage en mémoire par une vraie base de données
- Ajouter la persistance des messages
- Implémenter des queues persistantes

### Réseau
- Support des agents distribués
- Communication inter-processus
- APIs REST pour l'intégration externe

### Monitoring avancé
- Métriques Prometheus
- Dashboards Grafana
- Alertes en temps réel

## 🧪 Tests

### Exécution des tests
```bash
# Tests unitaires (à implémenter)
python -m pytest tests/

# Tests d'intégration
python demo.py
```

### Tests manuels via CLI
```bash
python main.py
(agents) demo  # Exécute une démonstration rapide
```

## 🐛 Dépannage

### Problèmes courants

**Agent non trouvé**
```
❌ Recipient not found: agent_name
```
Solution : Vérifier que l'agent est bien enregistré avec `agents`

**Erreur de validation JSON**
```
❌ Invalid JSON payload: ...
```
Solution : Vérifier la syntaxe JSON du payload

**Erreur de format de message**
```
MessageValidationError: Invalid message format
```
Solution : Vérifier que tous les champs requis sont présents

### Logs de débogage
- Consulter `logs/messages.log` pour les détails
- Utiliser `logs/messages.json` pour l'analyse programmatique
- Commande `search` pour retrouver des messages spécifiques

## 🤝 Contribution

### Ajouter de nouveaux agents
1. Hériter de `BaseAgent`
2. Implémenter `handle_message()`
3. Ajouter les capacités avec `add_capability()`
4. Enregistrer l'agent avec le bus

### Ajouter de nouveaux types de messages
1. Étendre `MessageType` dans `core/message_schema.py`
2. Mettre à jour la validation si nécessaire
3. Tester avec les agents existants

## 📄 Licence

MIT License - Voir le fichier LICENSE pour plus de détails.
