"""
Main script for the multi-agent communication system.
Provides an interactive CLI for testing and demonstrating the system.
"""
import cmd
import json
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional

from core.message_schema import Message, MessageType
from core.bus import MessageBus
from core.logger import MessageLogger
from agents.agent_compute import ComputeAgent
from agents.coordinator import CoordinatorAgent


class AgentCLI(cmd.Cmd):
    """Interactive CLI for the multi-agent communication system."""
    
    intro = """
🚀 Multi-Agent Communication System CLI
=====================================

Available commands:
  - agents: List all registered agents
  - send: Send a message to an agent
  - broadcast: Send a broadcast message
  - stats: Show system statistics
  - history: Show message history
  - search: Search messages
  - clear: Clear message history
  - demo: Run quick demo
  - test_format: Test specific message format
  - help: Show this help message
  - quit: Exit the CLI

Type 'help <command>' for detailed help on a command.
"""
    
    prompt = "(agents) "
    
    def __init__(self):
        super().__init__()
        self.setup_system()
    
    def setup_system(self):
        """Initialize the agent system."""
        print("Initializing multi-agent communication system...")
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # Initialize message bus and logger
        self.message_logger = MessageLogger()
        self.bus = MessageBus(self.message_logger)
        
        # Create agents
        self.compute_agent = ComputeAgent("compute_agent", self.bus)
        self.coordinator = CoordinatorAgent("coordinator", self.bus)
        
        # CLI agent for sending messages
        self.cli_agent_name = "cli_user"
        
        print(f"✓ System initialized with agents: {self.bus.get_registered_agents()}")
        print("Type 'help' for available commands.\n")
    
    def do_agents(self, args):
        """List all registered agents and their capabilities."""
        agents = self.bus.get_registered_agents()
        
        print(f"\n📋 Registered Agents ({len(agents)}):")
        print("-" * 50)
        
        for agent_name in agents:
            capabilities = self.bus.get_agent_capabilities(agent_name)
            print(f"  🤖 {agent_name}")
            if capabilities:
                print(f"     Capabilities: {', '.join(capabilities)}")
            else:
                print(f"     Capabilities: None")
            print()
    
    def do_send(self, args):
        """
        Send a message to an agent.
        
        Usage: send <recipient> <task> <payload_json>
        Example: send compute_agent calculate {"operation": "add", "operands": [1, 2, 3]}
        """
        parts = args.split(' ', 2)
        if len(parts) < 2:
            print("Usage: send <recipient> <task> [payload_json]")
            return
        
        recipient = parts[0]
        task = parts[1]
        payload_str = parts[2] if len(parts) > 2 else "{}"
        
        try:
            payload = json.loads(payload_str)
        except json.JSONDecodeError as e:
            print(f"❌ Invalid JSON payload: {e}")
            return
        
        # Create and send message
        message = Message(
            sender=self.cli_agent_name,
            recipient=recipient,
            type=MessageType.REQUEST,
            task=task,
            payload=payload
        )
        
        success = self.bus.route_message(message)
        if success:
            print(f"✅ Message sent to {recipient}: {task}")
        else:
            print(f"❌ Failed to send message to {recipient}")
    
    def do_broadcast(self, args):
        """
        Send a broadcast message to all agents.
        
        Usage: broadcast <task> <payload_json>
        Example: broadcast system_announcement {"message": "System maintenance"}
        """
        parts = args.split(' ', 1)
        if len(parts) < 1:
            print("Usage: broadcast <task> [payload_json]")
            return
        
        task = parts[0]
        payload_str = parts[1] if len(parts) > 1 else "{}"
        
        try:
            payload = json.loads(payload_str)
        except json.JSONDecodeError as e:
            print(f"❌ Invalid JSON payload: {e}")
            return
        
        # Create and send broadcast message
        message = Message(
            sender=self.cli_agent_name,
            recipient="*",
            type=MessageType.COORDINATION,
            task=task,
            payload=payload
        )
        
        success = self.bus.broadcast_message(message)
        if success:
            print(f"📢 Broadcast sent: {task}")
        else:
            print(f"❌ Failed to send broadcast")
    
    def do_stats(self, args):
        """Show system statistics."""
        print("\n📊 System Statistics")
        print("=" * 50)
        
        # Bus statistics
        bus_stats = self.bus.get_stats()
        print(f"Message Bus:")
        print(f"  Messages routed: {bus_stats['messages_routed']}")
        print(f"  Messages delivered: {bus_stats['messages_delivered']}")
        print(f"  Messages failed: {bus_stats['messages_failed']}")
        print(f"  Broadcasts sent: {bus_stats['broadcast_count']}")
        print(f"  Registered agents: {bus_stats['registered_agents']}")
        
        # Logger statistics
        logger_stats = self.message_logger.get_stats()
        print(f"\nMessage Logger:")
        print(f"  Total messages: {logger_stats['total_messages']}")
        print(f"  Messages by type: {logger_stats['messages_by_type']}")
        print(f"  Messages by agent: {logger_stats['messages_by_agent']}")
        
        # File information
        log_files = logger_stats['log_files']
        print(f"\nLog Files:")
        print(f"  JSON log: {log_files['json_size']}")
        print(f"  Human log: {log_files['human_size']}")
    
    def do_history(self, args):
        """
        Show message history.
        
        Usage: history [limit]
        Example: history 10
        """
        limit = 20  # Default limit
        
        if args:
            try:
                limit = int(args)
            except ValueError:
                print("❌ Invalid limit. Using default limit of 20.")
        
        messages = self.message_logger.get_message_history(limit)
        
        print(f"\n📜 Message History (last {len(messages)} messages):")
        print("-" * 80)
        
        for msg in messages:
            timestamp = msg.get('timestamp', '')
            if timestamp:
                # Format timestamp
                try:
                    dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                    timestamp = dt.strftime('%H:%M:%S')
                except:
                    timestamp = timestamp[:8]  # Take first 8 chars
            
            print(f"[{timestamp}] {msg['type'].upper()}: {msg['sender']} -> {msg['recipient']}")
            print(f"  Task: {msg['task']}")
            
            # Show payload preview
            payload = msg.get('payload', {})
            if payload:
                payload_str = json.dumps(payload, default=str)
                if len(payload_str) > 60:
                    payload_str = payload_str[:60] + "..."
                print(f"  Payload: {payload_str}")
            print()
    
    def do_search(self, args):
        """
        Search messages by content.
        
        Usage: search <query>
        Example: search calculate
        """
        if not args:
            print("Usage: search <query>")
            return
        
        results = self.message_logger.search_messages(args)
        
        print(f"\n🔍 Search Results for '{args}' ({len(results)} matches):")
        print("-" * 80)
        
        for msg in results:
            timestamp = msg.get('timestamp', '')
            if timestamp:
                try:
                    dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                    timestamp = dt.strftime('%H:%M:%S')
                except:
                    timestamp = timestamp[:8]
            
            print(f"[{timestamp}] {msg['type'].upper()}: {msg['sender']} -> {msg['recipient']}")
            print(f"  Task: {msg['task']}")
            
            # Highlight matching content
            payload = msg.get('payload', {})
            if payload:
                payload_str = json.dumps(payload, default=str)
                if len(payload_str) > 60:
                    payload_str = payload_str[:60] + "..."
                print(f"  Payload: {payload_str}")
            print()
    
    def do_clear(self, args):
        """Clear message history and logs."""
        try:
            self.message_logger.clear_logs()
            self.bus.clear_history()
            self.bus.reset_stats()
            print("✅ Message history and logs cleared")
        except Exception as e:
            print(f"❌ Failed to clear logs: {e}")
    
    def do_demo(self, args):
        """Run a quick demonstration of the system."""
        print("\n🎯 Quick Demo")
        print("-" * 30)
        
        # Demo 1: Perform calculation
        print("1. Performing calculation...")
        self.bus.route_message(Message(
            sender=self.cli_agent_name,
            recipient="compute_agent",
            type=MessageType.REQUEST,
            task="calculate",
            payload={"operation": "add", "operands": [10, 20, 30]}
        ))
        
        # Demo 2: Compute statistics
        print("2. Computing statistics...")
        self.bus.route_message(Message(
            sender=self.cli_agent_name,
            recipient="compute_agent",
            type=MessageType.REQUEST,
            task="statistics",
            payload={"data": [1, 2, 3, 4, 5], "operations": ["mean", "median"]}
        ))
        
        # Demo 3: Get system status
        print("3. Getting system status...")
        self.bus.route_message(Message(
            sender=self.cli_agent_name,
            recipient="coordinator",
            type=MessageType.REQUEST,
            task="get_system_status",
            payload={}
        ))
        
        print("✅ Demo completed! Use 'history' to see the message exchanges.")
    
    def do_test_format(self, args):
        """Test the specific message format requested by user."""
        print("\n🧪 Testing specific message format...")
        
        # The exact format requested
        message_data = {
            "sender": "coordinator",
            "receiver": "compute_agent",
            "action": "statistics",
            "payload": {
                "data": [1, 2, 3, 4, 5],
                "operations": ["mean", "median"]
            },
            "timestamp": "2025-07-09T12:00:00Z"
        }
        
        print("📨 Original message format:")
        print(json.dumps(message_data, indent=2))
        
        # Convert to internal format and route
        internal_message = Message(
            sender=message_data["sender"],
            recipient=message_data["receiver"],
            type=MessageType.REQUEST,
            task=message_data["action"],
            payload=message_data["payload"]
        )
        
        print("\n📤 Converting to internal format and routing...")
        success = self.bus.route_message(internal_message)
        
        if success:
            print("✅ Message successfully processed!")
            print("Use 'history' to see the complete message exchange.")
        else:
            print("❌ Message routing failed")
    
    def do_quit(self, args):
        """Exit the CLI."""
        print("Shutting down multi-agent communication system...")
        self.bus.shutdown()
        print("👋 Goodbye!")
        return True
    
    def do_exit(self, args):
        """Exit the CLI."""
        return self.do_quit(args)
    
    def do_EOF(self, args):
        """Handle Ctrl+D."""
        print()
        return self.do_quit(args)
    
    def emptyline(self):
        """Don't repeat the last command on empty line."""
        pass
    
    def default(self, line):
        """Handle unknown commands."""
        print(f"❌ Unknown command: {line}")
        print("Type 'help' for available commands.")


def main():
    """Main function to start the CLI."""
    try:
        cli = AgentCLI()
        cli.cmdloop()
    except KeyboardInterrupt:
        print("\n\n👋 Goodbye!")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
