#!/usr/bin/env python3
"""
Installation script for API dependencies.
"""

import subprocess
import sys
import os

def install_dependencies():
    """Install required dependencies."""
    dependencies = [
        "fastapi",
        "uvicorn[standard]",
        "pytest",
        "httpx"  # For testing
    ]
    
    for dep in dependencies:
        print(f"Installing {dep}...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", dep])
            print(f"✅ {dep} installed successfully")
        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to install {dep}: {e}")

if __name__ == "__main__":
    install_dependencies()