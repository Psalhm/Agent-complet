"""
Demonstration script for the multi-agent communication system.
"""
import time
import logging
from datetime import datetime

from core.message_schema import Message, MessageType
from core.bus import MessageBus
from core.logger import MessageLogger
from agents.agent_compute import ComputeAgent
from agents.coordinator import CoordinatorAgent


def setup_logging():
    """Setup logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )


def demonstrate_basic_communication():
    """Demonstrate basic agent-to-agent communication."""
    print("\n" + "="*60)
    print("DEMO 1: Basic Agent Communication")
    print("="*60)
    
    # Initialize message bus and logger
    message_logger = MessageLogger()
    bus = MessageBus(message_logger)
    
    # Create agents
    compute_agent = ComputeAgent("compute_agent", bus)
    
    print(f"✓ Created agents: {bus.get_registered_agents()}")
    
    # Demo 1: Perform calculation
    print("\n1. Performing calculation...")
    compute_agent.send_message("compute_agent", MessageType.REQUEST, "calculate", {
        "operation": "add",
        "operands": [15, 25, 10]
    })
    
    time.sleep(0.1)
    
    # Demo 2: Compute statistics
    print("\n2. Computing statistics...")
    compute_agent.send_message("compute_agent", MessageType.REQUEST, "statistics", {
        "data": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "operations": ["mean", "median", "std", "min", "max"]
    })
    
    time.sleep(0.1)
    
    # Demo 3: Mathematical operations
    print("\n3. Mathematical operations...")
    compute_agent.send_message("compute_agent", MessageType.REQUEST, "mathematical_operations", {
        "operation": "factorial",
        "value": 5
    })
    
    time.sleep(0.1)
    
    print("\n✓ Basic communication demo completed")
    return bus, message_logger


def demonstrate_error_handling():
    """Demonstrate error handling and error messages."""
    print("\n" + "="*60)
    print("DEMO 2: Error Handling")
    print("="*60)
    
    # Use existing bus from previous demo
    message_logger = MessageLogger()
    bus = MessageBus(message_logger)
    
    # Create agents
    compute_agent = ComputeAgent("compute_agent", bus)
    
    # Demo 1: Invalid operation
    print("\n1. Testing invalid operation...")
    compute_agent.send_message("compute_agent", MessageType.REQUEST, "calculate", {
        "operation": "invalid_op",
        "operands": [1, 2, 3]
    })
    
    time.sleep(0.1)
    
    # Demo 2: Missing required fields
    print("\n2. Testing missing required fields...")
    compute_agent.send_message("compute_agent", MessageType.REQUEST, "calculate", {
        "operation": "add"
        # Missing "operands" field
    })
    
    time.sleep(0.1)
    
    # Demo 3: Division by zero
    print("\n3. Testing division by zero...")
    compute_agent.send_message("compute_agent", MessageType.REQUEST, "calculate", {
        "operation": "divide",
        "operands": [10, 0]
    })
    
    time.sleep(0.1)
    
    # Demo 4: Send message to non-existent agent
    print("\n4. Testing message to non-existent agent...")
    compute_agent.send_message("non_existent_agent", MessageType.REQUEST, "some_task", {})
    
    time.sleep(0.1)
    
    print("\n✓ Error handling demo completed")
    return bus, message_logger


def demonstrate_coordination():
    """Demonstrate coordination between multiple agents."""
    print("\n" + "="*60)
    print("DEMO 3: Agent Coordination")
    print("="*60)
    
    # Initialize system
    message_logger = MessageLogger()
    bus = MessageBus(message_logger)
    
    # Create agents
    compute_agent = ComputeAgent("compute_agent", bus)
    coordinator = CoordinatorAgent("coordinator", bus)
    
    print(f"✓ Created agents: {bus.get_registered_agents()}")
    
    # Demo 1: Analyze sales data
    print("\n1. Analyzing sales data...")
    
    # Analyze the data
    compute_agent.send_message("compute_agent", MessageType.REQUEST, "statistics", {
        "data": [100, 150, 200, 175, 225, 300, 250, 180, 190, 210],
        "operations": ["mean", "median", "std", "min", "max"]
    })
    
    time.sleep(0.1)
    
    # Demo 2: Use coordinator to delegate tasks
    print("\n2. Using coordinator to delegate tasks...")
    
    coordinator.send_message("coordinator", MessageType.REQUEST, "delegate_task", {
        "task_type": "calculate",
        "task_payload": {
            "operation": "multiply",
            "operands": [5, 10, 2]
        }
    })
    
    time.sleep(0.1)
    
    # Demo 3: Coordinate multiple agents
    print("\n3. Coordinating multiple agents...")
    
    coordinator.send_message("coordinator", MessageType.REQUEST, "coordinate_task", {
        "task_id": "multi_agent_task_001",
        "target_agents": ["compute_agent"],
        "task_type": "get_capabilities",
        "task_payload": {}
    })
    
    time.sleep(0.2)  # Allow more time for coordination
    
    print("\n✓ Coordination demo completed")
    return bus, message_logger


def demonstrate_broadcast():
    """Demonstrate broadcast messaging."""
    print("\n" + "="*60)
    print("DEMO 4: Broadcast Messaging")
    print("="*60)
    
    # Initialize system
    message_logger = MessageLogger()
    bus = MessageBus(message_logger)
    
    # Create agents
    compute_agent = ComputeAgent("compute_agent", bus)
    coordinator = CoordinatorAgent("coordinator", bus)
    
    print(f"✓ Created agents: {bus.get_registered_agents()}")
    
    # Demo 1: Broadcast system status request
    print("\n1. Broadcasting system status request...")
    
    coordinator.broadcast_message(MessageType.REQUEST, "get_capabilities", {
        "broadcast_id": "system_status_001",
        "requester": "coordinator"
    })
    
    time.sleep(0.2)
    
    # Demo 2: Broadcast coordination message
    print("\n2. Broadcasting coordination message...")
    
    coordinator.broadcast_message(MessageType.COORDINATION, "system_announcement", {
        "message": "System maintenance will begin in 10 minutes",
        "priority": "high",
        "timestamp": datetime.now().isoformat()
    })
    
    time.sleep(0.1)
    
    # Demo 3: Broadcast from compute agent
    print("\n3. Broadcasting computation result...")
    
    compute_agent.broadcast_message(MessageType.COORDINATION, "computation_complete", {
        "computation_id": "calc_001",
        "result": "All scheduled calculations completed successfully",
        "stats": {"total_computations": 5, "average_time": 0.05}
    })
    
    time.sleep(0.1)
    
    print("\n✓ Broadcast demo completed")
    return bus, message_logger


def demonstrate_complex_workflow():
    """Demonstrate a complex workflow between agents."""
    print("\n" + "="*60)
    print("DEMO 5: Complex Workflow")
    print("="*60)
    
    # Initialize system
    message_logger = MessageLogger()
    bus = MessageBus(message_logger)
    
    # Create agents
    compute_agent = ComputeAgent("compute_agent", bus)
    coordinator = CoordinatorAgent("coordinator", bus)
    
    print(f"✓ Created agents: {bus.get_registered_agents()}")
    
    # Complex workflow: Data analysis pipeline
    print("\n1. Starting data analysis pipeline...")
    
    # Step 1: Analyze temperature data
    print("   Step 1: Analyzing temperature data...")
    compute_agent.send_message("compute_agent", MessageType.REQUEST, "data_analysis", {
        "data": [22.5, 23.1, 22.8, 24.2, 25.0, 24.5, 23.9, 23.2, 22.7, 23.5],
        "analysis_type": "summary"
    })
    
    time.sleep(0.1)
    
    # Step 2: Compute statistics
    print("   Step 2: Computing statistics...")
    compute_agent.send_message("compute_agent", MessageType.REQUEST, "statistics", {
        "data": [22.5, 23.1, 22.8, 24.2, 25.0, 24.5, 23.9, 23.2, 22.7, 23.5],
        "operations": ["mean", "median", "std", "min", "max", "range"]
    })
    
    time.sleep(0.1)
    
    # Step 3: Mathematical operations
    print("   Step 3: Mathematical operations...")
    compute_agent.send_message("compute_agent", MessageType.REQUEST, "mathematical_operations", {
        "operation": "factorial",
        "value": 7
    })
    
    time.sleep(0.1)
    
    # Step 4: Complex calculations
    print("   Step 4: Complex calculations...")
    compute_agent.send_message("compute_agent", MessageType.REQUEST, "calculate", {
        "operation": "multiply",
        "operands": [23.44, 0.84]  # mean * std
    })
    
    time.sleep(0.1)
    
    # Step 5: Coordinator orchestrates final workflow
    print("   Step 5: Coordinator orchestrating final workflow...")
    coordinator.send_message("coordinator", MessageType.REQUEST, "orchestrate_workflow", {
        "workflow_id": "temperature_analysis_workflow",
        "steps": [
            {"agent": "compute_agent", "task": "get_capabilities", "params": {}},
            {"agent": "compute_agent", "task": "get_history", "params": {}}
        ]
    })
    
    time.sleep(0.2)
    
    print("\n✓ Complex workflow demo completed")
    return bus, message_logger


def show_system_stats(bus: MessageBus, message_logger: MessageLogger):
    """Display system statistics."""
    print("\n" + "="*60)
    print("SYSTEM STATISTICS")
    print("="*60)
    
    # Bus statistics
    bus_stats = bus.get_stats()
    print(f"Message Bus Statistics:")
    print(f"  - Messages routed: {bus_stats['messages_routed']}")
    print(f"  - Messages delivered: {bus_stats['messages_delivered']}")
    print(f"  - Messages failed: {bus_stats['messages_failed']}")
    print(f"  - Broadcasts sent: {bus_stats['broadcast_count']}")
    print(f"  - Registered agents: {bus_stats['registered_agents']}")
    print(f"  - Active agents: {', '.join(bus_stats['active_agents'])}")
    
    # Logger statistics
    logger_stats = message_logger.get_stats()
    print(f"\nMessage Logger Statistics:")
    print(f"  - Total messages logged: {logger_stats['total_messages']}")
    print(f"  - Messages by type: {logger_stats['messages_by_type']}")
    print(f"  - Messages by agent: {logger_stats['messages_by_agent']}")
    
    # File information
    log_files = logger_stats['log_files']
    print(f"\nLog Files:")
    print(f"  - JSON log: {log_files['json_log']} ({log_files['json_size']})")
    print(f"  - Human log: {log_files['human_log']} ({log_files['human_size']})")


def main():
    """Main demonstration function."""
    print("🚀 Multi-Agent Communication System Demo")
    print("This demo will showcase various features of the agent communication system.")
    print("Press Ctrl+C to exit at any time.")
    
    # Setup logging
    setup_logging()
    
    try:
        # Run demonstrations
        bus1, logger1 = demonstrate_basic_communication()
        bus2, logger2 = demonstrate_error_handling()
        bus3, logger3 = demonstrate_coordination()
        bus4, logger4 = demonstrate_broadcast()
        bus5, logger5 = demonstrate_complex_workflow()
        
        # Show final system statistics
        show_system_stats(bus5, logger5)
        
        print("\n" + "="*60)
        print("DEMO COMPLETED SUCCESSFULLY!")
        print("="*60)
        print("\nCheck the logs/ directory for detailed message logs:")
        print("  - logs/messages.json (JSON format)")
        print("  - logs/messages.log (Human-readable format)")
        print("\nYou can now run 'python main.py' for interactive mode.")
        
    except KeyboardInterrupt:
        print("\n\nDemo interrupted by user.")
    except Exception as e:
        print(f"\n\nDemo failed with error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
