#!/usr/bin/env python3
"""
Exemple simple pour montrer ce que fait le système multi-agents
"""

from core.bus import MessageBus
from core.logger import MessageLogger
from core.message_schema import Message, MessageType
from agents.agent_compute import ComputeAgent

def exemple_concret():
    """
    Exemple concret d'utilisation du système multi-agents
    """
    print("🚀 SYSTÈME MULTI-AGENTS - EXEMPLE CONCRET")
    print("=" * 50)
    
    # 1. Créer le système de communication
    logger = MessageLogger()
    bus = MessageBus(logger)
    
    # 2. Créer les agents spécialisés
    agent_calcul = ComputeAgent("calculateur", bus)
    
    print("✅ Système créé avec 1 agent :")
    print("   - Agent 'calculateur' : calculs et statistiques")
    
    print("\n📝 SCÉNARIO : Analyse des ventes d'un magasin")
    print("-" * 40)
    
    # 3. Calculer le chiffre d'affaires
    print("1. L'agent Calcul fait les totaux...")
    message = Message(
        sender="utilisateur",
        recipient="calculateur",
        type=MessageType.REQUEST,
        task="calculate",
        payload={
            "operation": "add",
            "operands": [50*1.2, 30*0.8, 20*4.5]  # pain + lait + fromage
        }
    )
    bus.route_message(message)
    
    # 4. Analyser les statistiques
    print("2. L'agent Calcul analyse les ventes...")
    message2 = Message(
        sender="utilisateur",
        recipient="calculateur",
        type=MessageType.REQUEST,
        task="statistics",
        payload={
            "data": [50, 30, 20],  # quantités vendues
            "operations": ["mean", "median", "std"]
        }
    )
    bus.route_message(message2)
    
    # 5. Opérations mathématiques avancées
    print("3. L'agent Calcul fait des opérations avancées...")
    message3 = Message(
        sender="utilisateur",
        recipient="calculateur",
        type=MessageType.REQUEST,
        task="mathematical_operations",
        payload={
            "operation": "factorial",
            "value": 5
        }
    )
    bus.route_message(message3)
    
    print("\n📊 RÉSULTATS :")
    stats = bus.get_stats()
    print(f"   - Messages échangés : {stats['messages_routed']}")
    print(f"   - Messages livrés : {stats['messages_delivered']}")
    print(f"   - Agents actifs : {len(stats['active_agents'])}")
    
    print("\n💡 QUE S'EST-IL PASSÉ ?")
    print("   1. Chaque agent a une spécialité")
    print("   2. Ils s'échangent des messages JSON")
    print("   3. Le bus route les messages au bon agent")
    print("   4. Tout est enregistré dans les logs")
    print("   5. Les agents peuvent travailler ensemble")
    
    print("\n🔍 APPLICATIONS PRATIQUES :")
    print("   - Système de e-commerce (produits, commandes, paiements)")
    print("   - Analyse de données (collecte, traitement, rapport)")
    print("   - IoT (capteurs, traitement, alertes)")
    print("   - Chatbots (compréhension, recherche, réponse)")
    
    return bus, logger

if __name__ == "__main__":
    exemple_concret()