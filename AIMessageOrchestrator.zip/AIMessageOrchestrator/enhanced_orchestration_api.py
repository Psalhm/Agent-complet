#!/usr/bin/env python3
"""
Version améliorée de l'API d'orchestration avec fonctionnalités de production.
"""

from fastapi import FastAPI, HTTPException, status, Depends, BackgroundTasks, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
import asyncio
import uuid
import time
from datetime import datetime, timedelta
import logging
import json

from core.message_schema import Message, MessageType
from core.logger import MessageLogger
from core.bus import MessageBus
from agents.agent_compute import ComputeAgent
from agents.coordinator import CoordinatorAgent
from schemas.protocols import *

# Configuration de logging avancée
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class EnhancedOrchestrationAPI:
    def __init__(self):
        self.app = FastAPI(
            title="Enhanced Multi-Agent Orchestration API",
            description="Production-ready API for inter-agent communication",
            version="2.0.0",
            docs_url="/docs",
            redoc_url="/redoc"
        )
        
        # Middleware de sécurité et performance
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],  # En production, spécifier les domaines
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        self.app.add_middleware(GZipMiddleware, minimum_size=1000)
        
        # Composants système
        self.message_logger = MessageLogger()
        self.message_bus = MessageBus(self.message_logger)
        self.compute_agent = ComputeAgent('compute_agent', self.message_bus)
        self.coordinator_agent = CoordinatorAgent('coordinator', self.message_bus)
        
        # Composants de sécurité et performance
        self.auth_manager = AuthManager()
        self.rate_limiter = RateLimiter()
        self.cache_manager = CacheManager()
        self.metrics_collector = MetricsCollector()
        
        # Enregistrement des routes
        self.setup_routes()
        self.setup_error_handlers()
        
    def setup_routes(self):
        """Configuration des routes API."""
        
        @self.app.middleware("http")
        async def add_process_time_header(request: Request, call_next):
            start_time = time.time()
            response = await call_next(request)
            process_time = time.time() - start_time
            response.headers["X-Process-Time"] = str(process_time)
            
            # Enregistrer les métriques
            self.metrics_collector.record_request(
                str(request.url.path), 
                process_time
            )
            
            return response
        
        @self.app.get("/health")
        async def health_check():
            """Health check pour monitoring."""
            return {
                "status": "healthy",
                "timestamp": datetime.now().isoformat(),
                "agents": len(self.message_bus.get_registered_agents()),
                "uptime": time.time()
            }
        
        @self.app.get("/metrics")
        async def get_metrics():
            """Métriques système pour monitoring."""
            return {
                "success": True,
                "data": self.metrics_collector.metrics,
                "timestamp": datetime.now().isoformat()
            }
        
        @self.app.post("/exchange/async")
        async def exchange_message_async(
            request: ExchangeRequest,
            background_tasks: BackgroundTasks,
            auth: HTTPAuthorizationCredentials = Depends(HTTPBearer())
        ):
            """Échange de messages asynchrone avec authentification."""
            
            # Vérifier l'authentification
            user_info = self.auth_manager.validate_api_key(auth.credentials)
            if not user_info:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid API key"
                )
            
            # Vérifier les permissions
            if "exchange" not in user_info["permissions"] and "*" not in user_info["permissions"]:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Insufficient permissions"
                )
            
            # Rate limiting
            await self.rate_limiter.check_rate_limit(auth.credentials)
            
            # Traitement asynchrone
            exchange_id = str(uuid.uuid4())
            background_tasks.add_task(
                self.process_exchange_async,
                exchange_id,
                request
            )
            
            return {
                "success": True,
                "exchange_id": exchange_id,
                "status": "processing",
                "message": "Exchange request queued for processing"
            }
        
        @self.app.get("/exchange/{exchange_id}/status")
        async def get_exchange_status(exchange_id: str):
            """Statut d'un échange asynchrone."""
            # Vérifier dans le cache
            status_info = self.cache_manager.get(f"exchange_status_{exchange_id}")
            
            if not status_info:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Exchange not found"
                )
            
            return status_info
        
        @self.app.post("/batch/exchange")
        async def batch_exchange(
            requests: List[ExchangeRequest],
            background_tasks: BackgroundTasks
        ):
            """Traitement par lots de messages."""
            
            if len(requests) > 100:  # Limite de sécurité
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Batch size too large (max 100)"
                )
            
            batch_id = str(uuid.uuid4())
            background_tasks.add_task(
                self.process_batch_async,
                batch_id,
                requests
            )
            
            return {
                "success": True,
                "batch_id": batch_id,
                "total_requests": len(requests),
                "status": "processing"
            }
        
        @self.app.get("/agents/{agent_id}/status")
        async def get_agent_detailed_status(agent_id: str):
            """Statut détaillé d'un agent."""
            
            if agent_id not in self.message_bus.get_registered_agents():
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Agent not found"
                )
            
            # Informations détaillées selon l'agent
            agent_info = {
                "agent_id": agent_id,
                "status": "active",
                "capabilities": self.message_bus.get_agent_capabilities(agent_id),
                "last_activity": datetime.now().isoformat()
            }
            
            # Ajouter des métriques spécifiques
            if agent_id == "compute_agent":
                agent_info["computation_count"] = len(self.compute_agent.computation_history)
                agent_info["last_computations"] = self.compute_agent.computation_history[-5:]
            
            return {
                "success": True,
                "data": agent_info,
                "timestamp": datetime.now().isoformat()
            }
    
    def setup_error_handlers(self):
        """Configuration des gestionnaires d'erreurs."""
        
        @self.app.exception_handler(HTTPException)
        async def http_exception_handler(request: Request, exc: HTTPException):
            self.metrics_collector.record_error()
            return JSONResponse(
                status_code=exc.status_code,
                content={
                    "success": False,
                    "error": {
                        "code": exc.status_code,
                        "message": exc.detail,
                        "timestamp": datetime.now().isoformat()
                    }
                }
            )
        
        @self.app.exception_handler(Exception)
        async def general_exception_handler(request: Request, exc: Exception):
            self.metrics_collector.record_error()
            logger.error(f"Unhandled exception: {str(exc)}")
            return JSONResponse(
                status_code=500,
                content={
                    "success": False,
                    "error": {
                        "code": 500,
                        "message": "Internal server error",
                        "timestamp": datetime.now().isoformat()
                    }
                }
            )
    
    async def process_exchange_async(self, exchange_id: str, request: ExchangeRequest):
        """Traitement asynchrone d'un échange."""
        try:
            # Mettre à jour le statut
            self.cache_manager.set(
                f"exchange_status_{exchange_id}",
                {"status": "processing", "timestamp": datetime.now().isoformat()}
            )
            
            # Simuler le traitement
            await asyncio.sleep(0.1)
            
            # Traitement réel
            internal_message = await self.convert_to_internal_message(request)
            success = self.message_bus.route_message(internal_message)
            
            # Mettre à jour le statut final
            final_status = {
                "status": "completed" if success else "failed",
                "timestamp": datetime.now().isoformat(),
                "result": "Message processed successfully" if success else "Processing failed"
            }
            
            self.cache_manager.set(f"exchange_status_{exchange_id}", final_status)
            
        except Exception as e:
            logger.error(f"Async processing failed: {str(e)}")
            self.cache_manager.set(
                f"exchange_status_{exchange_id}",
                {
                    "status": "failed",
                    "error": str(e),
                    "timestamp": datetime.now().isoformat()
                }
            )
    
    async def process_batch_async(self, batch_id: str, requests: List[ExchangeRequest]):
        """Traitement par lots asynchrone."""
        results = []
        
        for i, request in enumerate(requests):
            try:
                internal_message = await self.convert_to_internal_message(request)
                success = self.message_bus.route_message(internal_message)
                results.append({
                    "index": i,
                    "success": success,
                    "message": "Processed successfully" if success else "Processing failed"
                })
            except Exception as e:
                results.append({
                    "index": i,
                    "success": False,
                    "error": str(e)
                })
        
        # Sauvegarder les résultats
        self.cache_manager.set(
            f"batch_results_{batch_id}",
            {
                "batch_id": batch_id,
                "total": len(requests),
                "successful": sum(1 for r in results if r["success"]),
                "failed": sum(1 for r in results if not r["success"]),
                "results": results,
                "timestamp": datetime.now().isoformat()
            },
            ttl_seconds=3600  # 1 heure
        )
    
    async def convert_to_internal_message(self, request: ExchangeRequest) -> Message:
        """Convertir vers le format interne."""
        # Même logique que dans l'API originale
        sender = request.sender
        recipient = request.recipient
        
        if request.protocol == "prompt":
            prompt_data = PromptProtocol(**request.message)
            task = self.extract_task_from_prompt(prompt_data.content)
            payload = {
                "prompt": prompt_data.content,
                "role": prompt_data.role,
                "context": prompt_data.context
            }
        
        elif request.protocol == "json-rpc":
            rpc_data = JsonRpcProtocol(**request.message)
            task = rpc_data.method
            payload = rpc_data.params
        
        elif request.protocol == "tool":
            tool_data = ToolProtocol(**request.message)
            task = tool_data.tool_name
            payload = tool_data.parameters
            recipient = tool_data.agent_id
        
        return Message(
            sender=sender,
            recipient=recipient,
            type=MessageType.REQUEST,
            task=task,
            payload=payload
        )
    
    def extract_task_from_prompt(self, content: str) -> str:
        """Extraire la tâche du prompt."""
        content_lower = content.lower()
        
        if any(word in content_lower for word in ["calculate", "compute", "math", "sum", "add"]):
            return "calculate"
        elif any(word in content_lower for word in ["statistics", "stats", "mean", "average"]):
            return "statistics"
        elif any(word in content_lower for word in ["status", "health", "system"]):
            return "get_system_status"
        else:
            return "general_query"

# Classes auxiliaires
class AuthManager:
    def __init__(self):
        self.api_keys = {
            "admin_key_123": {"role": "admin", "permissions": ["*"]},
            "user_key_456": {"role": "user", "permissions": ["read", "exchange"]},
            "readonly_key_789": {"role": "readonly", "permissions": ["read"]}
        }
    
    def validate_api_key(self, api_key: str) -> Optional[Dict[str, Any]]:
        return self.api_keys.get(api_key)

class RateLimiter:
    def __init__(self):
        self.requests = {}
    
    async def check_rate_limit(self, client_id: str, limit: int = 100):
        now = datetime.now()
        if client_id not in self.requests:
            self.requests[client_id] = []
        
        self.requests[client_id] = [
            req_time for req_time in self.requests[client_id]
            if now - req_time < timedelta(minutes=1)
        ]
        
        if len(self.requests[client_id]) >= limit:
            raise HTTPException(
                status_code=429,
                detail="Rate limit exceeded"
            )
        
        self.requests[client_id].append(now)

class CacheManager:
    def __init__(self):
        self.cache = {}
        self.cache_ttl = {}
    
    def get(self, key: str) -> Optional[Any]:
        if key in self.cache:
            if datetime.now() < self.cache_ttl[key]:
                return self.cache[key]
            else:
                del self.cache[key]
                del self.cache_ttl[key]
        return None
    
    def set(self, key: str, value: Any, ttl_seconds: int = 300):
        self.cache[key] = value
        self.cache_ttl[key] = datetime.now() + timedelta(seconds=ttl_seconds)

class MetricsCollector:
    def __init__(self):
        self.metrics = {
            "requests_total": 0,
            "requests_by_endpoint": {},
            "response_times": [],
            "errors_total": 0,
            "start_time": datetime.now().isoformat()
        }
    
    def record_request(self, endpoint: str, response_time: float):
        self.metrics["requests_total"] += 1
        if endpoint not in self.metrics["requests_by_endpoint"]:
            self.metrics["requests_by_endpoint"][endpoint] = 0
        self.metrics["requests_by_endpoint"][endpoint] += 1
        self.metrics["response_times"].append(response_time)
        
        # Garder seulement les 1000 derniers temps de réponse
        if len(self.metrics["response_times"]) > 1000:
            self.metrics["response_times"] = self.metrics["response_times"][-1000:]
    
    def record_error(self):
        self.metrics["errors_total"] += 1

if __name__ == "__main__":
    import uvicorn
    
    api = EnhancedOrchestrationAPI()
    uvicorn.run(api.app, host="0.0.0.0", port=5001)