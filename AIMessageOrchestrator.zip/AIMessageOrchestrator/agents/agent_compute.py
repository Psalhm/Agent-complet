"""
Compute agent that handles computational tasks and calculations.
"""
from typing import Dict, Any, Optional, List
import math
import statistics
from datetime import datetime

from .base import BaseAgent
from core.message_schema import Message, MessageType


class ComputeAgent(BaseAgent):
    """
    Agent that handles computational tasks and mathematical operations.
    """
    
    def __init__(self, name: str, bus):
        super().__init__(name, bus)
        
        # Add capabilities this agent can handle
        self.add_capability("calculate")
        self.add_capability("statistics")
        self.add_capability("mathematical_operations")
        self.add_capability("data_analysis")
        
        # Track computation history
        self.computation_history: List[Dict[str, Any]] = []
        
        self.logger.info(f"ComputeAgent {self.name} ready with capabilities: {self.capabilities}")
    
    def handle_message(self, message: Message) -> Optional[Dict[str, Any]]:
        """
        Handle incoming messages for computational tasks.
        
        Args:
            message: Incoming message
            
        Returns:
            Response payload if applicable
        """
        try:
            task = message.task
            payload = message.payload
            
            self.logger.info(f"Handling task: {task} from {message.sender}")
            
            if task == "calculate":
                return self._calculate(payload, message.sender)
            elif task == "statistics":
                return self._compute_statistics(payload, message.sender)
            elif task == "mathematical_operations":
                return self._mathematical_operations(payload, message.sender)
            elif task == "data_analysis":
                return self._data_analysis(payload, message.sender)
            elif task == "get_capabilities":
                return self._get_capabilities(message.sender)
            elif task == "get_history":
                return self._get_computation_history(message.sender)
            else:
                self.send_error(message.sender, 
                              f"Unknown task: {task}", task)
                return None
                
        except Exception as e:
            self.logger.error(f"Error handling message: {e}")
            self.send_error(message.sender, str(e), message.task)
            return None
    
    def _calculate(self, payload: Dict[str, Any], sender: str) -> Dict[str, Any]:
        """
        Perform basic calculations.
        
        Args:
            payload: Calculation parameters
            sender: Agent requesting the operation
            
        Returns:
            Response with calculation result
        """
        operation = payload.get("operation")
        operands = payload.get("operands", [])
        
        if not operation:
            self.send_error(sender, "Missing required field: operation", "calculate")
            return {"success": False, "error": "Missing operation"}
        
        if not operands:
            self.send_error(sender, "Missing required field: operands", "calculate")
            return {"success": False, "error": "Missing operands"}
        
        try:
            result = None
            
            if operation == "add":
                result = sum(operands)
            elif operation == "subtract":
                result = operands[0] - sum(operands[1:])
            elif operation == "multiply":
                result = 1
                for num in operands:
                    result *= num
            elif operation == "divide":
                if len(operands) < 2:
                    raise ValueError("Division requires at least 2 operands")
                result = operands[0]
                for num in operands[1:]:
                    if num == 0:
                        raise ValueError("Division by zero")
                    result /= num
            elif operation == "power":
                if len(operands) != 2:
                    raise ValueError("Power operation requires exactly 2 operands")
                result = operands[0] ** operands[1]
            elif operation == "sqrt":
                if len(operands) != 1:
                    raise ValueError("Square root requires exactly 1 operand")
                if operands[0] < 0:
                    raise ValueError("Square root of negative number")
                result = math.sqrt(operands[0])
            else:
                raise ValueError(f"Unknown operation: {operation}")
            
            # Store in history
            computation = {
                "operation": operation,
                "operands": operands,
                "result": result,
                "timestamp": datetime.now().isoformat(),
                "requested_by": sender
            }
            self.computation_history.append(computation)
            
            response = {
                "success": True,
                "operation": operation,
                "operands": operands,
                "result": result,
                "timestamp": computation["timestamp"]
            }
            
        except Exception as e:
            response = {
                "success": False,
                "operation": operation,
                "operands": operands,
                "error": str(e)
            }
        
        # Send response back to sender if sender is a registered agent
        if sender in self.bus.get_registered_agents():
            self.send_message(sender, MessageType.RESPONSE, "calculate_response", response)
        else:
            # Just log the response for non-agent senders
            self.logger.info(f"Calculation result for {sender}: {response}")
        
        return response
    
    def _compute_statistics(self, payload: Dict[str, Any], sender: str) -> Dict[str, Any]:
        """
        Compute statistical measures for a dataset.
        
        Args:
            payload: Statistical computation parameters
            sender: Agent requesting the operation
            
        Returns:
            Response with statistical results
        """
        data = payload.get("data", [])
        operations = payload.get("operations", ["mean", "median", "mode", "std"])
        
        if not data:
            self.send_error(sender, "Missing required field: data", "statistics")
            return {"success": False, "error": "Missing data"}
        
        if not isinstance(data, list):
            self.send_error(sender, "Data must be a list", "statistics")
            return {"success": False, "error": "Data must be a list"}
        
        try:
            # Convert to numbers
            numeric_data = [float(x) for x in data]
            results = {}
            
            if "mean" in operations:
                results["mean"] = statistics.mean(numeric_data)
            
            if "median" in operations:
                results["median"] = statistics.median(numeric_data)
            
            if "mode" in operations:
                try:
                    results["mode"] = statistics.mode(numeric_data)
                except statistics.StatisticsError:
                    results["mode"] = "No unique mode"
            
            if "std" in operations:
                if len(numeric_data) > 1:
                    results["standard_deviation"] = statistics.stdev(numeric_data)
                else:
                    results["standard_deviation"] = 0
            
            if "variance" in operations:
                if len(numeric_data) > 1:
                    results["variance"] = statistics.variance(numeric_data)
                else:
                    results["variance"] = 0
            
            if "min" in operations:
                results["minimum"] = min(numeric_data)
            
            if "max" in operations:
                results["maximum"] = max(numeric_data)
            
            if "range" in operations:
                results["range"] = max(numeric_data) - min(numeric_data)
            
            # Store in history
            computation = {
                "operation": "statistics",
                "data_size": len(numeric_data),
                "operations": operations,
                "results": results,
                "timestamp": datetime.now().isoformat(),
                "requested_by": sender
            }
            self.computation_history.append(computation)
            
            response = {
                "success": True,
                "data_size": len(numeric_data),
                "operations": operations,
                "results": results,
                "timestamp": computation["timestamp"]
            }
            
        except Exception as e:
            response = {
                "success": False,
                "error": str(e)
            }
        
        # Send response back to sender if sender is a registered agent
        if sender in self.bus.get_registered_agents():
            self.send_message(sender, MessageType.RESPONSE, "statistics_response", response)
        else:
            # Just log the response for non-agent senders
            self.logger.info(f"Statistics result for {sender}: {response}")
        
        return response
    
    def _mathematical_operations(self, payload: Dict[str, Any], sender: str) -> Dict[str, Any]:
        """
        Perform advanced mathematical operations.
        
        Args:
            payload: Mathematical operation parameters
            sender: Agent requesting the operation
            
        Returns:
            Response with operation result
        """
        operation = payload.get("operation")
        value = payload.get("value")
        
        if not operation:
            self.send_error(sender, "Missing required field: operation", "mathematical_operations")
            return {"success": False, "error": "Missing operation"}
        
        try:
            result = None
            
            if operation == "factorial":
                if not isinstance(value, int) or value < 0:
                    raise ValueError("Factorial requires a non-negative integer")
                result = math.factorial(value)
            
            elif operation == "fibonacci":
                if not isinstance(value, int) or value < 0:
                    raise ValueError("Fibonacci requires a non-negative integer")
                result = self._fibonacci(value)
            
            elif operation == "prime_check":
                if not isinstance(value, int) or value < 2:
                    result = False
                else:
                    result = self._is_prime(value)
            
            elif operation == "log":
                base = payload.get("base", math.e)
                if value <= 0:
                    raise ValueError("Logarithm requires a positive number")
                result = math.log(value, base)
            
            elif operation == "sin":
                result = math.sin(value)
            
            elif operation == "cos":
                result = math.cos(value)
            
            elif operation == "tan":
                result = math.tan(value)
            
            else:
                raise ValueError(f"Unknown mathematical operation: {operation}")
            
            # Store in history
            computation = {
                "operation": f"math_{operation}",
                "value": value,
                "result": result,
                "timestamp": datetime.now().isoformat(),
                "requested_by": sender
            }
            self.computation_history.append(computation)
            
            response = {
                "success": True,
                "operation": operation,
                "value": value,
                "result": result,
                "timestamp": computation["timestamp"]
            }
            
        except Exception as e:
            response = {
                "success": False,
                "operation": operation,
                "value": value,
                "error": str(e)
            }
        
        # Send response back to sender if sender is a registered agent
        if sender in self.bus.get_registered_agents():
            self.send_message(sender, MessageType.RESPONSE, "mathematical_operations_response", response)
        else:
            # Just log the response for non-agent senders
            self.logger.info(f"Mathematical operations result for {sender}: {response}")
        
        return response
    
    def _data_analysis(self, payload: Dict[str, Any], sender: str) -> Dict[str, Any]:
        """
        Perform data analysis operations.
        
        Args:
            payload: Data analysis parameters
            sender: Agent requesting the operation
            
        Returns:
            Response with analysis results
        """
        data = payload.get("data", [])
        analysis_type = payload.get("analysis_type", "summary")
        
        if not data:
            self.send_error(sender, "Missing required field: data", "data_analysis")
            return {"success": False, "error": "Missing data"}
        
        try:
            results = {}
            
            if analysis_type == "summary":
                numeric_data = [float(x) for x in data if isinstance(x, (int, float))]
                if numeric_data:
                    results = {
                        "count": len(numeric_data),
                        "mean": statistics.mean(numeric_data),
                        "median": statistics.median(numeric_data),
                        "min": min(numeric_data),
                        "max": max(numeric_data),
                        "std": statistics.stdev(numeric_data) if len(numeric_data) > 1 else 0,
                        "range": max(numeric_data) - min(numeric_data)
                    }
                else:
                    results = {"error": "No numeric data found"}
            
            elif analysis_type == "frequency":
                frequency = {}
                for item in data:
                    frequency[str(item)] = frequency.get(str(item), 0) + 1
                results = {
                    "frequency_distribution": frequency,
                    "unique_values": len(frequency),
                    "total_items": len(data)
                }
            
            else:
                raise ValueError(f"Unknown analysis type: {analysis_type}")
            
            # Store in history
            computation = {
                "operation": "data_analysis",
                "analysis_type": analysis_type,
                "data_size": len(data),
                "results": results,
                "timestamp": datetime.now().isoformat(),
                "requested_by": sender
            }
            self.computation_history.append(computation)
            
            response = {
                "success": True,
                "analysis_type": analysis_type,
                "data_size": len(data),
                "results": results,
                "timestamp": computation["timestamp"]
            }
            
        except Exception as e:
            response = {
                "success": False,
                "error": str(e)
            }
        
        # Send response back to sender if sender is a registered agent
        if sender in self.bus.get_registered_agents():
            self.send_message(sender, MessageType.RESPONSE, "data_analysis_response", response)
        else:
            # Just log the response for non-agent senders
            self.logger.info(f"Data analysis result for {sender}: {response}")
        
        return response
    
    def _get_capabilities(self, sender: str) -> Dict[str, Any]:
        """
        Return agent capabilities.
        
        Args:
            sender: Agent requesting capabilities
            
        Returns:
            Response with capabilities
        """
        response = {
            "success": True,
            "capabilities": self.capabilities,
            "agent": self.name,
            "supported_operations": {
                "calculate": ["add", "subtract", "multiply", "divide", "power", "sqrt"],
                "statistics": ["mean", "median", "mode", "std", "variance", "min", "max", "range"],
                "mathematical_operations": ["factorial", "fibonacci", "prime_check", "log", "sin", "cos", "tan"],
                "data_analysis": ["summary", "frequency"]
            },
            "computation_count": len(self.computation_history)
        }
        
        # Send response back to sender if sender is a registered agent
        if sender in self.bus.get_registered_agents():
            self.send_message(sender, MessageType.RESPONSE, "capabilities_response", response)
        else:
            # Just log the response for non-agent senders
            self.logger.info(f"Capabilities result for {sender}: {response}")
        
        return response
    
    def _get_computation_history(self, sender: str) -> Dict[str, Any]:
        """
        Return computation history.
        
        Args:
            sender: Agent requesting history
            
        Returns:
            Response with computation history
        """
        response = {
            "success": True,
            "history": self.computation_history[-10:],  # Last 10 computations
            "total_computations": len(self.computation_history)
        }
        
        # Send response back to sender if sender is a registered agent
        if sender in self.bus.get_registered_agents():
            self.send_message(sender, MessageType.RESPONSE, "computation_history_response", response)
        else:
            # Just log the response for non-agent senders
            self.logger.info(f"Computation history result for {sender}: {response}")
        
        return response
    
    def _fibonacci(self, n: int) -> int:
        """
        Calculate the nth Fibonacci number.
        
        Args:
            n: Position in Fibonacci sequence
            
        Returns:
            Fibonacci number at position n
        """
        if n <= 1:
            return n
        
        a, b = 0, 1
        for _ in range(2, n + 1):
            a, b = b, a + b
        return b
    
    def _is_prime(self, n: int) -> bool:
        """
        Check if a number is prime.
        
        Args:
            n: Number to check
            
        Returns:
            True if number is prime
        """
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False
        
        for i in range(3, int(math.sqrt(n)) + 1, 2):
            if n % i == 0:
                return False
        return True
