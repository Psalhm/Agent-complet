"""
Coordinator agent that orchestrates tasks between multiple agents.
"""
from typing import Dict, Any, Optional, List
import asyncio
from datetime import datetime

from .base import BaseAgent
from core.message_schema import Message, MessageType


class CoordinatorAgent(BaseAgent):
    """
    Agent that coordinates tasks between multiple agents and manages workflows.
    """
    
    def __init__(self, name: str, bus):
        super().__init__(name, bus)
        
        # Add capabilities this agent can handle
        self.add_capability("coordinate_task")
        self.add_capability("get_system_status")
        self.add_capability("orchestrate_workflow")
        self.add_capability("delegate_task")
        
        # Track active tasks and agent statuses
        self.active_tasks: Dict[str, Dict[str, Any]] = {}
        self.agent_statuses: Dict[str, Dict[str, Any]] = {}
        self.workflow_history: List[Dict[str, Any]] = []
        
        self.logger.info(f"CoordinatorAgent {self.name} ready with capabilities: {self.capabilities}")
    
    def handle_message(self, message: Message) -> Optional[Dict[str, Any]]:
        """
        Handle incoming messages for coordination tasks.
        
        Args:
            message: Incoming message
            
        Returns:
            Response payload if applicable
        """
        try:
            task = message.task
            payload = message.payload
            
            self.logger.info(f"Handling task: {task} from {message.sender}")
            
            if task == "coordinate_task":
                return self._coordinate_task(payload, message.sender)
            elif task == "get_system_status":
                return self._get_system_status(payload, message.sender)
            elif task == "orchestrate_workflow":
                return self._orchestrate_workflow(payload, message.sender)
            elif task == "delegate_task":
                return self._delegate_task(payload, message.sender)
            elif task == "get_capabilities":
                return self._get_capabilities(message.sender)
            elif task.endswith("_response"):
                return self._handle_task_response(message)
            else:
                self.send_error(message.sender, 
                              f"Unknown task: {task}", task)
                return None
                
        except Exception as e:
            self.logger.error(f"Error handling message: {e}")
            self.send_error(message.sender, str(e), message.task)
            return None
    
    def _coordinate_task(self, payload: Dict[str, Any], sender: str) -> Dict[str, Any]:
        """
        Coordinate a task between multiple agents.
        
        Args:
            payload: Task coordination parameters
            sender: Agent requesting coordination
            
        Returns:
            Response with coordination result
        """
        task_id = payload.get("task_id", f"task_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        target_agents = payload.get("target_agents", [])
        task_type = payload.get("task_type")
        task_payload = payload.get("task_payload", {})
        
        if not target_agents:
            self.send_error(sender, "Missing required field: target_agents", "coordinate_task")
            return {"success": False, "error": "Missing target agents"}
        
        if not task_type:
            self.send_error(sender, "Missing required field: task_type", "coordinate_task")
            return {"success": False, "error": "Missing task type"}
        
        # Track this coordination task
        self.active_tasks[task_id] = {
            "requested_by": sender,
            "target_agents": target_agents,
            "task_type": task_type,
            "task_payload": task_payload,
            "status": "in_progress",
            "responses": {},
            "start_time": datetime.now().isoformat(),
            "completed_agents": []
        }
        
        # Send the task to all target agents
        for agent_name in target_agents:
            self.send_message(agent_name, MessageType.REQUEST, task_type, {
                **task_payload,
                "coordination_id": task_id,
                "coordinator": self.name
            })
        
        response = {
            "success": True,
            "task_id": task_id,
            "target_agents": target_agents,
            "task_type": task_type,
            "status": "coordination_started",
            "message": f"Task {task_id} sent to {len(target_agents)} agents"
        }
        
        # Send response back to sender if sender is a registered agent
        if sender in self.bus.get_registered_agents():
            self.send_message(sender, MessageType.RESPONSE, "coordinate_task_response", response)
        else:
            # Just log the response for non-agent senders
            self.logger.info(f"Coordinate task result for {sender}: {response}")
        
        return response
    
    def _get_system_status(self, payload: Dict[str, Any], sender: str) -> Dict[str, Any]:
        """
        Get the status of the entire system.
        
        Args:
            payload: Status request parameters
            sender: Agent requesting status
            
        Returns:
            Response with system status
        """
        # Get agent capabilities by broadcasting
        self.broadcast_message(MessageType.REQUEST, "get_capabilities", {
            "requested_by": self.name,
            "status_request_id": f"status_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        })
        
        # Prepare system status
        system_status = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "coordinator": self.name,
            "active_tasks": len(self.active_tasks),
            "completed_workflows": len(self.workflow_history),
            "known_agents": list(self.agent_statuses.keys()),
            "system_metrics": {
                "total_tasks_coordinated": len(self.workflow_history),
                "active_coordinations": len(self.active_tasks)
            }
        }
        
        # Send response back to sender if sender is a registered agent
        if sender in self.bus.get_registered_agents():
            self.send_message(sender, MessageType.RESPONSE, "system_status_response", system_status)
        else:
            # Just log the response for non-agent senders
            self.logger.info(f"System status result for {sender}: {system_status}")
        
        return system_status
    
    def _orchestrate_workflow(self, payload: Dict[str, Any], sender: str) -> Dict[str, Any]:
        """
        Orchestrate a complex workflow between multiple agents.
        
        Args:
            payload: Workflow orchestration parameters
            sender: Agent requesting orchestration
            
        Returns:
            Response with orchestration result
        """
        workflow_id = payload.get("workflow_id", f"workflow_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        workflow_steps = payload.get("steps", [])
        
        if not workflow_steps:
            self.send_error(sender, "Missing required field: steps", "orchestrate_workflow")
            return {"success": False, "error": "Missing workflow steps"}
        
        # Start workflow execution
        workflow = {
            "workflow_id": workflow_id,
            "requested_by": sender,
            "steps": workflow_steps,
            "current_step": 0,
            "status": "started",
            "start_time": datetime.now().isoformat(),
            "step_results": []
        }
        
        # Execute first step
        self._execute_workflow_step(workflow)
        
        # Add to workflow history
        self.workflow_history.append(workflow)
        
        response = {
            "success": True,
            "workflow_id": workflow_id,
            "total_steps": len(workflow_steps),
            "status": "workflow_started",
            "message": f"Workflow {workflow_id} started with {len(workflow_steps)} steps"
        }
        
        # Send response back to sender if sender is a registered agent
        if sender in self.bus.get_registered_agents():
            self.send_message(sender, MessageType.RESPONSE, "orchestrate_workflow_response", response)
        else:
            # Just log the response for non-agent senders
            self.logger.info(f"Orchestrate workflow result for {sender}: {response}")
        
        return response
    
    def _delegate_task(self, payload: Dict[str, Any], sender: str) -> Dict[str, Any]:
        """
        Delegate a task to the most appropriate agent.
        
        Args:
            payload: Task delegation parameters
            sender: Agent requesting delegation
            
        Returns:
            Response with delegation result
        """
        task_type = payload.get("task_type")
        task_payload = payload.get("task_payload", {})
        preferred_agent = payload.get("preferred_agent")
        
        if not task_type:
            self.send_error(sender, "Missing required field: task_type", "delegate_task")
            return {"success": False, "error": "Missing task type"}
        
        # Find the best agent for this task
        target_agent = self._find_best_agent_for_task(task_type, preferred_agent)
        
        if not target_agent:
            response = {
                "success": False,
                "error": f"No agent found capable of handling task: {task_type}"
            }
        else:
            # Delegate the task
            delegation_id = f"delegation_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            self.send_message(target_agent, MessageType.REQUEST, task_type, {
                **task_payload,
                "delegation_id": delegation_id,
                "delegated_by": self.name,
                "original_requester": sender
            })
            
            response = {
                "success": True,
                "delegation_id": delegation_id,
                "target_agent": target_agent,
                "task_type": task_type,
                "message": f"Task delegated to {target_agent}"
            }
        
        # Send response back to sender if sender is a registered agent
        if sender in self.bus.get_registered_agents():
            self.send_message(sender, MessageType.RESPONSE, "delegate_task_response", response)
        else:
            # Just log the response for non-agent senders
            self.logger.info(f"Delegate task result for {sender}: {response}")
        
        return response
    
    def _handle_task_response(self, message: Message) -> Optional[Dict[str, Any]]:
        """
        Handle responses from agents for coordinated tasks.
        
        Args:
            message: Response message from agent
            
        Returns:
            None (responses are handled internally)
        """
        payload = message.payload
        coordination_id = payload.get("coordination_id")
        
        if coordination_id and coordination_id in self.active_tasks:
            task = self.active_tasks[coordination_id]
            task["responses"][message.sender] = payload
            task["completed_agents"].append(message.sender)
            
            # Check if all agents have responded
            if len(task["completed_agents"]) == len(task["target_agents"]):
                task["status"] = "completed"
                task["end_time"] = datetime.now().isoformat()
                
                # Notify original requester
                self.send_message(task["requested_by"], MessageType.RESPONSE, 
                                "coordination_complete", {
                                    "task_id": coordination_id,
                                    "status": "completed",
                                    "responses": task["responses"],
                                    "duration": task["end_time"]
                                })
                
                # Move to history
                self.workflow_history.append(task)
                del self.active_tasks[coordination_id]
        
        # Update agent status
        self.agent_statuses[message.sender] = {
            "last_response": datetime.now().isoformat(),
            "status": "active"
        }
        
        return None
    
    def _execute_workflow_step(self, workflow: Dict[str, Any]) -> None:
        """
        Execute a single step in a workflow.
        
        Args:
            workflow: Workflow definition
        """
        if workflow["current_step"] >= len(workflow["steps"]):
            workflow["status"] = "completed"
            workflow["end_time"] = datetime.now().isoformat()
            
            # Notify original requester
            self.send_message(workflow["requested_by"], MessageType.RESPONSE,
                            "workflow_complete", {
                                "workflow_id": workflow["workflow_id"],
                                "status": "completed",
                                "results": workflow["step_results"]
                            })
            return
        
        step = workflow["steps"][workflow["current_step"]]
        agent = step.get("agent")
        task = step.get("task")
        params = step.get("params", {})
        
        if agent and task:
            # Add workflow context to params
            params["workflow_id"] = workflow["workflow_id"]
            params["step_number"] = workflow["current_step"]
            
            self.send_message(agent, MessageType.REQUEST, task, params)
    
    def _find_best_agent_for_task(self, task_type: str, preferred_agent: Optional[str] = None) -> Optional[str]:
        """
        Find the best agent to handle a specific task.
        
        Args:
            task_type: Type of task to handle
            preferred_agent: Preferred agent if specified
            
        Returns:
            Name of the best agent or None
        """
        if preferred_agent:
            return preferred_agent
        
        # Simple mapping for demonstration
        task_to_agent = {
            "calculate": "compute_agent",
            "statistics": "compute_agent",
            "mathematical_operations": "compute_agent",
            "data_analysis": "compute_agent"
        }
        
        return task_to_agent.get(task_type)
    
    def _get_capabilities(self, sender: str) -> Dict[str, Any]:
        """
        Return coordinator capabilities.
        
        Args:
            sender: Agent requesting capabilities
            
        Returns:
            Response with capabilities
        """
        response = {
            "success": True,
            "capabilities": self.capabilities,
            "agent": self.name,
            "coordination_features": {
                "task_coordination": "Route tasks to multiple agents",
                "workflow_orchestration": "Execute complex multi-step workflows",
                "task_delegation": "Find and delegate tasks to appropriate agents",
                "system_monitoring": "Monitor system status and agent health"
            },
            "active_tasks": len(self.active_tasks),
            "workflow_history": len(self.workflow_history)
        }
        
        # Send response back to sender if sender is a registered agent
        if sender in self.bus.get_registered_agents():
            self.send_message(sender, MessageType.RESPONSE, "capabilities_response", response)
        else:
            # Just log the response for non-agent senders
            self.logger.info(f"Capabilities result for {sender}: {response}")
        
        return response
