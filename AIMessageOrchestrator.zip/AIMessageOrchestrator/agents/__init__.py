"""
Agents package for the multi-agent communication system.
"""
from .base import BaseAgent
from .agent_compute import ComputeAgent
from .coordinator import CoordinatorAgent

__all__ = ['BaseAgent', 'ComputeAgent', 'CoordinatorAgent']
