"""
Base agent class that provides common functionality for all agents.
"""
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
from datetime import datetime
import logging

from core.message_schema import Message, MessageType
from core.bus import MessageBus


class BaseAgent(ABC):
    """
    Abstract base class for all agents in the system.
    Provides common functionality for message handling and communication.
    """
    
    def __init__(self, name: str, bus: MessageBus):
        """
        Initialize the base agent.
        
        Args:
            name: Unique identifier for this agent
            bus: Message bus instance for communication
        """
        self.name = name
        self.bus = bus
        self.logger = logging.getLogger(f"agent.{name}")
        
        # Store capabilities that this agent can handle
        self.capabilities: List[str] = []
        
        # Register this agent with the message bus
        self.bus.register_agent(self)
        
        self.logger.info(f"Agent {self.name} initialized")
    
    def send_message(self, recipient: str, message_type: MessageType, 
                    task: str, payload: Dict[str, Any]) -> None:
        """
        Send a message to another agent via the message bus.
        
        Args:
            recipient: Name of the recipient agent
            message_type: Type of message (request, response, error, coordination)
            task: Description of the task
            payload: Message data
        """
        message = Message(
            sender=self.name,
            recipient=recipient,
            type=message_type,
            task=task,
            payload=payload,
            timestamp=datetime.now()
        )
        
        self.bus.route_message(message)
        self.logger.debug(f"Sent message to {recipient}: {task}")
    
    def broadcast_message(self, message_type: MessageType, 
                         task: str, payload: Dict[str, Any]) -> None:
        """
        Broadcast a message to all registered agents.
        
        Args:
            message_type: Type of message
            task: Description of the task
            payload: Message data
        """
        message = Message(
            sender=self.name,
            recipient="*",  # Broadcast indicator
            type=message_type,
            task=task,
            payload=payload,
            timestamp=datetime.now()
        )
        
        self.bus.broadcast_message(message)
        self.logger.debug(f"Broadcasted message: {task}")
    
    def send_error(self, recipient: str, error_message: str, 
                  original_task: str = "") -> None:
        """
        Send an error message to another agent or logger.
        
        Args:
            recipient: Name of the recipient
            error_message: Error description
            original_task: Original task that caused the error
        """
        payload = {
            "error": error_message,
            "original_task": original_task,
            "agent": self.name
        }
        
        self.send_message(recipient, MessageType.ERROR, "error_report", payload)
    
    @abstractmethod
    def handle_message(self, message: Message) -> Optional[Dict[str, Any]]:
        """
        Handle incoming messages. Must be implemented by subclasses.
        
        Args:
            message: Incoming message to process
            
        Returns:
            Optional response payload
        """
        pass
    
    def get_capabilities(self) -> List[str]:
        """
        Get the list of capabilities this agent supports.
        
        Returns:
            List of capability strings
        """
        return self.capabilities.copy()
    
    def add_capability(self, capability: str) -> None:
        """
        Add a new capability to this agent.
        
        Args:
            capability: New capability to add
        """
        if capability not in self.capabilities:
            self.capabilities.append(capability)
            self.logger.info(f"Added capability: {capability}")
    
    def can_handle_task(self, task: str) -> bool:
        """
        Check if this agent can handle a specific task.
        
        Args:
            task: Task to check
            
        Returns:
            True if agent can handle the task
        """
        return task in self.capabilities
    
    def __str__(self) -> str:
        return f"Agent({self.name})"
    
    def __repr__(self) -> str:
        return f"Agent(name='{self.name}', capabilities={self.capabilities})"
