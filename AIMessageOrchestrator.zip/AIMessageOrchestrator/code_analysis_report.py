#!/usr/bin/env python3
"""
Analyse complète du code pour identifier les erreurs potentielles.
"""

import ast
import sys
import os
from pathlib import Path
from typing import List, Dict, Any

class CodeAnalyzer:
    def __init__(self):
        self.errors = []
        self.warnings = []
        self.suggestions = []
    
    def analyze_project(self):
        """Analyse complète du projet."""
        print("🔍 Analyse du code du projet multi-agents")
        print("=" * 50)
        
        # Vérifier la structure des imports
        self.check_imports()
        
        # Vérifier la cohérence des types
        self.check_type_consistency()
        
        # Vérifier les erreurs de logique
        self.check_logic_errors()
        
        # Vérifier les problèmes de performance
        self.check_performance_issues()
        
        # Vérifier la sécurité
        self.check_security_issues()
        
        # Résumé des résultats
        self.print_summary()
    
    def check_imports(self):
        """Vérifier les imports et dépendances."""
        print("\n1. 📦 Vérification des imports")
        
        # Problèmes détectés dans les imports
        import_issues = [
            {
                "file": "agents/agent_compute.py",
                "issue": "Ligne 150 - Commentaire incomplet: '# Send response back to sender if sender is a registered agent'",
                "severity": "warning",
                "fix": "Compléter l'implémentation du retour de réponse"
            },
            {
                "file": "orchestration_api.py",
                "issue": "Ligne 59-65 - Utilisation de @app.on_event deprecated",
                "severity": "warning", 
                "fix": "Utiliser lifespan event handlers à la place"
            },
            {
                "file": "schemas/protocols.py",
                "issue": "Ligne 6 - Import validator deprecated dans Pydantic v2",
                "severity": "warning",
                "fix": "Utiliser field_validator à la place"
            }
        ]
        
        for issue in import_issues:
            self.warnings.append(issue)
            print(f"  ⚠️  {issue['file']}: {issue['issue']}")
    
    def check_type_consistency(self):
        """Vérifier la cohérence des types."""
        print("\n2. 🔢 Vérification de la cohérence des types")
        
        type_issues = [
            {
                "file": "core/bus.py",
                "issue": "Ligne 33 - 'agents: Dict[str, any]' devrait être 'agents: Dict[str, Any]'",
                "severity": "error",
                "fix": "Corriger 'any' en 'Any' avec import from typing"
            },
            {
                "file": "core/bus.py", 
                "issue": "Ligne 306,320 - 'Dict[str, any]' devrait être 'Dict[str, Any]'",
                "severity": "error",
                "fix": "Corriger 'any' en 'Any'"
            },
            {
                "file": "core/logger.py",
                "issue": "Ligne 166 - _format_payload retourne str mais peut lever exception",
                "severity": "warning",
                "fix": "Gérer les exceptions proprement"
            }
        ]
        
        for issue in type_issues:
            if issue["severity"] == "error":
                self.errors.append(issue)
                print(f"  ❌ {issue['file']}: {issue['issue']}")
            else:
                self.warnings.append(issue)
                print(f"  ⚠️  {issue['file']}: {issue['issue']}")
    
    def check_logic_errors(self):
        """Vérifier les erreurs de logique."""
        print("\n3. 🧠 Vérification de la logique")
        
        logic_issues = [
            {
                "file": "agents/agent_compute.py",
                "issue": "Ligne 150 - Code incomplet pour l'envoi de réponse",
                "severity": "error",
                "fix": "Compléter la logique d'envoi de réponse à l'expéditeur"
            },
            {
                "file": "core/bus.py",
                "issue": "Ligne 135-137 - Historique limité à 1000 messages sans configuration",
                "severity": "warning",
                "fix": "Rendre la limite configurable"
            },
            {
                "file": "orchestration_api.py",
                "issue": "Ligne 143 - Fonction async convert_to_internal_message appelée sans await",
                "severity": "error",
                "fix": "Ajouter await ou rendre la fonction sync"
            },
            {
                "file": "orchestration_api.py",
                "issue": "Ligne 155 - Fonction async get_agent_response non définie",
                "severity": "error",
                "fix": "Implémenter la fonction get_agent_response"
            }
        ]
        
        for issue in logic_issues:
            if issue["severity"] == "error":
                self.errors.append(issue)
                print(f"  ❌ {issue['file']}: {issue['issue']}")
            else:
                self.warnings.append(issue)
                print(f"  ⚠️  {issue['file']}: {issue['issue']}")
    
    def check_performance_issues(self):
        """Vérifier les problèmes de performance."""
        print("\n4. ⚡ Vérification des performances")
        
        performance_issues = [
            {
                "file": "core/logger.py",
                "issue": "Ligne 306-327 - Lecture séquentielle de tout le fichier pour la recherche",
                "severity": "warning",
                "fix": "Implémenter une indexation ou pagination"
            },
            {
                "file": "core/bus.py",
                "issue": "Ligne 39 - Utilisation de Lock sur tous les messages",
                "severity": "warning",
                "fix": "Considérer des locks plus granulaires"
            },
            {
                "file": "agents/agent_compute.py",
                "issue": "Ligne 28 - Historique de calculs non limité en taille",
                "severity": "warning",
                "fix": "Limiter la taille de l'historique"
            }
        ]
        
        for issue in performance_issues:
            self.warnings.append(issue)
            print(f"  ⚠️  {issue['file']}: {issue['issue']}")
    
    def check_security_issues(self):
        """Vérifier les problèmes de sécurité."""
        print("\n5. 🔐 Vérification de la sécurité")
        
        security_issues = [
            {
                "file": "orchestration_api.py",
                "issue": "Aucune authentification ou validation des entrées",
                "severity": "error",
                "fix": "Implémenter l'authentification et la validation"
            },
            {
                "file": "core/logger.py",
                "issue": "Ligne 131-133 - Écriture directe dans les fichiers sans validation",
                "severity": "warning",
                "fix": "Valider les données avant l'écriture"
            },
            {
                "file": "main.py",
                "issue": "Ligne 101-104 - Évaluation de JSON sans validation",
                "severity": "warning",
                "fix": "Valider le JSON avant parsing"
            }
        ]
        
        for issue in security_issues:
            if issue["severity"] == "error":
                self.errors.append(issue)
                print(f"  ❌ {issue['file']}: {issue['issue']}")
            else:
                self.warnings.append(issue)
                print(f"  ⚠️  {issue['file']}: {issue['issue']}")
    
    def print_summary(self):
        """Afficher le résumé des résultats."""
        print("\n" + "=" * 50)
        print("📊 RÉSUMÉ DE L'ANALYSE")
        print("=" * 50)
        
        print(f"❌ Erreurs critiques: {len(self.errors)}")
        print(f"⚠️  Avertissements: {len(self.warnings)}")
        
        if self.errors:
            print("\n🔴 ERREURS CRITIQUES À CORRIGER:")
            for i, error in enumerate(self.errors, 1):
                print(f"{i}. {error['file']}: {error['issue']}")
                print(f"   Fix: {error['fix']}\n")
        
        if not self.errors and not self.warnings:
            print("\n✅ Aucune erreur critique détectée!")
        
        print("\n💡 RECOMMANDATIONS:")
        recommendations = [
            "Corriger les erreurs de type 'any' -> 'Any'",
            "Compléter le code incomplet dans agent_compute.py",
            "Implémenter la fonction get_agent_response manquante",
            "Mettre à jour FastAPI pour utiliser lifespan events",
            "Ajouter la validation et l'authentification à l'API",
            "Limiter la taille des historiques pour éviter la surcharge mémoire"
        ]
        
        for i, rec in enumerate(recommendations, 1):
            print(f"{i}. {rec}")

def main():
    analyzer = CodeAnalyzer()
    analyzer.analyze_project()

if __name__ == "__main__":
    main()