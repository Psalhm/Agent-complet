#!/usr/bin/env python3
"""
Test suite for the orchestration API.
Tests all endpoints and protocols with comprehensive coverage.
"""

import pytest
import json
from fastapi.testclient import TestClient
from orchestration_api import app
from schemas.protocols import ProtocolType, PROTOCOL_EXAMPLES

# Create test client
client = TestClient(app)

class TestOrchestrationAPI:
    """Test suite for orchestration API endpoints."""
    
    def test_root_endpoint(self):
        """Test root endpoint returns API information."""
        response = client.get("/")
        assert response.status_code == 200
        
        data = response.json()
        assert data["success"] is True
        assert "Multi-Agent Orchestration API" in data["message"]
        assert "registered_agents" in data["data"]
        assert "available_protocols" in data["data"]
    
    def test_get_protocols(self):
        """Test protocols endpoint returns available protocols."""
        response = client.get("/protocols")
        assert response.status_code == 200
        
        data = response.json()
        assert data["success"] is True
        assert "protocols" in data["data"]
        
        protocols = data["data"]["protocols"]
        assert "prompt" in protocols
        assert "json-rpc" in protocols
        assert "tool" in protocols
        
        # Check protocol structure
        for protocol_name, protocol_info in protocols.items():
            assert "description" in protocol_info
            assert "fields" in protocol_info
            assert "example" in protocol_info
    
    def test_get_agents(self):
        """Test agents endpoint returns registered agents."""
        response = client.get("/agents")
        assert response.status_code == 200
        
        data = response.json()
        assert data["success"] is True
        assert "agents" in data["data"]
        
        agents = data["data"]["agents"]
        assert "compute_agent" in agents
        assert "coordinator" in agents
        
        # Check agent structure
        for agent_name, agent_info in agents.items():
            assert "name" in agent_info
            assert "capabilities" in agent_info
            assert "status" in agent_info
    
    def test_get_stats(self):
        """Test stats endpoint returns system statistics."""
        response = client.get("/stats")
        assert response.status_code == 200
        
        data = response.json()
        assert data["success"] is True
        assert "bus_stats" in data["data"]
        assert "logger_stats" in data["data"]
        assert "system_health" in data["data"]
    
    def test_validate_prompt_protocol(self):
        """Test validation of prompt protocol messages."""
        # Valid prompt message
        valid_message = {
            "protocol": "prompt",
            "message": {
                "role": "user",
                "content": "Calculate the sum of 1, 2, 3",
                "context": {"agent": "compute_agent"}
            }
        }
        
        response = client.post("/validate-message", json=valid_message)
        assert response.status_code == 200
        
        data = response.json()
        assert data["success"] is True
        assert data["protocol"] == "prompt"
        assert len(data["errors"]) == 0
        
        # Invalid prompt message (missing role)
        invalid_message = {
            "protocol": "prompt",
            "message": {
                "content": "Calculate something"
            }
        }
        
        response = client.post("/validate-message", json=invalid_message)
        assert response.status_code == 200
        
        data = response.json()
        assert data["success"] is False
        assert len(data["errors"]) > 0
    
    def test_validate_jsonrpc_protocol(self):
        """Test validation of JSON-RPC protocol messages."""
        # Valid JSON-RPC message
        valid_message = {
            "protocol": "json-rpc",
            "message": {
                "jsonrpc": "2.0",
                "method": "calculate",
                "params": {"operation": "add", "operands": [1, 2, 3]},
                "id": "req_123"
            }
        }
        
        response = client.post("/validate-message", json=valid_message)
        assert response.status_code == 200
        
        data = response.json()
        assert data["success"] is True
        assert data["protocol"] == "json-rpc"
        
        # Invalid JSON-RPC message (wrong version)
        invalid_message = {
            "protocol": "json-rpc",
            "message": {
                "jsonrpc": "1.0",
                "method": "calculate",
                "id": "req_123"
            }
        }
        
        response = client.post("/validate-message", json=invalid_message)
        assert response.status_code == 200
        
        data = response.json()
        assert data["success"] is False
        assert len(data["errors"]) > 0
    
    def test_validate_tool_protocol(self):
        """Test validation of tool protocol messages."""
        # Valid tool message
        valid_message = {
            "protocol": "tool",
            "message": {
                "tool_name": "statistics",
                "parameters": {"data": [1, 2, 3, 4, 5]},
                "agent_id": "compute_agent"
            }
        }
        
        response = client.post("/validate-message", json=valid_message)
        assert response.status_code == 200
        
        data = response.json()
        assert data["success"] is True
        assert data["protocol"] == "tool"
        
        # Invalid tool message (missing agent_id)
        invalid_message = {
            "protocol": "tool",
            "message": {
                "tool_name": "statistics",
                "parameters": {"data": [1, 2, 3]}
            }
        }
        
        response = client.post("/validate-message", json=invalid_message)
        assert response.status_code == 200
        
        data = response.json()
        assert data["success"] is False
        assert len(data["errors"]) > 0
    
    def test_exchange_prompt_message(self):
        """Test message exchange with prompt protocol."""
        exchange_request = {
            "sender": "user",
            "recipient": "compute_agent",
            "protocol": "prompt",
            "message": {
                "role": "user",
                "content": "Calculate the sum of 1, 2, 3",
                "context": {"agent": "compute_agent"}
            }
        }
        
        response = client.post("/exchange", json=exchange_request)
        assert response.status_code == 200
        
        data = response.json()
        assert data["success"] is True
        assert data["protocol"] == "prompt"
        assert "exchange_id" in data
        assert "response_data" in data
    
    def test_exchange_jsonrpc_message(self):
        """Test message exchange with JSON-RPC protocol."""
        exchange_request = {
            "sender": "user",
            "recipient": "compute_agent",
            "protocol": "json-rpc",
            "message": {
                "jsonrpc": "2.0",
                "method": "calculate",
                "params": {"operation": "add", "operands": [1, 2, 3]},
                "id": "req_123"
            }
        }
        
        response = client.post("/exchange", json=exchange_request)
        assert response.status_code == 200
        
        data = response.json()
        assert data["success"] is True
        assert data["protocol"] == "json-rpc"
        assert "exchange_id" in data
    
    def test_exchange_tool_message(self):
        """Test message exchange with tool protocol."""
        exchange_request = {
            "sender": "user",
            "recipient": "compute_agent",
            "protocol": "tool",
            "message": {
                "tool_name": "statistics",
                "parameters": {"data": [1, 2, 3, 4, 5], "operations": ["mean"]},
                "agent_id": "compute_agent"
            }
        }
        
        response = client.post("/exchange", json=exchange_request)
        assert response.status_code == 200
        
        data = response.json()
        assert data["success"] is True
        assert data["protocol"] == "tool"
        assert "exchange_id" in data
    
    def test_exchange_invalid_protocol(self):
        """Test message exchange with invalid protocol."""
        exchange_request = {
            "sender": "user",
            "recipient": "compute_agent",
            "protocol": "invalid_protocol",
            "message": {"test": "data"}
        }
        
        response = client.post("/exchange", json=exchange_request)
        assert response.status_code == 422  # Validation error
    
    def test_exchange_invalid_recipient(self):
        """Test message exchange with invalid recipient."""
        exchange_request = {
            "sender": "user",
            "recipient": "nonexistent_agent",
            "protocol": "prompt",
            "message": {
                "role": "user",
                "content": "Test message"
            }
        }
        
        response = client.post("/exchange", json=exchange_request)
        # Should still succeed at API level but may fail at routing
        assert response.status_code in [200, 500]
    
    def test_validation_unknown_protocol(self):
        """Test validation with unknown protocol."""
        invalid_message = {
            "protocol": "unknown_protocol",
            "message": {"test": "data"}
        }
        
        response = client.post("/validate-message", json=invalid_message)
        assert response.status_code == 422  # Validation error
    
    def test_exchange_malformed_request(self):
        """Test exchange endpoint with malformed request."""
        malformed_request = {
            "sender": "user",
            # Missing required fields
        }
        
        response = client.post("/exchange", json=malformed_request)
        assert response.status_code == 422  # Validation error

class TestProtocolExamples:
    """Test protocol examples for documentation."""
    
    def test_all_protocol_examples_valid(self):
        """Test that all protocol examples are valid."""
        for protocol_name, example in PROTOCOL_EXAMPLES.items():
            validation_request = {
                "protocol": protocol_name,
                "message": example
            }
            
            response = client.post("/validate-message", json=validation_request)
            assert response.status_code == 200
            
            data = response.json()
            assert data["success"] is True, f"Protocol {protocol_name} example is invalid: {data.get('errors', [])}"

class TestIntegration:
    """Integration tests for complete workflows."""
    
    def test_complete_calculation_workflow(self):
        """Test complete calculation workflow through API."""
        # Step 1: Validate message
        validation_request = {
            "protocol": "json-rpc",
            "message": {
                "jsonrpc": "2.0",
                "method": "calculate",
                "params": {"operation": "add", "operands": [10, 20, 30]},
                "id": "calc_test"
            }
        }
        
        response = client.post("/validate-message", json=validation_request)
        assert response.status_code == 200
        assert response.json()["success"] is True
        
        # Step 2: Exchange message
        exchange_request = {
            "sender": "test_user",
            "recipient": "compute_agent",
            "protocol": "json-rpc",
            "message": validation_request["message"]
        }
        
        response = client.post("/exchange", json=exchange_request)
        assert response.status_code == 200
        assert response.json()["success"] is True
        
        # Step 3: Check system stats
        response = client.get("/stats")
        assert response.status_code == 200
        stats = response.json()["data"]
        assert stats["bus_stats"]["messages_routed"] > 0

if __name__ == "__main__":
    # Run tests with pytest
    pytest.main([__file__, "-v"])