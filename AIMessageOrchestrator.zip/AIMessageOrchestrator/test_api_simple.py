#!/usr/bin/env python3
"""
Simple test script for the orchestration API.
"""

import requests
import json
import time

def test_api():
    """Test the orchestration API endpoints."""
    base_url = "http://localhost:5000"
    
    print("🧪 Testing Orchestration API")
    print("=" * 40)
    
    # Test 1: Root endpoint
    print("1. Testing root endpoint...")
    response = requests.get(f"{base_url}/")
    print(f"Status: {response.status_code}")
    if response.status_code == 200:
        data = response.json()
        print(f"✅ API is running: {data['message']}")
        print(f"Registered agents: {data['data']['registered_agents']}")
    else:
        print("❌ Root endpoint failed")
    
    # Test 2: Protocols endpoint
    print("\n2. Testing protocols endpoint...")
    response = requests.get(f"{base_url}/protocols")
    if response.status_code == 200:
        data = response.json()
        print(f"✅ Available protocols: {list(data['data']['protocols'].keys())}")
    else:
        print("❌ Protocols endpoint failed")
    
    # Test 3: Agents endpoint
    print("\n3. Testing agents endpoint...")
    response = requests.get(f"{base_url}/agents")
    if response.status_code == 200:
        data = response.json()
        print(f"✅ Registered agents: {list(data['data']['agents'].keys())}")
    else:
        print("❌ Agents endpoint failed")
    
    # Test 4: Validation endpoint
    print("\n4. Testing validation endpoint...")
    validation_payload = {
        "protocol": "json-rpc",
        "message": {
            "jsonrpc": "2.0",
            "method": "calculate",
            "params": {"operation": "add", "operands": [1, 2, 3]},
            "id": "test_validation"
        }
    }
    
    response = requests.post(f"{base_url}/validate-message", json=validation_payload)
    if response.status_code == 200:
        data = response.json()
        print(f"✅ Validation result: {data['success']}")
    else:
        print("❌ Validation endpoint failed")
    
    # Test 5: Exchange endpoint
    print("\n5. Testing exchange endpoint...")
    exchange_payload = {
        "sender": "test_user",
        "recipient": "compute_agent",
        "protocol": "json-rpc",
        "message": {
            "jsonrpc": "2.0",
            "method": "calculate",
            "params": {"operation": "add", "operands": [10, 20, 30]},
            "id": "test_exchange"
        }
    }
    
    response = requests.post(f"{base_url}/exchange", json=exchange_payload)
    if response.status_code == 200:
        data = response.json()
        print(f"✅ Exchange result: {data['success']}")
        print(f"Exchange ID: {data['exchange_id']}")
        print(f"Response data: {data['response_data']}")
    else:
        print(f"❌ Exchange endpoint failed: {response.status_code}")
        print(f"Error: {response.text}")
    
    # Test 6: Stats endpoint
    print("\n6. Testing stats endpoint...")
    response = requests.get(f"{base_url}/stats")
    if response.status_code == 200:
        data = response.json()
        print(f"✅ System stats retrieved")
        print(f"Messages routed: {data['data']['bus_stats']['messages_routed']}")
    else:
        print("❌ Stats endpoint failed")
    
    print("\n🎉 API testing completed!")

if __name__ == "__main__":
    try:
        test_api()
    except requests.exceptions.ConnectionError:
        print("❌ Could not connect to API. Make sure the server is running on localhost:5000")
    except Exception as e:
        print(f"❌ Test failed: {e}")