#!/usr/bin/env python3
"""
FastAPI orchestration API for inter-agent communication management.
Provides standardized protocols for agent exchanges with validation.
"""

from fastapi import FastAPI, HTTPException, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ValidationError
from typing import Dict, List, Any, Optional, Union
from enum import Enum
import json
import logging
from datetime import datetime
import uuid

from core.message_schema import Message, MessageType
from core.logger import MessageLogger
from core.bus import MessageBus
from agents.agent_compute import ComputeAgent
from agents.coordinator import CoordinatorAgent
from schemas.protocols import (
    PromptProtocol, 
    JsonRpcProtocol, 
    ToolProtocol,
    ProtocolType,
    ExchangeRequest,
    ExchangeResponse,
    ValidationRequest,
    ValidationResponse
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Multi-Agent Orchestration API",
    description="API for managing inter-agent communication with standardized protocols",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Global system components
message_logger = MessageLogger()
message_bus = MessageBus(message_logger)
compute_agent = ComputeAgent('compute_agent', message_bus)
coordinator_agent = CoordinatorAgent('coordinator', message_bus)

class APIResponse(BaseModel):
    """Standard API response format."""
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None
    timestamp: str = datetime.now().isoformat()

@app.on_event("startup")
async def startup_event():
    """Initialize the system on startup."""
    logger.info("Starting Multi-Agent Orchestration API")
    logger.info(f"Registered agents: {message_bus.get_registered_agents()}")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown."""
    logger.info("Shutting down Multi-Agent Orchestration API")
    message_bus.shutdown()

@app.get("/", response_model=APIResponse)
async def root():
    """Root endpoint with API information."""
    return APIResponse(
        success=True,
        message="Multi-Agent Orchestration API is running",
        data={
            "version": "1.0.0",
            "registered_agents": message_bus.get_registered_agents(),
            "available_protocols": [protocol.value for protocol in ProtocolType],
            "endpoints": {
                "exchange": "POST /exchange - Send messages between agents",
                "validate": "POST /validate-message - Validate message format",
                "protocols": "GET /protocols - List available protocols",
                "agents": "GET /agents - List registered agents",
                "stats": "GET /stats - System statistics"
            }
        }
    )

@app.get("/protocols", response_model=APIResponse)
async def get_protocols():
    """Get list of available communication protocols."""
    protocols = {
        "prompt": {
            "description": "Natural language prompt-based communication",
            "fields": ["role", "content", "context"],
            "example": {
                "role": "user",
                "content": "Calculate the sum of 1, 2, 3",
                "context": {"agent": "compute_agent"}
            }
        },
        "json-rpc": {
            "description": "JSON-RPC 2.0 protocol for structured requests",
            "fields": ["jsonrpc", "method", "params", "id"],
            "example": {
                "jsonrpc": "2.0",
                "method": "calculate",
                "params": {"operation": "add", "operands": [1, 2, 3]},
                "id": "req_123"
            }
        },
        "tool": {
            "description": "Tool-based protocol for agent function calls",
            "fields": ["tool_name", "parameters", "agent_id"],
            "example": {
                "tool_name": "statistics",
                "parameters": {"data": [1, 2, 3, 4, 5], "operations": ["mean"]},
                "agent_id": "compute_agent"
            }
        }
    }
    
    return APIResponse(
        success=True,
        message="Available communication protocols",
        data={"protocols": protocols}
    )

@app.post("/exchange", response_model=ExchangeResponse)
async def exchange_message(request: ExchangeRequest):
    """Send a message between agents using specified protocol."""
    try:
        # Validate protocol
        if request.protocol not in [p.value for p in ProtocolType]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unsupported protocol: {request.protocol}"
            )
        
        # Convert protocol message to internal format
        internal_message = convert_to_internal_message(request)
        
        # Route message through the system
        success = message_bus.route_message(internal_message)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to route message through system"
            )
        
        # Get response from message history
        response_data = get_agent_response(internal_message)
        
        return ExchangeResponse(
            success=True,
            message="Message exchanged successfully",
            exchange_id=str(uuid.uuid4()),
            protocol=request.protocol,
            response_data=response_data,
            timestamp=datetime.now().isoformat()
        )
        
    except ValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Validation error: {str(e)}"
        )
    except Exception as e:
        logger.error(f"Exchange error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Internal server error: {str(e)}"
        )

@app.post("/validate-message", response_model=ValidationResponse)
async def validate_message(request: ValidationRequest):
    """Validate message format according to specified protocol."""
    try:
        validation_result = validate_protocol_message(request.protocol, request.message)
        
        return ValidationResponse(
            success=validation_result["valid"],
            message=validation_result["message"],
            protocol=request.protocol,
            errors=validation_result.get("errors", []),
            timestamp=datetime.now().isoformat()
        )
        
    except Exception as e:
        logger.error(f"Validation error: {str(e)}")
        return ValidationResponse(
            success=False,
            message=f"Validation failed: {str(e)}",
            protocol=request.protocol,
            errors=[str(e)],
            timestamp=datetime.now().isoformat()
        )

@app.get("/agents", response_model=APIResponse)
async def get_agents():
    """Get list of registered agents and their capabilities."""
    agents_info = {}
    
    for agent_name in message_bus.get_registered_agents():
        capabilities = message_bus.get_agent_capabilities(agent_name)
        agents_info[agent_name] = {
            "name": agent_name,
            "capabilities": capabilities or [],
            "status": "active"
        }
    
    return APIResponse(
        success=True,
        message="Registered agents information",
        data={"agents": agents_info}
    )

@app.get("/stats", response_model=APIResponse)
async def get_system_stats():
    """Get system statistics and performance metrics."""
    bus_stats = message_bus.get_stats()
    logger_stats = message_logger.get_stats()
    
    return APIResponse(
        success=True,
        message="System statistics",
        data={
            "bus_stats": bus_stats,
            "logger_stats": logger_stats,
            "system_health": {
                "registered_agents": len(message_bus.get_registered_agents()),
                "message_success_rate": (
                    bus_stats["messages_delivered"] / max(bus_stats["messages_routed"], 1)
                ) * 100
            }
        }
    )

def convert_to_internal_message(request: ExchangeRequest) -> Message:
    """Convert protocol-specific message to internal Message format."""
    sender = request.sender
    recipient = request.recipient
    
    if request.protocol == "prompt":
        # Parse prompt protocol
        prompt_data = PromptProtocol(**request.message)
        task = extract_task_from_prompt(prompt_data.content)
        payload = {
            "prompt": prompt_data.content,
            "role": prompt_data.role,
            "context": prompt_data.context
        }
    
    elif request.protocol == "json-rpc":
        # Parse JSON-RPC protocol
        rpc_data = JsonRpcProtocol(**request.message)
        task = rpc_data.method
        payload = rpc_data.params
    
    elif request.protocol == "tool":
        # Parse tool protocol
        tool_data = ToolProtocol(**request.message)
        task = tool_data.tool_name
        payload = tool_data.parameters
        recipient = tool_data.agent_id
    
    else:
        raise ValueError(f"Unsupported protocol: {request.protocol}")
    
    return Message(
        sender=sender,
        recipient=recipient,
        type=MessageType.REQUEST,
        task=task,
        payload=payload
    )

def validate_protocol_message(protocol: str, message: Dict[str, Any]) -> Dict[str, Any]:
    """Validate message according to protocol specification."""
    try:
        if protocol == "prompt":
            PromptProtocol(**message)
        elif protocol == "json-rpc":
            JsonRpcProtocol(**message)
        elif protocol == "tool":
            ToolProtocol(**message)
        else:
            return {
                "valid": False,
                "message": f"Unknown protocol: {protocol}",
                "errors": [f"Protocol '{protocol}' is not supported"]
            }
        
        return {
            "valid": True,
            "message": f"Message is valid for {protocol} protocol"
        }
    
    except Exception as e:
        return {
            "valid": False,
            "message": f"Validation failed: {str(e)}",
            "errors": [str(e)]
        }

def get_agent_response(message: Message) -> Dict[str, Any]:
    """Get response from agent after processing message."""
    try:
        # Wait a bit for the agent to process the message
        import time
        time.sleep(0.1)
        
        # Look for response in message history
        recent_messages = message_bus.get_message_history(limit=10)
        
        # Find response message with matching correlation_id
        for msg in reversed(recent_messages):
            if (msg.get("correlation_id") == message.message_id and 
                msg.get("type") == "response"):
                return msg.get("payload", {})
        
        # If no response found, return basic acknowledgment
        return {
            "status": "processed",
            "message": "Request processed successfully",
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        return {
            "status": "error",
            "message": f"Error getting response: {str(e)}",
            "timestamp": datetime.now().isoformat()
        }
        
    except ValidationError as e:
        return {
            "valid": False,
            "message": f"Validation failed for {protocol} protocol",
            "errors": [str(error) for error in e.errors()]
        }

async def get_agent_response(message: Message) -> Dict[str, Any]:
    """Get response from agent after processing message."""
    # Wait a moment for processing
    import asyncio
    await asyncio.sleep(0.1)
    
    # Get recent messages from history
    recent_messages = message_bus.get_message_history(limit=5)
    
    # Find response message
    for msg in reversed(recent_messages):
        if (msg.get("type") == "response" and 
            msg.get("sender") == message.recipient and
            msg.get("task", "").endswith("_response")):
            return msg.get("payload", {})
    
    return {"message": "Response pending or not found"}

def extract_task_from_prompt(content: str) -> str:
    """Extract task from natural language prompt."""
    # Simple keyword extraction - can be enhanced with NLP
    content_lower = content.lower()
    
    if any(word in content_lower for word in ["calculate", "compute", "math", "sum", "add"]):
        return "calculate"
    elif any(word in content_lower for word in ["statistics", "stats", "mean", "average"]):
        return "statistics"
    elif any(word in content_lower for word in ["status", "health", "system"]):
        return "get_system_status"
    else:
        return "general_query"

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)